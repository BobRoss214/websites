#!/usr/bin/env python3
"""Build the Question Terminal into ONE html file.

    python3 T/build.py                                  -> T/dist/index.html (everything)
    python3 T/build.py --out T/dist-q/index.html --only 20-question.js
                                                        -> only 00-core.js + 20-question.js + 99-boot.js (all css)
    python3 T/build.py --only "" --extra T/test/stub-layout.js --out T/dist-core/index.html
                                                        -> core + boot + a stub layout that is NOT in src
    python3 T/build.py --list                           -> show which files would be used (no output file)

Options
  --out PATH       output file (default: T/dist/index.html)
  --only a.js,b.js only these js files (00-core.js and 99-boot.js are always added). "" = just those two.
  --extra a.js,b   more js files (any path) appended after the src files, before 99-boot.js
  --extra-css x    more css files (any path) appended after the src css
  --no-css         leave out src/css (use with --extra-css)
  --src DIR        use another src folder (default: T/src) - for tests of this script
  --doctype        put "<!doctype html>" + charset + viewport lines in front (for opening dist by hand; the
                   Artifact publisher adds its own skeleton, so the normal build has none)
  --no-check       do not run "node --check" on each js file
  --list           print the plan and stop

Rules
  * shell.html holds the markers /*__CSS__*/ and /*__JS__*/ (exactly once each).
  * css files go in alphabetical order, js files too (so file names start with 2 digits).
  * every js file becomes its OWN <script> element (a crash in one file does not stop the files after it;
    top-level `const` is not shared between files - everything lives on window.QT).
  * a js file that contains "</script" (or "<!--" together with "<script") is refused; a css file with "</style" too.
Exit code: 0 ok, 2 refused (bad input), 3 js syntax error.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ALWAYS = ("00-core.js", "99-boot.js")
PRELUDE = '<!doctype html>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n'


def fail(msg, code=2):
    print("build.py: " + msg, file=sys.stderr)
    sys.exit(code)


def read(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        fail("cannot read %s: %s" % (path, e))
    except UnicodeDecodeError as e:
        fail("%s is not UTF-8: %s" % (path, e))


def listdir(folder, ext):
    if not os.path.isdir(folder):
        return []
    return sorted(n for n in os.listdir(folder) if n.endswith(ext) and not n.startswith("."))


def csv(value):
    return [p.strip() for p in (value or "").split(",") if p.strip()]


def main():
    ap = argparse.ArgumentParser(description="Build the Question Terminal into one html file.")
    ap.add_argument("--out", default=None)
    ap.add_argument("--only", default=None)
    ap.add_argument("--extra", default="")
    ap.add_argument("--extra-css", default="")
    ap.add_argument("--no-css", action="store_true")
    ap.add_argument("--src", default=None)
    ap.add_argument("--doctype", action="store_true")
    ap.add_argument("--no-check", action="store_true")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    src = os.path.abspath(a.src) if a.src else os.path.join(HERE, "src")
    out = os.path.abspath(a.out) if a.out else os.path.join(HERE, "dist", "index.html")
    jsdir, cssdir = os.path.join(src, "js"), os.path.join(src, "css")

    # --- which css files
    css = [] if a.no_css else [os.path.join(cssdir, n) for n in listdir(cssdir, ".css")]
    css += [os.path.abspath(p) for p in csv(a.extra_css)]

    # --- which js files
    all_js = listdir(jsdir, ".js")
    if a.only is None:
        names = all_js
    else:
        wanted = set(ALWAYS)
        for item in csv(a.only):
            item = os.path.basename(item)
            if not item.endswith(".js"):
                item += ".js"
            if item not in all_js:
                fail("--only: %s is not in %s (have: %s)" % (item, jsdir, ", ".join(all_js) or "nothing"))
            wanted.add(item)
        names = sorted(n for n in wanted if n in all_js)
        for need in ALWAYS:
            if need not in names:
                fail("%s is missing from %s" % (need, jsdir))
    js = [os.path.join(jsdir, n) for n in names]
    extra = [os.path.abspath(p) for p in csv(a.extra)]
    boot = os.path.join(jsdir, "99-boot.js")
    if boot in js and extra:   # extras go in front of the boot file
        js.remove(boot)
        js += extra + [boot]
    else:
        js += extra

    if a.list:
        print("shell:", os.path.join(src, "shell.html"))
        for p in css:
            print("css  ", p, os.path.getsize(p) if os.path.exists(p) else "MISSING")
        for p in js:
            print("js   ", p, os.path.getsize(p) if os.path.exists(p) else "MISSING")
        print("out  ", out)
        return

    shell = read(os.path.join(src, "shell.html"))
    for marker in ("/*__CSS__*/", "/*__JS__*/"):
        if shell.count(marker) != 1:
            fail("shell.html must contain %s exactly once (found %d)" % (marker, shell.count(marker)))

    # --- css
    css_parts, sizes = [], []
    for p in css:
        text = read(p)
        if re.search(r"</style", text, re.I):
            fail("%s contains '</style' - that would end the style block" % p)
        css_parts.append("/* ==== %s ==== */\n%s" % (os.path.basename(p), text.rstrip() + "\n"))
        sizes.append(("css", os.path.basename(p), len(text.encode("utf-8"))))

    # --- js
    js_parts = []
    for p in js:
        text = read(p)
        if re.search(r"</script", text, re.I):
            fail("%s contains '</script' - write it as '<\\/script' (inside a string) or split the text" % p)
        if "<!--" in text and re.search(r"<script", text, re.I):
            fail("%s contains '<!--' together with '<script' - the browser would misread the script block" % p)
        if not os.path.exists(p):
            fail("missing js file " + p)
        # the sourceURL line makes error messages in the browser say "qt-00-core.js:12" instead of "index.html:917"
        js_parts.append("/* ==== %s ==== */\n%s\n//# sourceURL=qt-%s\n" % (os.path.basename(p), text.rstrip(), os.path.basename(p)))
        sizes.append(("js", os.path.basename(p), len(text.encode("utf-8"))))

    if not a.no_check:
        node = shutil.which("node") or ("/opt/node22/bin/node" if os.path.exists("/opt/node22/bin/node") else None)
        if node:
            bad = False
            for p in js:
                r = subprocess.run([node, "--check", p], capture_output=True, text=True, timeout=60)
                if r.returncode != 0:
                    bad = True
                    print("build.py: syntax error in %s\n%s" % (p, r.stderr.strip()), file=sys.stderr)
            if bad:
                sys.exit(3)

    # fill both markers in ONE pass over shell.html, so text inside a css/js file can never be taken for a marker
    fills = {"/*__CSS__*/": "\n".join(css_parts), "/*__JS__*/": "\n</script>\n<script>\n".join(js_parts)}
    html = re.sub(r"/\*__(?:CSS|JS)__\*/", lambda m: fills[m.group(0)], shell)
    if a.doctype:
        html = PRELUDE + html

    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(html)
    os.replace(tmp, out)

    total = len(html.encode("utf-8"))
    for kind, name, n in sizes:
        print("  %-4s %-28s %8d bytes" % (kind, name, n))
    print("built %s  (%d css, %d js files, %d bytes = %.1f KB)" % (out, len(css), len(js), total, total / 1024.0))
    if total > 12 * 1024 * 1024:
        print("build.py: WARNING the page is bigger than 12 MB (the limit is 16 MB)", file=sys.stderr)


if __name__ == "__main__":
    main()
