/* 00-core.js  (owner: core)
 * The global namespace QT: events, the shared notebook (store + writes), page routing (in memory), a tiny DOM builder, text helpers.
 * Everything else in the page attaches to QT. See T/notes/core.md for the full list of what is here.
 */
(function () {
  'use strict';

  var QT = window.QT = window.QT || {};
  var COLLECTIONS = ['sections', 'questions', 'answers', 'status', 'ideas', 'ideaStatus', 'plans', 'planReplies', 'meta',
                     'workers', 'tasks', 'replies', 'taskAdds', 'taskEdits', 'asks'];   // the last six are for the Workers and Tasks parts (SPEC2.md)
  var READY_TIMEOUT_MS = 6000;
  var ID_RE = /^[a-z0-9][a-z0-9_-]*$/;   // starts with a letter or digit: '__proto__' and the like can never be an id
  var RESERVED_IDS = { constructor: 1, prototype: 1 };   // lowercase words that would shadow an object's own parts
  var BUILTIN_IDS = { look: 1, other: 1, later: 1, kathy: 1 };

  QT.version = '1';
  QT.collections = COLLECTIONS.slice();
  QT.offline = false;          // true when the shared notebook is not available (page still draws, nothing is saved)
  QT.offlineReason = null;
  QT.isReady = false;          // true as soon as QT.ready has resolved
  QT.dbErrors = {};            // collection -> last subscribe error (normally empty)
  QT.user = { isOwner: null, canEdit: null, canWrite: null };   // filled a moment after start; 'user' event fires when known
  QT.store = {};
  COLLECTIONS.forEach(function (c) { QT.store[c] = {}; });

  function noop() {}

  /* ------------------------------------------------------------------ small helpers */
  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }

  function deepEqual(a, b) {
    if (a === b) return true;
    if (typeof a !== typeof b || a === null || b === null || typeof a !== 'object') return false;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    if (Array.isArray(a)) {
      if (a.length !== b.length) return false;
      for (var i = 0; i < a.length; i++) if (!deepEqual(a[i], b[i])) return false;
      return true;
    }
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    for (var j = 0; j < ka.length; j++) {
      if (!Object.prototype.hasOwnProperty.call(b, ka[j]) || !deepEqual(a[ka[j]], b[ka[j]])) return false;
    }
    return true;
  }

  function jsonClone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }

  /** Merge like the notebook's update(): objects merge recursively, everything else (arrays too) replaces. */
  function mergeInto(base, patch) {
    var out = isObj(base) ? Object.assign({}, base) : {};
    Object.keys(patch).forEach(function (k) {
      out[k] = (isObj(patch[k]) && isObj(out[k])) ? mergeInto(out[k], patch[k]) : patch[k];
    });
    return out;
  }

  function nowIso() { return new Date().toISOString(); }
  QT.now = nowIso;
  QT.deepEqual = deepEqual;

  /** A new id: lowercase letters, digits, - and _ only.  QT.uid('idea') -> "idea-lk3j2h-x7q9ab" */
  QT.uid = function (prefix) {
    var p = String(prefix == null ? '' : prefix).toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^[-_]+|-+$/g, '');
    var rnd = '';
    try {
      var a = new Uint32Array(2);
      (window.crypto || window.msCrypto).getRandomValues(a);
      rnd = a[0].toString(36) + a[1].toString(36);
    } catch (e) { rnd = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2); }
    var id = Date.now().toString(36) + '-' + rnd.slice(0, 8);
    return p ? p + '-' + id : id;
  };

  /** QT.debounce(fn, 600) -> function; .cancel() forgets a waiting call, .flush() runs a waiting call now. */
  QT.debounce = function (fn, wait) {
    var t = null, last = null;
    var d = function () {
      last = { self: this, args: arguments };
      if (t) clearTimeout(t);
      t = setTimeout(function () { t = null; var l = last; last = null; if (l) fn.apply(l.self, l.args); }, wait == null ? 600 : wait);
    };
    d.cancel = function () { if (t) { clearTimeout(t); t = null; } last = null; };
    d.flush = function () { if (t) { clearTimeout(t); t = null; } var l = last; last = null; if (l) fn.apply(l.self, l.args); };
    return d;
  };

  /** localStorage that never throws.  QT.storage.get(key) -> string|null ; set(key, string) -> Boolean ; remove(key) ; getJSON / setJSON */
  QT.storage = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, String(v)); return true; } catch (e) { return false; } },
    remove: function (k) { try { window.localStorage.removeItem(k); } catch (e) { /* blocked */ } },
    getJSON: function (k, fallback) { try { var s = window.localStorage.getItem(k); return s == null ? fallback : JSON.parse(s); } catch (e) { return fallback; } },
    setJSON: function (k, v) { try { window.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  };

  /* ------------------------------------------------------------------ events */
  var handlers = {};
  var sticky = {};   // 'ready' and 'offline' are replayed to anyone who subscribes after they happened

  function callSafe(fn, data, evt) {
    try { fn(data, evt); } catch (e) { try { console.error('[QT] a "' + evt + '" listener failed:', e); } catch (e2) { /* no console */ } }
  }

  QT.on = function (evt, fn) {
    if (typeof fn !== 'function') return noop;
    (handlers[evt] = handlers[evt] || []).push(fn);
    if (sticky[evt]) {
      var s = sticky[evt];
      Promise.resolve().then(function () { if ((handlers[evt] || []).indexOf(fn) >= 0) callSafe(fn, s.data, evt); });
    }
    return function () { QT.off(evt, fn); };
  };
  QT.off = function (evt, fn) {
    if (!handlers[evt]) return;
    if (!fn) { handlers[evt] = []; return; }
    handlers[evt] = handlers[evt].filter(function (f) { return f !== fn; });
  };
  QT.once = function (evt, fn) {
    var off = QT.on(evt, function (d, e) { off(); fn(d, e); });
    return off;
  };
  QT.emit = function (evt, data) {
    var list = (handlers[evt] || []).slice();
    for (var i = 0; i < list.length; i++) callSafe(list[i], data, evt);
    return list.length;
  };
  QT.events = { on: QT.on, off: QT.off, once: QT.once, emit: QT.emit };

  /* ------------------------------------------------------------------ text helpers */
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function toMs(v) {
    if (v == null || v === '') return null;
    if (v instanceof Date) return isNaN(v.getTime()) ? null : v.getTime();
    if (typeof v === 'number') return isFinite(v) ? v : null;
    var t = Date.parse(v);
    return isNaN(t) ? null : t;
  }
  function dayStart(ms) { var d = new Date(ms); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); }
  function dayDiff(now, then) { return Math.round((dayStart(now) - dayStart(then)) / 86400000); }
  function clock(ms) {
    var d = new Date(ms), h = d.getHours(), m = d.getMinutes();
    return (h % 12 === 0 ? 12 : h % 12) + ':' + (m < 10 ? '0' : '') + m + ' ' + (h < 12 ? 'AM' : 'PM');
  }
  function shortDate(ms, nowMs) {
    var d = new Date(ms);
    return MONTHS[d.getMonth()] + ' ' + d.getDate() + (d.getFullYear() !== new Date(nowMs).getFullYear() ? ', ' + d.getFullYear() : '');
  }
  function pluralWord(w) {
    if (/[^aeiou]y$/i.test(w)) return w.slice(0, -1) + 'ies';
    if (/(s|x|z|ch|sh)$/i.test(w)) return w + 'es';
    return w + 's';
  }

  QT.fmt = {
    /** "just now" | "5 min ago" | "3 hours ago" | "yesterday" | "4 days ago" | "Oct 3".  '' when the date is missing or wrong. */
    ago: function (iso, nowArg) {
      var t = toMs(iso);
      if (t == null) return '';
      var now = nowArg == null ? Date.now() : toMs(nowArg);
      var s = Math.round((now - t) / 1000);
      if (s < 45) return 'just now';
      var m = Math.max(1, Math.floor(s / 60));
      if (m < 60) return m + ' min ago';
      var h = Math.floor(s / 3600), dd = dayDiff(now, t);
      if (h < 12 || (h < 24 && dd === 0)) return h + (h === 1 ? ' hour ago' : ' hours ago');
      if (dd <= 1) return 'yesterday';
      if (dd < 7) return dd + ' days ago';
      return shortDate(t, now);
    },
    /** "3:42 PM" today, "yesterday, 3:42 PM", "Oct 3, 3:42 PM" (adds the year when it is another year). '' when missing. */
    time: function (iso, nowArg) {
      var t = toMs(iso);
      if (t == null) return '';
      var now = nowArg == null ? Date.now() : toMs(nowArg), dd = dayDiff(now, t);
      if (dd === 0) return clock(t);
      if (dd === 1) return 'yesterday, ' + clock(t);
      return shortDate(t, now) + ', ' + clock(t);
    },
    /** "Oct 3" (or "Oct 3, 2025" in another year) */
    date: function (iso, nowArg) {
      var t = toMs(iso);
      return t == null ? '' : shortDate(t, nowArg == null ? Date.now() : toMs(nowArg));
    },
    /** WITH the number: plural(1,'question') -> "1 question", plural(3,'question') -> "3 questions", plural(2,'story','stories') */
    plural: function (n, word, pluralForm) {
      n = Number(n) || 0;
      return n + ' ' + (n === 1 ? word : (pluralForm || pluralWord(String(word))));
    },
    /** WITHOUT the number: noun(3,'question') -> "questions" */
    noun: function (n, word, pluralForm) {
      return Number(n) === 1 ? word : (pluralForm || pluralWord(String(word)));
    },
    /** Plain one-line text: control characters (bell, escape, NUL...) and lone halves of an emoji are dropped, white space is collapsed.
     *  (The comment service refuses control characters, and a lone half of an emoji is not valid text.) */
    clean: function (text) {
      var s = String(text == null ? '' : text), out = '', gap = false;
      for (var i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i), ch = s.charAt(i);
        if (c >= 0xd800 && c <= 0xdbff) {
          var d = s.charCodeAt(i + 1);
          if (d >= 0xdc00 && d <= 0xdfff) { out += (gap && out ? ' ' : '') + ch + s.charAt(i + 1); gap = false; i++; }
          continue;   // a lone first half: dropped
        }
        if (c >= 0xdc00 && c <= 0xdfff) continue;   // a lone second half: dropped
        if (c <= 0x20 || (c >= 0x7f && c <= 0xa0) || c === 0x2028 || c === 0x2029) { gap = true; continue; }
        out += (gap && out ? ' ' : '') + ch; gap = false;
      }
      return out;
    },
    /** Shorten long text to at most max characters ("..." at the end). Never cuts an emoji in half; uses QT.fmt.clean first. */
    clip: function (text, max, wholeWords) {
      var s = QT.fmt.clean(text);
      max = max || 60;
      var cp = Array.from(s);
      if (cp.length <= max) return s;
      var cut = cp.slice(0, Math.max(1, max - 1)).join(''), sp = cut.lastIndexOf(' ');
      if (wholeWords ? sp > 0 : sp > max * 0.6) cut = cut.slice(0, sp);   // wholeWords: always cut between words when there is a space to cut at
      return cut.replace(/[\s.,;:!?-]+$/, '') + '\u2026';
    }
  };

  /* ------------------------------------------------------------------ DOM builder */
  var SVG_NS = 'http://www.w3.org/2000/svg';
  var SVG_TAGS = { svg: 'svg', g: 'g', path: 'path', circle: 'circle', rect: 'rect', line: 'line', polyline: 'polyline', polygon: 'polygon', ellipse: 'ellipse', defs: 'defs', use: 'use', text: 'text', tspan: 'tspan', lineargradient: 'linearGradient', radialgradient: 'radialGradient', stop: 'stop', clippath: 'clipPath', mask: 'mask' };
  var URL_ATTRS = { href: 1, src: 1, action: 1, formaction: 1, poster: 1, 'xlink:href': 1, background: 1, cite: 1, data: 1 };
  var PROP_BOOL = { hidden: 1, disabled: 1, checked: 1, selected: 1, readonly: 1, required: 1, multiple: 1, open: 1, autofocus: 1, controls: 1, loop: 1, muted: 1 };
  var NAME_FIX = { classname: 'class', htmlfor: 'for' };

  /** The address as a browser reads it: tabs and line breaks anywhere are ignored, spaces and control characters around it are trimmed.
   *  Returns null when something odd is left inside (a space, a control character, a zero-width character): such an address is not accepted. */
  function urlText(v) {
    var s = String(v), out = '';
    for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); if (c !== 9 && c !== 10 && c !== 13) out += s.charAt(i); }
    var a = 0, b = out.length;
    while (a < b && out.charCodeAt(a) <= 0x20) a++;
    while (b > a && out.charCodeAt(b - 1) <= 0x20) b--;
    out = out.slice(a, b);
    for (var k = 0; k < out.length; k++) {
      var d = out.charCodeAt(k);
      if (d <= 0x20 || (d >= 0x7f && d <= 0x9f) || (d >= 0x200b && d <= 0x200f) || d === 0x2028 || d === 0x2029 || d === 0xfeff) return null;
    }
    return out;
  }

  /** true when a link / picture address is safe to put in the page: http(s), mailto, tel, blob, a plain picture data: address, or a relative address */
  function safeUrl(v) {
    var s = urlText(v);
    if (s === null) return false;
    if (/^https:\/\/[a-z0-9]/i.test(s)) return true;                                   // a web address that stays private on the way (https only)
    if (/^data:image\/(png|jpe?g|gif|webp|avif)[;,]/i.test(s)) return true;           // a small picture inside the page (no svg, no html)
    if (/^\/_blob\/[0-9a-f]{32}(?:[.\/?#]\S*)?$/i.test(s)) return true;                // a picture the farm uploaded to this page
    if (/^#\S*$/.test(s)) return true;                                                  // a place on this page
    return false;                                                                        // everything else: http, mailto, tel, blob, //host, relative paths, javascript, data:text...
  }
  QT.safeUrl = safeUrl;

  function appendKid(parent, kid) {
    if (kid == null || kid === false || kid === true) return;
    if (Array.isArray(kid)) { for (var i = 0; i < kid.length; i++) appendKid(parent, kid[i]); return; }
    if (typeof Node !== 'undefined' && kid instanceof Node) { parent.appendChild(kid); return; }
    parent.appendChild(document.createTextNode(String(kid)));
  }

  function applyAttrs(el, attrs) {
    var later = [];
    Object.keys(attrs).forEach(function (key) {
      var v = attrs[key];
      if (v == null) { if (key === 'value') later.push([key, '']); return; }
      var wordy = /^(aria-|data-)/i.test(key);   // aria-pressed:false must stay "false"
      if (v === false && !wordy) { if (key === 'value') later.push([key, '']); return; }
      if (wordy && typeof v !== 'object') { el.setAttribute(key, String(v)); return; }
      if (key === 'on') {
        Object.keys(v).forEach(function (evt) {
          var h = v[evt];
          if (Array.isArray(h)) { if (typeof h[0] === 'function') el.addEventListener(evt, h[0], h[1]); }
          else if (typeof h === 'function') el.addEventListener(evt, h);
        });
        return;
      }
      if (key === 'text') { el.textContent = String(v); return; }
      if ((key === 'class' || key === 'className') && Array.isArray(v)) { el.setAttribute('class', v.filter(Boolean).join(' ')); return; }
      if (key === 'html' || key === 'innerHTML' || key === 'outerHTML' || key === 'srcdoc' || key === 'srcset') return;   // never from data
      if (key === 'style') {
        if (typeof v === 'string') el.setAttribute('style', v);
        else if (isObj(v)) Object.keys(v).forEach(function (p) { if (p.indexOf('--') === 0 || p.indexOf('-') > 0) el.style.setProperty(p, String(v[p])); else el.style[p] = v[p]; });
        return;
      }
      if (key === 'dataset' && isObj(v)) { Object.keys(v).forEach(function (p) { if (v[p] != null) el.dataset[p] = String(v[p]); }); return; }
      if (key === 'value' || key === 'selected') { later.push([key, v]); return; }   // after the children exist (needed for <select>)
      var name = NAME_FIX[key.toLowerCase()] || key;
      if (/^on/i.test(name)) { try { console.warn('[QT.el] ignored attribute', name); } catch (e) { /* no console */ } return; }
      if (URL_ATTRS[name.toLowerCase()] && !safeUrl(v)) { try { console.warn('[QT.el] dropped an unsafe address in', name); } catch (e) { /* no console */ } return; }
      if (PROP_BOOL[name.toLowerCase()]) {
        var low = name.toLowerCase();
        if (el.namespaceURI === SVG_NS) { if (v) el.setAttribute(low, ''); } else el[low === 'readonly' ? 'readOnly' : low] = !!v;
        return;
      }
      el.setAttribute(name, v === true ? '' : String(v));
    });
    if (attrs.target === '_blank' && !attrs.rel && el.setAttribute) el.setAttribute('rel', 'noopener noreferrer');
    later.forEach(function (p) {
      if (p[0] === 'value') el.value = String(p[1]);
      else el.selected = !!p[1];
    });
  }

  /** QT.el('div', {class:'card', on:{click:fn}, 'aria-label':'x'}, 'text', childEl, [more]) -> Element. Text is always text, never HTML. */
  QT.el = function (tag, attrs) {
    var t = String(tag || 'div');
    var low = t.toLowerCase();
    if (low === 'script') throw new Error('QT.el: script elements are not allowed');
    var el = SVG_TAGS[low] ? document.createElementNS(SVG_NS, SVG_TAGS[low]) : document.createElement(t);
    var start = 1;
    if (isObj(attrs) && !(typeof Node !== 'undefined' && attrs instanceof Node)) { start = 2; }
    for (var i = start; i < arguments.length; i++) appendKid(el, arguments[i]);
    if (start === 2) applyAttrs(el, attrs);
    return el;
  };
  /** Remove everything inside an element. */
  QT.clear = function (el) { while (el && el.firstChild) el.removeChild(el.firstChild); return el; };

  /* ------------------------------------------------------------------ routing (in memory; last view remembered in localStorage) */
  var VIEWS = ['home', 'section', 'question', 'done', 'newsection', 'workers', 'tasks'];   // workers / tasks take {focus: id}
  var ROUTE_KEY = 'qt.route';
  var route = { view: 'home', params: {} };
  var history = [];

  function cleanParams(p) {
    var out = {};
    if (isObj(p)) Object.keys(p).forEach(function (k) {
      var v = p[k];
      if ((k === 'id' || k === 'focus') && v !== '' && v != null && !validId(v)) return;   // an id that is not a plain id is dropped
      if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') out[k] = v;
    });
    return out;
  }
  function validRoute(view, params) {
    if (VIEWS.indexOf(view) < 0) return false;
    if ((view === 'section' || view === 'question') && !validId(params.id)) return false;
    return true;
  }
  function sameRoute(a, b) { return a.view === b.view && deepEqual(a.params, b.params); }
  function copyRoute(r) { return { view: r.view, params: Object.assign({}, r.params) }; }
  function saveRoute() {
    if (route.view === 'newsection') return;   // a half-finished form is not worth coming back to
    QT.storage.setJSON(ROUTE_KEY, { view: route.view, params: route.params });
  }
  (function restore() {
    var o = QT.storage.getJSON(ROUTE_KEY, null);
    if (isObj(o)) {
      var params = cleanParams(o.params);
      if (o.view !== 'newsection' && validRoute(o.view, params)) route = { view: o.view, params: params };
    }
  })();

  QT.route = {
    views: VIEWS.slice(),
    current: function () { return copyRoute(route); },
    go: function (view, params) {
      var next = { view: VIEWS.indexOf(view) >= 0 ? view : 'home', params: cleanParams(params) };
      if (!validRoute(next.view, next.params)) next = { view: 'home', params: {} };
      if (!sameRoute(route, next)) { history.push(route); if (history.length > 50) history.shift(); }
      route = next;
      saveRoute();
      QT.emit('route', copyRoute(route));
      return copyRoute(route);
    },
    back: function () {
      route = history.pop() || { view: 'home', params: {} };
      saveRoute();
      QT.emit('route', copyRoute(route));
      return copyRoute(route);
    },
    canGoBack: function () { return history.length > 0; }
  };

  /** After the first load: a remembered section / question that no longer exists sends her home instead of to an empty page. */
  function validateRoute() {
    if (QT.offline) return;
    var s = QT.store;
    // only judge a place when its collection has really been delivered (after a time-out the data may simply be late)
    if (route.view === 'section' && firstSeen.sections && !s.sections[route.params.id]) route = { view: 'home', params: {} };
    else if (route.view === 'question' && firstSeen.questions && !s.questions[route.params.id]) route = { view: 'home', params: {} };
    else if (route.view === 'workers' && route.params.focus && firstSeen.workers && !s.workers[route.params.focus]) route = { view: 'workers', params: {} };
    else if (route.view === 'tasks' && route.params.focus && firstSeen.tasks && firstSeen.taskAdds && !s.tasks[route.params.focus] && !s.taskAdds[route.params.focus]) route = { view: 'tasks', params: {} };
  }

  /* ------------------------------------------------------------------ the shared notebook: reading */
  var firstSeen = {};     // collection -> true after its first DEFINITIVE snapshot (or its error). A snapshot marked fromCache is only the first pages, not the whole.
  var raw = {};           // collection -> id -> the object the notebook delivered (to see what really changed)
  var DB = null;
  var dbKnown = false;
  var dbWaiters = [];
  var readyDone = false;
  var readyResolve;
  var unsubs = [];

  QT.ready = new Promise(function (r) { readyResolve = r; });

  function finishReady(why) {
    if (readyDone) return;
    readyDone = true;
    QT.isReady = true;
    QT.readyReason = why;
    validateRoute();
    sticky.ready = { data: { reason: why } };
    readyResolve();
    QT.emit('ready', { reason: why });
  }
  function checkReady() {
    for (var i = 0; i < COLLECTIONS.length; i++) if (!firstSeen[COLLECTIONS[i]]) return;
    finishReady('all');
  }
  function goOffline(reason) {
    if (reason === 'errors') DB = null;   // every listener is dead: later writes say "offline" instead of failing one by one
    if (!QT.offline) {
      QT.offline = true;
      QT.offlineReason = reason;
      sticky.offline = { data: { reason: reason } };
      QT.emit('offline', { reason: reason });
    }
    finishReady('offline');
  }
  var startedAt = Date.now();
  function dbIs(db) {
    DB = db || null;
    dbKnown = true;
    // the host answered late (after the 6 s mark): give the collections a few seconds to arrive, then open with what there is
    if (db && !readyDone && Date.now() - startedAt >= READY_TIMEOUT_MS) setTimeout(function () { finishReady('timeout'); }, 4000);
    var w = dbWaiters; dbWaiters = [];
    w.forEach(function (f) { f(DB); });
  }
  function whenDb() {
    if (dbKnown) return Promise.resolve(DB);
    return new Promise(function (r) { dbWaiters.push(r); });
  }

  var skippedWarned = {};
  QT.skippedIds = {};   // collection -> up to 20 document ids that were not accepted (normally empty)
  function noteSkipped(name, id) {
    var list = QT.skippedIds[name] = QT.skippedIds[name] || [];
    var shown = String(id).slice(0, 60);
    if (list.length < 20 && list.indexOf(shown) < 0) list.push(shown);
    var key = name + '/' + shown;
    if (!skippedWarned[key]) { skippedWarned[key] = 1; try { console.warn('[QT] a document with an odd id was left out: ' + key); } catch (e) { /* no console */ } }
  }
  /** Like jsonClone, but a "__proto__" key anywhere is dropped (it could change what a copy inherits). */
  function safeClone(v) { return JSON.parse(JSON.stringify(v), function (k, x) { return k === '__proto__' ? undefined : x; }); }

  function deliver(name, snap) {
    var docs = (snap && snap.docs) || [];
    var target = QT.store[name];
    var prevRaw = raw[name] || {};
    var nextRaw = {};
    var changed = [];
    for (var i = 0; i < docs.length; i++) {
      var d = docs[i];
      if (!d || d.exists === false) continue;
      var data = typeof d.data === 'function' ? d.data() : d.data;
      if (!isObj(data)) continue;
      var id = d.id;
      if (!validId(id)) { noteSkipped(name, id); continue; }   // a document id that is not plain letters / digits / - / _ is never put into the store
      nextRaw[id] = data;
      var before = prevRaw[id];
      if (before === data) continue;
      if (before !== undefined && deepEqual(before, data)) { nextRaw[id] = before; continue; }
      var copy = safeClone(data);   // a plain copy the page may sort or change freely (the notebook's own objects are frozen); a "__proto__" key is dropped
      if (copy.id == null) copy.id = id;
      var ver = d.version != null ? d.version : (d.metadata && d.metadata.version != null ? d.metadata.version : null);
      if (ver != null) copy._version = ver;
      target[id] = copy;
      changed.push(id);
    }
    Object.keys(prevRaw).forEach(function (id) {
      if (!Object.prototype.hasOwnProperty.call(nextRaw, id)) { delete target[id]; changed.push(id); }
    });
    raw[name] = nextRaw;
    delete QT.dbErrors[name];   // it works now (a replacement listener got through)
    var initial = !firstSeen[name];   // everything up to the first complete snapshot counts as "the first load" (no chimes, no NEW badges for it)
    if (!(snap && snap.metadata && snap.metadata.fromCache === true)) firstSeen[name] = true;
    if (initial || changed.length) QT.emit('store', { collection: name, ids: changed, initial: initial });
    if (firstSeen[name]) checkReady();
  }

  var resubscribes = {};
  function subscribe(db, name) {
    try {
      var un = db.collection(name).onSnapshot(function (snap) {
        try { deliver(name, snap); } catch (e) { try { console.error('[QT] could not read ' + name + ':', e); } catch (e2) { /* no console */ } }
      }, function (err) { subscribeFailed(db, name, err); });
      if (typeof un === 'function') unsubs.push(un);
    } catch (e) { subscribeFailed(db, name, e); }
  }
  function subscribeFailed(db, name, err) {
    QT.dbErrors[name] = err || { code: 'unknown' };
    var code = err && err.code;
    var again = (code === 'unavailable' || !code) && (resubscribes[name] || 0) < 3;   // a dead listener can only be replaced by a new one
    if (again) {
      resubscribes[name] = (resubscribes[name] || 0) + 1;
      setTimeout(function () { subscribe(db, name); }, 2000 * resubscribes[name] * resubscribes[name]);
    }
    var initial = !firstSeen[name];
    firstSeen[name] = true;
    QT.emit('dberror', { collection: name, error: err });
    if (initial) QT.emit('store', { collection: name, ids: [], initial: true, error: true });
    if (COLLECTIONS.every(function (c) { return QT.dbErrors[c]; }) && !again) goOffline('errors');
    checkReady();
  }

  function loadUser(claude) {
    try {
      Promise.resolve(claude.use('user')).then(function (u) {
        if (!u) return;
        return Promise.all([
          Promise.resolve(u.isOwner && u.isOwner()).catch(function () { return null; }),
          Promise.resolve(u.canEdit && u.canEdit()).catch(function () { return null; }),
          Promise.resolve(u.can && u.can('data.write')).catch(function () { return null; })
        ]).then(function (r) {
          QT.user = { isOwner: r[0], canEdit: r[1], canWrite: r[2] };
          QT.emit('user', QT.user);
        });
      }).catch(noop);
    } catch (e) { /* no user capability */ }
  }

  function start() {
    // After 6 s the page opens with what it has. But when the host has not even answered "is there a notebook?", an empty home would be a lie
    // ("nothing here yet"): wait for the answer (the viewer gives one after about 10 s), and after 15 s call it "not connected".
    setTimeout(function () { if (dbKnown) finishReady('timeout'); }, READY_TIMEOUT_MS);
    setTimeout(function () { if (!dbKnown) { dbIs(null); goOffline('no-answer'); } }, 15000);
    var claude = window.claude;
    if (!claude || typeof claude.use !== 'function') { dbIs(null); goOffline('no-claude'); return; }
    var p;
    try { p = Promise.resolve(claude.use('db')); } catch (e) { p = Promise.resolve(null); }
    p.then(function (db) { return db; }, function () { return null; }).then(function (db) {
      dbIs(db);
      if (!db) { goOffline('no-db'); return; }
      COLLECTIONS.forEach(function (name) { subscribe(db, name); });
      loadUser(claude);
    });
  }
  /** "Try again" for an offline page: asks the host for the notebook once more (instead of reloading the whole page, which the viewer's frame may not allow).
   *  Resolves {ok:true} (QT.offline is false again, 'online' is emitted and every collection arrives as a new first load) or {ok:false, reason}. */
  var retrying = null;
  QT.retry = function () {
    if (!QT.offline) return Promise.resolve({ ok: true, already: true });
    if (retrying) return retrying;
    var claude = window.claude;
    if (!claude || typeof claude.use !== 'function') return Promise.resolve({ ok: false, reason: 'no-claude' });
    retrying = new Promise(function (resolve) {
      var p;
      try { p = Promise.resolve(claude.use('db')); } catch (e) { p = Promise.resolve(null); }
      var timer = setTimeout(function () { resolve(null); }, 12000);
      p.then(function (db) { clearTimeout(timer); resolve(db); }, function () { clearTimeout(timer); resolve(null); });
    }).then(function (db) {
      retrying = null;
      if (!db) return { ok: false, reason: 'no-db' };
      DB = db; dbKnown = true;
      QT.offline = false; QT.offlineReason = null; delete sticky.offline;
      QT.dbErrors = {}; firstSeen = {}; raw = {}; resubscribes = {};
      COLLECTIONS.forEach(function (c) { Object.keys(QT.store[c]).forEach(function (id) { delete QT.store[c][id]; }); });
      COLLECTIONS.forEach(function (name) { subscribe(db, name); });
      loadUser(claude);
      QT.emit('online', {});
      return { ok: true };
    });
    return retrying;
  };
  QT.unsubscribeAll = function () { unsubs.splice(0).forEach(function (u) { try { u(); } catch (e) { /* gone */ } }); };

  /* ------------------------------------------------------------------ the shared notebook: writing */
  var queues = {};        // path -> promise at the end of that document's line
  var pendingCount = 0;

  function makeError(code, message) { var e = new Error(message || code); e.code = code; return e; }
  function normError(e) {
    if (e instanceof Error) { if (!e.code) e.code = 'unknown'; return e; }
    var x = new Error((e && e.message) || 'The notebook did not accept this.');
    x.code = (e && e.code) || 'unknown';
    return x;
  }
  var HARD = { invalid_argument: 1, quota_exceeded: 1, revoked: 1, not_granted: 1, capability_disabled: 1, capability_removed: 1, transform_error: 1, offline: 1 };
  function transient(e) { return !HARD[e.code]; }
  function pause(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function attempt(path, fn, n) {
    return whenDb().then(function (db) {
      if (!db) throw makeError('offline', 'The notebook is not available.');
      return fn(db.doc(path));
    }).catch(function (e) {
      e = normError(e);
      if (n === 0 && transient(e)) return pause(300 + Math.random() * 500).then(function () { return attempt(path, fn, 1); });
      throw e;
    });
  }

  var SKIPPED = {};   // what a job returns when there was nothing to write

  /** One write at a time per document; one retry after a short pause; failures emit "writeerror" and reject.
   *  fn(ref) does the notebook call (or returns SKIPPED); after() runs when it worked, BEFORE the next write of that document starts. */
  function runWrite(path, op, fn, after) {
    pendingCount++;
    var line = queues[path] || Promise.resolve();
    var p = line.then(function () { return attempt(path, fn, 0); }).then(function (res) {
      if (res === SKIPPED) return undefined;
      if (after) { try { after(res); } catch (e) { try { console.error('[QT] after-write step failed:', e); } catch (e2) { /* no console */ } } }
      return res;
    });
    var tail = p.then(noop, noop);
    queues[path] = tail;
    tail.then(function () { if (queues[path] === tail) delete queues[path]; });
    var out = p.then(function (v) { pendingCount--; return v; }, function (e) {
      pendingCount--;
      QT.emit('writeerror', { path: path, op: op, error: e });
      throw e;
    });
    out.catch(noop);   // a caller that does not look at the result does not cause an "unhandled" error
    return out;
  }

  /** Strip things the notebook should not hold: undefined, functions, keys that start with "_" ; must be a plain object under 250 KB. */
  function clean(obj) {
    var o = jsonClone(isObj(obj) ? obj : {});
    Object.keys(o).forEach(function (k) { if (k.charAt(0) === '_') delete o[k]; });
    return o;
  }
  function invalid(path, message) {
    var e = makeError('invalid_argument', message);
    QT.emit('writeerror', { path: path, op: 'check', error: e });
    var p = Promise.reject(e);
    p.catch(noop);
    return p;
  }
  function validId(id) { return typeof id === 'string' && id.length > 0 && id.length <= 120 && ID_RE.test(id) && RESERVED_IDS[id] !== 1; }

  /** Look at what the notebook holds now (the object from the last snapshot). */
  function rawOf(coll, id) { return (raw[coll] || {})[id]; }
  function storeWithout(coll, id) {
    var cur = QT.store[coll][id];
    if (!cur) return cur;
    var c = Object.assign({}, cur); delete c._version; return c;
  }

  /** After a write succeeded: if no snapshot has shown it yet, put it in the store ourselves so "await write(); read store" always works. */
  function applyLocal(coll, id, op, data, rawBefore) {
    if (rawOf(coll, id) !== rawBefore) return;   // a snapshot arrived in the meantime: it is newer or the same
    var target = QT.store[coll], next;
    if (op === 'delete') {
      if (!(id in target)) return;
      delete target[id];
      if (raw[coll]) delete raw[coll][id];
    } else {
      var base = target[id] ? storeWithout(coll, id) : {};
      next = op === 'update' ? mergeInto(base, data) : Object.assign({}, data);
      if (next.id == null) next.id = id;
      if (deepEqual(base, next)) return;
      target[id] = next;
      (raw[coll] = raw[coll] || {})[id] = Object.assign({}, next);
    }
    QT.emit('store', { collection: coll, ids: [id], initial: false, local: true });
  }

  /** Core of every page write. op: 'set' | 'update' | 'delete'. A write that would change nothing is skipped (looked at when its turn comes,
   *  so "A, then B, then A again" in quick succession really ends on A). */
  function write(coll, id, op, data, opts) {
    var path = coll + '/' + id;
    opts = opts || {};
    if (!validId(id)) return invalid(path, 'Bad id "' + id + '" (use lowercase letters, digits, - and _).');
    var body = op === 'delete' ? null : clean(data);
    if (body && JSON.stringify(body).length > 250000) return invalid(path, 'This is too big to save.');
    var rawBefore;
    return runWrite(path, op, function (ref) {
      if (op !== 'delete') {
        var have = storeWithout(coll, id);
        if (have && deepEqual(op === 'update' ? mergeInto(have, body) : body, have)) return SKIPPED;
      }
      rawBefore = rawOf(coll, id);
      if (op === 'delete') return ref.delete();
      if (op === 'update') {
        return Promise.resolve(ref.update(body)).catch(function (e) {
          // the document is not there (yet): an update cannot create it, a set can
          if (e && e.code === 'invalid_argument' && body.id != null && (opts.createOnMiss || !QT.store[coll][id])) return ref.set(body);
          throw e;
        });
      }
      return ref.set(body);
    }, function () {
      applyLocal(coll, id, op, body, rawBefore);
      QT.emit('wrote', { collection: coll, id: id, op: op, data: body });
    });
  }

  // What the ping says for the special answers. These phrases are used WHOLE (never cut); her own typed words are never copied.
  var PING_KEY_WORDS = {
    unsure: 'not sure yet', help: 'asked to explain another way', change: 'wants a change', own: 'own answer',
    cathy: 'This is a question for Miss Cathy and Rob', recheck: "check again to make sure it's safe", picks: 'chose from the pictures'
  };
  /** 'Answered: <title, at most 60 characters, cut between words> -> <what>'. At most 13 + 60 + 41 = about 115 characters. */
  function answerPingText(qid, a) {
    var q = QT.store.questions[qid];
    var what = PING_KEY_WORDS[a.key] || (a.label ? QT.fmt.clip(a.label, 40, true) : (a.key || 'answered'));
    return 'Answered: ' + QT.fmt.clip(q && q.title ? q.title : qid, 60, true) + ' → ' + what;
  }
  /** Notebook text inside a ping: quote marks taken out of it, cut between words, then put in curly quotes after a fixed prefix.
   *  A ping is a doorbell for Claude: the words in it are data, never a message, and never carry her full text. */
  function quoted(text, max) {
    var s = QT.fmt.clean(text), out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c === 34 || c === 96 || c === 0xab || c === 0xbb || (c >= 0x201c && c <= 0x201f) || c === 0x2033 || c === 0xff02) continue;
      out += s.charAt(i);
    }
    return String.fromCharCode(0x201c) + QT.fmt.clip(out, max || 60, true) + String.fromCharCode(0x201d);
  }
  function sectionQuoted(id) { var s = QT.store.sections[id]; return quoted(s && s.title ? s.title : id, 50); }
  function pingQuietly(text) { try { QT.write.ping(text).catch(noop); } catch (e) { /* no ping */ } }

  var SECTION_EDITABLE_BUILTIN = ['title', 'size', 'hold', 'archived'];
  var MAX_TASK_TITLE = 120, MAX_TASK_PLAIN = 1200, MAX_ASK = 600;   // her boxes stop earlier (80 / 600); these only guard against a bad caller

  /** A new id for something SHE makes: 'u-' + time in base 36 + 3 random letters or digits (lowercase). */
  function newUserId() {
    var abc = 'abcdefghijklmnopqrstuvwxyz0123456789', r = '';
    try {
      var a = new Uint8Array(3);
      (window.crypto || window.msCrypto).getRandomValues(a);
      for (var i = 0; i < 3; i++) r += abc.charAt(a[i] % 36);
    } catch (e) { for (var j = 0; j < 3; j++) r += abc.charAt(Math.floor(Math.random() * 36)); }
    return 'u-' + Date.now().toString(36) + r;
  }
  /** One line of text: control characters out, white space collapsed. */
  function oneLine(v) { return QT.fmt.clean(v); }
  /** Text that may have several lines: control characters out (new lines and tabs stay), lone emoji halves out, trimmed. */
  function tidyText(v) {
    var s = String(v == null ? '' : v).replace(/\r\n?/g, '\n'), out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c >= 0xd800 && c <= 0xdbff) { var d = s.charCodeAt(i + 1); if (d >= 0xdc00 && d <= 0xdfff) { out += s.charAt(i) + s.charAt(i + 1); i++; } continue; }
      if (c >= 0xdc00 && c <= 0xdfff) continue;
      if (c === 10 || c === 9) { out += s.charAt(i); continue; }
      if (c < 32 || (c >= 127 && c <= 159)) continue;
      out += s.charAt(i);
    }
    return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  /** The best name we know for a task: Claude's task, else her new one, else her last edit. */
  function taskTitleOf(id) {
    var t = QT.store.tasks[id] || QT.store.taskAdds[id], e = QT.store.taskEdits[id];
    return (e && e.title) || (t && t.title) || id;
  }
  function refuseOffline(path) {
    var e = makeError('offline', 'The notebook is not available.');
    QT.emit('writeerror', { path: path, op: 'check', error: e });
    var p = Promise.reject(e);
    p.catch(noop);
    return p;
  }

  QT.write = {
    /** answers/<qid> := obj (adds id, status "answered", answeredAt). A real change (not only the note) also pings Claude. */
    answer: function (qid, obj) {
      if (!validId(qid)) return invalid('answers/' + qid, 'Bad question id.');
      var prev = QT.store.answers[qid];
      var data = Object.assign({ status: 'answered' }, obj || {}, { id: qid });
      // answeredAt is ALWAYS "now" (a caller's older value is ignored): an Undo that puts an earlier answer back, or a new note, must look newer than anything
      // Claude has already seen. It is also never older than her previous answer, even if the computer's clock stepped back.
      var now = nowIso();
      if (prev && prev.answeredAt && prev.answeredAt >= now) now = new Date(Date.parse(prev.answeredAt) + 1).toISOString();
      data.answeredAt = now;
      return write('answers', qid, 'set', data).then(function (v) {
        QT.emit('answered', { qid: qid, answer: data, previous: prev || null });
        var changed = !prev || prev.key !== data.key || prev.status !== data.status || prev.ownText !== data.ownText || prev.changeText !== data.changeText ||
          !deepEqual(prev.picks, data.picks);   // a new choice in the picture chooser counts; a note-only save does not
        if (data.status === 'answered' && data.key && changed) pingQuietly(answerPingText(qid, data));
        return v;
      });
    },
    /** The Undo button: deletes answers/<qid>. */
    clearAnswer: function (qid) {
      var prev = QT.store.answers[qid] || null;
      return write('answers', qid, 'delete').then(function (v) { QT.emit('answercleared', { qid: qid, previous: prev }); return v; });
    },
    /** New custom section (set) or an edit of an existing one (merge). Claude-made sections only take title / size / hold / archived from the page. */
    section: function (id, obj) {
      if (!validId(id)) return invalid('sections/' + id, 'Bad section id.');
      var have = QT.store.sections[id];
      var patch = Object.assign({}, obj || {});
      if (have) {
        if (have.kind === 'builtin' || have.createdBy === 'claude') {
          var allowed = {};
          SECTION_EDITABLE_BUILTIN.forEach(function (k) { if (k in patch) allowed[k] = patch[k]; });
          patch = allowed;
        } else {
          delete patch.kind; delete patch.createdBy; delete patch.createdAt;
        }
        patch.id = id;
        return write('sections', id, 'update', patch);
      }
      if (BUILTIN_IDS[id]) return invalid('sections/' + id, 'The ready-made sections are made by Claude.');
      var orders = Object.keys(QT.store.sections).map(function (k) { return Number(QT.store.sections[k].order) || 0; });
      var doc = Object.assign({
        title: 'New section', size: 'big', hold: false, readOnly: false, blurb: '', archived: false,
        order: (orders.length ? Math.max.apply(null, orders) : 0) + 1
      }, patch, { id: id, kind: 'custom', createdBy: 'owner' });
      if (!doc.createdAt) doc.createdAt = nowIso();
      return write('sections', id, 'set', doc);
    },
    /** A new idea (a draft, or already sent with {send:true}). Resolves with the new id. */
    idea: function (obj) {
      obj = obj || {};
      var id = validId(obj.id) ? obj.id : QT.uid('idea');
      var sent = obj.send === true ? nowIso() : (obj.sentAt || null);
      var doc = { id: id, sectionId: obj.sectionId, text: String(obj.text == null ? '' : obj.text), createdAt: obj.createdAt || nowIso(), sentAt: sent };
      return write('ideas', id, 'set', doc).then(function () {
        if (sent) pingQuietly('New idea in ' + sectionQuoted(doc.sectionId));
        return id;
      });
    },
    /** Change a draft idea (for example its text). */
    updateIdea: function (id, patch) { return write('ideas', id, 'update', Object.assign({}, patch, { id: id })); },
    deleteIdea: function (id) { return write('ideas', id, 'delete'); },
    /** "Send to Claude": sets sentAt (and anything in extra, e.g. {text}) and pings Claude. Resolves with the sent time. */
    sendIdea: function (id, extra) {
      var sentAt = nowIso();
      var patch = Object.assign({}, extra || {}, { id: id, sentAt: sentAt });
      return write('ideas', id, 'update', patch).then(function () {
        var idea = QT.store.ideas[id];
        pingQuietly('New idea in ' + sectionQuoted(idea && idea.sectionId));
        return sentAt;
      });
    },
    /** planReplies/<sectionId> := { sectionId, version, decision:"ok"|"change", text, at } and pings Claude. */
    planReply: function (sectionId, obj) {
      if (!validId(sectionId)) return invalid('planReplies/' + sectionId, 'Bad section id.');
      var data = Object.assign({ text: '' }, obj || {}, { sectionId: sectionId });
      if (!data.at) data.at = nowIso();
      return write('planReplies', sectionId, 'set', data).then(function (v) {
        pingQuietly(data.decision === 'ok' ? 'Plan approved: ' + sectionQuoted(sectionId) : 'Plan: changes asked in ' + sectionQuoted(sectionId));
        return v;
      });
    },
    /** A task SHE adds: taskAdds/<id> := { id, parentId, title, plain, createdAt }. Resolves with the new id ("u-..."). Claude adopts it by writing tasks/<same id>. */
    taskAdd: function (obj) {
      obj = obj || {};
      if (QT.offline) return refuseOffline('taskAdds/new');
      var title = oneLine(obj.title), plain = tidyText(obj.plain), parentId = obj.parentId ? String(obj.parentId) : null;
      if (!title) return invalid('taskAdds/new', 'A task needs a name.');
      if (title.length > MAX_TASK_TITLE) return invalid('taskAdds/new', 'That name is too long. Please make it shorter.');
      if (plain.length > MAX_TASK_PLAIN) return invalid('taskAdds/new', 'That text is too long. Please make it shorter.');
      if (parentId && !validId(parentId)) return invalid('taskAdds/new', 'Bad parent id.');
      var id = newUserId();
      var doc = { id: id, parentId: parentId, title: title, plain: plain, createdAt: nowIso() };
      return write('taskAdds', id, 'set', doc).then(function () {
        QT.emit('taskadded', { id: id, doc: doc });
        pingQuietly('Added a task: ' + quoted(title, 60));
        return id;
      });
    },
    /** Her change to ANY task: merges { title?, plain?, paused?, removed? } into taskEdits/<taskId> and sets id + updatedAt. Rapid edits keep each other's fields. */
    taskEdit: function (taskId, patch) {
      if (QT.offline) return refuseOffline('taskEdits/' + taskId);
      if (!validId(taskId)) return invalid('taskEdits/' + taskId, 'Bad task id.');
      patch = patch || {};
      var data = { id: taskId, updatedAt: nowIso() }, any = false;
      if (patch.title !== undefined) {
        var t = oneLine(patch.title);
        if (!t) return invalid('taskEdits/' + taskId, 'A task needs a name.');
        if (t.length > MAX_TASK_TITLE) return invalid('taskEdits/' + taskId, 'That name is too long. Please make it shorter.');
        data.title = t; any = true;
      }
      if (patch.plain !== undefined) {
        var pl = tidyText(patch.plain);
        if (pl.length > MAX_TASK_PLAIN) return invalid('taskEdits/' + taskId, 'That text is too long. Please make it shorter.');
        data.plain = pl; any = true;
      }
      if (patch.paused !== undefined) { data.paused = !!patch.paused; any = true; }
      if (patch.removed !== undefined) { data.removed = !!patch.removed; any = true; }
      if (!any) return invalid('taskEdits/' + taskId, 'There is nothing to change.');
      var name = data.title || taskTitleOf(taskId);
      return write('taskEdits', taskId, 'update', data, { createOnMiss: true }).then(function (v) {
        QT.emit('taskedited', { id: taskId, patch: data });
        pingQuietly('Changed a task: ' + quoted(name, 60));
        return v;
      });
    },
    /** A question about a worker or a task: asks/<id> := { id, targetKind, targetId, text, createdAt }. Resolves with the new id. Claude answers in replies/<id>. */
    ask: function (obj) {
      obj = obj || {};
      if (QT.offline) return refuseOffline('asks/new');
      var kind = obj.targetKind, targetId = obj.targetId, text = tidyText(obj.text);
      if (kind !== 'worker' && kind !== 'task') return invalid('asks/new', 'Ask about a worker or a task.');
      if (!validId(targetId)) return invalid('asks/new', 'Bad target id.');
      if (!text) return invalid('asks/new', 'Please write your question first.');
      if (text.length > MAX_ASK) return invalid('asks/new', 'That question is too long. Please make it shorter.');
      var id = newUserId();
      var doc = { id: id, targetKind: kind, targetId: targetId, text: text, createdAt: nowIso() };
      return write('asks', id, 'set', doc).then(function () {
        var w = kind === 'worker' ? QT.store.workers[targetId] : null;
        var who = w && w.name ? w.name : (kind === 'task' ? taskTitleOf(targetId) : targetId);
        QT.emit('asked', { id: id, doc: doc });
        pingQuietly('Question for ' + quoted(who, 50) + ', open the Terminal to read it');   // never her words
        return id;
      });
    },
    /** The page's own notes in the notebook. Only meta/ping ({threadId}) may be written by the page. */
    meta: function (id, obj) {
      if (id !== 'ping') return invalid('meta/' + id, 'The page may only write meta/ping.');
      return write('meta', 'ping', 'set', Object.assign({}, obj || {}, { id: 'ping' }));
    },
    /** Tell Claude something short. Delegates to QT.status.ping(text) (throttling, "test must have worked" and the wording live there). */
    ping: function (text) {
      text = QT.fmt.clip(text, 400);   // short, one line, no control characters (the comment service refuses them)
      try {
        if (QT.status && typeof QT.status.ping === 'function') {
          return Promise.resolve(QT.status.ping(text)).then(function (r) { return r || { ok: false, reason: 'error' }; }, function () { return { ok: false, reason: 'error' }; });
        }
      } catch (e) { return Promise.resolve({ ok: false, reason: 'error' }); }
      return Promise.resolve({ ok: false, reason: 'none' });
    },
    /** How many writes are waiting or running. */
    pending: function () { return pendingCount; }
  };

  // Every write returns a promise that callers may or may not look at: a failure must not turn into an "unhandled error" when nobody does,
  // and a mistake in the arguments must come back as a rejected promise, not as a crash.
  Object.keys(QT.write).forEach(function (k) {
    if (k === 'ping' || k === 'pending') return;
    var f = QT.write[k];
    QT.write[k] = function () {
      var p;
      try { p = f.apply(QT.write, arguments); } catch (e) { p = Promise.reject(normError(e)); }
      if (p && typeof p.catch === 'function') p.catch(noop);
      return p;
    };
  });

  /* ------------------------------------------------------------------ go */
  // Start once the page has been put together (every module has attached its listeners by then).
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else Promise.resolve().then(start);
})();
