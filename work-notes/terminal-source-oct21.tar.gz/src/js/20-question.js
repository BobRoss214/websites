/* 20-question.js  (owner: question)
 * QT.views.question(el, {id})  - one question: sticky bar, story, "why I am asking", pictures (visual), answer controls.
 * QT.answerUI.render(el, q)    - ALL answer controls (A-D, I'm not sure, Explain another way, own answer, change, "Check again to make sure it's safe" (key recheck,
 *                                only when q.canRecheck), "This is a question for Miss Cathy and Rob" (key cathy), note, Saved + Undo, Next).
 * The Safety check card (q.safety) is drawn by the question view, just above the answers.
 *
 * Rules kept here: all text from documents goes in with textContent (through QT.el), never innerHTML; a click on an answer is saved at once;
 * the note is saved 600 ms after she stops typing and never from a redraw or a snapshot; text she is typing is never replaced.
 */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  QT.views = QT.views || {};

  var UNDO_MS = 8000;       // how long "Saved ✓ · Undo" stays
  var NOTE_MS = 600;        // pause before the note is saved
  var HIDE_DUPLICATE_EXTRAS = true;   // hide "Explain another way" / "I'm not sure yet" when one of the 4 choices already says the same
  var MAX_OWN = 8000, MAX_CHANGE = 4000, MAX_NOTE = 4000;

  var SEEN_SOON = 'Claude will see it soon.';
  var CATHY_LABEL = 'This is a question for Miss Cathy and Rob';       // answer key "cathy": the question goes to the Miss Cathy and Rob list
  var RECHECK_LABEL = "Check again to make sure it's safe";             // answer key "recheck": Claude researches the download again (only when the question says canRecheck)
  var ORDINAL = ['', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth'];
  var uid = 0;
  var LIVE = Object.create(null);     // qid -> the answer controls that are on the page for that question (QT.answerUI.pick finds them here)
  var DRAFTS = Object.create(null);   // qid -> { own, change, note }  text typed but not saved yet (survives leaving the question)
  var MSGS = Object.create(null);     // qid -> last "Saved" message, so it survives a redraw of the same question

  /* ------------------------------------------------------------------ tiny helpers */
  function str(v) { return v == null ? '' : String(v); }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function iso() { return new Date().toISOString(); }
  function coll(name) { return (QT.store && QT.store[name]) || {}; }
  function has(ids, id) {
    if (!ids) return true;
    if (Array.isArray(ids)) return ids.length === 0 || ids.indexOf(id) >= 0;
    if (typeof ids.has === 'function') return ids.has(id);
    return !!ids[id];
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  /* a small eye drawn in the neutral "For someone else to answer" chip (a picture next to the words, like the other status chips) */
  function eyeIcon() {
    var NS = 'http://www.w3.org/2000/svg', s = document.createElementNS(NS, 'svg'), a = document.createElementNS(NS, 'path'), b = document.createElementNS(NS, 'circle');
    s.setAttribute('viewBox', '0 0 16 16'); s.setAttribute('width', '14'); s.setAttribute('height', '14'); s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '1.6'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false'); s.setAttribute('class', 'qt-ico');
    a.setAttribute('d', 'M1.5 8S4 3.6 8 3.6 14.5 8 14.5 8 12 12.4 8 12.4 1.5 8 1.5 8z');
    b.setAttribute('cx', '8'); b.setAttribute('cy', '8'); b.setAttribute('r', '1.9');
    s.appendChild(a); s.appendChild(b);
    return s;
  }
  function clone(o) { return o ? JSON.parse(JSON.stringify(o)) : o; }
  function safeUrl(u) { u = str(u); return /^https:\/\/[^\s]+$/i.test(u) || /^data:image\/[a-z+.-]+[;,]/i.test(u) || /^\/_blob\/[0-9a-f]{32}$/i.test(u) ? u : ''; }

  /* QT.el builds the element; false / null attributes are skipped (so "hidden:false" never hides anything) and children may be nested arrays or text */
  function add(node, kid) {
    if (kid == null || kid === false) return;
    if (Array.isArray(kid)) { for (var i = 0; i < kid.length; i++) add(node, kid[i]); return; }
    node.appendChild(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  function h(tag, attrs) {
    var a = {}, hidden = false, disabled = false, k, v;
    if (attrs) for (k in attrs) {
      v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'hidden') { hidden = true; continue; }
      if (k === 'disabled') { disabled = true; continue; }
      a[k] = v;
    }
    var node = QT.el(tag, a);
    if (hidden) node.hidden = true;
    if (disabled) node.disabled = true;
    for (var i = 2; i < arguments.length; i++) add(node, arguments[i]);
    return node;
  }
  function btn(text, cls, onclick, attrs) {
    var a = { type: 'button', class: 'btn ' + (cls || ''), text: text };
    if (attrs) for (var k in attrs) a[k] = attrs[k];
    var b = h('button', a);
    if (onclick) b.addEventListener('click', onclick);
    return b;
  }
  function sectionTitle(sectionId) { var s = coll('sections')[sectionId]; return s && s.title ? str(s.title) : ''; }
  function goto(view, params) { if (QT.route && QT.route.go) QT.route.go(view, params); }
  function isTyping(t) {
    if (!t || !t.tagName) return false;
    var n = t.tagName.toUpperCase();
    return n === 'INPUT' || n === 'TEXTAREA' || n === 'SELECT' || !!t.isContentEditable;
  }
  function sameDoc(a, b) {
    if (!a || !b) return !a && !b;
    return ['status', 'key', 'label', 'ownText', 'changeText', 'note'].every(function (f) { return str(a[f]) === str(b[f]); });
  }

  /* ------------------------------------------------------------------ options of a question */
  function optionsOf(q) {
    var visual = q.kind === 'visual';
    var src = visual ? arr(q.versions) : arr(q.choices), out = [], seen = {};
    src.forEach(function (o) {
      if (!o || !/^[A-D]$/.test(str(o.key)) || seen[o.key]) return;
      seen[o.key] = 1;
      out.push({ key: o.key, label: str(o.label), explain: visual ? '' : str(o.explain), caption: str(o.caption) });
    });
    out.sort(function (x, y) { return x.key < y.key ? -1 : 1; });
    return out;
  }

  /* ================================================================== ANSWER CONTROLS */
  function createAnswer(q, cfg) {
    var qid = q.id, visual = q.kind === 'visual';
    var noChoices = !!(cfg && cfg.noChoices);      // the A-D row is drawn by someone else (the pictures): this module only keeps the keys and the rest
    var api = null;
    var n = ++uid, headId = 'qa-h' + n, ownId = 'qa-own' + n, chgId = 'qa-chg' + n, noteId = 'qa-note' + n;
    var opts = optionsOf(q);
    var dr = DRAFTS[qid] || (DRAFTS[qid] = {});
    var destroyed = false, wasConnected = false;
    var pending = null, seq = 0, queue = Promise.resolve();
    var msg = null, msgTimer = 0, noteTimer = 0, noteStatTimer = 0;
    var ownOpen = false, changeOpen = false, lastSel = null;
    var doc0 = answeredDoc(coll('answers')[qid]);

    function answeredDoc(d) { return d && d.status === 'answered' && d.key ? d : null; }
    function cur() { return pending ? pending.doc : (coll('answers')[qid] || null); }

    /* ---- what we hide: extra buttons that one of the four choices already is */
    var dupHelp = false, dupUnsure = false;
    if (HIDE_DUPLICATE_EXTRAS && !visual) opts.forEach(function (o) {
      if (/explain\b.*\b(another|different|other)\s+way|another\s+way/i.test(o.label)) dupHelp = true;
      if (/\bnot\s+sure\b/i.test(o.label)) dupUnsure = true;
    });

    /* ---- pieces ---- */
    var root = h('section', { class: 'qa ' + (visual ? 'is-visual' : 'is-choice'), 'aria-labelledby': headId, 'data-qid': qid });
    var tip = h('span', { class: 'qa-tip muted', text: 'Tip: press the A, B, C or D key' });
    var head = h('div', { class: 'qa-head', hidden: noChoices }, h('h2', { id: headId, text: visual ? 'Which version do you like?' : 'Pick one answer' }), opts.length && !noChoices ? tip : null);

    var group = h('div', { class: 'qa-choices ' + (visual ? 'is-visual' : 'is-choice'), hidden: noChoices, role: 'radiogroup', 'aria-labelledby': headId, 'data-n': String(opts.length) });
    var cards = [];
    opts.forEach(function (o) {
      var kids = [
        h('span', { class: 'qa-badge', text: o.key }),
        h('span', { class: 'qa-lab' + (o.label.length > 60 ? ' long' : ''), text: o.label }),
        h('span', { class: 'qa-mark', 'aria-hidden': 'true', title: 'Your answer', text: '✓' }),
        o.explain ? h('span', { class: 'qa-exp', text: o.explain }) : null
      ];
      var attrs = { type: 'button', class: 'qa-choice', role: 'radio', 'aria-checked': 'false', tabindex: '-1', 'data-key': o.key, 'data-fid': 'c-' + o.key, 'aria-keyshortcuts': o.key };
      if (visual) { attrs['aria-label'] = o.key + ' · ' + o.label; if (o.caption) attrs.title = o.caption; }
      var b = h.apply(null, ['button', attrs].concat(kids));
      b.addEventListener('click', function () { pick(o); });
      group.appendChild(b);
      cards.push({ o: o, el: b });
    });
    group.addEventListener('keydown', onGroupKey);
    group.addEventListener('focusin', function (e) {
      cards.forEach(function (c) { c.el.tabIndex = c.el === e.target ? 0 : -1; });
    });

    var unsureBtn = dupUnsure ? null : btn("I'm not sure yet", 'small qa-x', function () { quick('unsure', "I'm not sure yet"); }, { 'data-key': 'unsure', 'data-fid': 'x-unsure', 'aria-pressed': 'false' });
    var helpBtn = dupHelp ? null : btn('Explain another way', 'small qa-x', function () { quick('help', 'Explain another way'); }, { 'data-key': 'help', 'data-fid': 'x-help', 'aria-pressed': 'false' });
    var ownBtn = btn('Type my own answer', 'small qa-x', function () { togglePanel('own'); }, { 'data-key': 'own', 'data-fid': 'x-own', 'aria-expanded': 'false', 'aria-controls': ownId });
    var changeBtn = visual ? btn('', 'small qa-x', function () { togglePanel('change'); }, { 'data-key': 'change', 'data-fid': 'x-change', 'aria-expanded': 'false', 'aria-controls': chgId }) : null;
    if (changeBtn) {   // a shorter wording on a narrow window, so that all four extra buttons fit in one row
      changeBtn.appendChild(h('span', { class: 'lbl-full', text: 'I like none – please change these' }));
      changeBtn.appendChild(h('span', { class: 'lbl-short', text: 'None of these – please change them' }));
    }
    var recheckBtn = q.canRecheck === true ? btn(RECHECK_LABEL, 'small qa-x', function () { quick('recheck', RECHECK_LABEL); }, { 'data-key': 'recheck', 'data-fid': 'x-recheck', 'aria-pressed': 'false' }) : null;
    var cathyBtn = q.kind !== 'readonly' && q.sectionId !== 'kathy' ? btn(CATHY_LABEL, 'small qa-x', function () { quick('cathy', CATHY_LABEL); }, { 'data-key': 'cathy', 'data-fid': 'x-cathy', 'aria-pressed': 'false' }) : null;
    var extra = h('div', { class: 'qa-extra', role: 'group', 'aria-label': 'If none of the answers fits' }, unsureBtn, helpBtn, ownBtn, changeBtn, recheckBtn, cathyBtn);

    /* own answer */
    var ownTA = h('textarea', { id: ownId + '-t', class: 'qa-ta', rows: '3', maxlength: String(MAX_OWN), 'data-fid': 'own-text', 'aria-describedby': ownId + '-hint' });
    var ownSave = btn('Save my answer', 'primary small', saveOwn, { 'data-fid': 'own-save' });
    var ownStat = h('span', { class: 'savestat bad qa-unsaved', 'data-role': 'own-stat' });
    var chgStat = h('span', { class: 'savestat bad qa-unsaved', 'data-role': 'change-stat' });
    var ownPanel = h('div', { class: 'qa-panel', id: ownId, hidden: true },
      h('label', { for: ownId + '-t', class: 'qa-plabel', text: 'Your own answer' }),
      h('div', { class: 'hint', id: ownId + '-hint', text: str(q.ownTip) || 'Write what you would like, in your own words.' }),
      ownTA, h('div', { class: 'row' }, ownSave, ownStat));

    /* change (visual only) */
    var chgTA = h('textarea', { id: chgId + '-t', class: 'qa-ta', rows: '3', maxlength: String(MAX_CHANGE), 'data-fid': 'change-text' });
    var chgSave = btn('Save', 'primary small', saveChange, { 'data-fid': 'change-save' });
    var chgPanel = visual ? h('div', { class: 'qa-panel', id: chgId, hidden: true },
      h('label', { for: chgId + '-t', class: 'qa-plabel', text: 'What should Claude change?' }),
      h('div', { class: 'hint', text: 'Say what you dislike and what you would like instead.' }),
      chgTA, h('div', { class: 'row' }, chgSave, chgStat)) : null;

    /* the one line under the answers: "+ Add a note" (or the tip) on the left, Saved / Undo and Next question on the right */
    var noteOpen = false;
    var noteLink = btn('+ Add a note', 'quiet qa-notelink', function () { noteOpen = true; update(); try { noteTA.focus(); } catch (e) { /* ignore */ } }, { 'data-fid': 'note-open', 'aria-expanded': 'false', 'aria-controls': noteId, 'aria-label': '+ Add a note for Claude', title: 'Add a note for Claude (you do not have to)' });
    var msgText = h('span', { class: 'qa-msg-text' });
    var undoBtn = btn('Undo', 'quiet small qa-undo', undo, { hidden: true, 'data-fid': 'undo' });
    var msgEl = h('p', { class: 'savestat qa-msg', role: 'status', 'aria-live': 'polite' }, msgText);
    var seeBtn = btn('See their list', 'quiet small qa-undo qa-seelist', function () { goto('section', { id: 'kathy' }); }, { hidden: true, 'data-fid': 'see-list' });   // only after "This is a question for Miss Cathy and Rob"
    var nextBtn = btn('Next question →', 'primary qa-next', goNext, { hidden: true, 'data-fid': 'next' });
    var foot = h('div', { class: 'qa-foot qa-state is-empty' }, noteLink, h('span', { class: 'qa-msgbox' }, msgEl, undoBtn, seeBtn), noChoices && opts.length ? tip : null, nextBtn);

    /* note (folded away until she wants it, or already has one) */
    var noteStat = h('span', { class: 'savestat ok qa-notestat', role: 'status', 'aria-live': 'polite' });
    var noteHint = h('span', { class: 'muted qa-notehint', hidden: true, text: 'Saved when you pick an answer' });
    var noteTA = h('textarea', { id: noteId, class: 'qa-ta qa-note-ta', rows: '2', maxlength: String(MAX_NOTE), 'data-fid': 'note', 'aria-describedby': noteId + '-hint' });
    var noteBox = h('div', { class: 'qa-note', hidden: true },
      h('div', { class: 'row between qa-note-head' }, h('label', { for: noteId, text: 'Note for Claude (optional)' }), noteStat, noteHint),
      noteTA, h('span', { id: noteId + '-hint', class: 'sr', text: 'Saved by itself when you stop typing, together with your answer.' }));

    add(root, [head, group, extra, ownPanel, chgPanel, noteBox, foot]);

    /* ---- start values: typed-but-unsaved text first, else what is saved */
    // "synced" = the text the box had when it last matched the saved answer; a box that differs from it holds her own unsaved typing
    var synced = {
      own: doc0 && doc0.key === 'own' ? str(doc0.ownText).trim() : '',
      change: doc0 && doc0.key === 'change' ? str(doc0.changeText).trim() : '',
      note: doc0 ? str(doc0.note).trim() : ''
    };
    ownTA.value = dr.own != null ? dr.own : synced.own;
    chgTA.value = dr.change != null ? dr.change : synced.change;
    noteTA.value = dr.note != null ? dr.note : synced.note;
    if (MSGS[qid] && MSGS[qid].until > Date.now()) msg = MSGS[qid];
    if (dr.own) ownOpen = true;
    if (dr.change) changeOpen = true;

    ownTA.addEventListener('input', function () { remember(); update(); });
    chgTA.addEventListener('input', function () { remember(); update(); });
    ownTA.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); saveOwn(); } });
    chgTA.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); saveChange(); } });
    noteTA.addEventListener('input', function () {
      remember();
      noteHint.hidden = !!answeredDoc(cur()) || !noteTA.value.trim();
      clearTimeout(noteTimer);
      noteTimer = setTimeout(commitNote, NOTE_MS);
    });
    noteTA.addEventListener('blur', function () { if (noteTimer) commitNote(); });

    function remember() {   // typed but unsaved text, kept for when she comes back
      var o = ownTA.value.trim() !== synced.own ? ownTA.value : null;
      var c = chgTA.value.trim() !== synced.change ? chgTA.value : null;
      var t = noteTA.value.trim() !== synced.note ? noteTA.value : null;
      if (o != null) dr.own = o; else delete dr.own;
      if (c != null) dr.change = c; else delete dr.change;
      if (t != null) dr.note = t; else delete dr.note;
    }

    /* ---- messages under the answers */
    function setMsg(m) {
      msg = m;
      if (m && m.until) MSGS[qid] = m; else delete MSGS[qid];
      clearTimeout(msgTimer);
      if (m && m.until) msgTimer = setTimeout(function () { if (msg === m) { msg = null; delete MSGS[qid]; } update(); }, Math.max(30, m.until - Date.now() + 30));
    }
    function liveMsg() { return msg && (!msg.until || msg.until > Date.now()) ? msg : null; }

    /* ---- writing */
    function realWrite(doc) {
      if (!doc) return QT.write.clearAnswer(qid);
      return QT.write.answer(qid, doc);
    }
    function send(doc, onOk, onFail) {
      var token = ++seq;
      pending = { doc: doc ? clone(doc) : null, token: token, settled: false };
      queue = queue.then(function () { return realWrite(doc); }).then(function (res) {
        if (res && res.ok === false) throw new Error(res.reason || 'not saved');
        if (pending && pending.token === token) {
          pending.settled = true;
          if (sameDoc(pending.doc, coll('answers')[qid] || null)) pending = null;
          else setTimeout(function () { if (pending && pending.token === token) { pending = null; update(); } }, 4000);
        }
        if (!destroyed && onOk) onOk(res);
        update();
      }, function (err) {
        if (pending && pending.token === token) pending = null;
        if (!destroyed) {
          if (onFail) onFail(err);
          setMsg({ kind: 'error', text: 'Not saved. Your words are still here. Please try again.' });
        }
        update();
      }).catch(function () { /* the queue must never stop */ });
      return queue;
    }
    function buildDoc(fields) {
      var d = { id: qid, status: 'answered', key: '', label: '', ownText: '', changeText: '', note: noteTA.value.trim(), round: q.round || 1, answeredAt: iso() };
      for (var k in fields) d[k] = fields[k];
      return d;
    }
    function saveAnswer(fields, extraText) {          // extraText: the words after "Saved ✓" (a plain "·" first makes it read "Saved ✓ · ...")
      if (QT.offline) return;
      var prev = cur() ? clone(cur()) : null;
      var doc = buildDoc(fields);
      var here = answeredDoc(cur());
      if (here && sameDoc(doc, here)) {          // the same answer again: nothing to write (and Claude is not told about a "new" answer)
        setMsg({ kind: 'info', text: 'Already saved ✓', until: Date.now() + 2500 });
        update();
        return;
      }
      if (fields.key !== 'own') ownOpen = false;               // only one answer looks active: saving another one closes the open box
      if (fields.key !== 'change') changeOpen = false;
      clearTimeout(noteTimer); noteTimer = 0;
      synced.note = doc.note;
      if (fields.key === 'own') synced.own = fields.ownText;
      if (fields.key === 'change') synced.change = fields.changeText;
      remember();
      setMsg({ kind: 'saving', text: 'Saving…' });
      send(doc, function () {
        setMsg({ kind: 'saved', text: 'Saved ✓', extra: extraText || '', prev: prev, until: Date.now() + UNDO_MS });
        update();
        showSaved();
      });
      update();
    }
    function showSaved() {      // the "Saved ✓ · Undo · Next" line may sit below the fold on a short window: bring it into view
      if (typeof requestAnimationFrame !== 'function') return;
      requestAnimationFrame(function () {
        if (destroyed || !root.isConnected) return;
        var r = foot.getBoundingClientRect();
        if (r.bottom <= window.innerHeight - 8 && r.top >= 0) return;
        var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        try { foot.scrollIntoView({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' }); } catch (e) { /* ignore */ }
      });
    }
    function pick(o) { saveAnswer({ key: o.key, label: o.label }, SEEN_SOON); }
    function pickKey(key) {                 // used by the keys and by QT.answerUI.pick (the pictures)
      var o = null;
      opts.forEach(function (x) { if (x.key === key) o = x; });
      if (!o) return false;
      pick(o);
      return true;
    }
    function showChoices() {               // the pictures did not draw their own pick buttons: show the A-D row after all
      if (!noChoices) return;
      noChoices = false;
      head.hidden = false; group.hidden = false;
      if (opts.length) head.appendChild(tip);
      update();
    }
    var QUICK_SAYS = {
      help: 'Claude will explain it another way.',
      cathy: '· Sent to the Miss Cathy and Rob list',
      recheck: '· Claude will check again and come back'
    };
    function quick(key, label) {
      saveAnswer({ key: key, label: label }, QUICK_SAYS[key] || "That is fine. You can come back to it.");
    }
    function saveOwn() {
      var t = ownTA.value.trim();
      if (!t) return;
      saveAnswer({ key: 'own', label: 'My own answer', ownText: t }, SEEN_SOON);
    }
    function saveChange() {
      var t = chgTA.value.trim();
      if (!t) return;
      saveAnswer({ key: 'change', label: 'I like none – please change these', changeText: t }, 'Claude will read what you wrote.');
    }
    function undo() {
      var m = liveMsg();
      if (!m || m.kind !== 'saved' || QT.offline) return;
      var back = group.hidden ? extra.querySelector('button:not([disabled])') : (group.querySelector('[tabindex="0"]') || group.querySelector('.qa-choice'));
      if (back && !back.disabled) { try { back.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }   // the Undo button is about to go away
      var prev = m.prev ? clone(m.prev) : null;
      setMsg({ kind: 'saving', text: 'Undoing…' });
      send(prev, function () {
        setMsg({ kind: 'undone', text: prev ? 'Back to your earlier answer.' : 'Answer removed. You can pick again.', until: Date.now() + 3500 });
      });
      update();
    }
    function commitNote() {
      clearTimeout(noteTimer); noteTimer = 0;
      var d = answeredDoc(cur());
      var val = noteTA.value.trim();
      if (!d) return;                              // no answer yet: the note stays in the box and is saved together with the answer
      if (val === str(d.note).trim()) { synced.note = val; remember(); return; }
      synced.note = val;
      remember();
      var doc = Object.assign({}, clone(d), { note: val, answeredAt: iso() });
      var m = liveMsg();
      if (m && m.kind === 'saved' && m.prev) m.prev.note = val;   // Undo must not throw the new note away
      send(doc, function () {
        flashNote('Note saved ✓');
      }, null);
    }
    function flashNote(text) {
      noteStat.textContent = text;
      clearTimeout(noteStatTimer);
      noteStatTimer = setTimeout(function () { noteStat.textContent = ''; }, 2500);
    }

    /* ---- next question */
    function nextId() {
      var id = null;
      try { id = QT.sections && QT.sections.nextUnanswered ? QT.sections.nextUnanswered(qid) : null; } catch (e) { id = null; }
      return id && id !== qid ? id : null;
    }
    function goNext() {
      if (noteTimer) commitNote();
      var id = nextId();
      if (id) goto('question', { id: id });
      else if (q.sectionId) goto('section', { id: q.sectionId });
      else goto('home', {});
    }

    /* ---- panels and keys */
    function togglePanel(which) {
      if (which === 'own') { ownOpen = !ownOpen; if (ownOpen) changeOpen = false; }
      else { changeOpen = !changeOpen; if (changeOpen) ownOpen = false; }
      update();
      var ta = which === 'own' ? ownTA : chgTA;
      if ((which === 'own' ? ownOpen : changeOpen)) { try { ta.focus({ preventScroll: false }); } catch (e) { /* ignore */ } }
    }
    function onGroupKey(e) {
      var keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
      var idx = -1;
      cards.forEach(function (c, i) { if (c.el === e.target) idx = i; });
      if (idx < 0 || !cards.length) return;
      var to = -1;
      if (e.key === 'Home') to = 0; else if (e.key === 'End') to = cards.length - 1;
      else if (keys[e.key]) to = (idx + keys[e.key] + cards.length) % cards.length;
      if (to < 0) return;
      e.preventDefault();
      cards[to].el.focus();
    }
    function onKey(e) {
      if (destroyed) return;
      if (!root.isConnected) { if (wasConnected) destroy(); return; }   // the page was redrawn without telling us
      if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
      if (typeof e.key !== 'string' || e.key.length !== 1) return;
      var k = e.key.toUpperCase();
      if (!/^[A-D]$/.test(k)) return;
      if (isTyping(e.target) || isTyping(document.activeElement)) return;
      var t = e.target;
      if (t && t.closest && t.closest('.menu, .topbar, .toasts')) return;       // the menu and the top bar have their own keys
      if (QT.offline) return;
      if (document.querySelector('[role="dialog"]:not([hidden]), [aria-modal="true"]:not([hidden])')) return;   // a big picture or the menu is open
      var o = null;
      opts.forEach(function (x) { if (x.key === k) o = x; });
      if (!o) return;
      e.preventDefault();
      pick(o);
    }
    document.addEventListener('keydown', onKey);

    /* ---- store changes (answers of this question) */
    function onStore(ev) {
      if (destroyed) return;
      if (!root.isConnected && wasConnected) { destroy(); return; }
      var c = ev && ev.collection;
      if (c && c !== 'answers') return;
      if (ev && ev.ids && !has(ev.ids, qid)) return;
      if (pending && pending.settled && sameDoc(pending.doc, coll('answers')[qid] || null)) pending = null;
      update();
    }
    QT.on('store', onStore);
    var onConn = function () { update(); };
    QT.on('offline', onConn); QT.on('online', onConn);

    /* ---- one function draws the state of everything; it never recreates the boxes, so typing and focus are safe */
    function update() {
      if (destroyed) return;
      if (root.isConnected) wasConnected = true;
      var d = answeredDoc(cur()), sel = d ? d.key : '';
      var off = !!QT.offline;

      // the four answers
      var inGroup = group.contains(document.activeElement);
      var tabKey = null;
      cards.forEach(function (c) { if (c.o.key === sel) tabKey = sel; });
      if (!tabKey && cards.length) tabKey = cards[0].o.key;
      cards.forEach(function (c) {
        var on = c.o.key === sel;
        c.el.setAttribute('aria-checked', on ? 'true' : 'false');
        c.el.classList.toggle('is-picked', on);
        c.el.disabled = off;
        if (!inGroup) c.el.tabIndex = c.o.key === tabKey ? 0 : -1;
      });

      // the extra buttons
      [unsureBtn, helpBtn, recheckBtn, cathyBtn].forEach(function (b) {
        if (!b) return;
        var on = sel === b.getAttribute('data-key');
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        b.classList.toggle('on', on);
        b.disabled = off;
      });
      if (sel === 'own' && lastSel !== 'own') { ownOpen = true; changeOpen = false; }
      if (sel === 'change' && lastSel !== 'change') { changeOpen = true; ownOpen = false; }
      lastSel = sel;
      ownBtn.setAttribute('aria-expanded', ownOpen ? 'true' : 'false');
      ownBtn.classList.toggle('on', sel === 'own');
      ownPanel.hidden = !ownOpen;
      if (changeBtn) {
        changeBtn.setAttribute('aria-expanded', changeOpen ? 'true' : 'false');
        changeBtn.classList.toggle('on', sel === 'change');
        chgPanel.hidden = !changeOpen;
      }

      // text boxes: take over what is saved only when she has not changed the box herself
      var act = document.activeElement;
      syncBox(ownTA, 'own', d && d.key === 'own' ? str(d.ownText).trim() : null, act);
      syncBox(chgTA, 'change', d && d.key === 'change' ? str(d.changeText).trim() : null, act);
      syncBox(noteTA, 'note', d ? str(d.note).trim() : null, act);
      if (synced.note || noteTA.value.trim()) noteOpen = true;          // a note that exists is never hidden
      noteBox.hidden = !noteOpen;
      noteLink.hidden = noteOpen;
      noteLink.setAttribute('aria-expanded', noteOpen ? 'true' : 'false');
      var ot = ownTA.value.trim(), ct = chgTA.value.trim();
      noteHint.hidden = !!d || !noteTA.value.trim();
      ownSave.disabled = off || !ot || (sel === 'own' && ot === str(d.ownText).trim());
      ownStat.textContent = !off && ot && !ownSave.disabled ? 'Not saved yet. Press Save.' : '';
      chgStat.textContent = !off && ct && !(sel === 'change' && ct === str(d.changeText).trim()) ? 'Not saved yet. Press Save.' : '';
      ownSave.textContent = sel === 'own' ? 'Save changes' : 'Save my answer';
      chgSave.disabled = off || !ct || (sel === 'change' && ct === str(d.changeText).trim());
      chgSave.textContent = sel === 'change' ? 'Save changes' : 'Save';

      // the line with Saved / Undo / Next
      var m = liveMsg(), text = '', kind = '', showUndo = false;
      if (m) {
        text = m.text + (m.extra ? ' ' + m.extra : '');
        kind = m.kind === 'error' ? 'bad' : m.kind === 'saving' ? '' : 'ok';
        showUndo = m.kind === 'saved' && !off;
      } else if (d) {
        text = /^[A-D]$/.test(sel) ? '✓ Saved. Pick another ' + (visual ? 'version' : 'answer') + ' to change it.'
          : sel === 'cathy' ? '✓ Sent to the Miss Cathy and Rob list.'
          : sel === 'recheck' ? '✓ Claude will check again and come back.'
          : '✓ Saved. You can change it any time.';
        kind = 'ok';
      }
      if (msgText.textContent !== text) msgText.textContent = text;
      msgEl.className = 'savestat qa-msg ' + kind;
      undoBtn.hidden = !showUndo;
      seeBtn.hidden = !(sel === 'cathy' && (!m || m.kind === 'saved' || m.kind === 'info'));   // the way to the Miss Cathy and Rob list
      var nid = d ? nextId() : null;
      nextBtn.hidden = !d;
      if (d) {
        var st = sectionTitle(q.sectionId);
        nextBtn.textContent = nid ? 'Next question →' : (st ? 'Back to ' + st : 'Back to the list');
      }
      var tipInFoot = noChoices && group.hidden && !!opts.length;
      tip.hidden = off || (tipInFoot && !!d);
      foot.classList.toggle('is-empty', noteOpen && !text && !d && !(tipInFoot && !tip.hidden));
      foot.classList.toggle('has-tip', tipInFoot);
      root.classList.toggle('is-answered', !!d);
    }
    function syncBox(ta, name, saved, act) {
      // saved === null: nothing in the saved answer belongs to this box
      if (saved == null || saved === synced[name]) return;
      if (ta.value.trim() !== synced[name] || act === ta) return;     // never replace what she is typing
      ta.value = saved;
      synced[name] = saved;
    }

    function destroy() {
      if (destroyed) return;
      if (noteTimer) commitNote();
      remember();
      destroyed = true;
      clearTimeout(msgTimer); clearTimeout(noteStatTimer); clearTimeout(noteTimer);
      document.removeEventListener('keydown', onKey);
      QT.off('store', onStore); QT.off('offline', onConn); QT.off('online', onConn);
      if (LIVE[qid] === api) delete LIVE[qid];
    }

    api = { root: root, destroy: destroy, update: update, pick: pickKey, showChoices: showChoices };
    LIVE[qid] = api;
    update();
    return api;
  }

  QT.answerUI = {
    /** Draws every answer control into el. cfg.noChoices: do not draw the A-D row (the pictures have their own pick buttons; the A-D keys still work). */
    render: function (el, q, cfg) {
      if (!el || !q) return function () {};
      if (el.__qtAnswer) { el.__qtAnswer.destroy(); el.__qtAnswer = null; }
      clear(el);
      var inst = createAnswer(q, cfg);
      el.appendChild(inst.root);
      inst.update();
      el.__qtAnswer = inst;
      return function () { inst.destroy(); if (el.__qtAnswer === inst) el.__qtAnswer = null; };
    },
    /** Save answer `key` (A-D) for question q exactly as a click on its button does (Saved + Undo + Next). q may be the question or its id. */
    pick: function (q, key) {
      var id = q && typeof q === 'object' ? q.id : q;
      if (!id || !/^[A-D]$/.test(str(key))) return false;
      var inst = LIVE[id];
      if (inst && inst.root.isConnected) return inst.pick(key);
      // no controls on the page for this question: still save it, quietly
      var qq = q && typeof q === 'object' ? q : coll('questions')[id];
      if (!qq || QT.offline || !QT.write || !QT.write.answer) return false;
      var o = null;
      optionsOf(qq).forEach(function (x) { if (x.key === key) o = x; });
      if (!o) return false;
      var old = coll('answers')[id];
      QT.write.answer(id, { id: id, status: 'answered', key: key, label: o.label, ownText: '', changeText: '', note: old && old.note ? str(old.note) : '', round: qq.round || 1, answeredAt: iso() });
      return true;
    }
  };

  /* ================================================================== SAFETY CHECK CARD (questions in "Downloads and skills")
   * Shown only when the question has a `safety` object. It says what the data says and nothing more: the words come from the document,
   * the chip never says "safe" on its own. All text goes in with textContent (through h()). Fold-outs are closed until she opens them. */
  var VERDICTS = {
    looks_safe: { key: 'looks_safe', cls: 'good', ico: '✓', text: 'Looks safe' },
    mixed: { key: 'mixed', cls: 'warn', ico: '!', text: 'Some good, some bad: read the notes' },
    not_safe: { key: 'not_safe', cls: 'bad', ico: '✗', text: 'Not safe: do not download' },
    unchecked: { key: 'unchecked', cls: '', ico: '?', text: 'Not checked yet' }
  };
  var RUNS = { claude_only: "Only on Claude's side, not on your computer", your_computer: 'On your computer', a_website: 'A website', nothing_to_install: 'Nothing to install' };
  var CHECKS = {
    ok: { mark: '✓', word: 'Passed' }, warn: { mark: '!', word: 'Be careful' }, fail: { mark: '✗', word: 'Failed' }, unknown: { mark: '?', word: 'Could not tell' }
  };
  var CAP = { checks: 15, limits: 12, sources: 10 };      // a page of 200 lines helps nobody: the rest is said in one line
  var FOLDS = Object.create(null);                         // 'qid:fold' -> true while that fold-out is open (a redraw keeps it open)

  function verdictOf(s) { return VERDICTS[str(s && s.verdict)] || VERDICTS.unchecked; }
  function hostOf(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
  function checkedLine(s) {
    var when = s && s.checkedAt && QT.fmt && QT.fmt.ago ? QT.fmt.ago(s.checkedAt) : '';
    var n = Math.round(Number(s && s.round));
    var out = [];
    if (when) out.push('Checked ' + when);
    if (isFinite(n) && n >= 1) out.push((when ? 's' : 'S') + 'afety check number ' + n);
    return out.join(' · ');
  }
  function safetyCard(q) {
    var s = q && q.safety;
    if (!s || typeof s !== 'object' || Array.isArray(s)) return null;
    var qid = q.id, v = verdictOf(s), hid = 'sf-h' + (++uid);
    var checks = arr(s.checks).filter(function (c) { return c && typeof c === 'object'; });
    var limits = arr(s.limits).map(str).filter(function (t) { return t.trim(); });
    var sources = arr(s.sources).filter(function (x) { return x && typeof x === 'object'; });
    var what = str(s.whatItDoes).trim(), runs = RUNS[str(s.whereItRuns)] || '', summary = str(s.summary).trim();
    var notGreen = checks.some(function (c) { return str(c.result) === 'warn' || str(c.result) === 'fail'; });

    var card = h('section', { class: 'card tight sf is-' + v.key, 'aria-labelledby': hid, 'data-sf': 'card' });
    card.appendChild(h('div', { class: 'sf-top' },
      h('h2', { id: hid, class: 'sf-h', text: 'Safety check' }),
      h('span', { class: 'chip sf-verdict ' + v.cls, 'data-sf': 'verdict' }, h('span', { class: 'sf-ico', 'aria-hidden': 'true', text: v.ico }), h('span', { text: v.text }))));
    if (summary) card.appendChild(h('p', { class: 'sf-summary', 'data-sf': 'summary', text: summary }));
    if (v.key === 'looks_safe' && notGreen) card.appendChild(h('p', { class: 'sf-guard', text: 'Some checks below have a ! or ✗. Please read them.' }));
    if (what || runs) {
      card.appendChild(h('dl', { class: 'sf-facts' },
        what ? h('div', null, h('dt', { text: 'What it does' }), h('dd', { 'data-sf': 'what', text: what })) : null,
        runs ? h('div', null, h('dt', { text: 'Where it runs' }), h('dd', { 'data-sf': 'runs', text: runs })) : null));
    }

    function fold(key, title, body) {
      var d = h('details', { class: 'sf-fold', 'data-sf': key }, h('summary', null, h('span', { text: title })), body);
      d.open = !!FOLDS[qid + ':' + key];
      d.addEventListener('toggle', function () { if (d.open) FOLDS[qid + ':' + key] = true; else delete FOLDS[qid + ':' + key]; });
      return d;
    }
    function more(list, cap) { return list.length > cap ? h('p', { class: 'muted small', text: '…and ' + (list.length - cap) + ' more not shown here.' }) : null; }

    if (checks.length) {
      card.appendChild(fold('checks', 'What Claude checked (' + checks.length + ')', h('div', null,
        h('ul', { class: 'sf-checks' }, checks.slice(0, CAP.checks).map(function (c) {
          var kind = CHECKS[str(c.result)] ? str(c.result) : 'unknown', r = CHECKS[kind], note = str(c.note).trim();
          return h('li', { class: 'sf-check is-' + kind },
            h('span', { class: 'sf-mark', 'aria-hidden': 'true', text: r.mark }),
            h('span', { class: 'sf-cbody' }, h('span', { class: 'sf-clabel', text: (str(c.label).trim() || 'A check') + ' – ' + r.word }), note ? h('span', { class: 'sf-note', text: note }) : null));
        })), more(checks, CAP.checks))));
    }
    if (limits.length) {
      card.appendChild(fold('limits', 'What Claude could not check (' + limits.length + ')', h('div', null,
        h('ul', { class: 'sf-limits' }, limits.slice(0, CAP.limits).map(function (t) { return h('li', { text: t }); })), more(limits, CAP.limits))));
    }
    if (sources.length) {
      card.appendChild(fold('sources', 'Where Claude looked (' + sources.length + ')', h('div', null,
        h('ul', { class: 'sf-sources' }, sources.slice(0, CAP.sources).map(function (x) {
          var url = str(x.url).trim(), label = str(x.label).trim(), host = /^https:\/\/[^\s]+$/i.test(url) ? hostOf(url) : '';
          if (!host) return h('li', null, h('span', { text: label || 'A source' }), h('span', { class: 'sf-host muted', text: ' (no link shown)' }));
          return h('li', null,
            h('a', { href: url, target: '_blank', rel: 'noopener noreferrer' }, label || host, h('span', { class: 'sr', text: ' (opens in a new tab)' })),
            label && label !== host ? h('span', { class: 'sf-host muted', text: ' · ' + host }) : null);
        })), more(sources, CAP.sources))));
    }
    var when = checkedLine(s);
    if (when) card.appendChild(h('p', { class: 'sf-when muted small', 'data-sf': 'when', text: when }));
    return card;
  }

  /* ================================================================== THE QUESTION VIEW */
  var WHO ={ kathy: 'Miss Cathy', rob: 'Rob', adviser: 'Their adviser', unknown: 'Not sure who yet', owner: 'You' };

  /* the big picture viewer belongs to the "visual" helper: QT.lightbox.open(items, startIndex, {opener}) */
  function openPictures(images, index, opener) {
    var list = arr(images).filter(function (im) { return im && safeUrl(im.url); });
    if (!list.length || !QT.lightbox || typeof QT.lightbox.open !== 'function') return false;
    try {
      QT.lightbox.open(list.map(function (im) { return { url: im.url, alt: str(im.alt), caption: str(im.caption), w: im.w, h: im.h }; }), index, { opener: opener });
      return true;
    } catch (e) { return false; }
  }

  QT.views.question = function (el, params) {
    var id = params && params.id ? String(params.id) : '';
    var disposed = false, firstBuild = true;
    var q = null, qSig = '';
    var parts = { answer: null, visual: null };
    var crumbsBox = null, crumbsSig = '', metaBox = null, statusBox = null, statusSig = '', bar = null, jumpBtn = null, scrollTick = 0;
    var barChipBox = null, barChipMode = '', whenTimer = 0;

    function hasPickButtons(box) {        // did the picture module draw its own pick buttons? (if not, the A-D row comes back)
      var bs = box.querySelectorAll('button, [role="button"]');
      for (var i = 0; i < bs.length; i++) {
        if (bs[i].hasAttribute('data-pick') || bs[i].hasAttribute('data-pick-key') || /^\s*(pick|choose|select)\b/i.test(bs[i].textContent || '') || /^\s*(pick|choose|select)\b/i.test(bs[i].getAttribute('aria-label') || '')) return true;
      }
      return false;
    }

    function teardown() {
      if (parts.answer) { try { parts.answer(); } catch (e) { /* ignore */ } parts.answer = null; }
      if (parts.visual) { try { parts.visual(); } catch (e) { /* ignore */ } parts.visual = null; }
    }

    function captureFocus() {
      var a = document.activeElement;
      if (!a || !el.contains(a) || !a.getAttribute) return null;
      var fid = a.getAttribute('data-fid');
      if (!fid) return null;
      var f = { fid: fid };
      try { if (typeof a.selectionStart === 'number') { f.s = a.selectionStart; f.e = a.selectionEnd; } } catch (e) { /* not a text box */ }
      return f;
    }
    function restoreFocus(f) {
      if (!f) return;
      var t = el.querySelector('[data-fid="' + (window.CSS && CSS.escape ? CSS.escape(String(f.fid)) : String(f.fid).replace(/["\\]/g, '')) + '"]');
      if (!t || t.disabled || t.hidden) return;
      try { t.focus({ preventScroll: true }); if (f.s != null) t.setSelectionRange(f.s, f.e); } catch (e) { /* ignore */ }
    }

    function notFound() {
      clear(el);
      el.classList.remove('qv-view');
      var off = !!QT.offline;
      add(el, h('div', { class: 'card qv-missing' },
        h('h1', { text: off ? 'No connection, so Claude cannot show this question yet.' : 'This question is not here' }),
        h('p', { class: 'muted', text: off ? 'Please try again in a moment.' : 'It may have moved. Your answers are safe.' }),
        h('div', { class: 'mt-m' }, btn('Back to the start', 'primary', function () { goto('home', {}); }))));
    }

    /* ---------------- sticky bar ---------------- */
    var kBack = null, kPos = null;
    function buildBar() {
      var chip = null;
      var plainRo = q.kind === 'readonly' && (!QT.status || typeof QT.status.state !== 'function' || QT.status.state(id) === 'waiting');
      if (!plainRo && QT.status && typeof QT.status.chip === 'function') {
        try { chip = QT.status.chip(id, { compact: true }); } catch (e) { chip = null; }
      }
      if (plainRo) chip = h('span', { class: 'chip qv-ro-chip' }, eyeIcon(), h('span', { text: 'For someone else to answer' }));
      barChipBox = chip ? h('div', { class: 'qbar-chip' }, chip) : null;
      barChipMode = plainRo ? 'plain' : 'status';
      // the small line above the title: "← Look and feel · Question 2 of 5" (the back link is part of it)
      kBack = h('button', { type: 'button', class: 'qv-link', 'data-fid': 'back' });
      kBack.addEventListener('click', function () { if (q.sectionId) goto('section', { id: q.sectionId }); else goto('home', {}); });
      kPos = h('span', { class: 'qv-pos muted' });
      var imp = q.required ? h('span', { class: 'qv-imp', title: 'Claude needs your answer to this one.', text: 'Important' }) : null;
      return h('div', { class: 'qbar' },
        h('div', { class: 'qbar-main' },
          h('div', { class: 'qbar-kicker qv-kicker' }, kBack, kPos, imp),
          h('h1', { class: 'qbar-title', text: str(q.title), title: str(q.title), tabindex: '-1' })),
        barChipBox);
    }
    /* "Claude saw it ✓" reads "Sent to Miss Cathy and Rob" when she sent this question to their list; every other state keeps the normal chip */
    function paintBarChip() {
      if (!barChipBox || barChipMode === 'plain') return;
      var a = coll('answers')[id], sent = false;
      try { sent = !!a && a.status === 'answered' && a.key === 'cathy' && !!QT.status && typeof QT.status.state === 'function' && QT.status.state(id) === 'seen'; } catch (e) { sent = false; }
      var mode = sent ? 'sent' : 'status';
      if (mode === barChipMode) return;
      barChipMode = mode;
      clear(barChipBox);
      var c = null;
      if (sent) c = h('span', { class: 'chip', 'data-state': 'sent', text: 'Sent to Miss Cathy and Rob' });
      else if (QT.status && typeof QT.status.chip === 'function') { try { c = QT.status.chip(id, { compact: true }); } catch (e) { c = null; } }
      if (c) barChipBox.appendChild(c);
    }
    function updateKicker() {
      if (!kBack || !kPos) return;
      var st = sectionTitle(q.sectionId), full = st;
      if (st && /^Questions for /i.test(st)) st = st.replace(/^Questions for /i, '');       // "← Miss Cathy and Rob": the long name would be cut next to the chip (the menu says it this way too)
      var label = '← ' + (st || 'All questions');
      if (kBack.textContent !== label) kBack.textContent = label;
      if (full && full !== st) kBack.setAttribute('title', full); else kBack.removeAttribute('title');
      var pos = '';
      try {
        var list = QT.sections && QT.sections.questionsOf ? QT.sections.questionsOf(q.sectionId) : null;
        if (list && list.length > 1) {
          for (var i = 0; i < list.length; i++) if (list[i] && list[i].id === id) { pos = '\u00a0· Question ' + (i + 1) + ' of ' + list.length; break; }
        }
      } catch (e) { pos = ''; }
      if (kPos.textContent !== pos) kPos.textContent = pos;
    }

    /* ---------------- small row (only when there is something to show): round, earlier question, topic, "go to the answers" ---------------- */
    function buildCrumbs(box) {
      updateKicker();
      var par = q.parentId ? coll('questions')[q.parentId] : null;
      var sig = JSON.stringify([q.round, q.parentId, par ? str(par.title) : null, q.kind, q.topic]);
      if (sig === crumbsSig) { updateJump(); return; }                        // nothing changed: leave the buttons (and the cursor) alone
      crumbsSig = sig;
      clear(box);
      var rn = Number(q.round) > 1 ? Math.round(Number(q.round)) : (q.parentId ? 2 : 1);
      var why2 = rn === 2 ? 'Claude asked this after your first answer.' : 'Claude asked this after your earlier answers.';
      var round = rn > 1 ? [
        h('span', { class: 'chip info qv-round', title: why2, text: rn <= 10 ? ORDINAL[rn] + ' round' : 'Round ' + rn }),
        h('span', { class: 'muted small qv-round-why', text: why2 })
      ] : null;
      var earlier = null;
      if (par) {
        earlier = h('button', { type: 'button', class: 'qv-link', 'data-fid': 'earlier', title: str(par.title) }, 'See the earlier question');
        earlier.addEventListener('click', function () { goto('question', { id: q.parentId }); });
      }
      var topic = q.kind === 'readonly' && q.topic ? h('span', { class: 'qv-topic', text: str(q.topic) }) : null;
      jumpBtn = null;
      if (q.kind !== 'visual' && q.kind !== 'readonly' && q.kind !== 'chooser') {
        jumpBtn = h('button', { type: 'button', class: 'qv-link', hidden: true, 'data-fid': 'jump' }, 'Go to the answers ↓');
        jumpBtn.addEventListener('click', function () {
          var target = el.querySelector('.qv-answer');
          if (!target) return;
          target.scrollIntoView({ block: 'start' });
          var first = target.querySelector('.qa-choice[tabindex="0"]') || target.querySelector('.qa-choice');
          if (first) { try { first.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
        });
      }
      add(box, [round, earlier, topic, jumpBtn]);
      updateJump();
    }
    /* a long story pushes the answers off the screen: then a small link takes her straight to them */
    function hideEmptyMeta() {            // no small row and no status message: the block goes away and takes its gap with it
      if (!metaBox) return;
      function anyShown(b) { for (var k = b.firstChild; k; k = k.nextSibling) if (!k.hidden) return true; return false; }
      var crumbs = anyShown(crumbsBox), status = anyShown(statusBox);
      crumbsBox.hidden = !crumbs;                               // a row that holds only a hidden "go to the answers" button must not leave a blank strip
      metaBox.hidden = !crumbs && !status;
      if (metaBox.parentNode) metaBox.parentNode.classList.toggle('no-meta', metaBox.hidden);
    }
    function updateJump() {
      if (jumpBtn) {
        var target = el.querySelector('.qv-answer');
        jumpBtn.hidden = !target || !target.isConnected || target.getBoundingClientRect().top < window.innerHeight * 0.8;
      }
      hideEmptyMeta();
    }

    /* ---------------- done / follow-up / working ---------------- */
    function buildStatus() {
      var s = coll('status')[id] || {};
      var state = s.state;
      var follow = '';
      if (state === 'followup') {
        follow = s.followupId ? str(s.followupId) : '';
        if (!follow || !coll('questions')[follow]) {
          var kids = coll('questions'), best = null;
          Object.keys(kids).forEach(function (k) { var c = kids[k]; if (c && c.parentId === id && (!best || str(c.createdAt) > str(best.createdAt))) best = c; });
          follow = best ? best.id : '';
        }
      }
      var imgs = state === 'done' ? arr(s.doneImages).filter(function (im) { return im && safeUrl(im.url); }).slice(0, 6) : [];
      var sig = JSON.stringify([state, s.doneNote, imgs.map(function (i) { return i.url + '|' + i.alt; }), follow, state === 'working' ? s.note : '', s.at]);
      if (sig === statusSig) return;
      statusSig = sig;
      clear(statusBox);
      if (state === 'done') {
        var when = s.at && QT.fmt && QT.fmt.ago ? QT.fmt.ago(s.at) : '';
        var card = h('div', { class: 'card good tight qv-done' },
          h('div', { class: 'row between' }, h('strong', { text: 'Done ✓ This is what Claude did' }), when ? h('span', { class: 'muted small', text: when }) : null),
          s.doneNote ? h('p', { class: 'qv-done-note', text: str(s.doneNote) }) : null);
        if (imgs.length) {
          var row = null;
          if (QT.visual && typeof QT.visual.thumbRow === 'function') {
            try { row = QT.visual.thumbRow(imgs, { label: 'Result' }); } catch (e) { row = null; }
          }
          if (!row) {
            row = h('div', { class: 'qv-thumbs', role: 'group', 'aria-label': 'Pictures of the result' });
            imgs.forEach(function (im, i) {
              var img = h('img', { src: safeUrl(im.url), alt: '', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
              var b = h('button', { type: 'button', class: 'qv-thumb', 'aria-label': 'See the result, picture ' + (i + 1) + ' of ' + imgs.length + (im.alt ? ': ' + str(im.alt) : '') }, img);
              img.addEventListener('error', function () { b.classList.add('is-broken'); b.textContent = 'Picture not available'; });
              b.addEventListener('click', function () { openPictures(imgs, i, b); });
              row.appendChild(b);
            });
          }
          card.appendChild(row);
        }
        statusBox.appendChild(card);
      } else if (state === 'working' && s.note) {
        statusBox.appendChild(h('p', { class: 'qv-working muted' }, h('strong', { text: 'Claude is working on it: ' }), str(s.note)));
      } else if (state === 'followup' && follow) {
        var fb = btn('Open it →', 'small primary', function () { goto('question', { id: follow }); }, { 'data-fid': 'followup' });
        statusBox.appendChild(h('div', { class: 'banner info qv-follow' }, h('span', { class: 'banner-text', text: 'Claude has a follow-up question for you.' }), fb));
      }
    }

    /* ---------------- the text part ---------------- */
    function buildText(readonly) {
      var box = h('div', { class: 'qv-text stack' });
      var paras = arr(q.story).filter(function (p) { return str(p).trim(); }).slice(0, 8).map(function (p) { p = str(p); return p.length > 2000 ? p.slice(0, 2000) + '\u2026' : p; });   // at most 8 paragraphs of about 2000 characters
      if (paras.length) box.appendChild(h('div', { class: 'qv-story stack tight', 'aria-label': 'What is going on' }, paras.map(function (p) { return h('p', { text: str(p) }); })));
      if (!readonly && str(q.why).trim()) {
        box.appendChild(h('div', { class: 'panel qv-why' }, h('p', null, h('strong', { class: 'qv-why-h', text: 'Why Claude is asking: ' }), str(q.why))));
      }
      if (!readonly) { var sf = null; try { sf = safetyCard(q); } catch (e) { sf = null; } if (sf) box.appendChild(sf); }   // only questions that carry a `safety` check
      return box;
    }

    /* ---------------- read-only (questions for Miss Cathy and Rob) ---------------- */
    function buildReadonly(box) {
      var who = Object.prototype.hasOwnProperty.call(WHO, q.who) ? WHO[q.who] : WHO.unknown;
      var info = h('div', { class: 'card qv-ro stack' },
        h('div', { class: 'row qv-ro-who' }, h('span', { class: 'muted', text: 'Who should answer:' }), h('strong', { text: who }),
          q.previouslyNotSure ? h('span', { class: 'chip warn', text: 'You said "not sure" before' }) : null),
        str(q.needs).trim() ? h('div', { class: 'qv-ro-block' }, h('h2', { text: 'What Claude needs from them' }), h('p', { text: str(q.needs) })) : null,
        str(q.why).trim() ? h('div', { class: 'qv-ro-block' }, h('h2', { text: 'Why it matters' }), h('p', { text: str(q.why) })) : null);
      var opts = optionsOf(q);
      if (opts.length) {
        info.appendChild(h('div', { class: 'qv-ro-block' }, h('h2', { text: 'The options Claude was thinking about' }),
          h('ul', { class: 'qv-ro-opts' }, opts.map(function (o) {
            return h('li', null, h('strong', { text: o.key + '. ' }), o.label, o.explain ? h('span', { class: 'muted', text: ' – ' + o.explain }) : null);
          }))));
      }
      box.appendChild(info);
      box.appendChild(h('p', { class: 'muted small qv-ro-note', text: 'This question is for someone else. You can read it, but you do not need to answer it.' }));
      // earlier / next one in the same section, so a long pile can be read in order
      var list = [];
      try { list = QT.sections && QT.sections.questionsOf ? QT.sections.questionsOf(q.sectionId) || [] : []; } catch (e) { list = []; }
      var idx = -1;
      list.forEach(function (x, i) { if (x && x.id === id) idx = i; });
      if (idx >= 0 && list.length > 1) {
        var row = h('div', { class: 'row qv-ro-nav' });
        if (idx > 0) row.appendChild(btn('← Earlier one', 'small', function () { goto('question', { id: list[idx - 1].id }); }, { 'data-fid': 'ro-prev' }));
        if (idx < list.length - 1) row.appendChild(btn('Next one →', 'small', function () { goto('question', { id: list[idx + 1].id }); }, { 'data-fid': 'ro-next' }));
        box.appendChild(row);
      }
    }

    /* ---------------- build everything ---------------- */
    function build() {
      var focus = captureFocus();
      teardown();
      q = coll('questions')[id] || null;
      clear(el);
      if (!q) { qSig = ''; notFound(); return; }
      qSig = JSON.stringify(q);
      statusSig = '';
      crumbsSig = '';
      var readonly = q.kind === 'readonly';
      var visual = q.kind === 'visual';
      var chooser = q.kind === 'chooser';      // the picture chooser (23-chooser.js) draws its own pictures and big button
      el.classList.add('qv-view');

      bar = buildBar();
      crumbsBox = h('div', { class: 'qv-crumbs' });
      statusBox = h('div', { class: 'qv-status' });
      var meta = h('div', { class: 'qv-meta stack tight' }, crumbsBox, statusBox);
      metaBox = meta;
      var text = buildText(readonly);
      var grid = h('div', { class: 'qv-grid ' + (visual ? 'has-pics' : readonly ? 'is-readonly' : chooser ? 'is-chooser' : 'is-choice') }, meta, text);
      var picBox = null;
      if (visual || chooser) { picBox = h('div', { class: 'qv-pics' }); grid.appendChild(picBox); }
      var ans = h('div', { class: 'qv-answer' });
      grid.appendChild(ans);
      add(el, [bar, grid]);
      var picksDrawn = false;      // the pictures draw "Pick A..D" buttons on the thumbnails
      if (picBox && chooser) {
        try { if (!QT.chooser) throw new Error('no chooser'); parts.visual = QT.chooser.render(picBox, q); } catch (e) { clear(picBox); picBox.appendChild(h('p', { class: 'muted', text: 'The pictures could not be shown.' })); }
      } else if (picBox) {
        if (QT.visual && typeof QT.visual.render === 'function') {
          try {
            var r = QT.visual.render(picBox, q, { onPick: function (key) { QT.answerUI.pick(q, key); } });
            if (typeof r === 'function') parts.visual = r;
            picksDrawn = hasPickButtons(picBox);
          } catch (e) { clear(picBox); picBox.appendChild(h('p', { class: 'muted', text: 'The pictures could not be shown.' })); }
        } else picBox.appendChild(h('p', { class: 'muted', text: 'The pictures could not be shown.' }));
      }
      buildCrumbs(crumbsBox);
      buildStatus();
      hideEmptyMeta();
      paintBarChip();
      if (readonly) buildReadonly(ans);
      else if (QT.answerUI && QT.answerUI.render) parts.answer = QT.answerUI.render(ans, q, { noChoices: chooser || (visual && picksDrawn) });
      if (!text.firstChild) text.hidden = true;
      if (firstBuild) { firstBuild = false; try { window.scrollTo(0, 0); } catch (e) { /* ignore */ } }
      restoreFocus(focus);
      updateJump();
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(function () { if (!disposed) updateJump(); });
    }

    /* ---------------- live updates ---------------- */
    function onStore(ev) {
      if (disposed) return;
      var c = ev && ev.collection;
      if (c === 'questions') {
        var now = coll('questions')[id] || null;
        if ((now ? JSON.stringify(now) : '') !== qSig) { build(); return; }
        if (q && crumbsBox) buildCrumbs(crumbsBox);       // another question came or went: the "Question 2 of 5" line may change
      } else if (c === 'sections') {
        if (q && crumbsBox) buildCrumbs(crumbsBox);
      } else if (c === 'status') {
        if (q && statusBox && has(ev.ids, id)) { buildStatus(); hideEmptyMeta(); paintBarChip(); }
      } else if (c === 'answers') {
        if (q && has(ev.ids, id)) paintBarChip();
      }
    }
    QT.on('store', onStore);
    /* "Checked 3 hours ago" in the safety card is reworded once a minute while the question is open */
    whenTimer = setInterval(function () {
      if (disposed) return;
      var w = el.querySelector('.sf-when');
      if (!w || !q || !q.safety) return;
      var t = checkedLine(q.safety);
      if (t && w.textContent !== t) w.textContent = t;
    }, 60000);
    function onScrollOrResize() {
      if (scrollTick || typeof requestAnimationFrame !== 'function') return;
      scrollTick = requestAnimationFrame(function () { scrollTick = 0; if (!disposed) updateJump(); });
    }
    window.addEventListener('resize', onScrollOrResize);

    build();

    return function cleanup() {
      disposed = true;
      clearInterval(whenTimer);
      QT.off('store', onStore);
      window.removeEventListener('resize', onScrollOrResize);
      teardown();
    };
  };
})();
