/* 51-workers.js  (owner: visual)
   The WORKERS part of the Terminal:  QT.views.workers(el, params)   params.focus = a worker id (scrolls to it and flashes it).
   Claude (the boss) -> teams -> helpers as friendly cards; live counters with filters; "Ask this worker" with the
   sent / Claude saw it / answer-bubble flow; "What they did"; "Your questions". Everything she sees is read from QT.store
   (workers, tasks, taskAdds, replies, asks); the only thing this file writes is QT.write.ask().
   Safety: every piece of text from a document goes in through QT.el / textContent. Fold states and the help card are remembered
   in localStorage (always inside try/catch). Respects prefers-reduced-motion (CSS and the counter ticking). */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var el = function () { return QT.el.apply(QT, arguments); };

  var KEY = { help: 'qt.wk.help', folded: 'qt.wk.folded', fin: 'qt.wk.fin', seenAnswers: 'qt.wk.answers' };
  var STATES = ['working', 'waiting', 'resting', 'done', 'stopped'];
  var WORD = { working: 'working', waiting: 'waiting', resting: 'resting', done: 'finished', stopped: 'stopped' };
  var WAIT_FOR = { owner: 'Waiting for you', cathy: 'Waiting for Miss Cathy', rob: 'Waiting for Rob', claude: 'Waiting for Claude', none: 'Waiting' };
  var MAX_ASK = 600;

  /* ---------- small helpers ---------- */
  function str(v) { return v == null ? '' : String(v); }
  function isObj(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
  function own(o, k) { return o && Object.prototype.hasOwnProperty.call(o, k) ? o[k] : undefined; }     // only what is really in the table (not "constructor" and friends)
  function dict() { return Object.create(null); }      // a lookup table keyed by ids from the notebook: an id like "constructor" must not find something that was never put in
  function esc(v) {                                      // an id inside a [data-x="..."] selector
    v = str(v);
    try { if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(v); } catch (e) { /* fall through */ }
    return v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/(["\\])/g, '\\$1');
  }
  function store(coll) { return (QT.store && QT.store[coll]) || {}; }
  function docs(coll) { var o = store(coll); return Object.keys(o).map(function (k) { return o[k]; }).filter(isObj); }
  function ls(op, key, val) {
    try {
      if (QT.storage && typeof QT.storage[op] === 'function') return QT.storage[op](key, val);
      if (op === 'get') return window.localStorage.getItem(key);
      if (op === 'set') window.localStorage.setItem(key, val);
    } catch (e) { /* no storage here: the page still works */ }
    return null;
  }
  function reduced() { try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
  function ago(iso) { try { return iso && QT.fmt && QT.fmt.ago ? QT.fmt.ago(iso) : ''; } catch (e) { return ''; } }
  function time(iso) { return iso ? new Date(iso).getTime() || 0 : 0; }
  function initials(name) {
    var w = str(name).match(/[\p{L}\p{N}]+/gu) || [];
    if (!w.length) return '?';
    return (w[0].charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase();
  }
  /* ONE emoji: short, and not plain letters or digits (else the initials are used) */
  function cleanIcon(v) {
    var s = str(v).trim();
    if (!s || s.length > 12 || /[A-Za-z0-9<>&]/.test(s)) return '';
    return Array.from(s).length <= 4 ? s : '';
  }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }

  /* ---------- tiny drawings (decorative; the words next to them say the same) ---------- */
  var ICON = {
    caret: [['path', { d: 'M9 6l6 6-6 6' }]],
    check: [['path', { d: 'M5 12.5l4.5 4.5L19 7.5' }]],
    clock: [['circle', { cx: 12, cy: 12, r: 8 }], ['path', { d: 'M12 7.5V12l3 2' }]],
    moon: [['path', { d: 'M19.5 14.2A8 8 0 1 1 9.8 4.5a6.4 6.4 0 0 0 9.7 9.7z' }]],
    stop: [['rect', { x: 6.5, y: 6.5, width: 11, height: 11, rx: 2 }]],
    chat: [['path', { d: 'M5 6.5h14v9.5h-8l-4 3v-3H5z' }]],
    send: [['path', { d: 'M4 12l16-7-6 15-2.5-6z' }]],
    list: [['path', { d: 'M8 7h11M8 12h11M8 17h11' }], ['circle', { cx: 4.5, cy: 7, r: 1 }], ['circle', { cx: 4.5, cy: 12, r: 1 }], ['circle', { cx: 4.5, cy: 17, r: 1 }]],
    bolt: [['path', { d: 'M13 3L6 13.5h5L10 21l8-11h-5.2z' }]],
    help: [['circle', { cx: 12, cy: 12, r: 8.5 }], ['path', { d: 'M9.6 9.5a2.5 2.5 0 1 1 3.6 2.2c-.8.4-1.2 1-1.2 1.8M12 16.6v.1' }]]
  };
  function svg(name, size) {
    var s = size || 16;
    return el('svg', { viewBox: '0 0 24 24', width: s, height: s, fill: 'none', stroke: 'currentColor', 'stroke-width': 2.4, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false', class: 'wk-ic' },
      (ICON[name] || []).map(function (p) { return el(p[0], p[1]); }));
  }

  /* ---------- states: words, colours (class names), icon ---------- */
  function stateWord(w) { return w.state === 'waiting' ? (WAIT_FOR[w.waitingFor] || WAIT_FOR.none) : ({ working: 'Working', resting: 'Resting', done: 'Finished ✓', stopped: 'Stopped' }[w.state] || 'Resting'); }
  function stateChip(w) {
    var cls = { working: 'info', waiting: w.waitingFor === 'owner' ? 'accent' : 'warn', resting: 'quiet', done: 'good', stopped: '' }[w.state] || '';
    var kids = [];
    if (w.state === 'working') kids.push(el('span', { class: 'dots', 'aria-hidden': 'true' }, el('i'), el('i'), el('i')));
    else kids.push(svg({ waiting: 'clock', resting: 'moon', done: 'check', stopped: 'stop' }[w.state] || 'moon', 14));
    kids.push(el('span', { text: stateWord(w) }));
    return el('span', { class: ['chip', 'wk-chip', cls], 'data-state': w.state }, kids);
  }
  function strength(w) {
    if (w.brain === 'Opus') return 'Strength: extra strong';
    if (w.brain === 'Sonnet' || w.brain === 'Claude') return 'Strength: standard';
    return '';
  }

  /* ---------- reading the notebook ---------- */
  function normWorker(d) {
    var kind = d.kind === 'lead' || d.kind === 'team' ? d.kind : 'helper';
    var p = typeof d.progress === 'number' && isFinite(d.progress) ? Math.max(0, Math.min(100, d.progress)) : null;
    return {
      id: str(d.id), name: str(d.name).trim() || 'A worker', parentId: d.parentId ? str(d.parentId) : null, kind: kind, icon: cleanIcon(d.icon),
      role: str(d.role).trim(), state: STATES.indexOf(d.state) >= 0 ? d.state : 'resting', now: str(d.now).trim(), waitingFor: str(d.waitingFor),
      startedAt: str(d.startedAt), updatedAt: str(d.updatedAt), finishedAt: str(d.finishedAt),
      activity: (Array.isArray(d.activity) ? d.activity : []).filter(isObj).slice(0, 8).map(function (a) { return { at: str(a.at), text: str(a.text).trim() }; }).filter(function (a) { return a.text; }),
      result: str(d.result).trim(), taskIds: (Array.isArray(d.taskIds) ? d.taskIds : []).map(str).filter(Boolean), brain: str(d.brain), progress: p,
      order: typeof d.order === 'number' ? d.order : 0
    };
  }
  function byOrder(a, b) { return (a.order - b.order) || a.name.localeCompare(b.name); }
  function readCrew() {
    var list = docs('workers').filter(function (d) { return str(d.id); }).map(normWorker).sort(byOrder);
    var byId = dict(), kids = dict(), roots = [];
    list.forEach(function (w) { byId[w.id] = w; });
    // a loop (A under B under A, or a worker under itself) would never end: walk each worker's parents (at most 50 steps) and let the one that comes back to itself stand on top
    list.forEach(function (w) {
      var p = w.parentId, steps = 0;
      while (p && byId[p] && steps++ < 50) { if (p === w.id) { w.parentId = null; break; } p = byId[p].parentId; }
    });
    list.forEach(function (w) {
      if (w.parentId && byId[w.parentId] && w.parentId !== w.id) (kids[w.parentId] = kids[w.parentId] || []).push(w);
      else roots.push(w);
    });
    // anything still not reached from a root (a very long loop): cut it loose and show it as a top one
    var seen = dict();
    function mark(ws) { ws.forEach(function (w) { if (seen[w.id]) return; seen[w.id] = true; mark(kids[w.id] || []); }); }
    mark(roots);
    list.forEach(function (w) {
      if (seen[w.id]) return;
      var sib = kids[w.parentId];
      if (sib) kids[w.parentId] = sib.filter(function (x) { return x !== w; });
      w.parentId = null; roots.push(w);
      mark([w]);
    });
    return { list: list, byId: byId, kids: kids, roots: roots };
  }
  function isHelper(w) { return w.kind === 'helper'; }
  function taskInfo(id) {
    var t = own(store('tasks'), id) || own(store('taskAdds'), id);
    return isObj(t) ? str(t.title).trim() || 'A task' : '';
  }
  function asksFor(kind, id) {
    return docs('asks').filter(function (a) { return a.targetKind === kind && a.targetId === id; }).sort(function (a, b) { return time(a.createdAt) - time(b.createdAt); });
  }
  function replyFor(askId) { var r = own(store('replies'), askId); return isObj(r) ? r : null; }

  /* ---------- the view ---------- */
  QT.views = QT.views || {};
  QT.views.workers = function (root, params) {
    params = params || {};
    var S = {
      filter: 'all', showFin: null, finOpen: false, helpOpen: ls('get', KEY.help) !== 'closed', folded: dict(), askOpen: dict(), didOpen: dict(), qsOpen: dict(), drafts: dict(), msgs: dict(),
      crew: null, lastCounts: null, first: true, focusId: str(params.focus), sig: '', answered: dict(), timer: 0, raf: 0, dead: false
    };
    try { (JSON.parse(ls('get', KEY.folded) || '[]') || []).forEach(function (id) { S.folded[str(id)] = true; }); } catch (e) { /* ignore */ }
    try { (JSON.parse(ls('get', KEY.seenAnswers) || '[]') || []).forEach(function (id) { S.answered[str(id)] = true; }); } catch (e) { /* ignore */ }
    var fin = ls('get', KEY.fin);
    if (fin === '1' || fin === '0') S.showFin = fin === '1';

    var wrap = el('div', { class: 'wk', 'data-part': 'workers' });
    var live = el('div', { class: 'sr', role: 'status', 'aria-live': 'polite' });
    root.appendChild(wrap);
    root.appendChild(live);

    function say(t) { live.textContent = ''; setTimeout(function () { live.textContent = t; }, 30); }
    function saveFolded() { ls('set', KEY.folded, JSON.stringify(Object.keys(S.folded).filter(function (k) { return S.folded[k]; }))); }
    function finalShown(c) { return S.showFin === null ? c.hdone <= 3 : S.showFin; }

    /* ----- counters: EVERY worker (Claude and the teams too), the same number as the badge on the Workers tab; hdone = finished helpers (they are what folds away) ----- */
    function counts(crew) {
      var c = { working: 0, waiting: 0, resting: 0, done: 0, stopped: 0, all: 0, hdone: 0 };
      crew.list.forEach(function (w) { c[w.state]++; c.all++; if (isHelper(w) && w.state === 'done') c.hdone++; });
      return c;
    }
    function tick(node, from, to) {
      if (reduced() || from === to || !window.requestAnimationFrame) { node.textContent = String(to); return; }
      var t0 = 0, dur = 450;
      (function step(ts) {
        if (S.dead || !node.isConnected) { node.textContent = String(to); return; }
        if (!t0) t0 = ts;
        var k = Math.min(1, (ts - t0) / dur);
        node.textContent = String(Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3))));
        if (k < 1) window.requestAnimationFrame(step);
      })(window.performance.now ? window.performance.now() : 0);
    }

    /* ----- one ask (her words + the chip + the answer) ----- */
    function bubbles(w) {
      var asks = asksFor('worker', w.id);
      var list = el('ol', { class: 'wk-thread', 'aria-label': 'Your questions to ' + w.name });
      asks.forEach(function (a) {
        var r = replyFor(a.id), st = r && r.state ? r.state : '';
        var chip;
        if (!r) chip = el('span', { class: 'chip wk-pend', 'data-fid': 'ps-' + a.id }, svg('clock', 14), el('span', { text: 'Sent · waiting for Claude to see it' }));
        else if (st === 'answered') chip = el('span', { class: 'chip good' }, svg('check', 14), el('span', { text: 'Answered' }));
        else if (st === 'working') chip = el('span', { class: 'chip info' }, el('span', { class: 'dots', 'aria-hidden': 'true' }, el('i'), el('i'), el('i')), el('span', { text: 'Claude is working on your question' }));
        else chip = el('span', { class: 'chip wk-seen' }, svg('check', 14), el('span', { text: 'Claude saw it ✓' }));
        var li = el('li', { class: 'wk-ask' },
          el('div', { class: 'wk-bubble wk-me' }, el('p', { class: 'wk-bt', text: str(a.text) }), el('p', { class: 'wk-bw tiny' }, 'You asked · ' + (ago(a.createdAt) || 'just now'))),
          el('div', { class: 'wk-st' }, chip));
        if (r && st === 'answered' && str(r.text).trim()) {
          li.appendChild(el('div', { class: 'wk-bubble wk-them' },
            el('p', { class: 'wk-bw tiny strong', text: 'Answer from ' + (str(r.from).trim() || 'Claude') }),
            el('p', { class: 'wk-bt', text: str(r.text) }),
            el('p', { class: 'wk-bw tiny', text: ago(r.at) })));
        }
        list.appendChild(li);
      });
      return list;
    }

    /* one row of buttons under the card: Ask / What they did / Your questions + task chips; the open parts (form, log, bubbles) go under it */
    function footer(w) {
      var asks = asksFor('worker', w.id);
      var box = el('div', { class: 'wk-ask-area' });
      var open = !!S.askOpen[w.id], qOpen = !!S.qsOpen[w.id], dOpen = !!S.didOpen[w.id];
      // an answer she has not seen yet opens the list once
      var fresh = asks.filter(function (a) { var r = replyFor(a.id); return r && r.state === 'answered' && !S.answered[a.id]; });
      if (fresh.length && S.qsOpen[w.id] !== false) { qOpen = true; S.qsOpen[w.id] = true; }
      if (fresh.length) { fresh.forEach(function (a) { S.answered[a.id] = true; }); ls('set', KEY.seenAnswers, JSON.stringify(Object.keys(S.answered).slice(-200))); }
      var row = el('div', { class: 'wk-actions' });
      row.appendChild(el('button', { type: 'button', class: 'btn small wk-askbtn', 'aria-expanded': String(open), 'data-fid': 'ask-' + w.id, 'aria-label': 'Ask this worker: ' + w.name,
        on: { click: function () { S.askOpen[w.id] = !S.askOpen[w.id]; draw(); focusFid('ta-' + w.id); if (S.askOpen[w.id]) showForm(w.id); } } }, svg('chat', 16), el('span', { text: 'Ask this worker' })));
      if (w.activity.length) {
        row.appendChild(el('button', { type: 'button', class: 'btn small quiet wk-foldbtn', 'aria-expanded': String(dOpen), 'data-fid': 'did-' + w.id,
          on: { click: function () { S.didOpen[w.id] = !dOpen; draw(); focusFid('did-' + w.id); } } },
          el('span', { class: 'wk-caret', 'aria-hidden': 'true' }, svg('caret', 14)), el('span', { text: 'What they did (' + w.activity.length + ')' })));
      }
      if (asks.length) {
        row.appendChild(el('button', { type: 'button', class: 'btn small quiet wk-foldbtn', 'aria-expanded': String(qOpen), 'data-fid': 'qs-' + w.id,
          on: { click: function () { S.qsOpen[w.id] = !qOpen; draw(); focusFid('qs-' + w.id); } } },
          el('span', { class: 'wk-caret', 'aria-hidden': 'true' }, svg('caret', 14)), el('span', { text: 'Your questions (' + asks.length + ')' })));
      }
      var tc = taskChips(w);
      if (tc) row.appendChild(tc);
      box.appendChild(row);
      if (dOpen && w.activity.length) {
        var ul = el('ul', { class: 'wk-log' });
        w.activity.forEach(function (a) { ul.appendChild(el('li', {}, el('span', { class: 'wk-when tiny muted', text: ago(a.at) }), el('span', { class: 'wk-what', text: a.text }))); });
        box.appendChild(ul);
      }
      if (open) {
        var ta = el('textarea', { class: 'wk-ta', rows: 3, maxlength: MAX_ASK, 'data-fid': 'ta-' + w.id, 'aria-label': 'Your question for ' + w.name,
          placeholder: w.state === 'done' ? 'This worker has finished. Claude will answer from their notes.' : 'Ask anything about what ' + w.name + ' is doing.' });
        ta.value = S.drafts[w.id] || '';
        var count = el('span', { class: 'tiny muted wk-count-chars', 'aria-hidden': 'true', text: ta.value.length + ' / ' + MAX_ASK });
        var send = el('button', { type: 'button', class: 'btn primary small', 'data-fid': 'send-' + w.id, disabled: !ta.value.trim(), 'aria-label': 'Send your question to Claude' }, svg('send', 16), el('span', { text: 'Send' }));
        var msg = el('span', { class: 'savestat wk-msg', role: 'status', text: S.msgs[w.id] || '' });
        ta.addEventListener('input', function () { S.drafts[w.id] = ta.value; count.textContent = ta.value.length + ' / ' + MAX_ASK; send.disabled = !ta.value.trim(); if (msg.textContent) { msg.textContent = ''; S.msgs[w.id] = ''; } });
        ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !send.disabled) { e.preventDefault(); send.click(); } });
        send.addEventListener('click', function () { sendAsk(w, ta, send, msg); });
        var cancel = el('button', { type: 'button', class: 'btn quiet small', 'data-fid': 'cancel-' + w.id, on: { click: function () { S.askOpen[w.id] = false; draw(); focusFid('ask-' + w.id); } } }, 'Cancel');
        box.appendChild(el('div', { class: 'wk-form' },
          el('p', { class: 'tiny muted wk-howitgoes', text: 'Your question goes to Claude first, and Claude passes it on.' }),
          ta, el('div', { class: 'wk-formrow' }, count, el('span', { class: 'grow' }), msg, cancel, send)));
      }
      if (asks.length && qOpen) box.appendChild(bubbles(w));
      return box;
    }

    function sendAsk(w, ta, send, msg) {
      var text = ta.value.trim().slice(0, MAX_ASK);
      if (!text) return;
      if (QT.offline) { msg.className = 'savestat bad wk-msg'; msg.textContent = 'No connection. You can read, but questions will not send yet.'; return; }
      if (!QT.write || typeof QT.write.ask !== 'function') { msg.className = 'savestat bad wk-msg'; msg.textContent = 'Asking is not ready yet. Please try again in a minute.'; return; }
      send.disabled = true; msg.className = 'savestat wk-msg'; msg.textContent = 'Sending…';
      var p;
      try { p = QT.write.ask({ targetKind: 'worker', targetId: w.id, text: text }); } catch (e) { p = Promise.reject(e); }
      Promise.resolve(p).then(function () {
        if (S.dead) return;
        S.drafts[w.id] = ''; S.askOpen[w.id] = false; S.qsOpen[w.id] = true; S.msgs[w.id] = '';
        say('Sent. Claude will see your question soon.');
        draw(); focusFid('qs-' + w.id);
      }, function () {
        if (S.dead) return;
        S.msgs[w.id] = 'Not saved. Your words are still here. Please try again.';
        msg.className = 'savestat bad wk-msg'; msg.textContent = S.msgs[w.id]; send.disabled = !ta.value.trim();
      });
    }

    /* ----- one worker card ----- */
    function timesText(w) {
      var bits = [];
      if (w.state === 'done') { var f = ago(w.finishedAt || w.updatedAt); if (f) bits.push('Finished ' + f); }
      else if (w.state === 'stopped') { var s = ago(w.finishedAt || w.updatedAt); if (s) bits.push('Stopped ' + s); }
      else {
        if (w.startedAt && ago(w.startedAt)) bits.push('Started ' + ago(w.startedAt));
        if (w.updatedAt && ago(w.updatedAt)) bits.push('last update ' + ago(w.updatedAt));
      }
      return bits.join(' · ');
    }
    function badge(w, big) {
      return el('span', { class: ['wk-badge', big ? 'is-big' : ''], 'data-state': w.state, 'aria-hidden': 'true' }, el('span', { class: ['wk-face', w.icon ? '' : 'is-ini'], text: w.icon || initials(w.name) }));
    }
    function taskChips(w) {
      var ids = w.taskIds.filter(function (id) { return taskInfo(id); });
      if (!ids.length) return null;
      var row = el('div', { class: 'wk-tasks', role: 'group', 'aria-label': 'Tasks of ' + w.name });
      ids.slice(0, 4).forEach(function (id) {
        row.appendChild(el('a', { href: '#task-' + id, class: 'chip wk-task', 'aria-label': 'Open the task: ' + taskInfo(id),
          on: { click: function (e) { e.preventDefault(); if (QT.route && QT.route.go) QT.route.go('tasks', { focus: id }); } } }, svg('list', 14), el('span', { text: QT.fmt && QT.fmt.clip ? QT.fmt.clip(taskInfo(id), 34) : taskInfo(id) })));
      });
      if (ids.length > 4) row.appendChild(el('span', { class: 'tiny muted', text: '+' + (ids.length - 4) + ' more' }));
      return row;
    }
    function card(w, o) {
      o = o || {};
      var lead = w.kind === 'lead', team = w.kind === 'team';
      var kids = (o.kids || []);
      var hid = 'wk-n-' + w.id;
      var folded = !!S.folded[w.id];
      var head = el('header', { class: 'wk-head' });
      if (lead || team) {
        head.appendChild(el('button', { type: 'button', class: 'wk-fold', 'aria-expanded': String(!folded), 'aria-label': (folded ? 'Open ' : 'Close ') + w.name, 'data-fid': 'fold-' + w.id,
          on: { click: function (e) { toggleFold(w.id, e.currentTarget); } } }, el('span', { class: 'wk-caret', 'aria-hidden': 'true' }, svg('caret', 16))));
      }
      head.appendChild(badge(w, lead));
      head.appendChild(el('div', { class: 'wk-id' },
        el('h3', { class: 'wk-name', id: hid, text: w.name }),
        w.role ? el('p', { class: 'wk-role', text: w.role }) : null));
      head.appendChild(el('div', { class: 'wk-state' }, stateChip(w)));
      var art = el('article', { class: ['wk-card', 'is-' + w.kind, w.state === 'working' ? 'is-busy' : '', S.focusId === w.id ? 'is-focus' : ''], 'data-wid': w.id, 'data-state': w.state, 'aria-labelledby': hid, tabindex: '-1' }, head);
      if ((w.state === 'working' || w.state === 'waiting') && w.now) {
        art.appendChild(el('p', { class: 'wk-now' }, el('span', { class: 'wk-now-l', text: 'Right now:' }), ' ', el('span', { text: w.now })));
      }
      var pre = [];
      if (lead) pre.push('Boss of ' + plural(o.teamCount || 0, 'team', 'teams') + ' and ' + plural(o.helperCount || 0, 'worker', 'workers'));
      else if (team && o.summary) pre.push(o.summary);
      var sr = strength(w);
      if (sr) pre.push(sr);
      var t = timesText(w);
      if (pre.length || t) {
        art.appendChild(el('p', { class: 'wk-line tiny muted' },
          pre.length ? el('span', { class: 'wk-pre', text: pre.join(' · ') + (t ? ' · ' : '') }) : null,
          t ? el('span', { class: 'wk-times', 'data-wid': w.id, text: t }) : null));
      }
      if (w.progress !== null) {
        art.appendChild(el('div', { class: 'wk-barrow' },
          el('div', { class: 'progress wk-bar', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.round(w.progress), 'aria-label': 'How far ' + w.name + ' has got', 'aria-valuetext': Math.round(w.progress) + ' percent' }, el('i', { style: 'width:' + w.progress + '%' })),
          el('span', { class: 'tiny strong', text: Math.round(w.progress) + '%' })));
      }
      if (w.state === 'done' && w.result) art.appendChild(el('div', { class: 'wk-result' }, el('p', { class: 'wk-result-h tiny strong', text: 'What they handed back' }), el('p', { text: w.result })));
      art.appendChild(footer(w));
      if (o.tag) art.appendChild(el('p', { class: 'wk-from tiny muted', text: o.tag }));
      return art;
    }
    function toggleFold(id, btn) {
      S.folded[id] = !S.folded[id];
      saveFolded();
      var li = btn.closest('li'), fold = li && li.querySelector(':scope > .wk-fold-wrap');
      btn.setAttribute('aria-expanded', String(!S.folded[id]));
      var nm = (S.crew && S.crew.byId[id] && S.crew.byId[id].name) || '';
      btn.setAttribute('aria-label', (S.folded[id] ? 'Open ' : 'Close ') + nm);
      if (fold) { fold.setAttribute('data-open', String(!S.folded[id])); fold.inert = !!S.folded[id]; }
    }

    /* ----- the tree ----- */
    function describeKids(kids) {
      var c = { working: 0, waiting: 0, resting: 0, done: 0, stopped: 0 }, n = 0;
      (function walk(ws) { ws.forEach(function (x) { if (isHelper(x)) { c[x.state]++; n++; } walk(S.crew.kids[x.id] || []); }); })(kids);
      var bits = [];
      if (c.working) bits.push(c.working + ' working');
      if (c.waiting) bits.push(c.waiting + ' waiting');
      if (c.resting) bits.push(c.resting + ' resting');
      if (c.done) bits.push(c.done + ' finished');
      if (c.stopped) bits.push(c.stopped + ' stopped');
      return { text: bits.join(' · '), n: n };
    }
    function passes(w, c) {
      if (!isHelper(w)) return true;
      if (S.filter !== 'all') return w.state === S.filter;
      return w.state !== 'done' || finalShown(c);
    }
    function hasVisible(w, c) {   // does this team (or anything below it) have something to show?
      if (isHelper(w)) return passes(w, c);
      return (S.crew.kids[w.id] || []).some(function (k) { return hasVisible(k, c); });
    }
    function node(w, c, depth) {
      var kids = (S.crew.kids[w.id] || []);
      var shown = kids.filter(function (k) { return hasVisible(k, c) || (S.filter === 'all' && !isHelper(k)); });
      var d = describeKids(kids);
      var summary = d.text;
      if (S.filter === 'all' && !finalShown(c) && kids.length) {
        var hiddenDone = kids.filter(function (k) { return isHelper(k) && k.state === 'done'; }).length;
        if (hiddenDone && hiddenDone === kids.length) summary = 'All ' + hiddenDone + ' finished ✓ (see Finished below)';
      }
      var li = el('li', { class: ['wk-li', 'is-' + w.kind], 'data-depth': depth });
      var teamCount = kids.filter(function (k) { return k.kind === 'team'; }).length;
      li.appendChild(card(w, { kids: kids, summary: summary, helperCount: d.n, teamCount: teamCount }));
      if (kids.length) {
        var folded = !!S.folded[w.id];
        var inner = el('ul', { class: ['wk-kids', w.kind === 'lead' ? 'is-teams' : 'is-helpers'], role: 'list', 'aria-label': 'Under ' + w.name });
        shown.forEach(function (k) { inner.appendChild(node(k, c, depth + 1)); });
        if (!shown.length) inner.appendChild(el('li', { class: 'wk-none tiny muted', text: S.filter === 'all' ? 'Nobody to show here right now.' : 'Nobody here right now.' }));
        var fw = el('div', { class: 'wk-fold-wrap', 'data-open': String(!folded) }, inner);
        fw.inert = folded;
        li.appendChild(fw);
      }
      return li;
    }
    function finishedList(c) {
      if (S.filter !== 'all' || finalShown(c) || !c.hdone) return null;
      var done = S.crew.list.filter(function (w) { return isHelper(w) && w.state === 'done'; }).sort(function (a, b) { return time(b.finishedAt || b.updatedAt) - time(a.finishedAt || a.updatedAt); });
      var open = S.finOpen;
      var sec = el('section', { class: 'wk-fin', 'aria-labelledby': 'wk-fin-h' });
      sec.appendChild(el('h2', { class: 'wk-fin-h', id: 'wk-fin-h' }, el('button', { type: 'button', class: 'wk-finbtn', 'aria-expanded': String(open), 'data-fid': 'fin',
        on: { click: function () { S.finOpen = !S.finOpen; draw(); focusFid('fin'); } } },
        el('span', { class: 'wk-caret', 'aria-hidden': 'true' }, svg('caret', 16)), el('span', { text: 'Finished (' + done.length + ')' }), el('span', { class: 'tiny muted wk-fin-sub', text: 'Tap to see what they did' }))));
      if (open) {
        var grid = el('ul', { class: 'wk-grid', role: 'list' });
        done.forEach(function (w) {
          var team = w.parentId && S.crew.byId[w.parentId] ? S.crew.byId[w.parentId].name : '';
          grid.appendChild(el('li', { class: 'wk-li is-helper' }, card(w, { tag: team ? 'Part of ' + team : '' })));
        });
        sec.appendChild(grid);
      }
      return sec;
    }

    /* ----- top: intro, help card, counters ----- */
    function helpCard() {
      if (!S.helpOpen) {
        return el('div', { class: 'wk-helpbar' }, el('button', { type: 'button', class: 'btn small quiet', 'data-fid': 'help', 'aria-expanded': 'false',
          on: { click: function () { S.helpOpen = true; ls('set', KEY.help, 'open'); draw(); focusFid('help-close'); } } }, svg('help', 16), el('span', { text: 'How to read this' })));
      }
      var legend = el('ul', { class: 'wk-legend', role: 'list' });
      [['working', 'Busy right now.'], ['waiting', 'Needs an answer or something from someone.'], ['resting', 'Free and ready for more.'], ['done', 'Finished the task and handed it back.'], ['stopped', 'Stopped early.']].forEach(function (r) {
        var w = { state: r[0], waitingFor: 'owner' };
        legend.appendChild(el('li', {}, stateChip(w), el('span', { class: 'wk-lg-t', text: r[1] })));
      });
      return el('section', { class: 'wk-help card', 'aria-labelledby': 'wk-help-h' },
        el('h2', { id: 'wk-help-h', class: 'wk-help-h' }, svg('help', 18), el('span', { text: 'How to read this' })),
        el('p', { text: 'Claude is the boss of a farm crew. This page shows each worker, what they are doing now, and what they finished.' }),
        el('p', { text: 'You can ask any worker a question. Your question goes to Claude first, and Claude passes it on. Nothing you do here changes your website.' }),
        legend,
        el('div', { class: 'wk-help-foot' }, el('button', { type: 'button', class: 'btn small', 'data-fid': 'help-close',
          on: { click: function () { S.helpOpen = false; ls('set', KEY.help, 'closed'); draw(); focusFid('help'); } } }, 'Got it')));
    }
    function summary(c) {
      var bar = el('div', { class: 'wk-sumbar' });
      var strip = el('div', { class: 'wk-strip', role: 'group', 'aria-label': 'Filter the crew by what they are doing' });
      var ticks = [];
      STATES.forEach(function (s) {
        if (s === 'stopped' && !c.stopped && S.filter !== 'stopped') return;
        var on = S.filter === s;
        var n = el('b', { class: 'wk-n', text: String(c[s]) });
        var from = S.lastCounts ? S.lastCounts[s] : c[s];
        if (from !== c[s]) ticks.push([n, from, c[s]]);
        strip.appendChild(el('button', { type: 'button', class: ['wk-count', 'is-' + s], 'aria-pressed': String(on), 'data-fid': 'flt-' + s, 'data-state': s, 'aria-label': plural(c[s], s === 'done' ? 'finished worker' : WORD[s] + ' worker', s === 'done' ? 'finished workers' : WORD[s] + ' workers') + (on ? ', showing only these' : ''),
          on: { click: function () { S.filter = on ? 'all' : s; draw(); focusFid('flt-' + s); } } }, n, ' ', el('span', { class: 'wk-cw', text: WORD[s] })));
      });
      bar.appendChild(strip);
      if (c.hdone > 0) {
        var shown = finalShown(c);
        var input = el('input', { type: 'checkbox', role: 'switch', checked: shown, 'data-fid': 'showfin', 'aria-label': 'Show finished workers in the crew' });
        input.addEventListener('change', function () { S.showFin = input.checked; ls('set', KEY.fin, input.checked ? '1' : '0'); draw(); focusFid('showfin'); });
        bar.appendChild(el('label', { class: 'switch wk-showfin' }, input, el('span', { class: 'track', 'aria-hidden': 'true' }), el('span', { class: 'lbl', text: 'Show finished' })));
      }
      S.ticks = ticks;
      return bar;
    }

    /* ----- the whole page ----- */
    function emptyState() {
      var off = !!QT.offline;
      return el('div', { class: 'wk-empty card' },
        el('p', { class: 'wk-empty-pic', 'aria-hidden': 'true', text: off ? '📡' : '🌱' }),
        el('h2', { class: 'wk-empty-h', text: off ? 'No connection right now' : 'No crew yet' }),
        el('p', { text: off ? 'The crew cannot be shown until the connection is back. Please try again in a minute.' : 'When Claude has workers, they will show up here.' }),
        off && QT.retry ? el('button', { type: 'button', class: 'btn small', on: { click: function () { try { QT.retry(); } catch (e) { /* ignore */ } } } }, 'Try again') : null);
    }
    function build() {
      var crew = S.crew = readCrew();
      var c = counts(crew);
      var top = el('header', { class: 'wk-top' },
        el('h1', { class: 'wk-title' }, el('span', { class: 'wk-title-pic', 'aria-hidden': 'true', text: '🚜' }), el('span', { text: 'The crew' })),
        el('p', { class: 'wk-intro', text: 'Everyone who works on your website, what they are doing right now, and what they finished.' }));
      var frag = el('div', { class: 'wk-in' }, top, helpCard());
      if (!crew.list.length) { frag.appendChild(emptyState()); S.lastCounts = c; return frag; }
      frag.appendChild(summary(c));
      var tree = el('ul', { class: 'wk-tree', role: 'list', 'aria-label': 'The crew' });
      var any = false;
      crew.roots.forEach(function (r) { if (r.kind === 'lead' || hasVisible(r, c) || S.filter === 'all') { tree.appendChild(node(r, c, 0)); any = true; } });
      if (!any) tree.appendChild(el('li', { class: 'wk-none' }, 'Nobody here right now. ', el('button', { type: 'button', class: 'btn small', on: { click: function () { S.filter = 'all'; draw(); } } }, 'Show everyone')));
      frag.appendChild(tree);
      var f = finishedList(c);
      if (f) frag.appendChild(f);
      return frag;
    }

    /* remember what had the focus (and the typing cursor), draw, give the focus back */
    function activeFid() {
      var a = document.activeElement;
      if (!a || !wrap.contains(a)) return null;
      var f = a.closest && a.closest('[data-fid]');
      if (!f) return null;
      return { fid: f.getAttribute('data-fid'), s: typeof f.selectionStart === 'number' ? f.selectionStart : null, e: typeof f.selectionEnd === 'number' ? f.selectionEnd : null };
    }
    function focusFid(fid, caret) {
      var t = wrap.querySelector('[data-fid="' + esc(fid) + '"]');
      if (t && !t.disabled) { try { t.focus({ preventScroll: false }); if (caret && caret.s != null && t.setSelectionRange) t.setSelectionRange(caret.s, caret.e); } catch (e) { /* ignore */ } }
    }
    function showForm(id) {       // the box she just opened (with the Send button) is brought to the middle of the window, not left at the bottom edge
      var ta = wrap.querySelector('[data-fid="ta-' + esc(id) + '"]'), form = ta && ta.closest ? ta.closest('.wk-form') : null;
      if (!form) return;
      try { form.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' }); } catch (e) { /* ignore */ }
    }
    function draw() {
      if (S.dead) return;
      var keep = activeFid();
      var next = build();
      wrap.textContent = '';
      wrap.appendChild(next);
      wrap.classList.toggle('is-first', S.first);
      if (S.ticks) S.ticks.forEach(function (t) { t[0].textContent = String(t[1]); tick(t[0], t[1], t[2]); });
      S.lastCounts = counts(S.crew);
      if (keep) focusFid(keep.fid, keep);
      if (S.first) { S.first = false; setTimeout(function () { wrap.classList.remove('is-first'); }, 900); }
      if (S.focusId) { var fid = S.focusId; S.focusId = ''; focusWorker(fid); }
    }
    function focusWorker(id) {
      var w = S.crew && S.crew.byId[id];
      if (!w) return;
      var p = w.parentId, changed = false, guard = 0;
      while (p && S.crew.byId[p] && guard++ < 50) { if (S.folded[p]) { S.folded[p] = false; changed = true; } p = S.crew.byId[p].parentId; }
      if (S.filter !== 'all' && S.filter !== w.state) { S.filter = 'all'; changed = true; }
      if (isHelper(w) && w.state === 'done' && S.showFin === null && S.crew.list.filter(function (x) { return isHelper(x) && x.state === 'done'; }).length > 3) { S.showFin = true; changed = true; }
      if (changed) { S.focusId = ''; saveFolded(); draw(); }
      var node = wrap.querySelector('.wk-card[data-wid="' + esc(id) + '"]');
      if (!node) return;
      node.classList.add('is-focus');
      try { node.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' }); node.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
      setTimeout(function () { node.classList.remove('is-focus'); }, 2600);
    }

    /* ----- live: redraw when something relevant changed; keep the "x min ago" words fresh ----- */
    function signature() {
      try { return JSON.stringify([docs('workers'), docs('replies'), docs('asks'), Object.keys(store('tasks')).map(function (k) { return [k, store('tasks')[k] && store('tasks')[k].title]; }), !!QT.offline]); } catch (e) { return String(Math.random()); }
    }
    var WATCH = { workers: 1, replies: 1, asks: 1, tasks: 1, taskAdds: 1 };
    function onStore(ev) {
      if (S.dead || (ev && ev.collection && !WATCH[ev.collection])) return;
      var sg = signature();
      if (sg === S.sig) return;
      S.sig = sg;
      if (S.raf) return;
      S.raf = window.requestAnimationFrame ? window.requestAnimationFrame(function () { S.raf = 0; draw(); }) : setTimeout(function () { S.raf = 0; draw(); }, 16);
    }
    var off = [];
    if (typeof QT.on === 'function') {
      ['store', 'offline', 'online'].forEach(function (evt) { var u = QT.on(evt, onStore); off.push(typeof u === 'function' ? u : function () { if (QT.off) QT.off(evt, onStore); }); });
    }
    S.timer = setInterval(function () {
      if (S.dead) return;
      Array.prototype.forEach.call(wrap.querySelectorAll('.wk-times[data-wid]'), function (n) {
        var w = S.crew && S.crew.byId[n.getAttribute('data-wid')];
        if (w) { var t = timesText(w); if (t && n.textContent !== t) n.textContent = t; }
      });
    }, 30000);

    S.sig = signature();
    draw();
    return function cleanup() {
      S.dead = true;
      clearInterval(S.timer);
      if (S.raf && window.cancelAnimationFrame) window.cancelAnimationFrame(S.raf);
      off.forEach(function (f) { try { f(); } catch (e) { /* ignore */ } });
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
      if (live.parentNode) live.parentNode.removeChild(live);
    };
  };
})();
