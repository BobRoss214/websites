/* 60-speak.js  (owner: layout)  "Read it out loud": a little speaker button next to the text on the whole Terminal.
 *
 *   She clicks a speaker; the words next to it are read out loud and softly highlighted. Click again, press Esc, or leave the view: it stops.
 *   Uses the browser's own voice (window.speechSynthesis). If the browser has none, NOTHING is drawn and nothing breaks.
 *
 *   PRIVACY RULE (safety scout, T/notes/scout/d-local-voices.md): only voices that stay on her computer are ever used.
 *     A voice counts only when voice.localService === true AND its name does not start with "Google" AND does not contain "Online"
 *     (Chrome's "Google ..." voices and Edge's "... Online (Natural)" voices send the words being read to Google / Microsoft).
 *     Best remaining voice for the page language: en-US first, then any other en-*, natural/enhanced names first.
 *     No such voice (list loaded and nothing private in it): NO speaker buttons are drawn, nothing is ever spoken with a cloud voice, and the
 *     Voice switch in the top bar stays visible but greyed out, its tooltip saying why. While Chrome is still loading its voice list
 *     (the "voiceschanged" event, usually under a second) nothing is drawn yet, so the buttons never flash up and vanish.
 *
 *   QT.speak.supported()          -> true when the browser can speak AND a private voice is there (see the rule above)
 *   QT.speak.status()             -> 'ready' | 'loading' (voice list not here yet) | 'none' (no private voice) | 'unsupported' (no speech in this browser)
 *   QT.speak.say(text [, o])      -> start reading `text` (stops anything else first). o = {host: element to highlight, button: its speaker}. Returns true when it started.
 *   QT.speak.stop()               -> stop reading (true when something was being read)
 *   QT.speak.speaking()           -> true while something is being read
 *   QT.speak.button(getText, label [, host]) -> a speaker <button> that reads getText() (a function or a string) when clicked; `label` is its
 *                                    name when idle (default "Read this out loud"); `host` (optional element) gets the highlight.
 *   QT.speak.enabled() / setEnabled(bool)    -> the "Voice buttons" switch in the top bar (remembered; default on). Off = every speaker button is gone.
 *   QT.speak.readFocused()        -> read the block the keyboard focus is in (also on Alt+R)
 *   QT.speak.refresh()            -> look for new text at once (normally a short pause after the page changes)
 *   QT.speak.textOf(element)      -> exactly what would be read for this element (visible text only, no icons, no extra spaces)
 *
 *   HOW THE BUTTONS GET THERE (one generic decorator, nothing in the other modules has to know about it):
 *     * RULES below lists the text blocks of the existing views (page titles, paragraphs, answer choices, notes, worker and task cards, bubbles...).
 *       ONE speaker per block: a story of five paragraphs, a list, a safety card or a worker card gets ONE speaker (rule `group`), read as a whole.
 *       None on small labels, time and meta lines, headings that only name a block, or her own words. The speaker sits at the very end of the block and
 *       is glued to its last word (it can never stand alone on a line).
 *     * data-speak on ANY element = put a speaker next to it (its visible text is read). data-nospeak on any element = never here (and nothing inside it is read).
 *     * One MutationObserver on the app root collects changes and, about 100 ms later, looks only at what was added. A block gets at most one button
 *       (re-made when its view redraws it); a block that went away takes its button along.
 *   Never auto-starts: speech starts only from a click, a key press on a speaker, or Alt+R.
 */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var SP = QT.speak = QT.speak || {};
  if (SP._loaded) return;
  SP._loaded = true;

  var IDLE_LABEL = 'Read this out loud';
  var STOP_LABEL = 'Stop reading';
  var KEY = 'qt.speak';                 // localStorage: '0' = voice buttons off (default on)
  var MAX_CHUNK = 170;                  // characters per spoken piece (Chrome stops a long piece after about 15 seconds)
  var NS = 'http://www.w3.org/2000/svg';

  /* ------------------------------------------------------------------ the browser's voice */
  function synth() {
    try { var s = window.speechSynthesis; return s && typeof s.speak === 'function' && typeof s.cancel === 'function' ? s : null; } catch (e) { return null; }
  }
  function Utter() {
    try { return typeof window.SpeechSynthesisUtterance === 'function' ? window.SpeechSynthesisUtterance : null; } catch (e) { return null; }
  }
  var broken = false;                   // the browser said it cannot speak at all: no more buttons
  function apiOk() { return !broken && !!(synth() && Utter()); }

  function pageLang() {
    var l = '';
    try { l = (document.documentElement.getAttribute('lang') || '').trim(); } catch (e) { /* ignore */ }
    l = (l || 'en-US').replace('_', '-');
    return /^en$/i.test(l) ? 'en-US' : l;
  }
  // PRIVATE voices only: the text of a cloud voice goes over the internet (Google, Microsoft). See the rule at the top of this file.
  function isPrivate(v) {
    if (!v || v.localService !== true) return false;
    var name = String(v.name || '');
    return !/^\s*Google\b/i.test(name) && !/\bOnline\b/i.test(name);
  }
  function allVoices() {
    try { var l = synth().getVoices(); return l ? Array.prototype.slice.call(l) : []; } catch (e) { return []; }
  }
  // the best private voice for the language: exact language (en-US) first, then the same language family (en-*), natural / enhanced names first
  var NOVELTY = /\b(albert|bad news|bahh|bells|boing|bubbles|cellos|deranged|good news|hysterical|jester|organ|superstar|trinoids|whisper|wobble|zarvox|fred|junior|ralph)\b/i;
  function pickVoice(lang) {
    var list = allVoices();
    var want = String(lang).toLowerCase(), primary = want.split('-')[0], best = null, bestScore = -1e9;
    for (var i = 0; i < list.length; i++) {
      var v = list[i];
      if (!isPrivate(v)) continue;
      var vl = String(v.lang || '').toLowerCase().replace('_', '-');
      if (vl.split('-')[0] !== primary) continue;
      var name = String(v.name || ''), score = 0;
      if (vl === want) score += 30;
      if (/natural/i.test(name)) score += 20;
      if (/neural|premium|enhanced|siri/i.test(name)) score += 12;
      if (/samantha|ava|allison|zoe|karen|daniel|serena|moira|david|zira|mark|aria|jenny/i.test(name)) score += 6;
      if (v.default) score += 2;
      if (NOVELTY.test(name)) score -= 100;
      if (score > bestScore) { bestScore = score; best = v; }
    }
    return best;
  }

  /* Is there a private voice?  'loading' until the browser has handed over its list (Chrome does that a moment after the page starts: "voiceschanged").
     The buttons are only drawn in 'ready', so they never flash up and disappear again. */
  var voiceState = 'loading';
  var graceEnd = 0;                     // no "voiceschanged" yet: wait this long for the list
  var listAt = 0;                       // when the browser last said "the voice list changed"
  var pollTimer = 0;
  function checkVoices() {
    var next;
    if (!apiOk()) next = 'loading';
    else if (pickVoice(pageLang())) next = 'ready';
    else {
      // the browser said its list is empty: that is final (a computer with no voices at all). A list with only cloud voices: a moment more, in case the
      // private ones follow. No word from the browser yet: the grace time.
      var until = listAt ? listAt + (allVoices().length ? 500 : 0) : graceEnd;
      next = Date.now() < until ? 'loading' : 'none';
    }
    if (next !== voiceState) { voiceState = next; onVoiceState(); }
    if (voiceState === 'loading' && !pollTimer) pollTimer = setTimeout(function () { pollTimer = 0; checkVoices(); }, 150);
  }
  function onVoicesChanged() { listAt = Date.now(); checkVoices(); }
  SP.status = function () { return !apiOk() ? 'unsupported' : voiceState; };
  SP.supported = function () { return apiOk() && voiceState === 'ready'; };
  SP.NO_VOICE_REASON = 'This computer has no built-in voice, so the speaker buttons are hidden. Claude never uses voices that send your words over the internet.';

  /* ------------------------------------------------------------------ what is on screen, as words */
  var SKIP_TAG = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|SVG|IMG|PICTURE|CANVAS|VIDEO|AUDIO|IFRAME|OBJECT|TEXTAREA|INPUT|SELECT|OPTION|BUTTON|HEAD)$/;
  function shown(el) {
    try {
      if (typeof el.checkVisibility === 'function') return el.checkVisibility({ checkOpacity: false, checkVisibilityCSS: true, contentVisibilityAuto: true });
    } catch (e) { /* older browser */ }
    return el.getClientRects().length > 0;
  }
  function tinyBox(el) {            // the "read by screen readers only" trick: a 1 px clipped box
    var r = el.getClientRects();
    if (!r.length) return true;
    return r[0].width <= 1 && r[0].height <= 1 && getComputedStyle(el).overflow !== 'visible';
  }
  function skipEl(el) {
    if (SKIP_TAG.test(el.tagName.toUpperCase())) return true;
    if (el.hidden || el.hasAttribute('data-nospeak') || el.hasAttribute('inert')) return true;
    if (el.getAttribute('aria-hidden') === 'true') return true;
    var role = el.getAttribute('role');
    if (role === 'img' || role === 'presentation' && el.tagName === 'IMG') return true;
    if (el.classList.contains('qt-speak') || el.classList.contains('sr')) return true;
    if (el.matches && el.matches('.tk-example')) return true;          // the little drawing in the Tasks "How to read this" card
    if (!shown(el)) return true;
    if (tinyBox(el)) return true;
    return false;
  }
  var SYMBOLS = [
    [/[✓✔✗✘✕✖•●○▶▼▲↑↓★☆]/g, ' '],
    [/\s*[·|]\s*/g, ', '],
    [/\s*[→⇒]\s*/g, ' to '],
    [/[←⇐]/g, ' '],
    [/\s*&\s*/g, ' and '],
    [/[“”]/g, '"'],
    [/[‘’]/g, "'"]
  ];
  var EMOJI = /[\p{Extended_Pictographic}\p{Emoji_Modifier}‍︎️⃣\u{1F1E6}-\u{1F1FF}]/gu;
  function clean(raw) {
    var s = String(raw == null ? '' : raw).replace(EMOJI, ' ').replace(/[   ​]/g, ' ');
    for (var i = 0; i < SYMBOLS.length; i++) s = s.replace(SYMBOLS[i][0], SYMBOLS[i][1]);
    var lines = s.split('\n'), out = [];
    for (var j = 0; j < lines.length; j++) {
      var t = lines[j].replace(/\s+/g, ' ').replace(/\s+([,.;:!?])/g, '$1').replace(/^[\s,.;:]+/, '').trim();
      if (/[\p{L}\p{N}]/u.test(t)) out.push(t);
    }
    return out.join('\n');
  }
  function textOf(root) {
    if (!root || root.nodeType !== 1) return '';
    var parts = [];
    try {
      if (!shown(root)) return '';
      (function walk(node) {
        if (node.nodeType === 3) { parts.push(node.nodeValue); return; }
        if (node.nodeType !== 1) return;
        if (node !== root && skipEl(node)) return;
        if (node.tagName === 'BR') { parts.push('\n'); return; }
        if (node.tagName === 'DETAILS' && !node.open) {          // a closed fold-out: only its summary is on the screen
          parts.push('\n');
          for (var d = node.firstChild; d; d = d.nextSibling) if (d.nodeType === 1 && d.tagName === 'SUMMARY') walk(d);
          parts.push('\n');
          return;
        }
        var disp = node === root ? '' : getComputedStyle(node).display, block = disp && !/^(inline|contents)/.test(disp);
        if (block) parts.push('\n');
        for (var c = node.firstChild; c; c = c.nextSibling) walk(c);
        if (block) parts.push('\n');
      })(root);
    } catch (e) { return ''; }
    return clean(parts.join(''));
  }
  SP.textOf = textOf;

  /* ------------------------------------------------------------------ cutting the words into pieces */
  function pieces(text) {
    var out = [];
    text.split('\n').forEach(function (line) {
      if (!line) return;
      if (!/[.!?:;]["')\]]*$/.test(line)) line += '.';
      var sentences = line.split(/(?<=[.!?]["')\]]*)\s+/), cur = '';
      sentences.forEach(function (s) {
        if (s.length > MAX_CHUNK) {
          if (cur) { out.push(cur); cur = ''; }
          hardSplit(s).forEach(function (p) { out.push(p); });
        } else if (cur && cur.length + 1 + s.length > MAX_CHUNK) { out.push(cur); cur = s; }
        else cur = cur ? cur + ' ' + s : s;
      });
      if (cur) out.push(cur);
    });
    return out;
  }
  function hardSplit(s) {           // one very long sentence: at commas first, then at spaces
    var res = [], cur = '';
    s.split(/(?<=[,;:—])\s+/).forEach(function (part) {
      while (part.length > MAX_CHUNK) {
        var cut = part.lastIndexOf(' ', MAX_CHUNK);
        if (cut < 40) cut = MAX_CHUNK;
        if (cur) { res.push(cur); cur = ''; }
        res.push(part.slice(0, cut).trim());
        part = part.slice(cut).trim();
      }
      if (cur && cur.length + 1 + part.length > MAX_CHUNK) { res.push(cur); cur = part; }
      else cur = cur ? cur + ' ' + part : part;
    });
    if (cur) res.push(cur);
    return res;
  }
  SP._pieces = pieces;

  /* ------------------------------------------------------------------ reading */
  var cur = null;                   // {id, host, btn, text, list, i, timer, utter}
  var seq = 0;
  var keep = [];                    // utterances must not be thrown away by the browser before they finish
  var lastErrorToast = 0;

  function setBtnState(btn, on) {
    if (!btn) return;
    var label = on ? STOP_LABEL : (btn._qtIdle || IDLE_LABEL);
    btn.setAttribute('data-state', on ? 'speaking' : 'idle');
    if (btn.tagName === 'BUTTON') { btn.setAttribute('aria-label', label); btn.title = label; }
    else btn.setAttribute('title', label);
  }
  function mark(c, on) {
    var hs = c.hosts && c.hosts.length ? c.hosts : (c.host ? [c.host] : []);     // a block can be several elements (a worker card: name, job, what it does now)
    for (var i = 0; i < hs.length; i++) if (hs[i] && hs[i].classList) hs[i].classList.toggle('qt-speaking', on);
    setBtnState(c.btn, on);
  }
  function clearTimer(c) { if (c && c.timer) { clearTimeout(c.timer); c.timer = 0; } }
  function gone(c) { return !!((c.host && !c.host.isConnected) || (c.btn && !c.btn.isConnected)); }
  function marksOf(btn) { try { return typeof btn._qtMarks === 'function' ? btn._qtMarks() : null; } catch (e) { return null; } }
  function emit(name, data) { try { if (QT.emit) QT.emit(name, data); } catch (e) { /* ignore */ } }

  function finish(c, why) {
    if (cur !== c) return;
    clearTimer(c);
    cur = null;
    keep.length = 0;
    mark(c, false);
    emit('speak', { speaking: false, why: why || 'end' });
  }
  function fail(c, err) {
    var now = Date.now();
    finish(c, 'error');
    if (now - lastErrorToast > 15000) {
      lastErrorToast = now;
      try { if (QT.layout && QT.layout.toast) QT.layout.toast('This computer could not read that out loud. You can still read it on the page.', { kind: 'warn' }); } catch (e) { /* ignore */ }
    }
  }

  function speakPiece(c) {
    if (cur !== c) return;
    var s = synth(), U = Utter();
    if (!s || !U) { finish(c, 'gone'); return; }
    var text = c.list[c.i], u;
    try {
      u = new U(text);
      var v = c.voice || pickVoice(pageLang());
      if (!v) { finish(c, 'novoice'); checkVoices(); return; }       // never fall back to the browser's own pick: it may be a cloud voice
      u.voice = v;
      u.lang = v.lang || pageLang();
      u.rate = 0.95; u.pitch = 1; u.volume = 1;
    } catch (e) { broken = true; fail(c, e); stripButtons(); return; }
    var index = c.i;
    u.onend = function () { if (cur === c && c.i === index) next(c); };
    u.onerror = function (ev) {
      if (cur !== c || c.i !== index) return;
      var err = ev && ev.error;
      if (err === 'canceled' || err === 'interrupted') { finish(c, 'cancelled'); return; }
      fail(c, err);
    };
    c.utter = u;
    keep.push(u);
    try { s.speak(u); } catch (e) { fail(c, e); return; }
    // some browsers lose the "end" notice of a long piece: look again after a while and go on if nothing is being said any more
    clearTimer(c);
    var wait = Math.max(7000, text.length * 130);
    (function watch(n) {
      c.timer = setTimeout(function () {
        if (cur !== c || c.i !== index) return;
        var busy = false;
        try { busy = !!(s.speaking || s.pending); } catch (e) { busy = false; }
        if (busy && n < 8) watch(n + 1); else next(c);
      }, n ? 3000 : wait);
    })(0);
  }
  function next(c) {
    if (cur !== c) return;
    clearTimer(c);
    if (c.i + 1 >= c.list.length) { finish(c, 'end'); return; }
    c.i++;
    speakPiece(c);
  }

  SP.stop = function () {
    var c = cur, was = !!c;
    if (c) { clearTimer(c); cur = null; keep.length = 0; mark(c, false); }
    var s = synth();
    if (s) { try { s.cancel(); } catch (e) { /* ignore */ } }
    if (was) emit('speak', { speaking: false, why: 'stop' });
    return was;
  };
  SP.speaking = function () { return !!cur; };

  SP.say = function (text, o) {
    o = o || {};
    if (!SP.supported()) return false;
    var voice = pickVoice(pageLang());
    if (!voice) return false;               // no private voice: say nothing rather than use a cloud voice
    var t = clean(text);
    if (!t) return false;
    var list = pieces(t);
    if (!list.length) return false;
    var had = !!cur;
    var s = synth();
    if (cur) { var old = cur; clearTimer(old); cur = null; keep.length = 0; mark(old, false); }
    if (s) { try { s.cancel(); } catch (e) { /* ignore */ } }
    var c = { id: ++seq, host: o.host || null, hosts: o.hosts || null, btn: o.button || null, text: t, list: list, i: 0, timer: 0, utter: null, voice: voice };
    cur = c;
    mark(c, true);
    emit('speak', { speaking: true, text: t });
    if (had) setTimeout(function () { if (cur === c) speakPiece(c); }, 50);   // some browsers drop a piece that starts the same moment as a cancel
    else speakPiece(c);
    return true;
  };

  /* ------------------------------------------------------------------ the speaker button */
  function el(tag, cls, attrs) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (attrs) for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  function svgEl(tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  function icon() {
    var s = svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true', focusable: 'false', class: 'qt-sp-ic' });
    var play = svgEl('g', { class: 'qt-sp-play' });
    play.appendChild(svgEl('path', { class: 'qt-sp-body', d: 'M4 9.2h3.3L12.2 5v14l-4.9-4.2H4z' }));
    play.appendChild(svgEl('path', { class: 'qt-sp-wave1', d: 'M15.4 9.3a3.6 3.6 0 0 1 0 5.4' }));
    play.appendChild(svgEl('path', { class: 'qt-sp-wave2', d: 'M18.2 6.6a7.4 7.4 0 0 1 0 10.8' }));
    s.appendChild(play);
    var stop = svgEl('g', { class: 'qt-sp-stop' });
    stop.appendChild(svgEl('rect', { x: '7', y: '7', width: '10', height: '10', rx: '2.2' }));
    s.appendChild(stop);
    return s;
  }
  var proto = null;
  function newButton(tag) {
    if (!proto) { proto = el('button', 'qt-speak', { type: 'button' }); proto.appendChild(icon()); }
    var b;
    if (tag === 'span') {           // inside another button (an answer choice): a picture only, not a second control
      b = el('span', 'qt-speak qt-inbtn', { 'aria-hidden': 'true' });
      b.appendChild(icon());
    } else b = proto.cloneNode(true);
    b._qtIdle = IDLE_LABEL;
    setBtnState(b, false);
    return b;
  }
  SP.button = function (getText, label, host) {
    if (!SP.supported()) { var none = el('span', 'qt-speak-none'); none.hidden = true; return none; }
    var b = newButton('button');
    if (label) { b._qtIdle = String(label); setBtnState(b, false); }
    b._qtGet = typeof getText === 'function' ? getText : function () { return getText; };
    if (host) b._qtHost = host;
    return b;
  };

  function toggle(btn) {
    if (cur && cur.btn === btn) { SP.stop(); return; }
    var text = '';
    try { text = typeof btn._qtGet === 'function' ? btn._qtGet() : ''; } catch (e) { text = ''; }
    if (!clean(text)) { SP.stop(); return; }
    SP.say(text, { host: btn._qtHost || null, hosts: marksOf(btn), button: btn });
  }

  /* one listener for every speaker (nothing to attach, nothing to forget) */
  function onClick(e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var b = t.closest('.qt-speak');
    if (!b) {
      // a speaker drawn inside an answer choice: some browsers send the click to the choice itself, so look at where the pointer is
      var host = t.closest('[data-qt-sp="inbtn"]');
      if (host && e.detail > 0 && host._qtBtn && host._qtBtn.isConnected) {
        var r = host._qtBtn.getBoundingClientRect();
        if (e.clientX >= r.left - 6 && e.clientX <= r.right + 6 && e.clientY >= r.top - 6 && e.clientY <= r.bottom + 6) b = host._qtBtn;
      }
    }
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    toggle(b);
  }
  function onKey(e) {
    if (e.key === 'Escape' || e.key === 'Esc') { if (cur) SP.stop(); return; }
    var t = e.target;
    if (t && t.closest && t.closest('.qt-speak')) {
      // Enter / Space on a speaker must not be taken for "open this card" by a list or a tree around it
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') e.stopPropagation();
      return;
    }
    if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && (e.code === 'KeyR' || e.key === 'r' || e.key === 'R') && SP.enabled() && SP.supported()) {
      if (SP.readFocused()) e.preventDefault();
    }
  }

  /* ------------------------------------------------------------------ which text gets a speaker */
  // RULES: first match wins.  sel = css selector of the block, head = read even when short, place = 'end' (default: last thing inside the block),
  // 'after' (right behind the block), 'qbar' (the sticky question bar), 'inbtn' (a picture inside an answer-choice button), text = custom reader,
  // group = the WHOLE block (a story, a list, a card) is ONE thing: the blocks inside it get no speaker of their own, and the one speaker sits at the end
  // of the last `last` match inside it (default: the block itself); marks = the elements to wash yellow while reading (default: the block); skip = nothing here.
  function cardLines(host, sel) {      // a task in the tree: its title, then the plain words and the live note of the same card
    var card = host.closest(sel);
    var out = [textOf(host)];
    if (card) ['.tk-plain', '.tk-note'].forEach(function (s) { var e = card.querySelector(s); if (e) { var t = textOf(e); if (t) out.push(t); } });
    return out.join('\n');
  }
  function cardMarks(host, sel) {
    var card = host.closest(sel), out = [host];
    if (card) ['.tk-plain', '.tk-note'].forEach(function (s) { var e = card.querySelector(s); if (e) out.push(e); });
    return out;
  }
  function wholeCard(host, sel) {      // a "How to read this" card: one speaker at its heading reads the whole card
    var card = host.closest(sel);
    return card ? textOf(card) : textOf(host);
  }
  function workerParts(host) {         // a worker: ONE speaker reads the name and the job, what the worker does right now, and what they handed back
    var card = host.closest('.wk-card'), out = [host];
    if (card) ['.wk-now', '.wk-result'].forEach(function (s) { var e = card.querySelector(s); if (e) out.push(e); });
    return out;
  }
  function workerLines(host) {
    return workerParts(host).map(function (e) { return textOf(e); }).filter(Boolean).join('\n');
  }
  // time lines, small labels and notes that sit next to a block: never a speaker of their own
  var META = '.tiny, .small.muted, .muted.small, .item-sub, .qt-note, .hint, .sf-when, .sf-host, .wk-name, .wk-line, .wk-times, .wk-pre, .wk-when, .wk-bw, .wk-howitgoes, ' +
    '.tk-meta, .tk-bwho, .pt-bub-name, .pt-bub-foot, .sx-sumstat, .sx-progline, .sx-progress, .qv-round-why, .qv-topic, .qv-ro-note, .qtv-head-label, .chs-peopleline, .chs-galhint';
  var RULES = [
    // left out on purpose: lines that a bigger speaker already reads, time and meta lines, small labels, and her own words (she wrote them)
    { sel: '.tk-how li, .tk-how p, .tk-legend li, .wk-help p, .wk-help li, .wk-legend li, .wk-now, .wk-result, .wk-result p, ' + META +
        ', .wk-me .wk-bt, .tk-bubble.mine .tk-btext, .pt-you .pt-bub-text, .sx-idea-text', skip: true },
    // the question in the sticky bar
    { sel: '.qbar-title', place: 'qbar', head: true },
    // one answer choice: its label, then what happens if she picks it
    { sel: '.qa-choices.is-choice > .qa-choice', place: 'inbtn', text: function (h) {
      var a = h.querySelector('.qa-lab'), b = h.querySelector('.qa-exp');
      return [a ? textOf(a) : '', b ? textOf(b) : ''].filter(Boolean).join('\n');
    } },
    // "How to read this" cards (Tasks, Workers): the speaker at the heading reads the whole card
    { sel: '.tk-how h2', head: true, text: function (h) { return wholeCard(h, '.tk-how'); } },
    { sel: '.wk-help h2', head: true, text: function (h) { return wholeCard(h, '.wk-help'); } },
    // a task in the tree: the speaker at its title reads title + plain words + live note
    { sel: '.tk-card .tk-title', head: true, text: function (h) { return cardLines(h, '.tk-card'); }, marks: function (h) { return cardMarks(h, '.tk-card'); } },
    // a worker: ONE speaker at the end of the job line reads name, job, "Right now" and what they handed back
    { sel: '.wk-card .wk-id', group: true, last: '.wk-role, .wk-name', text: workerLines, marks: workerParts },
    // blocks of text that are ONE thing: a story (all its paragraphs), a safety check, a list of steps, options, limits or checks
    { sel: '.qv-story', group: true, last: 'p' },
    { sel: '.sf', group: true, last: '.sf-summary, .sf-top h2' },
    { sel: '.sx-steps, .sx-needs, .qv-ro-opts', group: true, last: 'li' },
    // only the page title gets a speaker (the other headings just name a block that has its own)
    { sel: 'h1', head: true },
    // plain paragraphs and the text lines the views draw as <div> or <li>
    { sel: 'p' },
    { sel: '.qv-done-note, .qv-working, .sx-empty, .sx-donetext, .sx-donenote' },
    { sel: '.pt-bub-text, .wk-bt, .tk-btext' },
    { sel: '.chs-people-note' },
    { sel: '[data-speak]' }
  ];
  var ALL = RULES.map(function (r) { return r.sel; }).join(',');
  var INNER_ALL = RULES.filter(function (r) { return r.sel !== '[data-speak]' && !r.skip && !r.group; }).map(function (r) { return r.sel; }).join(',');
  var GROUP_ALL = RULES.filter(function (r) { return r.group; }).map(function (r) { return r.sel; }).join(',');
  // never in these places: buttons, links, tabs, menus, counters, small chips, field labels, tiny status lines
  var DENY = 'button, a, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="switch"], [role="progressbar"], summary, label, nav, textarea, select, ' +
    '.chip, .count, .badge-new, .sr, .qt-speak, .toast, .toasts, .savestat, .tk-bar, .progress, .pt-strip, .menu, .qa-tip, [aria-hidden="true"]';

  function ruleFor(host) {
    for (var i = 0; i < RULES.length; i++) { try { if (host.matches(RULES[i].sel)) return RULES[i]; } catch (e) { /* bad selector */ } }
    return null;
  }

  var hostBtn = new WeakMap();      // host -> its speaker
  var root = null;

  function wantsHost(host, rule) {
    if (host.hasAttribute('data-nospeak') || host.closest('[data-nospeak]')) return false;
    var optIn = host.hasAttribute('data-speak');
    if (!optIn && rule.place !== 'inbtn') {
      if (host.closest(DENY)) return false;
      var outer = host.parentElement ? host.parentElement.closest('[data-speak]') : null;
      if (outer) return false;       // the bigger block was asked for as a whole
      if (GROUP_ALL && host.parentElement && host.parentElement.closest(GROUP_ALL)) return false;     // a bigger block (story, card...) is read as ONE
    }
    if (optIn && host.closest('button, [role="button"]') && host.tagName !== 'BUTTON' && !host.closest('[data-qt-sp="inbtn"]')) return false;
    var txt = (host.textContent || '').replace(/\s+/g, ' ').trim();
    if (!txt) return false;
    if (!optIn && !rule.head && !rule.group && rule.place !== 'inbtn') {
      if (txt.length < 12 || txt.indexOf(' ') < 0) return false;
      if (INNER_ALL && host.querySelector(INNER_ALL)) return false;   // it holds smaller text blocks of its own: they get the buttons
    }
    return true;
  }
  function plainEnd(host) {          // can a button be the last thing inside this block without breaking it?
    var cs = getComputedStyle(host);
    if (cs.display === '-webkit-box') return false;
    if (cs.textOverflow === 'ellipsis') return false;
    if (cs.webkitLineClamp && cs.webkitLineClamp !== 'none') return false;
    return true;
  }
  function lastIn(host, sel) {
    try { var all = host.querySelectorAll(sel); return all.length ? all[all.length - 1] : null; } catch (e) { return null; }
  }

  /* The speaker goes at the very end of its block, glued to the last word (a box that cannot break holds the word and the speaker), so it can never
     fall alone on a line. When the block ends in something else than plain words (a link, bold words), the speaker simply comes last. */
  function putAtEnd(anchor, btn) {
    var last = anchor.lastChild;
    while (last && last.nodeType === 3 && !/\S/.test(last.nodeValue)) last = last.previousSibling;
    if (last && last.nodeType === 1 && last.classList.contains('qt-glue')) { last.appendChild(btn); return; }       // made earlier: the same box again
    if (last && last.nodeType === 3) {
      var m = /(\S+)\s*$/.exec(last.nodeValue);
      if (m && m[1].length <= 24) {                // a very long last word (a web address) is not glued: it could not fit a narrow line
        var glue = el('span', 'qt-glue');
        glue.appendChild(document.createTextNode(m[1]));
        last.nodeValue = last.nodeValue.slice(0, m.index);
        glue.appendChild(btn);
        anchor.insertBefore(glue, last.nextSibling);
        // anything after the last word (only blanks) stays behind it
        while (glue.nextSibling && glue.nextSibling.nodeType === 3 && !/\S/.test(glue.nextSibling.nodeValue)) anchor.removeChild(glue.nextSibling);
        return;
      }
    }
    anchor.appendChild(btn);
  }
  function takeOut(btn) {            // remove a speaker; give its box (and the word in it) back to the text
    var par = btn.parentNode;
    btn.remove();
    if (par && par.classList && par.classList.contains('qt-glue')) {
      var host = par.parentNode;
      while (par.firstChild) host.insertBefore(par.firstChild, par);
      host.removeChild(par);
      try { host.normalize(); } catch (e) { /* ignore */ }
    }
  }
  function dropFor(host) { var was = hostBtn.get(host); if (was && was.isConnected) takeOut(was); hostBtn.delete(host); }

  function decorate(host) {
    var rule = host.hasAttribute('data-speak') ? { sel: '[data-speak]', place: host.tagName === 'BUTTON' ? 'after' : 'end' } : ruleFor(host);
    if (!rule) return;
    if (rule.skip) { dropFor(host); return; }
    var old = hostBtn.get(host);
    var place = rule.place || 'end';
    if (old && old.isConnected && (place === 'end' || place === 'inbtn' ? host.contains(old) : old.previousSibling === host)) return;
    if (old && old.isConnected) { if (cur && cur.btn === old) SP.stop(); takeOut(old); }
    if (!wantsHost(host, rule)) { hostBtn.delete(host); return; }
    var anchor = host;
    if (rule.last && place === 'end') anchor = lastIn(host, rule.last) || host;
    if (place === 'end' && !plainEnd(anchor)) {
      if (host.hasAttribute('data-speak') && host.parentNode) place = 'after';
      else { hostBtn.delete(host); return; }
    }
    var btn = newButton(place === 'inbtn' ? 'span' : 'button');
    var getText = rule.text ? function () { return rule.text(host); } : function () { return textOf(host); };
    btn._qtGet = getText;
    btn._qtHost = host;
    if (rule.marks) btn._qtMarks = function () { return rule.marks(host); };
    if (place === 'inbtn') { host.setAttribute('data-qt-sp', 'inbtn'); host._qtBtn = btn; host.appendChild(btn); }
    else if (place === 'qbar') { host.setAttribute('data-qt-sp', 'qbar'); btn.classList.add('qt-qbar'); host.parentNode.insertBefore(btn, host.nextSibling); }
    else if (place === 'after') { btn.classList.add('qt-after'); host.parentNode.insertBefore(btn, host.nextSibling); }
    else putAtEnd(anchor, btn);
    if (host.closest('[role="tree"]')) btn.tabIndex = -1;       // a tree keeps ONE tab stop; Alt+R reads the item the keyboard is on
    hostBtn.set(host, btn);
    // the thing being read was drawn again by its view: carry on with the new copy
    if (cur && cur.btn && !cur.btn.isConnected && cur.text === clean(getText())) { cur.btn = btn; cur.host = host; cur.hosts = marksOf(btn); mark(cur, true); }
  }

  function scan(top) {
    if (!top || top.nodeType !== 1 || !top.isConnected) return;
    var list = [];
    try {
      if (top.matches(ALL)) list.push(top);
      var found = top.querySelectorAll(ALL);
      for (var i = 0; i < found.length; i++) list.push(found[i]);
      // something inside a story / card was drawn again: the block as a whole looks at where its speaker belongs
      var bigger = GROUP_ALL && top.parentElement ? top.parentElement.closest(GROUP_ALL) : null;
      if (bigger && list.indexOf(bigger) < 0) list.push(bigger);
    } catch (e) { return; }
    for (var j = 0; j < list.length; j++) { try { decorate(list[j]); } catch (e) { /* one odd block must not stop the others */ } }
  }

  function stripButtons() {
    var all = document.querySelectorAll('.qt-speak');
    for (var i = 0; i < all.length; i++) takeOut(all[i]);
    var hosts = document.querySelectorAll('[data-qt-sp]');
    for (var k = 0; k < hosts.length; k++) { hosts[k].removeAttribute('data-qt-sp'); hosts[k]._qtBtn = null; }
    hostBtn = new WeakMap();
  }

  /* ------------------------------------------------------------------ watching the page */
  var dirty = [];
  var timer = 0;
  var observer = null;

  function flush() {
    timer = 0;
    if (!SP.enabled() || !SP.supported()) { dirty = []; installSwitch(root); return; }
    var list = dirty; dirty = [];
    if (list.length > 150 && root) list = [root];
    installSwitch(root);
    var seen = [];
    for (var i = 0; i < list.length; i++) {
      var n = list[i];
      if (seen.indexOf(n) >= 0) continue;
      // a parent that is going to be scanned anyway covers its children
      var covered = false;
      for (var j = 0; j < list.length; j++) if (j !== i && list[j] !== n && list[j].contains(n)) { covered = true; break; }
      if (covered) continue;
      seen.push(n);
      scan(n);
    }
    if (cur && gone(cur)) {
      // the text being read is gone (its view was redrawn): if the same words are still somewhere, go on, else stop
      var again = false;
      if (root) {
        var all = root.querySelectorAll('.qt-speak');
        for (var k = 0; k < all.length && !again; k++) {
          var b = all[k];
          if (b._qtGet && b._qtHost && b._qtHost.isConnected) { try { if (clean(b._qtGet()) === cur.text) { cur.btn = b; cur.host = b._qtHost; cur.hosts = marksOf(b); mark(cur, true); again = true; } } catch (e) { /* ignore */ } }
        }
      }
      if (!again) SP.stop();
    }
  }
  function schedule() { if (!timer) timer = setTimeout(flush, 100); }
  SP.refresh = function () {
    if (!root || !SP.enabled() || !SP.supported()) return;
    dirty.push(root);
    if (timer) clearTimeout(timer);
    flush();
  };

  function isMine(n) { return n.nodeType === 1 && (n.classList.contains('qt-speak') || n.classList.contains('qt-glue') || n.classList.contains('qt-voice-btn')); }
  function onMutations(recs) {
    var work = false;
    for (var i = 0; i < recs.length; i++) {
      var r = recs[i], a, n;
      for (a = 0; a < r.addedNodes.length; a++) {
        n = r.addedNodes[a];
        if (isMine(n)) continue;
        if (n.nodeType === 1) { dirty.push(n); work = true; }
        else if (n.nodeType === 3 && r.target.nodeType === 1 && n.nodeValue.trim()) { dirty.push(r.target); work = true; }
      }
      if (cur) for (a = 0; a < r.removedNodes.length; a++) { if (!isMine(r.removedNodes[a])) { work = true; break; } }
    }
    if (work) schedule();
  }

  /* ------------------------------------------------------------------ on / off, and the switch in the top bar */
  var on = true;
  try { on = window.localStorage.getItem(KEY) !== '0'; } catch (e) { on = true; }
  var voiceBtn = null;

  SP.enabled = function () { return !!on; };
  SP.setEnabled = function (v) {
    v = !!v;
    if (v === on) { refreshSwitch(); return on; }
    on = v;
    try { window.localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) { /* not remembered */ }
    document.documentElement.classList.toggle('qt-speak-off', !on);
    if (!on) { SP.stop(); stripButtons(); }
    else SP.refresh();
    refreshSwitch();
    emit('speakswitch', { enabled: on });
    return on;
  };

  function switchIcon(off) {
    var s = svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true', focusable: 'false', class: 'ic' });
    s.appendChild(svgEl('path', { d: 'M4 9.2h3.3L12.2 5v14l-4.9-4.2H4z' }));
    if (off) s.appendChild(svgEl('path', { d: 'M16 9.5l5 5M21 9.5l-5 5' }));
    else { s.appendChild(svgEl('path', { d: 'M15.4 9.3a3.6 3.6 0 0 1 0 5.4' })); s.appendChild(svgEl('path', { d: 'M18.2 6.6a7.4 7.4 0 0 1 0 10.8' })); }
    return s;
  }
  function refreshSwitch() {
    if (!voiceBtn) return;
    var none = voiceState === 'none';
    var isOn = on && !none;
    var word = isOn ? 'Voice: on' : 'Voice: off';
    voiceBtn.setAttribute('aria-pressed', isOn ? 'true' : 'false');
    if (none) voiceBtn.setAttribute('aria-disabled', 'true'); else voiceBtn.removeAttribute('aria-disabled');
    voiceBtn.classList.toggle('is-na', none);
    voiceBtn.setAttribute('aria-label', word + '. ' + (none ? SP.NO_VOICE_REASON : 'Little speaker buttons read the words out loud.'));
    voiceBtn.title = none ? 'Voice buttons: off. ' + SP.NO_VOICE_REASON
      : 'Voice buttons: ' + (on ? 'on' : 'off') + '. ' + (on ? 'Click to hide the little speakers.' : 'Click to show little speakers that read words out loud.') + ' Tip: Alt+R reads the place you are on.';
    var lbl = voiceBtn.querySelector('.lbl');
    if (lbl) lbl.textContent = word;
    var old = voiceBtn.querySelector('svg');
    if (old) old.replaceWith(switchIcon(!isOn));
  }
  // drawn when the voice list is known: 'ready' (normal) or 'none' (greyed out, the tooltip says why). Not while it is still 'loading'.
  function installSwitch(appRoot) {
    if (!apiOk() || (voiceState !== 'ready' && voiceState !== 'none')) return;
    var bar = (appRoot || document).querySelector('.topbar');
    if (!bar) return;
    if (voiceBtn && voiceBtn.isConnected) return;
    var existing = bar.querySelector('.qt-voice-btn');
    if (existing) { voiceBtn = existing; refreshSwitch(); return; }
    voiceBtn = el('button', 'btn qt-voice-btn tgl', { type: 'button' });      // "tgl": the top bar's shared on/off switch look (10-layout.css), the same as the Sound switch
    voiceBtn.appendChild(switchIcon(!on));
    voiceBtn.appendChild(el('span', 'lbl'));
    voiceBtn.addEventListener('click', function () {
      if (voiceState === 'none') {
        try { if (QT.layout && QT.layout.toast) QT.layout.toast(SP.NO_VOICE_REASON, { kind: 'info', ms: 8000 }); } catch (e) { /* ignore */ }
        return;
      }
      SP.setEnabled(!on);
    });
    var sound = bar.querySelector('.sound-btn');
    if (sound && sound.parentNode === bar) bar.insertBefore(voiceBtn, sound.nextSibling);
    else { var test = bar.querySelector('.test-btn'); if (test && test.parentNode === bar) bar.insertBefore(voiceBtn, test); else bar.appendChild(voiceBtn); }
    refreshSwitch();
  }
  // the voice list changed state (arrived / nothing private in it / gone)
  function onVoiceState() {
    if (voiceState === 'ready') {
      installSwitch(root); refreshSwitch();
      if (on && root) SP.refresh();
    } else {
      SP.stop();
      stripButtons();
      if (voiceState === 'none') { installSwitch(root); refreshSwitch(); }
      else if (voiceBtn && voiceBtn.isConnected) { voiceBtn.remove(); voiceBtn = null; }
    }
    emit('speakvoices', { state: voiceState });
  }

  /* Alt+R and the keyboard: read the block the focus is in (or, on a whole card/tree item, the text lines in it) */
  SP.readFocused = function () {
    var a = document.activeElement;
    if (!a || a === document.body || !SP.supported() || !SP.enabled()) return false;
    if (cur) { SP.stop(); return true; }
    var host = null, n = a;
    while (n && n.nodeType === 1 && n !== document.body) {
      var b = hostBtn.get(n);
      if (b && b.isConnected) { host = n; break; }
      n = n.parentElement;
    }
    var texts = [];
    if (host) texts.push(hostBtn.get(host)._qtGet());
    else {                                        // a whole card / tree item: its own text lines, not the ones of the items below it
      var inner = a.querySelectorAll('.qt-speak');
      for (var i = 0; i < inner.length && texts.length < 6; i++) {
        var nested = inner[i].closest('[role="treeitem"], [role="group"], article');
        if (nested && nested !== a && a.contains(nested)) continue;
        if (inner[i]._qtGet) texts.push(inner[i]._qtGet());
      }
    }
    var joined = texts.join('\n');
    if (!clean(joined)) return false;
    var btn = host ? hostBtn.get(host) : null;
    return SP.say(joined, { host: host, hosts: btn ? marksOf(btn) : null, button: btn });
  };

  /* ------------------------------------------------------------------ start */
  function start() {
    if (!apiOk()) return;
    root = document.getElementById('app') || document.body;
    document.documentElement.classList.toggle('qt-speak-off', !on);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('pagehide', function () { SP.stop(); });
    try { if (QT.on) QT.on('route', function () { SP.stop(); }); } catch (e) { /* ignore */ }
    try {
      observer = new MutationObserver(onMutations);
      observer.observe(root, { childList: true, subtree: true });
    } catch (e) { observer = null; }
    // the voice list: Chrome hands it over a moment later ("voiceschanged"); until then (or until the grace time is over) nothing is drawn
    var grace = Number(window.QT_SPEAK_GRACE);
    graceEnd = Date.now() + (isFinite(grace) && grace >= 0 ? grace : 1500);
    var s = synth();
    try { if (s.addEventListener) s.addEventListener('voiceschanged', onVoicesChanged); else s.onvoiceschanged = onVoicesChanged; } catch (e) { /* the timer still looks */ }
    document.addEventListener('visibilitychange', function () { if (!document.hidden) checkVoices(); });
    checkVoices();
    installSwitch(root);
    if (on && SP.supported()) SP.refresh();
  }

  // the switch goes in when the layout has drawn the top bar (the layout file stays as it is: we wrap its mount, like the tab strip does)
  if (QT.layout && typeof QT.layout.mount === 'function' && !QT.layout.mount._speak) {
    var origMount = QT.layout.mount;
    QT.layout.mount = function (appRoot) {
      var out = origMount.apply(this, arguments);
      try { installSwitch(appRoot); if (root && on && SP.supported()) SP.refresh(); } catch (e) { /* the page works without the switch */ }
      return out;
    };
    QT.layout.mount._speak = true;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
