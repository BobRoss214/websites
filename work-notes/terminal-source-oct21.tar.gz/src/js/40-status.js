/* 40-status.js  (owner: "status" helper)
 * Status chips, heartbeat label, sound, tab-title count, NEW badges, "Test connection" and the automatic ping.
 * Attaches QT.status and QT.sound.  Everything here is guarded: a missing piece of QT, localStorage, Web Audio or
 * window.claude must never throw into the page.  All document text goes in with textContent (never innerHTML).
 */
(function () {
  'use strict';

  var QT = (window.QT = window.QT || {});
  var status = (QT.status = QT.status || {});
  var sound = (QT.sound = QT.sound || {});

  var HEARTBEAT_STALE_MS = 20 * 60 * 1000;   // older than this: "Claude may be busy"
  var PING_GAP_MS = 20 * 1000;               // at most one automatic ping per 20 s
  var CHIME_GAP_MS = 4 * 1000;               // at most one chime per 4 s
  var DING_GAP_MS = 400;                     // her "answer saved" ding: every answer gets one, but not a machine gun
  var PARTY_GAP_MS = 3 * 1000;               // the celebration at most once per 3 s
  var CUT = 120;                             // longest line we ever send to Claude
  var TEST_TEXT = 'Question Terminal test ping';
  var MSG_OK = 'Claude heard you ✓';
  var MSG_FAIL = 'Claude did not hear this one. That is OK. Claude still finds your answers every few minutes.';
  var MSG_SLOW = 'Please wait a moment and try again.';
  var MSG_WORKING = 'Checking… If a box asks to allow this, click Allow.';

  /* ------------------------------------------------------------------ small helpers */
  function noop() {}
  function coll(name) { return (QT.store && QT.store[name]) || {}; }
  function ts(iso) { var t = Date.parse(iso); return isNaN(t) ? NaN : t; }
  function str(v) { return typeof v === 'string' ? v : (v == null ? '' : String(v)); }
  function emit(evt, data) { try { if (typeof QT.emit === 'function') QT.emit(evt, data); } catch (e) { /* ignore */ } }

  function h(tag, cls, text) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    if (text != null && text !== '') el.textContent = text;
    return el;
  }

  var memStore = {};
  function lsGet(k) {
    try { var v = window.localStorage.getItem(k); if (v !== null) return v; } catch (e) { /* blocked */ }
    return Object.prototype.hasOwnProperty.call(memStore, k) ? memStore[k] : null;
  }
  function lsSet(k, v) {
    memStore[k] = v;
    try { window.localStorage.setItem(k, v); } catch (e) { /* blocked: the in-memory copy keeps this visit consistent */ }
  }

  function cut(s, n) {
    s = str(s).replace(/\s+/g, ' ').trim();
    if (s.length <= n) return s;
    var c = s.slice(0, n - 1);
    var sp = c.lastIndexOf(' ');
    if (sp > n * 0.6) c = c.slice(0, sp);
    return c.replace(/[\s,.;:–-]+$/, '') + '…';
  }

  function fmtTime(iso) {
    try { if (QT.fmt && typeof QT.fmt.time === 'function') return str(QT.fmt.time(iso)); } catch (e) { /* fall through */ }
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    try { return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; }
  }

  function fmtAgo(iso, now) {
    var t = ts(iso);
    if (isNaN(t)) return '';
    if (t > now) return 'just now';                       // a clock that is a little ahead must not say "in 3 min"
    try { if (QT.fmt && typeof QT.fmt.ago === 'function') { var r = str(QT.fmt.ago(iso)); if (r) return r; } } catch (e) { /* own fallback below */ }
    var m = Math.floor((now - t) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + ' min ago';
    var hr = Math.floor(m / 60);
    if (hr < 24) return hr + (hr === 1 ? ' hour ago' : ' hours ago');
    var d = Math.floor(hr / 24);
    return d + (d === 1 ? ' day ago' : ' days ago');
  }

  var SVGNS = 'http://www.w3.org/2000/svg';
  var ICONS = {
    circle: [['circle', { cx: 8, cy: 8, r: 5.2 }]],
    clock: [['circle', { cx: 8, cy: 8, r: 5.8 }], ['path', { d: 'M8 4.8V8l2.3 1.6' }]],
    pause: [['path', { d: 'M5.6 4.2v7.6M10.4 4.2v7.6', 'stroke-width': 2.2 }]],
    chat: [['path', { d: 'M3 3.6h10v6.8H8.6L5.6 13v-2.6H3z', 'stroke-linejoin': 'round' }]]
  };
  function icon(kind) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 16 16');
    s.setAttribute('width', '14');
    s.setAttribute('height', '14');
    s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '1.6');
    s.setAttribute('stroke-linecap', 'round');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('focusable', 'false');
    s.setAttribute('class', 'qt-ico');
    (ICONS[kind] || []).forEach(function (p) {
      var e = document.createElementNS(SVGNS, p[0]);
      Object.keys(p[1]).forEach(function (k) { e.setAttribute(k, p[1][k]); });
      s.appendChild(e);
    });
    return s;
  }

  /* ------------------------------------------------------------------ the state machine */
  var STATES = { seen: 1, working: 1, done: 1, followup: 1, held: 1 };

  /** 'waiting' | 'answeredUnseen' | 'seen' | 'working' | 'done' | 'followup' | 'held' */
  function stateOf(qid) {
    var a = coll('answers')[qid];
    var s = coll('status')[qid];
    var named = s && STATES[s.state] === 1 ? s.state : null;
    if (a) {
      // Claude has "looked" at the answer when status.seenAt (or, if Claude never wrote seenAt, status.at) is not older than the answer
      var aT = ts(a.answeredAt);
      var seenT = s ? ts(s.seenAt) : NaN;
      if (isNaN(seenT) && s) seenT = ts(s.at);
      if (!s || (!isNaN(aT) && (isNaN(seenT) || aT > seenT))) return 'answeredUnseen';
      return named || 'seen';
    }
    // no answer: Claude may still show that it is working on / finished / paused something
    if (named && named !== 'seen') return named;
    return 'waiting';
  }

  function isAnswerable(q) {
    if (!q || q.kind === 'readonly' || q.sectionId === 'kathy') return false;
    var sec = coll('sections')[q.sectionId];
    return !!sec && !sec.archived && !sec.readOnly;
  }

  /** A question the owner can still answer: answerable, no answer yet, and Claude has not closed it. */
  function needsAnswer(q) {
    if (!isAnswerable(q)) return false;
    if (coll('answers')[q.id]) return false;
    var s = coll('status')[q.id];
    return !(s && s.state === 'done');
  }

  function badgeCount(sectionId) {
    var qs = coll('questions'), n = 0;
    Object.keys(qs).forEach(function (id) {
      var q = qs[id];
      if (!q) return;
      if (!q.id) q = Object.assign({ id: id }, q);
      if (sectionId != null && q.sectionId !== sectionId) return;
      if (needsAnswer(q)) n++;
    });
    return n;
  }

  /** {text, stale, ...}.  text = "Claude last checked for your answers 5 min ago", plus " (Claude may be busy. Your answers are safe.)" when older than 20 min.
   *  Pieces for a layout that wants to shorten it: lead (words before the time), when ("5 min ago"), short ("Claude: 5 min ago"), hint (the bracket), tip (hover words). */
  function heartbeatLabel() {
    var hb = coll('meta').heartbeat;
    var t = hb ? ts(hb.at) : NaN;
    if (isNaN(t)) {
      var none = 'Claude has not checked for your answers yet';
      return { text: none, base: none, lead: none, when: '', short: 'Claude has not checked yet', hint: '', tip: 'Claude looks for your answers every few minutes.', stale: false, ageMin: null, at: null };
    }
    var now = Date.now();
    var age = Math.max(0, now - t);
    var lead = 'Claude last checked for your answers';
    var when = fmtAgo(hb.at, now);
    var base = lead + ' ' + when;
    var stale = age > HEARTBEAT_STALE_MS;
    var hint = stale ? '(Claude may be busy. Your answers are safe.)' : '';
    return {
      text: stale ? base + ' ' + hint : base, base: base, lead: lead, when: when, short: 'Claude: ' + when, hint: hint,
      tip: stale ? 'Claude may be busy. Your answers are safe and Claude will read them soon.' : 'Claude looks for your answers every few minutes.',
      stale: stale, ageMin: Math.floor(age / 60000), at: hb.at
    };
  }

  /* ------------------------------------------------------------------ live widgets (chip, NEW badge, heartbeat) */
  // One shared list of widgets that are on the page.  A widget joins when it is attached and leaves when it is detached,
  // so nothing is left listening after a view is thrown away.
  var live = new Set();
  var tickTimer = null;

  function startTick() {
    if (tickTimer || typeof setInterval !== 'function') return;
    tickTimer = setInterval(function () {
      live.forEach(function (w) { if (w._tick) safe(w._refresh, w); });
    }, 30000);
  }
  function stopTick() {
    if (!tickTimer) return;
    var need = false;
    live.forEach(function (w) { if (w._tick) need = true; });
    if (!need) { clearInterval(tickTimer); tickTimer = null; }
  }
  function safe(fn, self, arg) { try { if (fn) fn.call(self, arg); } catch (e) { /* a widget must never break the page */ } }

  var CE = window.customElements;
  var defined = {};
  function widget(tag) {
    // Returns a new element of the given tag.  With custom elements the browser tells us when it is attached/detached.
    if (CE && typeof CE.define === 'function') {
      if (!defined[tag]) {
        defined[tag] = true;
        if (!CE.get(tag)) {
          CE.define(tag, class extends HTMLElement {
            connectedCallback() { live.add(this); safe(this._refresh, this); if (this._tick) startTick(); }
            disconnectedCallback() { live.delete(this); stopTick(); }
          });
        }
      }
      return document.createElement(tag);
    }
    // very old browser: plain element; it is dropped from the list the first time it is found detached after having been attached
    var el = document.createElement(tag);
    el._legacy = true;
    live.add(el);
    return el;
  }

  function onStoreForWidgets(e) {
    live.forEach(function (w) {
      if (w._legacy) {
        if (w.isConnected) w._wasIn = true;
        else if (w._wasIn) { live.delete(w); return; }
      }
      if (!w.isConnected && !w._legacy) return;
      if (w._onStore) safe(w._onStore, w, e); else safe(w._refresh, w);
    });
  }

  /* ---- the chip */
  var CHIP = {
    waiting:        { cls: 'chip accent', ico: 'circle', text: 'Waiting for you',                               tip: 'Claude is waiting for your answer.' },
    answeredUnseen: { cls: 'chip qt-unseen', ico: 'clock',  text: 'You answered · waiting for Claude to see it', tip: 'Your answer is saved. Claude has not looked at it yet.' },
    seen:           { cls: 'chip',        ico: null,     text: 'Claude saw it ✓',                          tip: 'Claude saw your answer.' },
    working:        { cls: 'chip info',   ico: null,     text: 'Claude is working on it',                                 tip: 'Claude is working on this.' },
    done:           { cls: 'chip good',   ico: null,     text: 'Done ✓',                                   tip: 'Claude finished this.' },
    followup:       { cls: 'chip warn',   ico: 'chat',   text: 'Claude has a follow-up question',               tip: 'Claude has another question about this.' },
    held:           { cls: 'chip',        ico: 'pause',  text: 'Paused – you asked Claude to wait',                 tip: 'You asked Claude to wait on this.' }
  };

  function safeUrl(u) { u = str(u); return /^https:\/\/[^\s]+$/i.test(u) || /^\/_blob\/[0-9a-f]{32}$/i.test(u) ? u : ''; }

  function thumbRow(images) {
    var list = (Array.isArray(images) ? images : []).filter(function (im) { return im && safeUrl(im.url); }).slice(0, 4);
    if (!list.length) return null;
    var row = h('span', 'qt-thumbs');
    row.appendChild(h('span', 'qt-thumbs-label', 'See the result'));
    list.forEach(function (im, i) {
      var a = h('a', 'qt-thumb');
      a.href = safeUrl(im.url);
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.setAttribute('aria-label', 'See the result' + (list.length > 1 ? ' (picture ' + (i + 1) + ' of ' + list.length + ')' : ''));
      a.addEventListener('click', function (ev) { ev.stopPropagation(); });
      var img = document.createElement('img');
      img.src = safeUrl(im.url);
      img.alt = str(im.alt);
      img.loading = 'lazy';
      img.decoding = 'async';
      img.referrerPolicy = 'no-referrer';
      a.appendChild(img);
      row.appendChild(a);
    });
    return row;
  }

  function chip(qid, opts) {
    opts = opts || {};
    var el = widget('qt-chip');
    el.className = 'qt-status';
    el._qid = qid;
    el._sig = null;
    el._tick = true;                 // "Claude saw it ✓ · 2 min ago" is re-worded every 30 s while the chip is on the page
    el._onStore = function (e) {
      var c = e && e.collection;
      if (c && c !== 'answers' && c !== 'status' && c !== 'questions') return;
      if (e && e.ids && e.ids.length && e.ids.indexOf(qid) < 0) return;
      el._refresh();
    };
    el._refresh = function () {
      var st = stateOf(qid);
      var s = coll('status')[qid] || {};
      var q = coll('questions')[qid];
      var hide = st === 'waiting' && q && (q.kind === 'readonly' || q.sectionId === 'kathy');   // she cannot answer these: no "Waiting for you"
      var follow = st === 'followup' && s.followupId ? str(s.followupId) : '';
      var followOk = !!(follow && coll('questions')[follow]);
      var doneImgs = st === 'done' && opts.images ? (Array.isArray(s.doneImages) ? s.doneImages : []) : [];
      var time = st === 'seen' && s.seenAt ? fmtAgo(s.seenAt, Date.now()) : '';   // "2 min ago", the same way as the Done view says it (never a clock time)
      var note = st === 'working' ? cut(s.note, 160) : (st === 'done' ? cut(s.doneNote, 90) : '');
      var fullDone = st === 'done' ? str(s.doneNote).replace(/\s+/g, ' ').trim() : '';
      var sig = JSON.stringify([st, hide, follow, followOk, time, note, fullDone, doneImgs.map(function (i) { return i && i.url; }), !!opts.compact]);
      if (sig === el._sig) return;
      el._sig = sig;

      var def = CHIP[st];
      el.textContent = '';
      el.setAttribute('data-state', st);
      el.hidden = !!hide;
      if (hide) { el.removeAttribute('title'); return; }

      var line = h('span', 'qt-line');
      var pill = h('span', def.cls + ' qt-pill');
      if (def.ico) pill.appendChild(icon(def.ico));
      pill.appendChild(h('span', 'qt-pill-text', def.text));
      if (st === 'working') {
        var dots = h('span', 'dots qt-dots');
        dots.setAttribute('aria-hidden', 'true');
        dots.appendChild(document.createElement('i'));
        dots.appendChild(document.createElement('i'));
        dots.appendChild(document.createElement('i'));
        pill.appendChild(dots);
      }
      if (time) pill.appendChild(h('span', 'qt-pill-time', ' · ' + time));
      line.appendChild(pill);
      el.appendChild(line);

      if (st === 'followup' && followOk) {
        var b = h('button', 'qt-link', 'Open it →');
        b.type = 'button';
        b.setAttribute('aria-label', 'Open the follow-up question');
        b.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          try { if (QT.route && typeof QT.route.go === 'function') QT.route.go('question', { id: follow }); } catch (err) { /* ignore */ }
        });
        line.appendChild(b);
      }
      if (note) el.appendChild(h('span', 'qt-note' + (opts.compact ? ' qt-note-1' : ''), note));   // compact (sticky bar): one line, the rest is in the tooltip
      if (doneImgs.length && !opts.compact) { var row = thumbRow(doneImgs); if (row) el.appendChild(row); }

      var tip = def.tip;
      if (st === 'seen' && time) tip = 'Claude saw your answer ' + time + '.';
      if (st === 'working' && s.note) tip = 'Claude is working on this: ' + cut(s.note, 200);
      if (st === 'done' && fullDone) tip = fullDone;
      el.title = tip;
    };
    el._refresh();
    return el;
  }

  /* ---- the NEW badge */
  function newBadge(qid) {
    var el = widget('qt-new');
    el._isNew = true;
    el._refresh = function () {
      var on = isNew(qid);
      el.hidden = !on;
      if (on && !el.firstChild) {
        var b = h('span', 'badge-new qt-new-b', 'New');
        el.appendChild(b);
        el.title = 'New question';
      }
      if (!on) { el.textContent = ''; el.removeAttribute('title'); }
    };
    el._refresh();
    return el;
  }

  /* ---- the "Claude last looked" label as a self-updating element (layout may use it, or just heartbeatLabel()) */
  function heartbeatEl() {
    var el = widget('qt-heartbeat');
    el._tick = true;
    el._onStore = function (e) { if (!e || !e.collection || e.collection === 'meta') el._refresh(); };
    el._refresh = function () {
      var l = heartbeatLabel();
      el.setAttribute('data-stale', l.stale ? 'true' : 'false');
      el.title = l.tip;
      if (el._txt !== l.text) { el._txt = l.text; el.textContent = l.text; }
    };
    el._refresh();
    return el;
  }

  /* ------------------------------------------------------------------ NEW badges (qt.seenq) */
  var seenSet = null;   // null until the first load has finished: before that nothing is "new"
  function loadSeen() {
    var raw = lsGet('qt.seenq');
    if (raw == null) return null;
    try {
      var j = JSON.parse(raw);
      var arr = Array.isArray(j) ? j : (j && Array.isArray(j.ids) ? j.ids : null);
      if (arr) return new Set(arr.filter(function (x) { return typeof x === 'string'; }));
    } catch (e) { /* damaged: start again below */ }
    return null;
  }
  function saveSeen() {
    if (!seenSet) return;
    var ids = Array.from(seenSet);
    if (ids.length > 4000) ids = ids.slice(ids.length - 4000);
    lsSet('qt.seenq', JSON.stringify({ v: 1, ids: ids }));
  }
  function baselineSeen() {
    var existing = loadSeen();
    if (existing) { seenSet = existing; return; }
    // the very first visit ever (or damaged data): everything that exists right now counts as seen, so a fresh browser shows no NEW at all
    seenSet = new Set(Object.keys(coll('questions')));
    saveSeen();
  }
  function isNew(qid) {
    if (!seenSet || !qid) return false;
    if (!coll('questions')[qid]) return false;
    if (coll('answers')[qid]) return false;
    return !seenSet.has(qid);
  }
  function markSeen(qid) {
    var ids = Array.isArray(qid) ? qid : [qid];
    var changed = [];
    if (!seenSet) { seenSet = loadSeen() || new Set(); }
    ids.forEach(function (id) { if (typeof id === 'string' && id && !seenSet.has(id)) { seenSet.add(id); changed.push(id); } });
    if (!changed.length) return false;
    saveSeen();
    emit('seen', { ids: changed });
    live.forEach(function (w) { if (w._isNew) safe(w._refresh, w); });
    updateTitle();
    return true;
  }
  function newCount(sectionId) {
    var qs = coll('questions'), n = 0;
    Object.keys(qs).forEach(function (id) {
      var q = qs[id];
      if (q && (sectionId == null || q.sectionId === sectionId) && isNew(id)) n++;
    });
    return n;
  }

  /* ------------------------------------------------------------------ tab title */
  function updateTitle() {
    try {
      var n = badgeCount();
      var t = n > 0 ? '(' + n + ') Terminal' : 'Terminal';
      if (document.title !== t) document.title = t;
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------------------ sound */
  var soundOn = lsGet('qt.sound') === '1';
  var audio = null;
  var gestured = false;
  var lastChimeAt = -1e15;
  sound.played = 0;

  function hadGesture() {
    if (gestured) return true;
    try { if (navigator.userActivation && navigator.userActivation.hasBeenActive) return true; } catch (e) { /* ignore */ }
    return false;
  }
  function ensureAudio() {
    if (audio && audio.state === 'closed') audio = null;
    if (!audio) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try { audio = new AC(); } catch (e) { audio = null; return null; }
    }
    try {
      if (audio.state === 'suspended' && typeof audio.resume === 'function') {
        var p = audio.resume();
        if (p && typeof p.catch === 'function') p.catch(noop);
      }
    } catch (e) { /* ignore */ }
    return audio;
  }
  function onGesture() {
    gestured = true;
    if (soundOn) ensureAudio();                              // get the sound ready on the first click, so later chimes can play
  }
  ['pointerdown', 'keydown', 'touchend', 'click'].forEach(function (t) {
    try { document.addEventListener(t, onGesture, { capture: true, passive: true }); } catch (e) { /* ignore */ }
  });

  /* Three sounds, so she can tell them apart without looking:
       question  – a new question (or finished work) from Claude: the happy rising chime
       answered  – she saved an answer: a short, soft "ding-ding"
       party     – she answered the last question waiting for her: a little celebration */
  var PATTERNS = {
    question: { vol: 0.14, tail: 2000, notes: [
      { f: 523.25, at: 0,    len: 0.45, type: 'triangle' },      // C5 E5 G5
      { f: 659.25, at: 0.13, len: 0.45, type: 'triangle' },
      { f: 783.99, at: 0.26, len: 0.9,  type: 'triangle' }
    ] },
    answered: { vol: 0.10, tail: 1200, notes: [
      { f: 987.77,  at: 0,    len: 0.22, type: 'sine' },         // B5 then E6: short and light
      { f: 1318.51, at: 0.09, len: 0.4,  type: 'sine' }
    ] },
    party: { vol: 0.15, tail: 4000, notes: [
      { f: 523.25,  at: 0,    len: 0.25, type: 'triangle' },     // a quick run up: C5 E5 G5 C6 E6 G6
      { f: 659.25,  at: 0.09, len: 0.25, type: 'triangle' },
      { f: 783.99,  at: 0.18, len: 0.25, type: 'triangle' },
      { f: 1046.5,  at: 0.27, len: 0.25, type: 'triangle' },
      { f: 1318.51, at: 0.36, len: 0.25, type: 'triangle' },
      { f: 1567.98, at: 0.45, len: 0.3,  type: 'triangle' },
      { f: 1046.5,  at: 0.62, len: 1.4,  type: 'triangle' },     // then a long happy chord: C6 E6 G6 C7
      { f: 1318.51, at: 0.62, len: 1.4,  type: 'triangle' },
      { f: 1567.98, at: 0.62, len: 1.4,  type: 'triangle' },
      { f: 2093.0,  at: 0.62, len: 1.4,  type: 'sine' },
      { f: 2637.02, at: 0.8,  len: 0.3,  type: 'sine' },         // and a few sparkles on top
      { f: 3135.96, at: 0.95, len: 0.3,  type: 'sine' },
      { f: 2093.0,  at: 1.1,  len: 0.5,  type: 'sine' }
    ] }
  };

  function playPattern(c, pat) {
    var t0 = c.currentTime + 0.03;
    var master = c.createGain();
    master.gain.value = pat.vol;                             // modest volume
    master.connect(c.destination);
    pat.notes.forEach(function (n) {
      var o = c.createOscillator();
      var g = c.createGain();
      var t = t0 + n.at;
      o.type = n.type;
      o.frequency.value = n.f;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(1, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + n.len);
      o.connect(g);
      g.connect(master);
      o.start(t);
      o.stop(t + n.len + 0.05);
      o.onended = function () { try { o.disconnect(); g.disconnect(); } catch (e) { /* ignore */ } };
    });
    setTimeout(function () { try { master.disconnect(); } catch (e) { /* ignore */ } }, pat.tail);
  }

  sound.enabled = function () { return !!soundOn; };
  sound.set = function (on) {
    on = !!on;
    soundOn = on;
    lsSet('qt.sound', on ? '1' : '0');
    if (on) ensureAudio();                                   // called from her click: the browser lets us start the sound now
    emit('sound', { enabled: on });
    return on;
  };
  var lastAt = { question: -1e15, answered: -1e15, party: -1e15 };
  var GAP = { question: CHIME_GAP_MS, answered: DING_GAP_MS, party: PARTY_GAP_MS };
  sound.playedBy = { question: 0, answered: 0, party: 0 };
  sound.last = '';
  /** Plays a sound if sound is on and the last one of that kind was long enough ago.
   *  opts.kind: 'question' (default), 'answered' or 'party'.  Returns true when it played. */
  sound.chime = function (opts) {
    var force = !!(opts && opts.force);
    var kind = opts && PATTERNS[opts.kind] ? opts.kind : 'question';
    if (!force) {
      if (!soundOn) return false;
      if (Date.now() - lastAt[kind] < GAP[kind]) return false;
    }
    try {
      var c = ensureAudio();
      if (!c) return false;
      // before her first click a browser keeps the sound switched off ("suspended"): do not queue a chime that would pop out later
      if (c.state !== 'running' && !hadGesture()) return false;
      playPattern(c, PATTERNS[kind]);
      lastAt[kind] = Date.now();
      lastChimeAt = lastAt[kind];
      sound.played++;
      sound.playedBy[kind]++;
      sound.last = kind;
      return true;
    } catch (e) { return false; }
  };

  /* ------------------------------------------------------------------ what makes a chime / the title change */
  var armed = false;                 // true only after the first load is finished
  var known = { q: null, st: null, pl: null, an: null, wait: 0, rp: null, is: null, wk: null, tk: null, sn: null };

  function seedKnown() {
    known.q = new Set(Object.keys(coll('questions')));
    known.st = Object.create(null);
    Object.keys(coll('status')).forEach(function (id) { var s = coll('status')[id]; known.st[id] = s && s.state; });
    known.pl = Object.create(null);
    Object.keys(coll('plans')).forEach(function (id) { known.pl[id] = planKey(coll('plans')[id]); });
    known.an = Object.create(null);
    Object.keys(coll('answers')).forEach(function (id) { known.an[id] = answerKey(coll('answers')[id]); });
    known.wait = badgeCount();
    known.rp = Object.create(null); Object.keys(coll('replies')).forEach(function (id) { var r = coll('replies')[id]; known.rp[id] = r && r.state; });
    known.is = Object.create(null); Object.keys(coll('ideaStatus')).forEach(function (id) { var r = coll('ideaStatus')[id]; known.is[id] = r && r.state; });
    known.wk = new Set(Object.keys(coll('workers')));
    known.tk = new Set(Object.keys(coll('tasks')));
    known.sn = seenMap();
  }
  /* Has Claude looked at something she wrote on the Tasks part?  add: tasks/<id> exists and (no seenAt, or seenAt >= her add time); edit: seenAt >= her edit time.
     (the same rules as QT.parts.seen in 50-parts.js; copied here so this file stays free of other modules) */
  function seenMap() {
    var m = Object.create(null), A = coll('taskAdds'), E = coll('taskEdits'), T = coll('tasks');
    function when(iso) { var t = Date.parse(iso); return isNaN(t) ? null : t; }
    Object.keys(A).forEach(function (id) {
      var d = A[id], t = T[id];
      if (!d) return;
      var sa = t ? when(t.seenAt) : null, c = when(d.createdAt);
      m['a:' + id + '|' + str(d.createdAt)] = !!t && (sa == null ? true : (c == null || sa >= c));
    });
    Object.keys(E).forEach(function (id) {
      var d = E[id], t = T[id];
      if (!d) return;
      var sa = t ? when(t.seenAt) : null, u = when(d.updatedAt);
      m['e:' + id + '|' + str(d.updatedAt)] = !!t && sa != null && (u == null || sa >= u);
    });
    return m;
  }
  function answerKey(a) { return a ? str(a.answeredAt) + '|' + str(a.key) : ''; }
  function planKey(p) { return p ? String(p.version == null ? '' : p.version) + '|' + str(p.at) : ''; }

  function chimeQuestion(q) {
    if (!q || q.sectionId === 'kathy' || q.kind === 'readonly') return false;
    var sec = coll('sections')[q.sectionId];
    return !(sec && (sec.readOnly || sec.archived));
  }

  function watchForChime(e) {
    if (!known.q) seedKnown();
    var allow = armed && !(e && e.initial);
    var why = null;
    var c = e && e.collection;
    if (!c || c === 'questions') {
      var qs = coll('questions');
      Object.keys(qs).forEach(function (id) {
        if (known.q.has(id)) return;
        known.q.add(id);
        if (allow && chimeQuestion(qs[id])) why = why || 'question';
      });
    }
    if (!c || c === 'status') {
      var ss = coll('status');
      Object.keys(ss).forEach(function (id) {
        var now = ss[id] && ss[id].state;
        if (now === 'done' && known.st[id] !== 'done' && allow) why = why || 'done';
        known.st[id] = now;
      });
    }
    if (!c || c === 'plans') {
      var ps = coll('plans');
      Object.keys(ps).forEach(function (id) {
        var k = planKey(ps[id]);
        if (known.pl[id] !== k && allow) why = why || 'plan';
        known.pl[id] = k;
      });
    }
    /* Claude's news on the Workers and Tasks parts: the same happy chime (the owner asked for it "whenever anything new arrives").
       Never on the first load, never for what she wrote herself (her adds, edits and asks), and the 4 s gap still applies. */
    if (!c || c === 'replies') {
      var rs = coll('replies');
      Object.keys(rs).forEach(function (id) {
        var st = rs[id] && rs[id].state, had = Object.prototype.hasOwnProperty.call(known.rp, id);
        if (allow && (!had || (st === 'answered' && known.rp[id] !== 'answered'))) why = why || 'reply';    // a new answer (or a "seen" note that became the answer)
        known.rp[id] = st;
      });
    }
    if (!c || c === 'ideaStatus') {
      var is = coll('ideaStatus');
      Object.keys(is).forEach(function (id) {
        var st = is[id] && is[id].state, had = Object.prototype.hasOwnProperty.call(known.is, id);
        if (allow && (!had || (st === 'questionsReady' && known.is[id] !== 'questionsReady'))) why = why || 'idea';
        known.is[id] = st;
      });
    }
    if (!c || c === 'workers') {
      Object.keys(coll('workers')).forEach(function (id) {
        if (known.wk.has(id)) return;
        known.wk.add(id);
        if (allow) why = why || 'worker';
      });
    }
    if (!c || c === 'tasks') {
      var tk = coll('tasks');
      Object.keys(tk).forEach(function (id) {
        if (known.tk.has(id)) return;
        known.tk.add(id);
        if (allow && !(tk[id] && tk[id].createdBy === 'owner')) why = why || 'task';       // a task Claude made; her own task being adopted is the "seen" case below
      });
    }
    if (!c || c === 'tasks' || c === 'taskAdds' || c === 'taskEdits') {
      var sn = seenMap();
      Object.keys(sn).forEach(function (k) { if (allow && known.sn[k] === false && sn[k] === true) why = why || 'seen'; });
      known.sn = sn;
    }
    var party = false, ding = false;
    if (!c || c === 'answers') {
      var as = coll('answers');
      Object.keys(as).forEach(function (id) {
        var k = answerKey(as[id]);
        if (known.an[id] !== k && allow) ding = true;
        known.an[id] = k;
      });
    }
    var waitNow = badgeCount();
    if (ding && known.wait > 0 && waitNow === 0) party = true;    // she just answered the last question waiting for her
    known.wait = waitNow;
    if (party) { sound.chime({ kind: 'party', reason: 'party' }); return; }
    if (ding) sound.chime({ kind: 'answered', reason: 'answered' });
    if (why) sound.chime({ reason: why });
  }

  /* ------------------------------------------------------------------ talking to Claude (comments) */
  var commentsPromise = null;
  function getComments() {
    if (QT.comments && typeof QT.comments.sendToClaude === 'function') return Promise.resolve(QT.comments);
    if (commentsPromise) return commentsPromise;
    commentsPromise = (async function () {
      try {
        if (window.claude && typeof window.claude.use === 'function') {
          var c = await window.claude.use('comments');
          if (c && typeof c.sendToClaude === 'function') return c;
        }
      } catch (e) { /* not available here */ }
      return null;
    })().then(function (c) { if (!c) commentsPromise = null; return c; });   // a "no" is not remembered: the next try asks again
    return commentsPromise;
  }
  function codeOf(e) {
    var c = e && typeof e.code === 'string' ? e.code : '';
    return c || 'upstream_error';
  }

  var autoPing = false, autoTried = false;
  var pingOk = false;          // the test worked during this visit
  var pingReason = 'not_tested';
  var threadId = null;
  var lastSendAt = -1e15;

  var deadThreads = {};        // thread ids that Claude's side said do not exist any more
  function currentThread() {
    if (threadId && !deadThreads[threadId]) return threadId;
    var m = coll('meta').ping;
    var id = m && typeof m.threadId === 'string' && m.threadId ? m.threadId : null;
    return id && !deadThreads[id] ? id : null;
  }
  function rememberThread(id) {
    id = id || null;
    var before = currentThread();
    threadId = id;
    if (before === id) return;
    try {
      var p = null;
      if (QT.write && typeof QT.write.meta === 'function') p = QT.write.meta('ping', { threadId: id });
      if (p && typeof p.catch === 'function') p.catch(noop);
    } catch (e) { /* the thread is still remembered for this visit */ }
  }

  function cleanLine(s) {
    return cut(str(s).replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, ' '), CUT);
  }

  /** Builds the one-line "what she did" text that is safe to send: the question and the label of her choice, never her own typed words. */
  function answerText(qid, answer) {
    var q = coll('questions')[qid] || {};
    var a = answer || coll('answers')[qid] || {};
    var what;
    if (a.key === 'own') what = 'her own answer';
    else if (a.key === 'unsure') what = 'not sure yet';
    else if (a.key === 'help') what = 'asked for another explanation';
    else if (a.key === 'change') what = 'wants a change';
    else what = a.label ? cut(a.label, 50) : (a.key ? 'choice ' + a.key : 'answered');
    var title = cut(q.title || qid, Math.max(20, CUT - 11 - what.length));
    return cleanLine('Answered: ' + title + ' → ' + what);
  }

  async function sendNow(c, text, anchorEl) {
    var tid = currentThread();
    try {
      if (tid) {
        try {
          var r0 = await c.sendToClaude({ threadId: tid, text: text });
          return { ok: true, threadId: (r0 && r0.threadId) || tid };
        } catch (e) {
          if (codeOf(e) !== 'not_found') throw e;
          deadThreads[tid] = true;                            // the old conversation is gone: start a new one below
          threadId = null;
          rememberThread(null);
        }
      }
      var el = anchorEl && anchorEl.isConnected ? anchorEl : document.body;
      var anchor;
      try { anchor = await c.anchorFor(el); } catch (e2) { anchor = await c.anchorFor(document.body); }
      var r = await c.sendToClaude({ anchor: anchor, text: text });
      var id = r && r.threadId;
      if (id) rememberThread(id);
      return { ok: true, threadId: id || null };
    } catch (e3) {
      return { ok: false, reason: codeOf(e3) };
    }
  }

  /* ---- toast (the layout owns the real one and drops a message that is already showing; ours is only the fallback) */
  var ownToastWrap = null, ownToastTimer = null;
  function toast(text, kind, ms) {
    try {
      if (QT.layout && typeof QT.layout.toast === 'function') {
        var t = QT.layout.toast(text, { kind: kind, ms: ms });
        if (t) return t;
      }
    } catch (e) { /* use our own */ }
    if (!document.body) return null;
    if (!ownToastWrap || !ownToastWrap.isConnected) {
      ownToastWrap = h('div', 'qt-conn-wrap');
      ownToastWrap.setAttribute('role', 'status');
      ownToastWrap.setAttribute('aria-live', 'polite');
      document.body.appendChild(ownToastWrap);
    }
    ownToastWrap.textContent = '';
    var box = h('div', 'qt-conn qt-conn-' + (kind || 'info'));
    box.appendChild(h('span', 'qt-conn-text', text));
    var x = h('button', 'btn small quiet', 'Close');
    x.type = 'button';
    box._close = function () { if (box.parentNode) box.parentNode.removeChild(box); };
    x.addEventListener('click', box._close);
    box.appendChild(x);
    ownToastWrap.appendChild(box);
    clearTimeout(ownToastTimer);
    ownToastTimer = setTimeout(box._close, ms || 9000);
    return box;
  }
  function closeToast(t) { try { if (t && typeof t._close === 'function') t._close(); } catch (e) { /* ignore */ } }

  /* ---- Test connection */
  var testing = null;
  function testConnection(arg) {
    if (testing) return testing;
    var btn = null;
    try {
      var cand = arg && arg.currentTarget ? arg.currentTarget : arg;
      if (cand && cand.nodeType === 1) btn = cand;
    } catch (e) { btn = null; }
    if (btn) btn.setAttribute('aria-busy', 'true');
    var checking = null;
    testing = (async function () {
      checking = toast(MSG_WORKING, 'info', 30000);
      var result;
      var c = await getComments();
      if (!c) {
        result = { ok: false, reason: 'no_comments' };
      } else {
        var can;
        try { can = await c.canSendToClaude(); } catch (e) { can = 'off'; }
        if (can !== 'available') result = { ok: false, reason: can === 'writers_only' ? 'writers_only' : (can || 'off') };
        else result = await sendNow(c, TEST_TEXT, btn || document.querySelector('.test-btn'));
      }
      pingOk = !!result.ok;
      pingReason = result.ok ? 'ok' : (result.reason || 'failed');
      result.message = result.ok ? MSG_OK : (result.reason === 'rate_limited' ? MSG_SLOW : MSG_FAIL);
      closeToast(checking);
      toast(result.message, result.ok ? 'good' : (result.reason === 'rate_limited' ? 'warn' : 'info'), result.ok ? 6000 : 12000);
      if (result.ok) lastSendAt = Date.now();
      emit('ping', { ok: result.ok, reason: pingReason, test: true });
      return result;
    })().catch(function (e) {
      pingOk = false;
      pingReason = 'failed';
      var r = { ok: false, reason: 'failed', message: MSG_FAIL };
      closeToast(checking);
      toast(MSG_FAIL, 'info', 12000);
      return r;
    }).then(function (r) {
      testing = null;
      if (btn) btn.removeAttribute('aria-busy');
      return r;
    });
    return testing;
  }

  /* ---- automatic ping after an answer (only after a good test, at most one per 20 s, batched) */
  var queue = [];
  var timer = null;
  var inflight = false;
  var gestureArmed = false;
  var inGesture = false;
  var GESTURE_EVENTS = ['pointerdown', 'keydown', 'touchend'];

  function needsGesture() {
    if (inGesture) return false;
    try { return !!(navigator.userActivation && !navigator.userActivation.isActive); } catch (e) { return false; }
  }
  function armGesture() {
    if (gestureArmed) return;
    gestureArmed = true;
    var fire = function () {
      GESTURE_EVENTS.forEach(function (t) { document.removeEventListener(t, fire, true); });
      gestureArmed = false;
      inGesture = true;
      try { schedule(); } finally { inGesture = false; }
    };
    GESTURE_EVENTS.forEach(function (t) { document.addEventListener(t, fire, true); });
  }

  function mergeText(items) {
    if (items.length === 1) return items[0].text;
    var answers = items.filter(function (i) { return /^Answered/i.test(i.text); });
    var others = items.filter(function (i) { return !/^Answered/i.test(i.text); });
    var lines = [];
    if (answers.length === 1) lines.push(answers[0].text);
    else if (answers.length > 1) lines.push('Answered ' + answers.length + ' questions');
    others.slice(0, 3).forEach(function (i) { lines.push(i.text); });
    if (others.length > 3) lines.push('…and ' + (others.length - 3) + ' more');
    return lines.join('\n');
  }

  function finishItems(items, res) { items.forEach(function (i) { try { i.resolve(res); } catch (e) { /* ignore */ } }); }

  function schedule() {
    if (inflight || !queue.length) return;
    var wait = lastSendAt + PING_GAP_MS - Date.now();
    if (wait > 0) {
      if (!timer) timer = setTimeout(function () { timer = null; schedule(); }, wait + 25);
      return;
    }
    if (needsGesture()) { armGesture(); return; }
    flush();
  }

  async function flush() {
    if (inflight || !queue.length) return;
    inflight = true;
    var items = queue.splice(0, queue.length);
    var text = mergeText(items);
    lastSendAt = Date.now();
    var res;
    try {
      var c = await getComments();
      res = c ? await sendNow(c, text, null) : { ok: false, reason: 'no_comments' };
    } catch (e) {
      res = { ok: false, reason: 'failed' };
    }
    inflight = false;
    if (res.ok) {
      finishItems(items, { ok: true });
    } else {
      var why = res.reason || 'failed';
      var retryable = (why === 'claude_unavailable' || why === 'unavailable' || why === 'upstream_error');
      var tries = Math.max.apply(null, items.map(function (i) { return i.tries; }));
      if (why === 'rate_limited' && tries < 2) {
        // too fast for Claude's side: keep the words and try again a bit later
        items.forEach(function (i) { i.tries++; });
        queue.unshift.apply(queue, items);
        lastSendAt = Date.now() + 40 * 1000;
      } else if (retryable && tries < 1) {
        // maybe it was not "from a click": keep the words and send them with her next click
        items.forEach(function (i) { i.tries++; });
        queue.unshift.apply(queue, items);
        armGesture();
      } else {
        finishItems(items, { ok: false, reason: why });
        if (why !== 'invalid') { pingOk = false; pingReason = why; emit('ping', { ok: false, reason: why, test: false }); }
      }
    }
    if (queue.length) schedule();
  }

  /** Called by QT.write.ping after an answer.  Resolves {ok, reason}. Safe to call any time. */
  function ping(what) {
    var text = '';
    try {
      if (what && typeof what === 'object') text = answerText(what.qid, what.answer);
      else text = cleanLine(what);
    } catch (e) { text = ''; }
    if (!text) return Promise.resolve({ ok: false, reason: 'empty' });
    if (!pingOk) {
      // normally a ping needs a good "Test connection" first; the lead may switch on QT.status.setAutoPing(true) to try one real send without it (once)
      if (!autoPing || autoTried) return Promise.resolve({ ok: false, reason: 'not_tested' });
      autoTried = true;
      pingOk = true;
      pingReason = 'auto';
    }
    return new Promise(function (resolve) {
      if (queue.length >= 40) queue.shift().resolve({ ok: false, reason: 'dropped' });
      queue.push({ text: text, resolve: resolve, tries: 0 });
      schedule();
    });
  }

  function connection() {
    return { tested: pingOk || pingReason !== 'not_tested', ok: pingOk, reason: pingReason, threadId: currentThread(), waiting: queue.length };
  }

  /* ------------------------------------------------------------------ wiring */
  function onStore(e) {
    if (e && e.collection === 'questions' && e.initial && !e.error) {
      questionsHere = true;
      if (armed && !seenSet) safe(baselineSeen);       // the very first look arrived after the page said "ready" (a slow notebook)
    }
    safe(watchForChime, null, e);
    safe(updateTitle);
    safe(onStoreForWidgets, null, e);
  }
  function onRoute(e) {
    try {
      var p = e && e.params;
      if (e && e.view === 'question' && p && p.id) markSeen(p.id);   // opening a question is what clears its NEW badge
    } catch (err) { /* ignore */ }
  }
  var questionsHere = false;     // the first look at the questions has been delivered
  function arm() {
    seedKnown();
    armed = true;
    if (questionsHere || Object.keys(coll('questions')).length) { questionsHere = true; baselineSeen(); }   // otherwise: when the questions arrive (see onStore)
    updateTitle();
    live.forEach(function (w) { safe(w._refresh, w); });
    // the question she is looking at right now is not "new" any more
    try {
      var r = QT.route && QT.route.current;
      if (typeof r === 'function') r = r.call(QT.route);
      if (r && r.view === 'question' && r.params && r.params.id) markSeen(r.params.id);
    } catch (err) { /* ignore */ }
  }

  Object.assign(status, {
    state: stateOf,
    chip: chip,
    badgeCount: badgeCount,
    totalUnanswered: function () { return badgeCount(); },
    needsAnswer: function (qid) { var q = coll('questions')[qid]; return !!q && needsAnswer(q.id ? q : Object.assign({ id: qid }, q)); },
    heartbeatLabel: heartbeatLabel,
    heartbeatEl: heartbeatEl,
    newBadge: newBadge,
    isNew: isNew,
    markSeen: markSeen,
    newCount: newCount,
    updateTitle: updateTitle,
    answerText: answerText,
    testConnection: testConnection,
    ping: ping,
    connection: connection,
    setAutoPing: function (on) { autoPing = !!on; },
    _liveCount: function () { return live.size; }   // for the tests: how many chips/badges are listening right now
  });

  if (typeof QT.on === 'function') {
    QT.on('store', onStore);
    QT.on('route', onRoute);
    var ready = QT.ready && typeof QT.ready.then === 'function' ? QT.ready : Promise.resolve();
    ready.then(function () { if (!QT.offline) arm(); else updateTitle(); }, noop);
  }
})();
