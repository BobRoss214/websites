/* 99-boot.js  (owner: core)
 * Last file. When the page is ready: find (or make) #app, wait for the notebook's first look (QT.ready), then let the layout draw everything.
 */
(function () {
  'use strict';
  var QT = window.QT;

  function say(app, title, text) {
    app.textContent = '';
    var box = document.createElement('div');
    box.setAttribute('role', 'status');
    box.style.cssText = 'max-width:34em;margin:2.5em auto;padding:0 1em;font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:inherit';
    var h = document.createElement('h1');
    h.style.cssText = 'font-size:1.25em;margin:0 0 .4em';
    h.textContent = title;
    var p = document.createElement('p');
    p.style.margin = '0';
    p.textContent = text;
    box.appendChild(h);
    box.appendChild(p);
    app.appendChild(box);
  }

  function boot() {
    try { if (!document.documentElement.getAttribute('lang')) document.documentElement.setAttribute('lang', 'en'); } catch (e) {}
    try { if (QT && QT.status && typeof QT.status.setAutoPing === 'function') QT.status.setAutoPing(true); } catch (e) {}   /* lead: pings after answers start by themselves (the owner wants Claude to hear her answers at once) */
    var app = document.getElementById('app');
    if (!app) {
      app = document.createElement('div');
      app.id = 'app';
      document.body.appendChild(app);
    }
    if (!QT || !QT.ready) { say(app, 'Something went wrong', 'This page could not start. Please tell Claude, and try again in a moment.'); return; }
    if (!app.firstChild) say(app, 'Terminal', 'Opening your questions…');
    app.setAttribute('aria-busy', 'true');
    QT.ready.then(function () {
      app.removeAttribute('aria-busy');
      if (!QT.layout || typeof QT.layout.mount !== 'function') {
        say(app, 'Terminal', 'The page is still being put together. Please tell Claude, and try again in a moment.');
        return;
      }
      app.textContent = '';
      try { QT.layout.mount(app); }
      catch (e) {
        try { console.error('[QT] the page could not be drawn:', e); } catch (e2) { /* no console */ }
        say(app, 'Something went wrong', 'The page could not be drawn. Please tell Claude, and try again in a moment.');
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
