/* 50-parts.js  (owner: question)
   The three PARTS of the Terminal: Questions | Workers | Tasks.  This file
     1. draws the sticky tab strip under the top bar (after QT.layout.mount: it wraps that function, 10-layout.js is untouched),
        keeps it in step with the route, remembers the part, shows the count badges, hides the left menu in Workers / Tasks (css + a data attribute
        on the app root: data-part="questions|workers|tasks"), and says "Terminal" instead of "Question Terminal" (brand text and tab title);
     2. offers QT.parts: the selectors the Workers (51-workers.js) and Tasks (52-tasks.js) views read their data with;
     3. offers a few tiny shared helpers (chip "pending / Claude saw it", speech bubble, time words) so both views look and talk the same.
   Nothing here writes to the notebook. All document text goes in with textContent. Everything works when a collection is missing or empty.

   ======================================== QT.parts  (the API) ========================================
   Part ids: 'questions' (home, section, question, done, newsection) | 'workers' | 'tasks'
     QT.parts.current()                  -> 'questions' | 'workers' | 'tasks'      (from the route)
     QT.parts.partOf(view)               -> the part a route view belongs to
     QT.parts.go(part, params)           -> switches part. 'questions' goes back to where she last was in the questions (home if unknown),
                                            'workers' / 'tasks' call QT.route.go(part, params)  (params e.g. {focus: workerId|taskId}).
   Workers  (documents of workers/<id>, plain objects as stored; sorted by `order`, then lead < team < helper, then name)
     QT.parts.workers()                  -> [worker...]            every worker
     QT.parts.workerRoots()              -> [worker...]            parentId null, or the parent does not exist, or a loop was cut: so nobody vanishes
     QT.parts.workerKids(id)             -> [worker...]            the workers directly under `id`
   Tasks  (EFFECTIVE tasks, see SPEC2 section 3: tasks/<id> or else taskAdds/<id> (state 'todo'), then her taskEdits on top)
     QT.parts.tasks()                    -> [task...]   each task = the stored fields (with safe defaults) plus
                                              pending:   true while her ADD is not adopted/seen by Claude yet       (only for tasks that exist as taskAdds)
                                              mine:      true when createdBy === 'owner'
                                              edit:      her taskEdits document, or null
                                              editPending: true when she has an edit that Claude has not seen yet
                                              youPaused: her edit says paused:true (state is then 'paused')
                                              resumeAsked: her edit says paused:false while the task is paused by Claude (state stays 'paused')
                                              removed:   her edit says removed:true ("You asked to remove this"; the task is still listed)
                                              (title / plain are her edited words when she edited them)
     QT.parts.task(id)                   -> one effective task or null
     QT.parts.taskRoots()                -> [task...]   big ideas (parentId null / unknown parent / loop cut)
     QT.parts.taskKids(id)               -> [task...]   the tasks directly under `id`
     QT.parts.progress(taskId)           -> {done, total}  counts the LEAF tasks below it (a task without children counts itself; a leaf is done when
                                              its state is 'done'; leaves she asked to remove are not counted). A task nobody can see below it counts itself.
   Her words and Claude's answers
     QT.parts.seen(doc [, kind])         -> true | false   for a taskAdds / taskEdits / asks document (kind 'add'|'edit'|'ask' is guessed when missing):
                                              add : tasks/<id> exists and (seenAt is empty or seenAt >= the add time)
                                              edit: tasks/<taskId> exists and seenAt >= the edit time
                                              ask : replies/<askId> exists
     QT.parts.asksFor(kind, targetId)    -> [{ask, reply|null, state:'sent'|'seen'|'working'|'answered', seen}]  oldest first (a little conversation)
     QT.parts.askState(ask)              -> 'sent' | 'seen' | 'working' | 'answered'
   Numbers
     QT.parts.counts()                   -> {questionsWaiting, workersWorking, tasksWaitingForYou, tasksWorking, tasksDone}
   Live
     QT.parts.watch(fn)                  -> unsubscribe function; fn() runs (at most every 60 ms) when workers/tasks/replies/taskAdds/taskEdits/asks change
   CSS variable (50-parts.css):  --tabs-h  = how much of the window the sticky strip covers under the top bar: 2.5rem, or 0px while the strip has scrolled away
                                 (root class tabs-free). Stick something under the strip with  top: calc(var(--topbar-h) + var(--tabs-h)).
   Shared helpers (css in 50-parts.css)
     QT.parts.seenChip({what, seen, at}) -> <span class="chip ..."> what: 'add'|'edit'|'ask'|'pause'|'resume'|'remove'.
                                              not seen: grey dashed chip "You added this · waiting for Claude to see it" (same look as the question chips);
                                              seen:     "Claude saw it ✓" (+ " · 2 min ago" when `at` is given).
     QT.parts.bubble({side, name, text, at, chip, label}) -> <div class="pt-bub pt-you|pt-claude">: a speech bubble. side 'you' (right, blue) | 'claude' (left, warm);
                                              name = who is talking, text = the words (line breaks kept), at = ISO time (shown as "2 min ago"), chip = optional element in the foot.
     QT.parts.ago(iso)                   -> "just now" | "5 min ago" | ...   ('' when the date is wrong)
     QT.parts.initials(name)             -> "MD" for "Map drawer A"  (fallback badge text when a worker has no emoji)
     QT.parts.label(part)                -> 'Questions' | 'Workers' | 'Tasks'
   ===========================================================================================================*/
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var P = QT.parts = QT.parts || {};

  var PARTS = ['questions', 'workers', 'tasks'];
  var LABEL = { questions: 'Questions', workers: 'Workers', tasks: 'Tasks' };
  var PART_KEY = 'qt.part', QROUTE_KEY = 'qt.part.q';
  var QUESTION_VIEWS = ['home', 'section', 'question', 'done', 'newsection'];
  var TASK_STATES = ['todo', 'working', 'waiting', 'done', 'paused'];
  var WAITERS = ['owner', 'cathy', 'rob', 'none'];
  var KIND_RANK = { lead: 0, team: 1, helper: 2 };
  var BIG = 1e12;

  /* ---------- tiny helpers ---------- */
  function str(v) { return typeof v === 'string' ? v : (v == null ? '' : String(v)); }
  function arr(v) { return Array.isArray(v) ? v.filter(function (x) { return typeof x === 'string' && x; }) : []; }
  function ms(iso) { var t = Date.parse(iso); return isNaN(t) ? null : t; }
  function safe(fn, dflt) { try { var r = fn(); return r === undefined ? dflt : r; } catch (e) { return dflt; } }
  function coll(name) { var s = QT.store && QT.store[name]; return s && typeof s === 'object' ? s : {}; }
  function listOf(name) {
    var c = coll(name);
    return Object.keys(c).map(function (id) {
      var d = c[id];
      if (!d || typeof d !== 'object' || Array.isArray(d)) return null;
      return d.id === id ? d : Object.assign({}, d, { id: id });
    }).filter(Boolean);
  }
  function h(tag, attrs) {
    var el = document.createElement(tag), k, i;
    if (attrs) for (k in attrs) {
      var v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'hidden') el.hidden = !!v;
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    for (i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
    }
    return el;
  }
  var SVGNS = 'http://www.w3.org/2000/svg';
  var ICONS = {
    questions: 'M4 5h16v11H9.5L4 20zM9.7 9.3a2.4 2.4 0 1 1 3.4 2.2c-.7.4-1.1.8-1.1 1.5M12 14.6h.01',
    workers: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20c0-3.6 2.8-6 6.5-6s6.5 2.4 6.5 6M16 4.3a3.5 3.5 0 0 1 0 6.4M18 14.4c2.2.7 3.5 2.6 3.5 5.6',
    tasks: 'M3.5 4h6v4.5h-6zM14.5 10h6v4.5h-6zM14.5 16.5h6V21h-6zM6.5 8.5V12.2a2 2 0 0 0 2 2H14.5M12 14.2v4.3a2 2 0 0 0 2 2',
    clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7.5V12l3 2'
  };
  function icon(name) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'pt-ic'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    var p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', ICONS[name] || ICONS.clock); s.appendChild(p);
    return s;
  }

  /* ---------- parts and routes ---------- */
  function partOf(view) { return view === 'workers' ? 'workers' : (view === 'tasks' ? 'tasks' : 'questions'); }
  function currentRoute() {
    var c = QT.route && typeof QT.route.current === 'function' ? safe(function () { return QT.route.current(); }, null) : null;
    return c && c.view ? c : { view: 'home', params: {} };
  }
  P.partOf = partOf;
  P.label = function (part) { return LABEL[part] || LABEL.questions; };
  P.current = function () { return partOf(currentRoute().view); };

  var lastQ = QT.storage ? QT.storage.getJSON(QROUTE_KEY, null) : null;
  if (!lastQ || QUESTION_VIEWS.indexOf(lastQ.view) < 0 || lastQ.view === 'newsection') lastQ = null;
  function rememberRoute(r) {
    if (!r || !r.view) return;
    var part = partOf(r.view);
    if (QT.storage) QT.storage.set(PART_KEY, part);
    if (part === 'questions' && r.view !== 'newsection') {
      lastQ = { view: r.view, params: r.params || {} };
      if (QT.storage) QT.storage.setJSON(QROUTE_KEY, lastQ);
    }
  }
  function questionRouteStillThere(r) {
    if (!r) return false;
    var p = r.params || {};
    if (r.view === 'section') return !!(coll('sections')[p.id]) || ['look', 'other', 'later', 'kathy'].indexOf(p.id) >= 0;
    if (r.view === 'question') return !!coll('questions')[p.id];
    return true;
  }
  P.go = function (part, params) {
    if (!QT.route || typeof QT.route.go !== 'function') return null;
    part = PARTS.indexOf(part) >= 0 ? part : 'questions';
    if (part === 'questions') {
      if (P.current() === 'questions' && !params) return QT.route.current();
      var r = lastQ && questionRouteStillThere(lastQ) ? lastQ : { view: 'home', params: {} };
      return QT.route.go(r.view, params || r.params);
    }
    return QT.route.go(part, params || {});
  };

  /* ---------- sorting and forests ---------- */
  function numOr(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }
  function byWorker(a, b) {
    var d = numOr(a.order, BIG) - numOr(b.order, BIG);
    if (d) return d;
    d = (KIND_RANK[a.kind] != null ? KIND_RANK[a.kind] : 3) - (KIND_RANK[b.kind] != null ? KIND_RANK[b.kind] : 3);
    if (d) return d;
    var n = str(a.name).toLowerCase(), m = str(b.name).toLowerCase();
    return n < m ? -1 : n > m ? 1 : (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
  function byTask(a, b) {
    var d = numOr(a.order, BIG) - numOr(b.order, BIG);
    if (d) return d;
    var x = str(a.createdAt), y = str(b.createdAt);
    if (x !== y) return x < y ? -1 : 1;
    var n = str(a.title).toLowerCase(), m = str(b.title).toLowerCase();
    return n < m ? -1 : n > m ? 1 : (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
  /** items (sorted) -> {roots, kids}. A parent that does not exist makes the item a root; a loop is cut at its first item, so everything is reachable. */
  function forest(items) {
    var byId = {}, parent = {}, kids = {}, roots = [];
    items.forEach(function (i) { byId[i.id] = i; });
    items.forEach(function (i) { var p = i.parentId; parent[i.id] = p && p !== i.id && byId[p] ? p : null; });
    items.forEach(function (i) {
      var seen = {}, cur = i.id;
      while (cur && parent[cur]) { if (seen[cur]) { parent[cur] = null; break; } seen[cur] = 1; cur = parent[cur]; }
    });
    items.forEach(function (i) {
      var p = parent[i.id];
      if (p) (kids[p] = kids[p] || []).push(i); else roots.push(i);
    });
    return { roots: roots, kids: kids };
  }

  /* ---------- workers ---------- */
  P.workers = function () { return listOf('workers').sort(byWorker); };
  P.workerRoots = function () { return forest(P.workers()).roots; };
  P.workerKids = function (id) { return forest(P.workers()).kids[id] || []; };

  /* ---------- tasks (effective) ---------- */
  function baseTask(d) {
    return Object.assign({}, d, {
      parentId: d.parentId ? str(d.parentId) : null,
      title: str(d.title), plain: str(d.plain),
      state: TASK_STATES.indexOf(d.state) >= 0 ? d.state : 'todo',
      waitingFor: WAITERS.indexOf(d.waitingFor) >= 0 ? d.waitingFor : 'none',
      workerIds: arr(d.workerIds), questionIds: arr(d.questionIds), note: str(d.note),
      order: numOr(d.order, BIG), createdAt: str(d.createdAt), updatedAt: str(d.updatedAt) || str(d.createdAt),
      doneAt: d.doneAt || null, createdBy: d.createdBy === 'owner' ? 'owner' : 'claude', seenAt: d.seenAt || null
    });
  }
  function seenAdd(add) {
    var t = coll('tasks')[add.id];
    if (!t || typeof t !== 'object') return false;
    var s = ms(t.seenAt), c = ms(add.createdAt);
    return s == null ? true : (c == null || s >= c);
  }
  function seenEdit(edit) {
    var t = coll('tasks')[edit.id];
    if (!t || typeof t !== 'object') return false;
    var s = ms(t.seenAt), u = ms(edit.updatedAt);
    return s != null && (u == null || s >= u);
  }
  P.seen = function (doc, kind) {
    if (!doc || typeof doc !== 'object' || !doc.id) return false;
    var k = kind || (doc.targetKind ? 'ask' : (doc.updatedAt ? 'edit' : 'add'));
    if (k === 'ask') return !!coll('replies')[doc.id];
    if (k === 'edit') return seenEdit(doc);
    return seenAdd(doc);
  };
  function effectiveTasks() {
    var T = coll('tasks'), A = coll('taskAdds'), E = coll('taskEdits'), out = {};
    Object.keys(T).forEach(function (id) {
      var d = T[id];
      if (!d || typeof d !== 'object' || Array.isArray(d)) return;
      var t = baseTask(Object.assign({}, d, { id: id }));
      t.pending = false; t.mine = t.createdBy === 'owner'; t.edit = null; t.editPending = false; t.youPaused = false; t.resumeAsked = false; t.removed = false;
      out[id] = t;
    });
    Object.keys(A).forEach(function (id) {
      var a = A[id];
      if (out[id] || !a || typeof a !== 'object' || Array.isArray(a)) return;
      var t = baseTask({ id: id, parentId: a.parentId, title: a.title, plain: a.plain, state: 'todo', waitingFor: 'none', createdAt: a.createdAt, updatedAt: a.createdAt,
        order: typeof a.order === 'number' ? a.order : BIG, createdBy: 'owner' });
      t.id = id; t.pending = true; t.mine = true; t.edit = null; t.editPending = false; t.youPaused = false; t.resumeAsked = false; t.removed = false;
      out[id] = t;
    });
    Object.keys(E).forEach(function (id) {
      var e = E[id], t = out[id];
      if (!t || !e || typeof e !== 'object' || Array.isArray(e)) return;
      e = Object.assign({}, e, { id: id });
      t.edit = e;
      t.editPending = !seenEdit(e);
      if (typeof e.title === 'string' && e.title.trim()) t.title = e.title;
      if (typeof e.plain === 'string') t.plain = e.plain;
      if (e.paused === true) { t.state = 'paused'; t.youPaused = true; }
      else if (e.paused === false && t.state === 'paused') t.resumeAsked = true;
      if (e.removed === true) t.removed = true;
    });
    return Object.keys(out).map(function (id) { return out[id]; }).sort(byTask);
  }
  P.tasks = effectiveTasks;
  P.task = function (id) { var l = effectiveTasks(), i; for (i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; };
  P.taskRoots = function () { return forest(effectiveTasks()).roots; };
  P.taskKids = function (id) { return forest(effectiveTasks()).kids[id] || []; };
  P.progress = function (taskId) {
    var all = effectiveTasks(), f = forest(all), byId = {}, done = 0, total = 0, seen = {};
    all.forEach(function (t) { byId[t.id] = t; });
    if (!byId[taskId]) return { done: 0, total: 0 };
    (function walk(id) {
      if (seen[id]) return;
      seen[id] = 1;
      var kids = (f.kids[id] || []).filter(function (k) { return !k.removed; });
      if (!kids.length) {
        if (!byId[id].removed || id === taskId) { total++; if (byId[id].state === 'done') done++; }
        return;
      }
      kids.forEach(function (k) { walk(k.id); });
    })(taskId);
    return { done: done, total: total };
  };

  /* ---------- asks and answers ---------- */
  P.askState = function (ask) {
    var r = ask && coll('replies')[ask.id];
    if (!r) return 'sent';
    return r.state === 'working' || r.state === 'answered' ? r.state : 'seen';
  };
  P.asksFor = function (kind, targetId) {
    var R = coll('replies');
    return listOf('asks').filter(function (a) { return a.targetKind === kind && a.targetId === targetId; })
      .sort(function (a, b) { var x = str(a.createdAt), y = str(b.createdAt); return x < y ? -1 : x > y ? 1 : (a.id < b.id ? -1 : 1); })
      .map(function (a) {
        var r = R[a.id] && typeof R[a.id] === 'object' ? Object.assign({}, R[a.id], { id: a.id }) : null;
        return { ask: a, reply: r, state: P.askState(a), seen: !!r };
      });
  };

  /* ---------- numbers ---------- */
  function questionsWaiting() {
    var n = QT.status && typeof QT.status.badgeCount === 'function' ? safe(function () { return Number(QT.status.badgeCount()); }, NaN) : NaN;
    if (isFinite(n)) return Math.max(0, Math.floor(n));
    var A = coll('answers'), c = 0;
    listOf('questions').forEach(function (q) { if (q.kind !== 'readonly' && q.sectionId !== 'kathy' && !A[q.id]) c++; });
    return c;
  }
  P.counts = function () {
    var ts = effectiveTasks().filter(function (t) { return !t.removed; }), ws = listOf('workers');
    return {
      questionsWaiting: questionsWaiting(),
      workersWorking: ws.filter(function (w) { return w.state === 'working'; }).length,
      tasksWaitingForYou: ts.filter(function (t) { return t.state === 'waiting' && t.waitingFor === 'owner'; }).length,
      tasksWorking: ts.filter(function (t) { return t.state === 'working'; }).length,
      tasksDone: ts.filter(function (t) { return t.state === 'done'; }).length
    };
  };

  /* ---------- watching ---------- */
  var WATCHED = { workers: 1, tasks: 1, replies: 1, taskAdds: 1, taskEdits: 1, asks: 1 };
  P.watch = function (fn) {
    if (typeof fn !== 'function' || typeof QT.on !== 'function') return function () {};
    var timer = 0, off = QT.on('store', function (ev) {
      if (ev && ev.collection && !WATCHED[ev.collection]) return;
      if (timer) return;
      timer = setTimeout(function () { timer = 0; try { fn(); } catch (e) { console.error(e); } }, 60);
    });
    return function () { if (typeof off === 'function') off(); if (timer) { clearTimeout(timer); timer = 0; } };
  };

  /* ---------- shared look: words, chip, bubble ---------- */
  P.ago = function (iso) { return QT.fmt && typeof QT.fmt.ago === 'function' ? str(safe(function () { return QT.fmt.ago(iso); }, '')) : ''; };
  P.initials = function (name) {
    var w = str(name).replace(/[^A-Za-z0-9À-ɏ ]+/g, ' ').trim().split(/\s+/).filter(Boolean);
    if (!w.length) return '?';
    if (w.length === 1) return w[0].slice(0, 2).toUpperCase();
    return (w[0].charAt(0) + w[1].charAt(0)).toUpperCase();
  };
  var UNSEEN_WORDS = {
    add: 'You added this', edit: 'You changed this', ask: 'Sent', pause: 'You paused this', resume: 'You asked to start it again', remove: 'You asked to remove this'
  };
  P.seenChip = function (o) {
    o = o || {};
    var what = UNSEEN_WORDS[o.what] ? o.what : 'add';
    if (o.seen) {
      var when = o.at ? P.ago(o.at) : '';
      return h('span', { class: 'chip pt-seen', title: 'Claude saw it.' }, h('span', { text: 'Claude saw it ✓' + (when ? ' · ' + when : '') }));
    }
    return h('span', { class: 'chip qt-unseen pt-pending', title: 'It is saved. Claude has not looked at it yet.' }, icon('clock'),
      h('span', { text: UNSEEN_WORDS[what] + ' · waiting for Claude to see it' }));
  };
  P.bubble = function (o) {
    o = o || {};
    var side = o.side === 'claude' ? 'claude' : 'you';
    var who = str(o.name) || (side === 'you' ? 'You' : 'Claude');
    var when = o.at ? P.ago(o.at) : '';
    var label = o.label || (side === 'you' ? 'Your question' : 'Answer from ' + who);
    var foot = (when || o.chip) ? h('div', { class: 'pt-bub-foot' }, when ? h('span', { class: 'pt-bub-when', text: when }) : null, o.chip || null) : null;
    return h('div', { class: 'pt-bub pt-' + side, role: 'group', 'aria-label': label },
      h('div', { class: 'pt-bub-name', text: side === 'you' && !o.name ? 'You' : who }),
      h('p', { class: 'pt-bub-text', text: str(o.text) }),
      foot);
  };

  /* ---------- the tab strip ---------- */
  var S = null;   // { root, strip, tabs: {part: button}, counts: {part: span}, sig, timer }
  var TAB_NOUN = { questions: ['question', 'questions'], workers: ['worker', 'workers'], tasks: ['task', 'tasks'] };
  function tabName(part, n) {
    if (!n) return LABEL[part];
    var noun = TAB_NOUN[part][n === 1 ? 0 : 1];
    if (part === 'workers') return LABEL[part] + ', ' + n + ' ' + noun + ' working';
    return LABEL[part] + ', ' + n + ' ' + noun + ' waiting for you';
  }
  function refreshTabs() {
    if (!S) return;
    var cur = P.current(), c = P.counts(), n = { questions: c.questionsWaiting, workers: c.workersWorking, tasks: c.tasksWaitingForYou };
    S.root.setAttribute('data-part', cur);
    PARTS.forEach(function (p) {
      var b = S.tabs[p], on = p === cur, el = S.counts[p];
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      b.tabIndex = on ? 0 : -1;
      b.classList.toggle('is-on', on);
      var num = Math.max(0, Math.floor(Number(n[p]) || 0));
      var txt = num > 99 ? '99+' : String(num);
      if (el.textContent !== txt) {
        var was = el.textContent;
        el.textContent = txt;
        if (was && was !== '0') { el.classList.remove('pt-tick'); void el.offsetWidth; el.classList.add('pt-tick'); }
      }
      el.hidden = num < 1;
      b.setAttribute('aria-label', tabName(p, num));
    });
  }
  function scheduleTabs() {
    if (!S || S.timer) return;
    S.timer = setTimeout(function () { S.timer = 0; refreshTabs(); fit(); }, 60);
  }
  /* Priority of the sticky things when the window is short or the text is big: top bar, then question bar, then this strip.
     The strip scrolls away (is-free) before the question bar has to; the layout's own rule (35% of the window) stays true for the Questions part. */
  function fit() {
    if (!S) return;
    var tb = S.root.querySelector('.topbar'), q = S.root.querySelector('#qt-view .qbar'), vh = window.innerHeight || 800;
    S.strip.classList.remove('is-free'); S.root.classList.remove('tabs-free');
    var tbH = tb ? tb.offsetHeight : 0, tH = S.strip.offsetHeight;
    var qH = q && getComputedStyle(q).position === 'sticky' ? q.offsetHeight : 0;
    if (tbH + tH + qH > 0.35 * vh) { S.strip.classList.add('is-free'); S.root.classList.add('tabs-free'); }
  }
  function onTabKey(e) {
    var k = e.key, i = PARTS.indexOf(document.activeElement && document.activeElement.getAttribute && document.activeElement.getAttribute('data-part')), to = -1;
    if (i < 0) return;
    if (k === 'ArrowRight' || k === 'ArrowDown') to = (i + 1) % PARTS.length;
    else if (k === 'ArrowLeft' || k === 'ArrowUp') to = (i + PARTS.length - 1) % PARTS.length;
    else if (k === 'Home') to = 0;
    else if (k === 'End') to = PARTS.length - 1;
    if (to < 0) return;
    e.preventDefault();
    PARTS.forEach(function (p) { S.tabs[p].tabIndex = -1; });
    S.tabs[PARTS[to]].tabIndex = 0;
    S.tabs[PARTS[to]].focus();
  }
  function fixTitle() {
    var t = document.title;
    if (/Question Terminal/.test(t)) document.title = t.replace(/Question Terminal/g, 'Terminal');
  }
  function installStrip(root) {
    if (S || !root || !root.querySelector) return;
    var topbar = root.querySelector('.topbar');
    if (!topbar) return;
    var tabs = {}, counts = {};
    var list = h('div', { class: 'pt-tablist', role: 'tablist', 'aria-label': 'Parts of the Terminal' });
    PARTS.forEach(function (p) {
      var cnt = h('span', { class: 'count' + (p === 'workers' ? ' calm' : ''), hidden: true, 'aria-hidden': 'true', text: '0' });
      var b = h('button', { type: 'button', class: 'pt-tab', role: 'tab', id: 'pt-tab-' + p, 'data-part': p, 'aria-selected': 'false', 'aria-controls': 'qt-main', tabindex: '-1', 'aria-label': LABEL[p] },
        icon(p), h('span', { class: 'pt-tab-t', text: LABEL[p] }), cnt);
      // another part: go there (the questions part returns to where she was); the open part: back to its top (the questions home)
      b.addEventListener('click', function () {
        if (P.current() !== p) P.go(p);
        else if (p === 'questions') { if (currentRoute().view !== 'home' && QT.route) QT.route.go('home'); }
        else P.go(p);
      });
      tabs[p] = b; counts[p] = cnt;
      list.appendChild(b);
    });
    list.addEventListener('keydown', onTabKey);
    var strip = h('div', { class: 'pt-strip', role: 'navigation', 'aria-label': 'Parts of the Terminal' }, list);   // not a <nav> element: other code finds the menu with querySelector('nav')
    topbar.parentNode.insertBefore(strip, topbar.nextSibling);
    root.classList.add('has-parts');
    document.documentElement.classList.add('pt-on');
    S = { root: root, strip: strip, tabs: tabs, counts: counts, sig: '', timer: 0 };

    var brand = root.querySelector('.brand-t');
    if (brand) brand.textContent = 'Terminal';
    fixTitle();
    var titleEl = document.querySelector('title') || document.head;
    if (window.MutationObserver) { try { new MutationObserver(fixTitle).observe(titleEl, { childList: true, characterData: true, subtree: true }); } catch (e) { /* no title watching */ } }

    // she opened the page with nothing remembered by the route but a remembered part (e.g. an older notebook): go there
    var stored = QT.storage ? QT.storage.get(PART_KEY) : null;
    if (QT.storage && QT.storage.get('qt.route') == null && (stored === 'workers' || stored === 'tasks') && P.current() === 'questions') {
      try { P.go(stored); } catch (e) { /* stay */ }
    }
    refreshTabs();
    if (typeof QT.on === 'function') {
      QT.on('route', function (ev) {
        rememberRoute(ev && ev.view ? ev : currentRoute());
        refreshTabs();
        fit();
        if (window.requestAnimationFrame) requestAnimationFrame(function () { requestAnimationFrame(fit); });
      });
      QT.on('store', function () { scheduleTabs(); });
      QT.on('ready', function () { refreshTabs(); fit(); });
      QT.on('offline', scheduleTabs); QT.on('online', scheduleTabs);
    }
    if (window.ResizeObserver) { try { var ro = new ResizeObserver(function () { fit(); }); ro.observe(root); ro.observe(strip); } catch (e) { /* no resize watching */ } }
    else window.addEventListener('resize', fit);
    rememberRoute(currentRoute());
    fit();
    if (window.requestAnimationFrame) requestAnimationFrame(function () { fit(); });
    setInterval(function () { refreshTabs(); }, 30000);
  }
  P.mountStrip = installStrip;

  // wrap the layout's mount: the strip is drawn right after the shell exists, before the first view
  if (QT.layout && typeof QT.layout.mount === 'function' && !QT.layout.mount._parts) {
    var origMount = QT.layout.mount;
    QT.layout.mount = function (root) {
      var out = origMount.apply(this, arguments);
      try { installStrip(root); } catch (e) { console.error('[QT] the tab strip could not be drawn', e); }
      return out;
    };
    QT.layout.mount._parts = true;
  }

  /* ---------- friendly stand-ins until the Workers / Tasks views exist (51-workers.js / 52-tasks.js replace them) ---------- */
  QT.views = QT.views || {};
  ['workers', 'tasks'].forEach(function (name) {
    if (typeof QT.views[name] === 'function') return;
    var fn = function (el) {
      var worker = name === 'workers';
      el.appendChild(h('div', { class: 'card info pt-soon' },
        h('h2', { text: worker ? 'The crew page is on its way' : 'The task page is on its way' }),
        h('p', { class: 'mt-s', text: worker ? 'Soon you will see here who is on Claude\'s crew and what each one is doing.' : 'Soon you will see here every task Claude is working on, big and small.' }),
        h('div', { class: 'mt-m' }, h('button', { type: 'button', class: 'btn', text: 'Back to the questions' }))));
      var b = el.querySelector('button');
      if (b) b.addEventListener('click', function () { P.go('questions'); });
    };
    fn.placeholder = true;
    QT.views[name] = fn;
  });
})();
