/* 21-visual.js  (owner: visual)
   The PICTURES of a question. The answer buttons are drawn by QT.answerUI, never here.
     QT.visual.render(el, q, opts)  the grid of versions A-D (+ a small "See how it looks now" link). Clicking a picture opens the big viewer.
                                    opts.onPick(key) adds a "Pick A" button on each picture; the chosen one is shown with a green border.
     QT.visual.thumbRow(images) a row of small pictures that open the big viewer (used for "See the result" on Done questions).
   Safety: every piece of text from a document goes in with textContent; a picture address must start with https://, data:image/ or be an uploaded picture (/_blob/<id>),
   otherwise the calm "Picture did not load" box is shown. No innerHTML anywhere in this file. */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var SVGNS = 'http://www.w3.org/2000/svg';
  var LETTERS = 'ABCDEFGH';
  var loaded = Object.create(null);      // address -> true once it has shown fine (a redraw then never flashes an empty box)
  var todayOpen = Object.create(null);   // question id -> true/false: what she chose for "How it looks now"
  var uid = 0;

  /* ---------- tiny helpers ---------- */
  function str(v) { return v == null ? '' : String(v); }
  function isObj(v) { return !!v && typeof v === 'object'; }
  function dim(n) { n = Number(n); return n > 0 && n <= 20000 ? Math.round(n) : 0; }
  function safeUrl(u) {
    u = str(u).trim();
    return (/^https:\/\//i.test(u) || /^data:image\//i.test(u) || /^\/_blob\/[0-9a-f]{32}$/i.test(u)) ? u : '';
  }
  function h(tag, cls, text, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null && text !== '') n.textContent = text;
    if (attrs) for (var k in attrs) { if (attrs[k] != null && attrs[k] !== false) n.setAttribute(k, attrs[k] === true ? '' : attrs[k]); }
    return n;
  }
  var ICONS = {
    zoom: ['M21 21l-5.2-5.2', 'c:10.5,10.5,6.5'],
    chev: ['M9 6l6 6-6 6'],
    image: ['r:3,4,18,16,2', 'M3 16l5-5 4 4 3-3 6 6', 'c:15.5,9,1.5']
  };
  function icon(name, size) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size || 18); s.setAttribute('height', size || 18);
    s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '2.4');
    s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    (ICONS[name] || []).forEach(function (d) {
      var p, a;
      if (d.indexOf('c:') === 0) { a = d.slice(2).split(','); p = document.createElementNS(SVGNS, 'circle'); p.setAttribute('cx', a[0]); p.setAttribute('cy', a[1]); p.setAttribute('r', a[2]); }
      else if (d.indexOf('r:') === 0) { a = d.slice(2).split(','); p = document.createElementNS(SVGNS, 'rect'); p.setAttribute('x', a[0]); p.setAttribute('y', a[1]); p.setAttribute('width', a[2]); p.setAttribute('height', a[3]); p.setAttribute('rx', a[4]); }
      else { p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', d); }
      s.appendChild(p);
    });
    return s;
  }
  function pictures(n) { return n === 1 ? '1 picture' : n + ' pictures'; }
  function esc(v) {   // text from a document inside a [data-x="..."] selector
    v = str(v);
    try { if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(v); } catch (e) { /* fall through */ }
    return v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/(["\\])/g, '\\$1');
  }

  /* ---------- one picture box: lazy image, calm placeholder when it cannot be shown ---------- */
  function placeholder(alt, withIcon) {
    var ph = h('span', 'qtv-ph');
    if (withIcon !== false) { var ic = h('span', 'qtv-ph-icon'); ic.appendChild(icon('image', 22)); ph.appendChild(ic); }
    ph.appendChild(h('span', 'qtv-ph-alt', alt || 'Picture'));
    ph.appendChild(h('span', 'qtv-ph-msg', 'Picture did not load'));
    return ph;
  }
  function makePic(im) {
    var pic = h('span', 'qtv-pic');
    var url = safeUrl(im.url), alt = str(im.alt).trim(), w = dim(im.w), hh = dim(im.h);
    function fail() {
      var old = pic.querySelector('img'); if (old && old.parentNode) old.parentNode.removeChild(old);
      pic.classList.remove('is-ok'); pic.classList.add('is-bad');
      if (!pic.querySelector('.qtv-ph')) pic.appendChild(placeholder(alt));
    }
    if (!url) { fail(); return pic; }
    var img = document.createElement('img');
    img.alt = '';                 // the button around it carries the name; the alt text is shown only if the picture fails
    img.draggable = false;
    img.referrerPolicy = 'no-referrer';      // a picture from another website does not learn which page it is shown on
    if (w && hh) { img.width = w; img.height = hh; }
    var known = loaded[url] === true;
    img.decoding = known ? 'sync' : 'async';
    if (!known) img.loading = 'lazy';
    img.addEventListener('load', function () { loaded[url] = true; pic.classList.add('is-ok'); });
    img.addEventListener('error', fail);
    if (known) pic.classList.add('is-ok', 'is-cached');
    img.src = url;
    pic.appendChild(img);
    return pic;
  }

  /* ---------- what to show: clean copies of the question's pictures, and the list the big viewer walks through ---------- */
  function normImg(im, caption) {
    return { url: str(im.url), alt: str(im.alt).trim(), w: dim(im.w), h: dim(im.h), caption: str(caption != null ? caption : im.caption).trim() };
  }
  function model(q) {
    q = isObj(q) ? q : {};
    var m = { id: str(q.id), before: [], versions: [], items: [] };
    (Array.isArray(q.beforeImages) ? q.beforeImages : []).forEach(function (b) { if (isObj(b)) m.before.push(normImg(b)); });
    (Array.isArray(q.versions) ? q.versions : []).forEach(function (v, i) {
      if (!isObj(v)) return;
      var key = str(v.key).trim().toUpperCase().slice(0, 2) || LETTERS.charAt(i) || String(i + 1);
      var imgs = (Array.isArray(v.images) ? v.images : []).filter(isObj).map(function (im) { return normImg(im, ''); });
      m.versions.push({ key: key, label: str(v.label).trim(), caption: str(v.caption).trim(), images: imgs, start: 0 });
    });
    m.before.forEach(function (b) {
      m.items.push({ url: b.url, alt: b.alt, caption: b.caption, label: '', group: 'Now', groupTitle: 'How it looks now', w: b.w, h: b.h });
    });
    m.versions.forEach(function (v) {
      v.start = m.items.length;
      v.images.forEach(function (im) {
        m.items.push({ url: im.url, alt: im.alt, caption: v.caption, label: v.label, key: v.key, w: im.w, h: im.h });
      });
    });
    return m;
  }

  /* ---------- small thumbnails (the "now" row and result rows) ---------- */
  function mini(im, n, total, prefix, items, index, returnTo, open) {
    var text = im.caption || im.alt || 'picture ' + n;
    var b = h('button', 'qtv-mini', null, {
      type: 'button',
      'aria-label': prefix + ', picture ' + n + ' of ' + total + ': ' + text + ', open big view',
      title: im.caption || im.alt || null,
      'data-idx': String(index)
    });
    var pic = makePic(im);
    var zoom = h('span', 'qtv-zoom', null, { 'aria-hidden': 'true' }); zoom.appendChild(icon('zoom', 14));
    pic.appendChild(zoom);
    b.appendChild(pic);
    if (im.caption) b.appendChild(h('span', 'qtv-mini-cap', im.caption));
    b.addEventListener('click', function () { open(items, index, b, returnTo); });
    return b;
  }

  /* ---------- "How it looks now" ----------
     With a versions grid: a header row above the grid: "Pick your favorite" on the left, a small link "See how it looks now" on the right that opens the strip BELOW the grid.
     Without a grid: a boxed, open strip. Her choice is remembered per question. */
  function buildToday(m, solo, open) {
    var id = 'qtv-today-' + (++uid);
    var isOpen = m.id in todayOpen ? todayOpen[m.id] : solo;
    var toggle = h('button', 'qtv-today-toggle' + (solo ? '' : ' is-link'), null, { type: 'button', 'aria-expanded': String(isOpen), 'aria-controls': id });
    var chev = icon('chev', 16); chev.setAttribute('class', 'qtv-chev');
    var title = h('span', 'qtv-today-title');
    var count = solo ? h('span', 'qtv-today-count', pictures(m.before.length)) : null;
    function words(on) { return solo ? 'How it looks now' : (on ? 'Hide how it looks now' : 'See how it looks now'); }
    title.textContent = words(isOpen);
    toggle.appendChild(chev); toggle.appendChild(title); if (count) toggle.appendChild(count);
    var body = h('div', 'qtv-today-body', null, { id: id });
    body.hidden = !isOpen;
    var row = h('div', 'qtv-minis');
    m.before.forEach(function (b, i) {
      row.appendChild(mini(b, i + 1, m.before.length, 'How it looks now', m.items, i, '.qtv-today-body .qtv-mini[data-idx="' + i + '"]', open));
    });
    body.appendChild(row);
    var box = solo ? h('section', 'qtv-today is-solo') : h('div', 'qtv-today-wrap');
    if (m.before.length === 1) body.className += ' is-single';
    toggle.addEventListener('click', function () {
      var now = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(now));
      title.textContent = words(now);
      body.hidden = !now;
      box.classList.toggle('is-open', now);
      if (m.id) todayOpen[m.id] = now;
    });
    box.classList.toggle('is-open', isOpen);
    if (solo) { box.appendChild(toggle); box.appendChild(body); return { top: box, toggle: null, below: null }; }
    body.className += ' qtv-today-below';
    return { top: null, toggle: toggle, below: body };
  }

  /* ---------- one version: the picture (opens the big viewer) + a "Pick" button on top of it ---------- */
  function strip(v) {
    var s = h('span', 'qtv-strip');
    s.appendChild(h('span', 'qtv-badge', v.key, { 'aria-hidden': 'true' }));
    var t = h('span', 'qtv-text');
    t.appendChild(h('span', 'qtv-label', v.label || ('Version ' + v.key)));
    if (v.caption) { t.appendChild(document.createTextNode(' ')); t.appendChild(h('span', 'qtv-cap', v.caption)); }
    s.appendChild(t);
    return s;
  }
  function buildCell(m, v, st) {
    var n = v.images.length;
    var name = 'Version ' + v.key + (v.label ? ': ' + v.label : '');
    var cell = h('div', 'qtv-cell', null, { 'data-cell': v.key });
    if (!n) {
      var empty = h('div', 'qtv-card is-empty', null, { 'data-vkey': v.key, role: 'group', 'aria-label': name + ', no picture' });
      var ep = h('span', 'qtv-pic is-bad'), eph = h('span', 'qtv-ph');
      var eic = h('span', 'qtv-ph-icon'); eic.appendChild(icon('image', 22));
      eph.appendChild(eic); eph.appendChild(h('span', 'qtv-ph-alt', 'No picture for this version yet'));
      ep.appendChild(eph);
      empty.appendChild(ep); empty.appendChild(strip(v));
      cell.appendChild(empty);
      return cell;
    }
    var card = h('button', 'qtv-card', null, {
      type: 'button',
      'data-vkey': v.key,
      'aria-label': name + (n > 1 ? ', picture 1 of ' + n : '') + ', open big view',
      title: ([v.label, v.caption].filter(Boolean).join(' - ') + (v.label || v.caption ? '. ' : '') + (st.coarse ? 'Tap' : 'Click') + ' to see it big.')
    });
    var pic = makePic(v.images[0]);
    if (n > 1) pic.appendChild(h('span', 'qtv-more', '+' + (n - 1), { 'aria-hidden': 'true' }));
    card.appendChild(pic);
    card.appendChild(strip(v));
    card.addEventListener('click', function () { st.open(m.items, v.start, card, '.qtv-card[data-vkey="' + esc(v.key) + '"]'); });
    cell.appendChild(card);
    return cell;
  }
  function buildPick(v, st) {
    var name = 'Pick version ' + v.key + (v.label ? ': ' + v.label : '');
    var b = h('button', 'qtv-pick', null, { type: 'button', 'data-pick': v.key, 'aria-label': name, 'aria-pressed': 'false' });
    b.appendChild(h('span', 'qtv-pick-in', 'Pick ' + v.key));
    b.addEventListener('click', function () { if (st.opts && typeof st.opts.onPick === 'function') st.opts.onPick(v.key); });
    return b;
  }

  /* what she picked: QT.store.answers[qid].key, when it is one of the versions */
  function pickedKey(m) {
    try {
      var a = QT.store && QT.store.answers && QT.store.answers[m.id];
      if (!a || a.status === 'skipped') return '';
      var k = str(a.key).toUpperCase();
      return m.versions.some(function (v) { return v.key === k; }) ? k : '';
    } catch (e) { return ''; }
  }
  function applyPicked(root, m) {
    var k = pickedKey(m);
    Array.prototype.forEach.call(root.querySelectorAll('.qtv-cell'), function (cell) {
      var key = cell.getAttribute('data-cell'), on = key === k;
      cell.classList.toggle('is-picked', on);
      var pb = cell.querySelector('.qtv-pick'), t = pb && pb.querySelector('.qtv-pick-in');
      if (pb) { pb.setAttribute('aria-pressed', on ? 'true' : 'false'); }
      if (t) t.textContent = on ? '✓ Your pick' : 'Pick ' + key;
    });
  }

  function signature(m, opts) {
    try { return JSON.stringify([m.id, m.before, m.versions, !!(opts && typeof opts.onPick === 'function')]); } catch (e) { return String(Math.random()); }
  }

  /* render(el, q, opts)   opts.onPick(key): shows a "Pick A" button on each picture (and "Pick this version" in the big viewer).
     The chosen version (QT.store.answers[q.id].key) gets a green border and "Your pick" while the box is on the page. */
  function render(host, q, opts) {
    if (!host || !host.appendChild) return function () {};
    var m = model(q), sig = signature(m, opts);
    var prev = host.__qtv;
    if (prev && prev.sig === sig && prev.root.parentNode === host) { prev.st.opts = opts || null; return prev.destroy; }   // nothing changed: leave the page exactly as it is
    if (prev) prev.destroy();                                                                                         // only ever replaces its own box, never other things in host

    var st = { opts: opts || null, coarse: !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches), open: null };
    var canPick = !!(opts && typeof opts.onPick === 'function');
    st.open = function (items, index, opener, returnTo) {
      if (!QT.lightbox || typeof QT.lightbox.open !== 'function') return;
      var lb = { opener: opener, returnTo: returnTo };
      lb.focusFor = function (i) {   // when the viewer closes, focus goes to the picture she was looking at last
        var it = m.items[i];
        if (!it) return null;
        return it.key ? '.qtv-card[data-vkey="' + esc(it.key) + '"]' : '.qtv-today-body .qtv-mini[data-idx="' + i + '"]';
      };
      if (canPick) {
        lb.onPick = function (key) { if (st.opts && typeof st.opts.onPick === 'function') st.opts.onPick(key); };
        lb.picked = function () { return pickedKey(m); };
      }
      QT.lightbox.open(items, index, lb);
    };

    var root = h('div', 'qtv', null, { 'data-qid': m.id || null });
    var hasGrid = m.versions.length > 0, below = null, head = null;
    if (m.before.length) {
      var t = buildToday(m, !hasGrid, st.open);
      if (t.top) root.appendChild(t.top);   // no grid: a boxed strip
      else { head = t; below = t.below; }
    }
    if (hasGrid && (canPick || head)) {      // the grid header row: "Pick your favorite" on the left, "See how it looks now" on the right
      var row = h('div', 'qtv-head' + (head ? ' has-link' : ''));
      if (canPick) row.appendChild(h('p', 'qtv-head-label', 'Pick your favorite'));
      if (head) row.appendChild(head.toggle);
      root.appendChild(row);
    }
    if (hasGrid) {
      var grid = h('div', 'qtv-grid' + (m.versions.some(function (v) { return !!v.caption; }) ? ' has-caps' : ''), null, { role: 'group', 'aria-label': 'Pictures of the versions. Each letter is one version to choose from. Click a picture to see it big.', 'data-n': String(Math.min(m.versions.length, 5)) });
      m.versions.forEach(function (v) {
        var cell = buildCell(m, v, st);
        if (v.images.length && canPick) cell.appendChild(buildPick(v, st));
        grid.appendChild(cell);
      });
      root.appendChild(grid);
      if (below) root.appendChild(below);
    } else if (!m.before.length) {
      root.appendChild(h('p', 'qtv-none', 'There are no pictures for this question.'));
    }
    host.appendChild(root);
    applyPicked(root, m);

    var watching = false, wasOnPage = false;
    function onStore(ev) {
      if (ev && ev.collection && ev.collection !== 'answers') return;
      if (root.isConnected) wasOnPage = true; else if (wasOnPage) { destroy(); return; }
      applyPicked(root, m);
    }
    if (m.id && typeof QT.on === 'function') { QT.on('store', onStore); watching = true; }
    function destroy() {
      if (watching) { watching = false; if (typeof QT.off === 'function') QT.off('store', onStore); }
      if (root.parentNode) root.parentNode.removeChild(root);
      if (host.__qtv && host.__qtv.root === root) host.__qtv = null;
    }
    host.__qtv = { sig: sig, root: root, destroy: destroy, st: st };
    return destroy;
  }

  /* A row of small pictures that open the big viewer. images: [{url, alt, w, h, caption?}]. opts.label names them for screen readers (default "Result"). */
  function thumbRow(images, opts) {
    opts = opts || {};
    var label = str(opts.label).trim() || 'Result';
    var list = (Array.isArray(images) ? images : []).filter(isObj).map(function (im) { return normImg(im); });
    var row = h('div', 'qtv-minis qtv-results');
    if (!list.length) { row.hidden = true; return row; }
    var items = list.map(function (im) { return { url: im.url, alt: im.alt, caption: im.caption, label: '', w: im.w, h: im.h }; });
    var rid = 'qtv-r' + (++uid);
    var open = function (its, index, opener, returnTo) {
      if (QT.lightbox && QT.lightbox.open) QT.lightbox.open(its, index, { opener: opener, returnTo: returnTo, focusFor: function (i) { return '[data-rid="' + rid + '"] .qtv-mini[data-idx="' + i + '"]'; } });
    };
    row.setAttribute('data-rid', rid);
    list.forEach(function (im, i) { row.appendChild(mini(im, i + 1, list.length, label, items, i, '[data-rid="' + rid + '"] .qtv-mini[data-idx="' + i + '"]', open)); });
    return row;
  }

  QT.visual = QT.visual || {};
  QT.visual.render = render;
  QT.visual.thumbRow = thumbRow;
  QT.visual.safeUrl = safeUrl;
})();
