/* 10-layout.js  (owner: layout)
   QT.layout.mount(root): top bar, left menu (drop-down when narrow), main area, toasts, offline banner.
   Calls QT.views[view](el, params) for the current route and the previous view's cleanup. See notes/layout-classes.md. */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var L = QT.layout = QT.layout || {};

  var BUILTIN = ['look', 'other', 'downloads', 'later', 'kathy'];   // menu order
  var OPTIONAL = { downloads: 1 };   // shown only when its section document exists (an older notebook has none: no link to nowhere)
  var FALLBACK_TITLE = { look: 'Look and feel', other: 'Other questions', downloads: 'Downloads and skills', later: 'Ideas for later', kathy: 'Questions for Miss Cathy and Rob' };
  var BUILTIN_ICON = { look: 'image', other: 'chat', downloads: 'download', later: 'bulb', kathy: 'people' };
  var TEST_LABEL = 'Check Claude hears me';
  var TEST_SHORT = 'Check Claude';
  var SOUND_HINT = 'Play a happy sound when something new arrives';

  /* ---------- tiny helpers (no innerHTML anywhere) ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag), k, v, ev, i;
    if (attrs) for (k in attrs) {
      v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'hidden') el.hidden = !!v;
      else if (k === 'on') { for (ev in v) el.addEventListener(ev, v[ev]); }
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    for (i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
    el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  }
  var SVGNS = 'http://www.w3.org/2000/svg';
  var ICONS = {
    home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
    image: 'M4 5h16v14H4zM8.5 10.5a1.5 1.5 0 1 0 0-.01M20 16l-5-5-9 8',
    chat: 'M4 5h16v11H9.5L4 20z',
    bulb: 'M9 18h6M10 21h4M12 3a6 6 0 0 0-3.8 10.6c.8.7 1.1 1.4 1.1 2.4h5.4c0-1 .3-1.7 1.1-2.4A6 6 0 0 0 12 3z',
    people: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20c0-3.6 2.8-6 6.5-6s6.5 2.4 6.5 6M16 4.3a3.5 3.5 0 0 1 0 6.4M18 14.4c2.2.7 3.5 2.6 3.5 5.6',
    folder: 'M3 6h6l2 2h10v11H3z',
    download: 'M12 4v10M8 10.5l4 4 4-4M5 19h14',
    plus: 'M12 5v14M5 12h14',
    done: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8 12l3 3 5-6',
    bell: 'M6 16v-5a6 6 0 0 1 12 0v5l2 2H4zM10 21h4',
    bellOff: 'M6 16v-5a6 6 0 0 1 12 0v5l2 2H4zM10 21h4M4 4l16 16',
    menu: 'M4 7h16M4 12h16M4 17h16',
    wifi: 'M3 9.5a14 14 0 0 1 18 0M6 13a9.5 9.5 0 0 1 12 0M9 16.5a5 5 0 0 1 6 0M12 20h.01',
    logo: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9.5a2.6 2.6 0 1 1 3.6 2.4c-.8.4-1.1.9-1.1 1.8M12 17h.01'
  };
  function icon(name) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    var p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', ICONS[name] || ICONS.logo); s.appendChild(p);
    return s;
  }
  // a small filled speech bubble with a tick: a picture, not a control (no outline, no circle)
  function markIcon() {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic mark'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    var a = document.createElementNS(SVGNS, 'path'); a.setAttribute('d', 'M5 3.5h14a2.5 2.5 0 0 1 2.5 2.5v8.5a2.5 2.5 0 0 1-2.5 2.5h-6.2L8 21.5V17H5a2.5 2.5 0 0 1-2.5-2.5V6A2.5 2.5 0 0 1 5 3.5z');
    var b = document.createElementNS(SVGNS, 'path'); b.setAttribute('d', 'M7.8 10.6l2.8 2.8 5.6-5.8');
    s.appendChild(a); s.appendChild(b);
    return s;
  }
  function cssEsc(v) {   // an id from a document inside a [data-x="..."] selector
    v = String(v);
    try { if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(v); } catch (e) { /* fall through */ }
    return v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/(["\\])/g, '\\$1');
  }
  function safe(fn, dflt) { try { var r = fn(); return r === undefined ? dflt : r; } catch (e) { return dflt; } }
  // "narrow" = the menu is a drop-down. The CSS decides (a container query in em, so big text and zoom count); the menu button is only drawn then.
  function isNarrow() { return !!S && getComputedStyle(S.menuBtn).display !== 'none'; }
  // The sticky bars (top bar + question bar) must not eat the window: more than 35% of its height (a short window, big text) and the question bar scrolls away.
  function fitQbar() {
    if (!S) return;
    var q = S.viewEl.querySelector('.qbar');
    if (!q) return;
    q.classList.remove('qbar-free');
    if (S.topbar.offsetHeight + q.offsetHeight > 0.35 * window.innerHeight) q.classList.add('qbar-free');
  }

  var S = null; // state of the mounted shell

  /* ---------- data helpers (all guarded: other modules may be missing while testing) ---------- */
  function allSections() {
    var list = safe(function () { return QT.sections && QT.sections.list ? QT.sections.list() : null; }, null);
    if (!Array.isArray(list)) {
      var st = (QT.store && QT.store.sections) || {};
      list = Object.keys(st).map(function (k) { return st[k]; }).filter(function (s) { return s && !s.archived; })
        .sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
    }
    return list;
  }
  function menuModel() {
    var list = allSections(), byId = {}, store = (QT.store && QT.store.sections) || {};
    list.forEach(function (s) { byId[s.id] = s; });
    var built = [], custom = [];
    BUILTIN.forEach(function (id) {
      if (store[id] && store[id].archived) return;
      if (OPTIONAL[id] && !byId[id]) return;
      built.push(byId[id] || { id: id, title: FALLBACK_TITLE[id], kind: 'builtin' });
    });
    list.forEach(function (s) { if (BUILTIN.indexOf(s.id) < 0) custom.push(s); });
    return { built: built, custom: custom };
  }
  function badgeFor(id) {
    var n = 0;
    try {
      if (id === 'kathy') {
        var qs = QT.sections && QT.sections.questionsOf ? QT.sections.questionsOf('kathy') : Object.keys(QT.store.questions || {}).map(function (k) { return QT.store.questions[k]; }).filter(function (q) { return q.sectionId === 'kathy'; });
        n = qs.filter(function (q) { return !(QT.status && QT.status.state && QT.status.state(q.id) === 'done'); }).length;
      } else if (QT.status && QT.status.badgeCount) n = QT.status.badgeCount(id);
    } catch (e) { n = 0; }
    return Number(n) > 0 ? Math.floor(Number(n)) : 0;
  }
  function currentSectionId() {
    var r = S.route || {}, p = r.params || {};
    if (r.view === 'section') return p.id || null;
    if (r.view === 'question') {
      var q = QT.store && QT.store.questions && QT.store.questions[p.id];
      return q ? q.sectionId : null;
    }
    return null;
  }

  /* ---------- menu ---------- */
  function go(view, params) {
    closeMenu();
    if (QT.route && typeof QT.route.go === 'function') QT.route.go(view, params);
  }
  function menuLabel(s) {
    var t = s.title || FALLBACK_TITLE[s.id] || 'My section';
    return s.id === 'kathy' && /^Questions for /i.test(t) ? t.replace(/^Questions for /i, '') : t; // shorter in the menu: "Miss Cathy and Rob" 
  }
  function menuItem(o) {
    var b = h('button', { type: 'button', class: 'mi' + (o.cls ? ' ' + o.cls : ''), 'data-key': o.key, title: o.full && o.full !== o.title ? o.full : null, on: { click: o.onClick } },
      o.icon ? icon(o.icon) : h('span', { class: 'ic', 'aria-hidden': 'true' }), h('span', { class: 'mi-t', text: o.title }));
    if (o.current) b.setAttribute('aria-current', 'page');
    if (o.count) b.appendChild(h('span', { class: 'count' + (o.calm ? ' calm' : ''), text: String(o.count), 'aria-label': o.count + (o.calm ? ' questions to read' : ' waiting') }));
    return b;
  }
  function refreshMenu() {
    if (!S) return;
    var m = menuModel(), r = S.route || { view: 'home' }, curSec = currentSectionId(), items = [], total = 0;
    items.push({ key: 'home', icon: 'home', title: 'Home', current: r.view === 'home', onClick: function () { go('home'); } });
    var rows = [];
    m.built.forEach(function (s) {
      var n = badgeFor(s.id), calm = s.id === 'kathy';
      if (!calm) total += n;
      rows.push({ key: 's:' + s.id, icon: BUILTIN_ICON[s.id] || 'folder', title: menuLabel(s), full: s.title || FALLBACK_TITLE[s.id], count: n, calm: calm, current: curSec === s.id, onClick: function () { go('section', { id: s.id }); } });
    });
    var crow = m.custom.map(function (s) {
      var n = badgeFor(s.id); total += n;
      return { key: 's:' + s.id, icon: 'folder', title: s.title || 'My section', count: n, current: curSec === s.id, onClick: function () { go('section', { id: s.id }); } };
    });
    var addRow = { key: 'new', icon: null, cls: 'add', title: '+ New section', current: r.view === 'newsection', onClick: function () { go('newsection'); } };
    var doneRow = { key: 'done', icon: 'done', title: 'What Claude finished', full: 'Only things Claude has finished. Your other answers stay in their own sections.', current: r.view === 'done', onClick: function () { go('done'); } };

    var sig = items.concat(rows, crow, [addRow, doneRow]).map(function (o) { return [o.key, o.title, o.count || 0, o.current ? 1 : 0].join('~'); }).join('|');
    if (sig !== S.menuSig) {
      S.menuSig = sig;
      var hadFocus = S.menu.contains(document.activeElement) ? document.activeElement.getAttribute('data-key') : null;
      S.menu.textContent = '';
      items.concat(rows).forEach(function (o, i) {
        S.menu.appendChild(menuItem(o));
        if (i === 0) S.menu.appendChild(h('hr'));
      });
      if (crow.length) {
        S.menu.appendChild(h('div', { class: 'mi-label', text: 'My sections' }));
        crow.forEach(function (o) { S.menu.appendChild(menuItem(o)); });
      }
      S.menu.appendChild(menuItem(addRow));
      S.menu.appendChild(h('hr'));
      S.menu.appendChild(menuItem(doneRow));
      if (hadFocus) { var again = S.menu.querySelector('[data-key="' + cssEsc(hadFocus) + '"]'); if (again) again.focus({ preventScroll: true }); }
    }
    // the little number on the drop-down button (all waiting questions she can answer)
    S.menuCount.textContent = String(total);
    S.menuCount.hidden = total < 1;
    S.menuBtn.setAttribute('aria-label', total > 0 ? 'Menu, ' + total + ' questions waiting' : 'Menu');
  }
  function scheduleMenu() {
    if (!S || S.menuTimer) return;
    S.menuTimer = setTimeout(function () { S.menuTimer = 0; refreshMenu(); }, 60);
  }
  function openMenu() {
    if (!S || !isNarrow()) return;
    S.menu.classList.add('open'); S.root.classList.add('menu-open'); S.menuBtn.setAttribute('aria-expanded', 'true');
    var cur = S.menu.querySelector('[aria-current="page"]') || S.menu.querySelector('.mi');
    if (cur) cur.focus({ preventScroll: true });
  }
  function closeMenu(refocus) {
    if (!S) return;
    var was = S.menu.classList.contains('open');
    S.menu.classList.remove('open'); S.root.classList.remove('menu-open'); S.menuBtn.setAttribute('aria-expanded', 'false');
    if (was && refocus) S.menuBtn.focus({ preventScroll: true });
  }

  /* ---------- top bar bits ---------- */
  function refreshHeartbeat() {
    if (!S) return;
    var r = safe(function () { return QT.status && QT.status.heartbeatLabel ? QT.status.heartbeatLabel() : null; }, null);
    var hb = S.hb;
    if (!r || !r.text) { hb.hidden = true; return; }
    var text = String(r.text);
    var key = text + '|' + (r.stale ? 1 : 0);
    hb.hidden = false;
    if (key === S.hbKey) return;
    S.hbKey = key;
    hb.textContent = '';
    hb.classList.toggle('stale', !!r.stale);
    var m = /^(Claude last [A-Za-z ]*?:?\s+)(?=\d|just now|yesterday|[A-Z][a-z]{2} \d)(.*?)(\s*\(.*\))?$/.exec(text);
    hb.title = m ? 'Claude last checked for your answers ' + m[2] + (m[3] ? (/safe/i.test(m[3]) ? ' ' + m[3].trim() : ' (Claude may be busy. Your answers are safe.)') : '') : text;
    if (m) {
      hb.appendChild(h('span', { class: 'hb-long', text: m[1] }));
      hb.appendChild(h('span', { class: 'hb-mid', text: 'Claude checked ' }));
      hb.appendChild(h('span', { class: 'hb-short', text: 'Claude: ' }));
      hb.appendChild(h('span', { class: 'hb-when', text: m[2] }));
      if (m[3]) hb.appendChild(h('span', { class: 'hb-extra', text: m[3] }));
    } else hb.appendChild(document.createTextNode(text));
    fitHb();
  }
  // The time ("2 min ago") must never be cut. Try, in this order, the label in one line with the lead text getting shorter
  // (long -> "Claude checked" -> "Claude:" -> nothing); only a stale label (it has a hint) may then wrap onto two or three lines, with the
  // title stepping aside, and finally in smaller type. The title steps aside only when the label truly needs the room.
  function fitHb() {
    if (!S || S.hb.hidden) return;
    var hb = S.hb, tm = S.tbMain, stale = hb.classList.contains('stale');
    var spans = !!hb.querySelector('.hb-when');
    tm.classList.remove('aside'); hb.classList.remove('wrap', 'small');
    if (!spans) return;
    var oneLine = function () { return hb.scrollWidth <= hb.clientWidth + 1; };
    var fitsBar = function () { return hb.scrollWidth <= hb.clientWidth + 1 && hb.getBoundingClientRect().height <= S.topbar.clientHeight - 3; };
    var st;
    for (st = 0; st <= 3; st++) { hb.setAttribute('data-stage', st); if (oneLine()) return; }
    if (stale) {
      tm.classList.add('aside'); hb.classList.add('wrap');
      for (var pass = 0; pass < 2; pass++) {
        hb.classList.toggle('small', pass === 1);
        for (st = 0; st <= 3; st++) { hb.setAttribute('data-stage', st); if (fitsBar()) return; }
      }
    }
    hb.setAttribute('data-stage', 3);   // last resort: only the time (and the hint)
  }
  function refreshConn() {
    if (!S) return;
    var off = !!QT.offline;
    S.live.classList.toggle('off', off);
    S.liveText.textContent = off ? 'Not connected' : 'Live';
    S.live.title = off ? 'Not connected' : 'Connected to Claude';
    S.banner.hidden = !off;
    S.bannerWrap.hidden = !off;
  }
  function refreshSound() {
    if (!S) return;
    var has = !!(QT.sound && typeof QT.sound.enabled === 'function');
    S.soundBtn.hidden = !has;
    if (!has) return;
    var on = !!safe(function () { return QT.sound.enabled(); }, false);
    S.soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    S.soundBtn.setAttribute('aria-label', (on ? 'Sound: on' : 'Sound: off') + '. ' + SOUND_HINT);
    S.soundBtn.title = on ? 'Sound is on. Click to turn it off. ' + SOUND_HINT + '.' : SOUND_HINT + '. Click to turn it on.';
    S.soundLbl.textContent = on ? 'Sound: on' : 'Sound: off';
    S.soundBtn.replaceChildren(icon(on ? 'bell' : 'bellOff'), S.soundLbl);
  }
  function refreshTest() {
    if (!S) return;
    S.testBtn.hidden = !(QT.status && typeof QT.status.testConnection === 'function');
  }
  function refreshAll() { refreshConn(); refreshHeartbeat(); refreshSound(); refreshTest(); scheduleMenu(); }

  function onSoundClick() {
    if (!(QT.sound && typeof QT.sound.set === 'function')) return;
    var now = !!safe(function () { return QT.sound.enabled(); }, false);
    safe(function () { QT.sound.set(!now); });
    refreshSound();
    if (!now && typeof QT.sound.chime === 'function') safe(function () { QT.sound.chime(); }); // one click gives the browser permission to play, so it can play now
  }
  function onTestClick() {
    if (!(QT.status && typeof QT.status.testConnection === 'function') || S.testBusy) return;
    S.testBusy = true; S.testBtn.disabled = true; S.testLong.textContent = 'Checking…'; S.testShort.textContent = 'Checking…';
    var done = function () { S.testBusy = false; S.testBtn.disabled = false; S.testLong.textContent = TEST_LABEL; S.testShort.textContent = TEST_SHORT; };
    var out;
    try { out = QT.status.testConnection(S.testBtn); } catch (e) { console.error(e); done(); toast('The check did not run. Please try again.', { kind: 'warn' }); return; }
    // the status module shows its own messages through QT.layout.toast; only a plain string result is shown here
    Promise.resolve(out).then(function (v) { if (typeof v === 'string' && v) toast(v, { kind: 'info' }); })
      .catch(function (e) { console.error(e); toast('The check did not run. Please try again.', { kind: 'warn' }); }).then(done);
  }

  /* ---------- toasts ---------- */
  function toast(text, opts) {
    if (!S || !text) return null;
    opts = opts || {};
    var kind = opts.kind || '', ms = opts.ms || (kind === 'warn' ? 7000 : 5000);
    // same text already on screen: just keep it a bit longer
    var existing = S.toasts.querySelectorAll('.toast'), i;
    for (i = 0; i < existing.length; i++) {
      if (existing[i].getAttribute('data-text') === text) { clearTimeout(existing[i]._t); existing[i]._t = setTimeout(existing[i]._close, ms); return existing[i]; }
    }
    var el = h('div', { class: 'toast' + (kind ? ' ' + kind : ''), role: kind === 'warn' ? 'alert' : 'status', 'data-text': text },
      h('span', { class: 'grow', text: text }),
      h('button', { type: 'button', class: 'toast-x', 'aria-label': 'Close this message' }));
    el._close = function () { clearTimeout(el._t); if (el.parentNode) el.parentNode.removeChild(el); };
    el.querySelector('.toast-x').addEventListener('click', el._close);
    el._t = setTimeout(el._close, ms);
    S.toasts.appendChild(el);
    while (S.toasts.children.length > 3) S.toasts.removeChild(S.toasts.firstChild);
    return el;
  }

  /* ---------- views ---------- */
  function currentRoute() {
    var r = QT.route, c = null;
    if (r) c = typeof r.current === 'function' ? safe(function () { return r.current(); }, null) : (r.current || (typeof r.get === 'function' ? safe(function () { return r.get(); }, null) : null));
    if (!c && r && r.view) c = { view: r.view, params: r.params };
    return c && c.view ? { view: c.view, params: c.params || {} } : { view: 'home', params: {} };
  }
  function renderRoute(route) {
    if (!S) return;
    route = route && route.view ? { view: route.view, params: route.params || {} } : { view: 'home', params: {} };
    var stamp = JSON.stringify(route);
    if (stamp === S.lastStamp && Date.now() - S.lastAt < 150) return; // a double notice for the same page
    S.lastStamp = stamp; S.lastAt = Date.now();
    var token = ++S.token;
    if (S.cleanup) { var c = S.cleanup; S.cleanup = null; try { c(); } catch (e) { console.error('view cleanup failed', e); } }
    var el = h('div', { class: 'view', id: 'qt-view' });
    S.main.replaceChild(el, S.viewEl); S.viewEl = el;
    S.route = route;
    closeMenu();
    refreshMenu();
    if (S.rendered) { window.scrollTo(0, 0); try { S.main.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
    S.rendered = true;
    var fn = QT.views && QT.views[route.view];
    if (typeof fn !== 'function') {
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'This page is not ready yet' }), h('p', { class: 'muted mt-s', text: 'Please use the menu to go somewhere else.' })));
      return;
    }
    try {
      var out = fn(el, route.params);
      if (typeof out === 'function') S.cleanup = out;
      else if (out && typeof out.then === 'function') out.then(function (f) {
        if (typeof f !== 'function') return;
        if (S && S.token === token) S.cleanup = f; else try { f(); } catch (e) { console.error(e); }
      }, function (e) { console.error('view failed', e); showViewError(el); });
    } catch (e) {
      console.error('view failed', e);
      showViewError(el);
    }
    fitQbar(); if (window.requestAnimationFrame) requestAnimationFrame(fitQbar);
  }
  function showViewError(el) {
    el.textContent = '';
    el.appendChild(h('div', { class: 'card warn' }, h('h2', { text: 'Something went wrong showing this page' }),
      h('p', { class: 'mt-s', text: 'Your answers are safe. Please try the Home button in the menu.' })));
  }

  /* ---------- mount ---------- */
  L.mount = function (root) {
    if (!root) return;
    if (S) { if (S.root === root) return; }
    root.textContent = '';
    root.classList.add('qt-app');

    var menuBtn = h('button', { type: 'button', class: 'btn menu-btn', 'aria-expanded': 'false', 'aria-controls': 'qt-menu', 'aria-haspopup': 'true' },
      icon('menu'), h('span', { class: 'lbl', text: 'Menu' }), h('span', { class: 'count', hidden: true }));
    var live = h('span', { class: 'live', role: 'status' }, h('span', { class: 'dot', 'aria-hidden': 'true' }), h('span', { class: 'live-t', text: 'Live' }));
    var hb = h('span', { class: 'hb', 'data-stage': '0', hidden: true });
    var soundLbl = h('span', { class: 'lbl', text: 'Sound: off' });
    var soundBtn = h('button', { type: 'button', class: 'btn tgl sound-btn', 'aria-label': 'Sound: off. ' + SOUND_HINT, title: SOUND_HINT + '. Click to turn it on.', 'aria-pressed': 'false', hidden: true }, icon('bellOff'), soundLbl);
    var testLong = h('span', { class: 'lbl lbl-long', text: TEST_LABEL });
    var testShort = h('span', { class: 'lbl lbl-short', text: TEST_SHORT });
    var testBtn = h('button', { type: 'button', class: 'btn test-btn', title: 'Sends Claude a small test note. Nothing changes.', 'aria-label': TEST_LABEL, hidden: true }, icon('wifi'), testLong, testShort);
    var tbMain = h('div', { class: 'tb-main' }, h('div', { class: 'brand-t', text: 'Terminal' }), h('div', { class: 'tb-status' }, live, hb));
    var topbar = h('header', { class: 'topbar' },
      menuBtn,
      h('span', { class: 'brand', 'aria-hidden': 'true' }, markIcon()),
      tbMain,
      soundBtn, testBtn);

    var menu = h('nav', { class: 'menu', id: 'qt-menu', 'aria-label': 'Sections' });
    var backdrop = h('div', { class: 'menu-backdrop', 'aria-hidden': 'true' });
    var banner = h('div', { class: 'banner warn', id: 'qt-offline', role: 'status', hidden: true },
      h('span', { class: 'banner-text', text: 'No connection. You can read, but answers will not save yet.' }));
    var bannerWrap = h('div', { class: 'banner-wrap', hidden: true }, banner);
    var viewEl = h('div', { class: 'view', id: 'qt-view' }, h('p', { class: 'view-loading', text: 'Loading…' }));
    var main = h('main', { class: 'qt-main', id: 'qt-main', tabindex: '-1' }, bannerWrap, viewEl);
    var toasts = h('div', { class: 'toasts', 'aria-live': 'polite' });

    root.appendChild(topbar); root.appendChild(menu); root.appendChild(backdrop); root.appendChild(main); root.appendChild(toasts);

    S = { root: root, topbar: topbar, menu: menu, menuBtn: menuBtn, menuCount: menuBtn.querySelector('.count'), live: live, liveText: live.querySelector('.live-t'),
      hb: hb, tbMain: tbMain, soundBtn: soundBtn, soundLbl: soundLbl, testBtn: testBtn, testLong: testLong, testShort: testShort, banner: banner, bannerWrap: bannerWrap, main: main, viewEl: viewEl, toasts: toasts,
      route: currentRoute(), cleanup: null, token: 0, rendered: false, lastStamp: '', lastAt: 0, menuSig: '', hbKey: '', menuTimer: 0, testBusy: false, ready: false, pending: null };

    menuBtn.addEventListener('click', function () { if (menu.classList.contains('open')) closeMenu(true); else openMenu(); });
    backdrop.addEventListener('click', function () { closeMenu(); });
    soundBtn.addEventListener('click', onSoundClick);
    testBtn.addEventListener('click', onTestClick);
    menu.addEventListener('focusout', function (e) {
      if (menu.classList.contains('open') && e.relatedTarget && !menu.contains(e.relatedTarget) && e.relatedTarget !== menuBtn) closeMenu();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && S && S.menu.classList.contains('open')) { e.preventDefault(); closeMenu(true); }
    });
    var watch = function () { if (!isNarrow()) closeMenu(); fitQbar(); fitHb(); };
    if (window.ResizeObserver) { var ro = new ResizeObserver(watch); ro.observe(root); ro.observe(viewEl.parentNode); ro.observe(tbMain); S.ro = ro; }
    else window.addEventListener('resize', watch);

    // events from the rest of the page
    if (typeof QT.on === 'function') {
      QT.on('route', function (ev) { if (!S) return; if (S.ready) renderRoute(ev); else S.pending = ev; });
      QT.on('store', function (ev) {
        if (!S) return;
        scheduleMenu();
        if (!ev || ev.collection === 'meta' || ev.collection === undefined) refreshHeartbeat();
        refreshConn();
      });
      QT.on('writeerror', function () { toast('Not saved. Your words are still here. Please try again.', { kind: 'warn' }); });
      QT.on('offline', function () { refreshConn(); });
      QT.on('online', function () { refreshConn(); });
      QT.on('ready', function () { refreshAll(); });
    }
    setInterval(function () { refreshHeartbeat(); }, 30000); // only reads the clock: no writes
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { refreshHeartbeat(); refreshConn(); } });

    refreshAll();
    var start = function () {
      if (!S) return;
      S.ready = true;
      refreshAll();
      var r = S.pending || currentRoute();
      S.pending = null;
      renderRoute(r);
    };
    var ready = QT.ready && typeof QT.ready.then === 'function' ? QT.ready : Promise.resolve();
    ready.then(start, start);
  };

  L.toast = toast;
  L.refreshMenu = function () { if (S) { S.menuSig = ''; refreshMenu(); } };
  L.closeMenu = function () { closeMenu(); };
  L.viewEl = function () { return S ? S.viewEl : null; };
  L.narrow = isNarrow;
})();
