/* 22-lightbox.js  (owner: visual)
   The big picture viewer.   QT.lightbox.open(items, startIndex, opts)   items: [{url, alt, caption, label, key?, group?, groupTitle?, w?, h?}]
     key        a version letter ("B"): gives the "Version B" chip and the "Version B · picture 2 of 3" line
     group      a short name for other sets of pictures (e.g. "Now"), groupTitle its long name ("How it looks now")
     opts       { opener: the element to give focus back to, returnTo: selector to find it again if the page was redrawn,
                  focusFor(index): selector/element to focus on close for the picture shown last (default: opener);
                  onPick(key): adds a "Pick this version" button for pictures that have a key; picked(): the key chosen so far ('' if none);
                  action:{label(i), pressed(i), run(i)}: ONE button of the page's own for every picture (the picture chooser: "Use this photo") instead of the pick button }
   The picture is fitted to the window by CSS alone (no measuring, so no blank frames). Click, tap, Enter or + switches between
   "fits the window" and "full size" (then it scrolls and can be dragged). Left/Right keys, the on-screen arrows and a swipe move
   through ALL pictures. Esc or Close closes. Focus stays inside, the page behind cannot scroll, focus goes back when it closes.
   Safety: only textContent; a picture address must start with https://, data:image/ or be an uploaded picture (/_blob/<id>). */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var SVGNS = 'http://www.w3.org/2000/svg';
  var S = null;   // the viewer that is open right now, or null

  function str(v) { return v == null ? '' : String(v); }
  function dim(n) { n = Number(n); return n > 0 && n <= 20000 ? Math.round(n) : 0; }
  function safeUrl(u) { u = str(u).trim(); return (/^https:\/\//i.test(u) || /^data:image\//i.test(u) || /^\/_blob\/[0-9a-f]{32}$/i.test(u)) ? u : ''; }
  function h(tag, cls, text, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null && text !== '') n.textContent = text;
    if (attrs) for (var k in attrs) { if (attrs[k] != null && attrs[k] !== false) n.setAttribute(k, attrs[k] === true ? '' : attrs[k]); }
    return n;
  }
  var ICONS = {
    close: ['M6 6l12 12', 'M18 6L6 18'],
    prev: ['M15 5l-7 7 7 7'],
    next: ['M9 5l7 7-7 7'],
    zoom: ['M21 21l-5.2-5.2', 'c:10.5,10.5,6.5'],
    fit: ['M4 9V4h5', 'M20 9V4h-5', 'M4 15v5h5', 'M20 15v5h-5'],
    image: ['r:3,4,18,16,2', 'M3 16l5-5 4 4 3-3 6 6', 'c:15.5,9,1.5']
  };
  function icon(name, size) {
    var s = document.createElementNS(SVGNS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size || 20); s.setAttribute('height', size || 20);
    s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '2.6');
    s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
    (ICONS[name] || []).forEach(function (d) {
      var p, a;
      if (d.indexOf('c:') === 0) { a = d.slice(2).split(','); p = document.createElementNS(SVGNS, 'circle'); p.setAttribute('cx', a[0]); p.setAttribute('cy', a[1]); p.setAttribute('r', a[2]); }
      else if (d.indexOf('r:') === 0) { a = d.slice(2).split(','); p = document.createElementNS(SVGNS, 'rect'); p.setAttribute('x', a[0]); p.setAttribute('y', a[1]); p.setAttribute('width', a[2]); p.setAttribute('height', a[3]); p.setAttribute('rx', a[4]); }
      else { p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', d); }
      s.appendChild(p);
    });
    return s;
  }
  function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }

  /* ---------- the list of pictures, and which "version" each belongs to ---------- */
  function prepare(items) {
    var list = (Array.isArray(items) ? items : []).filter(function (it) { return it && typeof it === 'object'; }).map(function (it) {
      return {
        url: safeUrl(it.url), alt: str(it.alt).trim(), caption: str(it.caption).trim(), label: str(it.label).trim(),
        key: str(it.key).trim(), group: str(it.group).trim(), groupTitle: str(it.groupTitle).trim(), w: dim(it.w), h: dim(it.h), gid: '', pos: 0
      };
    });
    var groups = [], seen = {};
    list.forEach(function (it, n) {
      var gid = it.key ? 'k:' + it.key : it.group ? 'g:' + it.group : '';
      it.gid = gid;
      if (!gid) { it.pos = n + 1; return; }
      if (!(gid in seen)) {
        seen[gid] = groups.length;
        groups.push({ id: gid, first: n, total: 0, chip: it.key || it.group, title: it.key ? 'Version ' + it.key : (it.groupTitle || it.group) });
      }
      var g = groups[seen[gid]]; g.total++; it.pos = g.total;
    });
    return { items: list, groups: groups, byId: seen };
  }

  /* ---------- open ---------- */
  function open(items, startIndex, opts) {
    if (S) close(true);
    var prep = prepare(items);
    if (!prep.items.length) return false;
    opts = opts || {};
    S = {
      items: prep.items, groups: prep.groups, byId: prep.byId, i: 0, actual: false, canZoom: false, nat: null, img: null, token: 0,
      opener: opts.opener || document.activeElement, returnTo: opts.returnTo || null,
      focusFor: typeof opts.focusFor === 'function' ? opts.focusFor : null, onPick: typeof opts.onPick === 'function' ? opts.onPick : null, picked: typeof opts.picked === 'function' ? opts.picked : null, action: opts.action && typeof opts.action.run === 'function' && typeof opts.action.label === 'function' ? opts.action : null, slow: 0, ptr: null, quiet: 0, inerted: [], saved: null
    };
    build();
    lock();
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('focusin', onFocusIn, true);
    window.addEventListener('resize', onResize);
    if (S.onPick && typeof QT.on === 'function') { QT.on('store', onStore); S.watching = true; }
    show(clamp(parseInt(startIndex, 10) || 0, 0, S.items.length - 1));
    try { S.scroll.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    return true;
  }

  function build() {
    var root = h('div', 'qtl', null, { role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Big picture viewer', tabindex: '-1', 'data-mode': 'fit' });

    var top = h('div', 'qtl-top');
    var chips = h('div', 'qtl-chips', null, { role: 'group', 'aria-label': 'Jump to another version' });
    S.chipEls = [];
    if (S.groups.length > 1) {
      S.groups.forEach(function (g) {
        var c = h('button', 'qtl-chip' + (g.chip.length > 2 ? ' is-wide' : '') + (g.id.indexOf('g:') === 0 ? ' is-group' : ''), g.chip, { type: 'button', 'aria-label': 'Show ' + g.title, title: g.title });
        c.addEventListener('click', function () { show(g.first); });
        chips.appendChild(c); S.chipEls.push(c);
      });
    } else chips.hidden = true;
    var mode = h('button', 'qtl-btn qtl-mode', null, { type: 'button' });
    mode.addEventListener('click', function () { toggle(null); });
    var closeB = h('button', 'qtl-btn qtl-close', null, { type: 'button', 'aria-label': 'Close the big view' });
    closeB.appendChild(icon('close', 18)); closeB.appendChild(h('span', null, 'Close'));
    closeB.addEventListener('click', function () { close(); });
    top.appendChild(chips); top.appendChild(mode); top.appendChild(closeB);

    var stage = h('div', 'qtl-stage');
    var scroll = h('div', 'qtl-scroll', null, { tabindex: '0', role: 'group', 'aria-label': 'Picture' });
    var loading = h('div', 'qtl-loading', 'Loading the picture…', { role: 'status' });
    loading.hidden = true;
    var prev = h('button', 'qtl-nav qtl-prev', null, { type: 'button', 'aria-label': 'Previous picture' });
    prev.appendChild(icon('prev', 24));
    var next = h('button', 'qtl-nav qtl-next', null, { type: 'button', 'aria-label': 'Next picture' });
    next.appendChild(icon('next', 24));
    prev.addEventListener('click', function () { move(-1); });
    next.addEventListener('click', function () { move(1); });
    if (S.items.length < 2) { prev.hidden = true; next.hidden = true; }
    stage.appendChild(scroll); stage.appendChild(loading); stage.appendChild(prev); stage.appendChild(next);

    var foot = h('div', 'qtl-foot');
    var head = h('p', 'qtl-head'), count = h('span', 'qtl-count'), title = h('span', 'qtl-title');
    head.appendChild(count); head.appendChild(title);
    var pick = h('button', 'qtl-btn qtl-pick', null, { type: 'button' });
    pick.hidden = true;
    pick.addEventListener('click', function () {
      var it = S.items[S.i];
      if (S.action && it) { try { S.action.run(S.i); } catch (e) { /* the page's own button failed: the viewer stays */ } refreshPick(); if (S.live) S.live.textContent = pickBtnText(); return; }
      if (S.onPick && it && it.key) { S.onPick(it.key); refreshPick(); }
    });
    head.appendChild(pick);
    var text = h('p', 'qtl-text'), alt = h('p', 'qtl-alt');
    var help = h('p', 'qtl-help');
    var live = h('div', 'qtl-live sr', null, { 'aria-live': 'polite', 'aria-atomic': 'true' });
    foot.appendChild(head); foot.appendChild(text); foot.appendChild(alt); foot.appendChild(help);

    root.appendChild(top); root.appendChild(stage); root.appendChild(foot); root.appendChild(live);
    scroll.addEventListener('click', onStageClick);
    scroll.addEventListener('pointerdown', onPointerDown);
    scroll.addEventListener('pointermove', onPointerMove);
    scroll.addEventListener('pointerup', onPointerUp);
    scroll.addEventListener('pointercancel', function () { S.ptr = null; root.classList.remove('is-dragging'); });
    S.root = root; S.scroll = scroll; S.countEl = count; S.mode = mode; S.loading = loading;
    S.titleEl = title; S.textEl = text; S.altEl = alt; S.live = live; S.closeBtn = closeB; S.help = help; S.pickBtn = pick;
    document.body.appendChild(root);
  }

  /* The page behind: no scrolling and no keyboard focus (inert), restored on close. */
  function lock() {
    var de = document.documentElement, b = document.body;
    S.saved = { html: de.style.overflow, body: b.style.overflow };
    de.style.overflow = 'hidden'; b.style.overflow = 'hidden';
    Array.prototype.forEach.call(b.children, function (n) {
      if (n === S.root || n.inert || /^(SCRIPT|STYLE|LINK)$/.test(n.tagName)) return;
      try { n.inert = true; S.inerted.push(n); } catch (e) { /* old browser: the Tab trap below still holds focus */ }
    });
  }
  function unlock(s) {
    var de = document.documentElement, b = document.body;
    de.style.overflow = s.saved ? s.saved.html : ''; b.style.overflow = s.saved ? s.saved.body : '';
    s.inerted.forEach(function (n) { try { n.inert = false; } catch (e) { /* ignore */ } });
  }

  /* ---------- showing one picture ---------- */
  function show(i) {
    var it = S.items[i];
    S.i = i; S.actual = false; S.img = null; S.canZoom = false; S.nat = null;
    S.root.setAttribute('data-index', String(i)); S.root.setAttribute('data-mode', 'fit'); S.root.setAttribute('data-state', 'loading'); S.root.classList.remove('is-actual');
    writeText(it);
    S.chipEls.forEach(function (c, n) {
      var on = S.groups[n].id === it.gid;
      if (on) c.setAttribute('aria-current', 'true'); else c.removeAttribute('aria-current');
    });
    paint(i);
    [i - 1, i + 1].forEach(function (n) {   // quietly fetch the neighbours so stepping is instant
      var nb = S.items[(n + S.items.length) % S.items.length];
      if (nb && nb.url && S.items.length > 1 && nb !== it) { var pre = new Image(); pre.referrerPolicy = 'no-referrer'; pre.src = nb.url; }
    });
  }
  function writeText(it) {
    var n = S.items.length, g = it.gid ? S.groups[S.byId[it.gid]] : null, count;
    if (g) count = g.title + (g.total > 1 ? ' · picture ' + it.pos + ' of ' + g.total : '');
    else count = n > 1 ? 'Picture ' + (S.i + 1) + ' of ' + n : 'Picture';
    S.countEl.textContent = count;
    S.titleEl.textContent = it.label; S.titleEl.hidden = !it.label;
    S.textEl.textContent = it.caption; S.textEl.hidden = !it.caption;
    var showAlt = it.alt && it.alt !== it.caption;
    S.altEl.textContent = showAlt ? it.alt : ''; S.altEl.hidden = !showAlt;
    refreshPick();
    S.scroll.setAttribute('aria-label', count);
    S.live.textContent = [count, it.label, it.caption].filter(Boolean).join('. ');
  }
  /* the "Pick this version" button: only for a picture that belongs to a version, and only when the page gave us onPick */
  function refreshPick() {
    if (!S || !S.pickBtn) return;
    var it = S.items[S.i], b = S.pickBtn;
    if (S.action && it) {      // a button of the page's own (the picture chooser: "Use this photo")
      var on0 = false, lab = '';
      try { on0 = !!(S.action.pressed && S.action.pressed(S.i)); lab = String(S.action.label(S.i)); } catch (e) { lab = ''; }
      b.hidden = !lab;
      b.textContent = lab;
      b.setAttribute('aria-pressed', on0 ? 'true' : 'false');
      b.setAttribute('aria-label', lab + (it.label ? ': ' + it.label : ''));
      b.classList.toggle('is-picked', on0);
      return;
    }
    if (!S.onPick || !it || !it.key) { b.hidden = true; return; }
    var on = false;
    try { on = !!S.picked && S.picked() === it.key; } catch (e) { on = false; }
    b.hidden = false;
    b.textContent = on ? '\u2713 Your pick' : 'Pick this version';
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.setAttribute('aria-label', (on ? 'Your pick: ' : 'Pick this version: ') + 'Version ' + it.key + (it.label ? ', ' + it.label : ''));
    b.classList.toggle('is-picked', on);
  }
  function pickBtnText() { return S && S.pickBtn ? S.pickBtn.getAttribute('aria-label') || S.pickBtn.textContent : ''; }
  function onStore() { refreshPick(); }
  function swap(node) {
    S.scroll.textContent = '';
    S.scroll.appendChild(node);
    S.scroll.scrollLeft = 0; S.scroll.scrollTop = 0;
  }
  function paint(i) {
    var it = S.items[i], tok = ++S.token;
    clearTimeout(S.slow); S.loading.hidden = true;
    if (!it.url) { fail(it); return; }
    var img = document.createElement('img');
    img.className = 'qtl-img';
    img.alt = it.alt || it.label || 'Picture';
    img.draggable = false;
    img.referrerPolicy = 'no-referrer';
    img.decoding = 'async';
    var done = false;
    function stale() { return done || !S || tok !== S.token; }
    function show1() {   // the picture is loaded AND decoded: only now does it replace the old one (so there is never an empty frame)
      if (stale()) return;
      done = true; clearTimeout(S.slow); S.loading.hidden = true;
      var nw = img.naturalWidth || it.w, nh = img.naturalHeight || it.h;
      S.nat = nw && nh ? { w: nw, h: nh } : null;
      S.img = img;
      if (S.nat) { img.style.maxWidth = nw + 'px'; img.style.maxHeight = nh + 'px'; }   // never blown up bigger than it really is
      swap(img);
      S.root.setAttribute('data-state', 'ready');
      refreshZoom();
    }
    function bad() {
      if (stale()) return;
      done = true; clearTimeout(S.slow); S.loading.hidden = true;
      fail(it);
    }
    img.addEventListener('load', function () {
      if (stale()) return;
      if (typeof img.decode === 'function') img.decode().then(show1, function () { if (img.naturalWidth) show1(); else bad(); });
      else show1();
    });
    img.addEventListener('error', bad);
    img.src = it.url;
    if (!done) S.slow = setTimeout(function () { if (S && tok === S.token && !done) S.loading.hidden = false; }, 160);
  }
  function fail(it) {
    S.img = null; S.nat = null; S.canZoom = false;
    var ph = h('div', 'qtl-ph', null, { role: 'status' });
    var ic = h('div', 'qtl-ph-icon'); ic.appendChild(icon('image', 40));
    ph.appendChild(ic);
    ph.appendChild(h('p', 'qtl-ph-msg', 'Picture did not load'));
    if (it.alt) ph.appendChild(h('p', 'qtl-ph-alt', it.alt));
    if (it.url) {
      var again = h('button', 'qtl-btn qtl-again', 'Try again', { type: 'button' });
      again.addEventListener('click', function () { paint(S.i); });
      ph.appendChild(again);
    }
    swap(ph);
    S.root.setAttribute('data-state', 'failed');
    refreshZoom();
  }

  /* ---------- fit / full size ---------- */
  function refreshZoom() {
    if (!S) return;
    if (S.actual) S.canZoom = true;
    else if (S.img && S.nat) {
      var r = S.img.getBoundingClientRect();
      S.canZoom = Math.min(r.width / S.nat.w, r.height / S.nat.h) < 0.97;
    } else S.canZoom = false;
    var m = S.mode;
    m.textContent = '';
    m.appendChild(icon(S.actual ? 'fit' : 'zoom', 18));
    m.appendChild(h('span', null, S.actual ? 'Fit to window' : 'Full size'));
    S.help.textContent = helpText();
    m.setAttribute('aria-disabled', S.canZoom ? 'false' : 'true');
    m.title = S.actual ? 'Show the whole picture in the window' : S.canZoom ? 'Show the picture at its real size (key: +)' : 'This picture is already shown at its real size';
    S.scroll.classList.toggle('can-zoom', S.canZoom);
  }
  function helpText() {
    var coarse = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches), parts = [];
    if (S.actual) parts.push('Drag to move around the picture. ' + (coarse ? 'Tap' : 'Click') + ' it to fit the window again.');
    else if (S.canZoom) parts.push((coarse ? 'Tap' : 'Click') + ' the picture for full size, or the dark space to close.');
    if (S.items.length > 1) parts.push(coarse ? 'Swipe to see the other pictures.' : 'Arrow keys show the other pictures.');
    if (!coarse) parts.push('Esc closes.');
    return parts.join(' ');
  }
  function toggle(ev) { setActual(!S.actual, ev); }
  /* where the picture really is on the screen (the picture box can be bigger than the picture, which is centred inside it) */
  function drawnRect() {
    var r = S.img.getBoundingClientRect(), n = S.nat, k = Math.min(r.width / n.w, r.height / n.h), dw = n.w * k, dh = n.h * k;
    return { left: r.left + (r.width - dw) / 2, top: r.top + (r.height - dh) / 2, w: dw, h: dh };
  }
  function setActual(on, ev) {
    if (!S || on === S.actual) return;
    if (on && (!S.canZoom || !S.img || !S.nat)) return;
    var img = S.img, nat = S.nat, fx = 0.5, fy = 0.5;
    if (on && ev && ev.clientX != null) {   // zoom in where she clicked
      var d = drawnRect();
      fx = clamp((ev.clientX - d.left) / d.w, 0, 1); fy = clamp((ev.clientY - d.top) / d.h, 0, 1);
    }
    S.actual = on;
    S.root.classList.toggle('is-actual', on);
    S.root.setAttribute('data-mode', on ? 'actual' : 'fit');
    if (on) {
      img.style.maxWidth = 'none'; img.style.maxHeight = 'none'; img.style.width = nat.w + 'px'; img.style.height = nat.h + 'px';
      var sc = S.scroll;
      sc.scrollLeft = Math.max(0, fx * nat.w - sc.clientWidth / 2);
      sc.scrollTop = Math.max(0, fy * nat.h - sc.clientHeight / 2);
    } else {
      img.style.width = ''; img.style.height = '';
      img.style.maxWidth = nat.w + 'px'; img.style.maxHeight = nat.h + 'px';
      S.scroll.scrollLeft = 0; S.scroll.scrollTop = 0;
    }
    refreshZoom();
  }
  function move(d) {
    if (!S || S.items.length < 2) return;
    show((S.i + d + S.items.length) % S.items.length);
  }

  /* ---------- mouse, finger ---------- */
  function onStageClick(e) {
    if (!S) return;
    if (e.target.closest && e.target.closest('.qtl-ph')) return;
    if (performance.now() < S.quiet) return;   // this click ended a drag or a swipe
    if (S.root.getAttribute('data-state') === 'loading') return;
    if (!S.actual) {   // the dark space round the picture closes the viewer; the picture itself switches to full size
      var inside = false;
      if (S.img && S.nat) { var d = drawnRect(); inside = e.clientX >= d.left && e.clientX <= d.left + d.w && e.clientY >= d.top && e.clientY <= d.top + d.h; }
      else if (S.img) inside = true;
      if (!inside) { close(); return; }
      if (!S.canZoom) return;
    }
    toggle(e);
  }
  function onPointerDown(e) {
    if (!S || (e.pointerType === 'mouse' && e.button !== 0)) return;
    if (e.target.closest && e.target.closest('.qtl-ph')) return;
    S.quiet = 0;   // a new press starts a new gesture (only the click that ends a drag or swipe is ignored)
    S.ptr = { x: e.clientX, y: e.clientY, sl: S.scroll.scrollLeft, st: S.scroll.scrollTop, type: e.pointerType, id: e.pointerId, moved: 0, drag: false };
  }
  function onPointerMove(e) {
    var p = S && S.ptr; if (!p) return;
    var dx = e.clientX - p.x, dy = e.clientY - p.y;
    p.moved = Math.max(p.moved, Math.sqrt(dx * dx + dy * dy));
    if (S.actual && p.type === 'mouse' && (e.buttons & 1)) {
      if (!p.drag && p.moved > 5) { p.drag = true; S.root.classList.add('is-dragging'); try { S.scroll.setPointerCapture(p.id); } catch (er) { /* ignore */ } }
      if (p.drag) { S.scroll.scrollLeft = p.sl - dx; S.scroll.scrollTop = p.st - dy; }
    }
  }
  function onPointerUp(e) {
    var p = S && S.ptr; if (!p) return;
    var dx = e.clientX - p.x, dy = e.clientY - p.y;
    S.ptr = null; S.root.classList.remove('is-dragging');
    if (!S.actual && p.type !== 'mouse' && Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) { S.quiet = performance.now() + 400; move(dx < 0 ? 1 : -1); return; }
    if (p.moved > 6) S.quiet = performance.now() + 400;
  }

  /* ---------- keys, focus ---------- */
  function visibleFocusables() {
    return Array.prototype.filter.call(S.root.querySelectorAll('button, [tabindex="0"]'), function (n) {
      return !n.disabled && !n.hidden && n.getClientRects().length > 0 && !(n.closest && n.closest('[hidden]'));
    });
  }
  function stop(e) { e.preventDefault(); e.stopPropagation(); }
  function onKey(e) {
    if (!S) return;
    var k = e.key;
    if (k === 'Escape') { stop(e); close(); return; }
    if (k === 'Tab') {
      var list = visibleFocusables(); if (!list.length) { stop(e); return; }
      var first = list[0], last = list[list.length - 1], a = document.activeElement, inside = S.root.contains(a) && a !== S.root;
      if (e.shiftKey && (a === first || !inside)) { stop(e); last.focus(); }
      else if (!e.shiftKey && (a === last || !inside)) { stop(e); first.focus(); }
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (k === 'ArrowRight') { stop(e); move(1); }
    else if (k === 'ArrowLeft') { stop(e); move(-1); }
    else if (k === 'Home') { stop(e); if (S.items.length > 1) show(0); }
    else if (k === 'End') { stop(e); if (S.items.length > 1) show(S.items.length - 1); }
    else if (k === '+' || k === '=') { stop(e); toggle(null); }
    else if (k === '-' || k === '_') { stop(e); setActual(false); }
    else if (k === 'Enter' && e.target === S.scroll) { stop(e); toggle(null); }
    else if (k.length === 1) e.stopPropagation();   // letters belong to the viewer while it is open (the page behind has A-D shortcuts)
  }
  function onFocusIn(e) {
    if (!S || S.root.contains(e.target)) return;
    try { S.scroll.focus({ preventScroll: true }); } catch (er) { /* ignore */ }
  }
  function onResize() { if (S) refreshZoom(); }

  /* ---------- close ---------- */
  function close(quiet) {
    if (!S) return;
    var s = S; S = null;
    clearTimeout(s.slow);
    document.removeEventListener('keydown', onKey, true);
    document.removeEventListener('focusin', onFocusIn, true);
    window.removeEventListener('resize', onResize);
    if (s.watching && typeof QT.off === 'function') QT.off('store', onStore);
    unlock(s);
    if (s.root.parentNode) s.root.parentNode.removeChild(s.root);
    if (quiet) return;
    var target = null;
    if (s.focusFor) {   // the picture she was looking at when she closed it (not always the one she opened)
      try { var f = s.focusFor(s.i); target = typeof f === 'string' ? document.querySelector(f) : f; } catch (e) { target = null; }
      if (target && !(target.isConnected && target.getClientRects().length)) target = null;
    }
    if (!target && s.opener && s.opener.isConnected && s.opener !== document.body) target = s.opener;
    if (!target && s.returnTo) { try { target = typeof s.returnTo === 'function' ? s.returnTo() : document.querySelector(s.returnTo); } catch (e) { target = null; } }
    if (!target) target = document.getElementById('qt-main') || document.body;
    try { target.focus(); } catch (e) { /* ignore */ }
  }

  QT.lightbox = {
    open: open,
    close: function () { close(); },
    isOpen: function () { return !!S; },
    current: function () { return S ? { index: S.i, count: S.items.length, mode: S.actual ? 'actual' : 'fit' } : null }
  };
  if (typeof QT.on === 'function') QT.on('route', function () { close(true); });   // she moved to another page: the viewer must not stay on top
})();
