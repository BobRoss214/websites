/* 30-sections.js  (owner: sections)
 * QT.sections (lists, next question, progress) and the views QT.views.home / section / done / newsection.
 * Text comes from documents and is untrusted: it only ever goes in with textContent (through QT.el).
 * Notes for other helpers: T/notes/sections.md
 */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  QT.views = QT.views || {};

  /* ======================================================================
   * Small helpers
   * ==================================================================== */
  /** QT.el, but null / false / undefined children and attributes are skipped, and arrays are flattened. */
  function el(tag, attrs) {
    var kids = [];
    for (var i = 2; i < arguments.length; i++) pushKid(kids, arguments[i]);
    var a = {};
    if (attrs) Object.keys(attrs).forEach(function (k) { var v = attrs[k]; if (v !== null && v !== undefined && v !== false) a[k] = v; });
    return QT.el.apply(null, [tag, a].concat(kids));
  }
  function pushKid(out, k) {
    if (k === null || k === undefined || k === false) return;
    if (Array.isArray(k)) k.forEach(function (x) { pushKid(out, x); }); else out.push(k);
  }
  function col(name) { return (QT.store && QT.store[name]) || {}; }
  function vals(o) { return Object.keys(o).map(function (k) { return o[k]; }).filter(Boolean); }
  function num(x, d) { return typeof x === 'number' && isFinite(x) ? x : d; }
  function nowIso() { return new Date().toISOString(); }
  function str(x) { return typeof x === 'string' ? x : (x === null || x === undefined ? '' : String(x)); }
  function pl(n, word) { return n + ' ' + word + (n === 1 ? '' : 's'); }
  function ago(iso) {
    if (!iso) return '';
    try { if (QT.fmt && QT.fmt.ago) return QT.fmt.ago(iso); } catch (e) { /* fall through */ }
    var s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (isNaN(s)) return '';
    if (s < 60) return 'just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    return Math.round(s / 86400) + ' days ago';
  }
  function safeUrl(u) { return typeof u === 'string' && (QT.safeUrl ? QT.safeUrl(u) : /^https?:\/\//i.test(u)); }
  function byOrder(a, b) {
    var d = num(a.order, 1e9) - num(b.order, 1e9);
    if (d) return d;
    var ca = str(a.createdAt), cb = str(b.createdAt);
    if (ca !== cb) return ca < cb ? -1 : 1;
    return str(a.id) < str(b.id) ? -1 : (str(a.id) > str(b.id) ? 1 : 0);
  }
  function go(view, params) { if (QT.route && QT.route.go) QT.route.go(view, params || {}); }
  function openQuestion(id) { go('question', { id: id }); }
  function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { if (v === null || v === undefined || v === '') window.localStorage.removeItem(k); else window.localStorage.setItem(k, v); } catch (e) { /* private window */ } }

  /* Text typed into boxes is kept here, so a redraw (or leaving the page and coming back) never loses it. */
  var memory = Object.create(null);
  function getDraft(key) {
    if (!(key in memory)) { var v = lsGet('qt.draft.' + key); memory[key] = v === null ? '' : v; }
    return memory[key];
  }
  function setDraft(key, v) { memory[key] = v; lsSet('qt.draft.' + key, v); }

  /* Open / closed state of collapsible groups, kept across redraws. */
  var openState = Object.create(null);

  /** Redraws a part of the page and puts the cursor back where it was. */
  function keepFocus(box, fn) {
    var a = document.activeElement, key = null, s = null, e = null, top = 0;
    if (a && a !== document.body && box.contains(a) && a.getAttribute && a.getAttribute('data-key')) {
      key = a.getAttribute('data-key');
      try { s = a.selectionStart; e = a.selectionEnd; } catch (x) { s = null; }
      top = a.scrollTop || 0;
    }
    fn();
    if (key !== null) {
      var n = null;
      var all = box.querySelectorAll('[data-key]');
      for (var i = 0; i < all.length; i++) if (all[i].getAttribute('data-key') === key) { n = all[i]; break; }
      if (n) {
        try { n.focus({ preventScroll: true }); } catch (x) { n.focus(); }
        try { if (s !== null && n.setSelectionRange) n.setSelectionRange(s, e); } catch (x) { /* not a text box */ }
        if (top) n.scrollTop = top;
      }
    }
  }
  function focusKey(box, key) {
    var all = box.querySelectorAll('[data-key]');
    for (var i = 0; i < all.length; i++) if (all[i].getAttribute('data-key') === key) { all[i].focus(); return true; }
    return false;
  }
  function isTyping(root) {
    var a = document.activeElement;
    return !!(a && root.contains(a) && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && /^(text|search)$/i.test(a.type || 'text'))));
  }

  /**
   * A view is a stack of regions. Each region lists the collections it shows and is redrawn (after a short pause,
   * so a burst of changes is one redraw) only when one of them changes.
   */
  function Regions(root, hook) {
    var self = { list: [], dead: false };
    var timer = 0, dirty = [];
    var live = el('div', { class: 'sr', role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true' });
    root.classList.add('sx');
    /* one quiet announcement for screen readers (the visible message boxes are redrawn, so they cannot be relied on) */
    self.announce = function (text) {
      live.textContent = '';
      if (text) setTimeout(function () { if (!self.dead) live.textContent = text; }, 60);
    };
    function paint(r) {
      keepFocus(r.node, function () {
        r.node.textContent = '';
        try { r.d.render(r.node); } catch (err) {
          if (window.console) console.error(err);
          r.node.textContent = '';
          r.node.appendChild(el('p', { class: 'muted small', text: 'Something went wrong while showing this part. Your answers are safe. Please reload the page.' }));
        }
      });
    }
    /* the first change after a quiet moment is drawn after 30 ms; a flood of changes is drawn at most four times a second */
    var lastFlush = 0;
    function flush() { timer = 0; lastFlush = Date.now(); if (self.dead) return; var d = dirty; dirty = []; d.forEach(function (r) { if (self.list.indexOf(r) >= 0) paint(r); }); }
    function mark(r) { if (dirty.indexOf(r) < 0) dirty.push(r); if (!timer) timer = setTimeout(flush, Math.max(30, 600 - (Date.now() - lastFlush))); }
    self.set = function (defs) {
      root.textContent = '';
      root.appendChild(live);
      dirty = [];
      self.list = defs.map(function (d) { return { d: d, node: el('div', { class: 'sx-region sx-r-' + d.name }) }; });
      self.list.forEach(function (r) { root.appendChild(r.node); paint(r); });
    };
    self.repaint = function (name) { self.list.forEach(function (r) { if (!name || r.d.name === name) paint(r); }); };
    self.node = function (name) { for (var i = 0; i < self.list.length; i++) if (self.list[i].d.name === name) return self.list[i].node; return null; };
    function onStore(e) {
      if (self.dead) return;
      if (hook && hook(e) === true) return;
      var c = e && e.collection;
      self.list.forEach(function (r) { if (!c || r.d.deps.indexOf(c) >= 0) mark(r); });
    }
    function onReady() { if (!self.dead) { if (hook) hook({ collection: null, ready: true }); self.repaint(); } }
    var tick = setInterval(function () { if (!self.dead && !isTyping(root) && root.isConnected !== false) self.repaint(); }, 60000);
    QT.on('store', onStore);
    if (!QT.isReady) QT.on('ready', onReady);
    self.destroy = function () {
      self.dead = true;
      clearTimeout(timer); clearInterval(tick);
      QT.off('store', onStore); QT.off('ready', onReady);
    };
    return self;
  }

  /* ======================================================================
   * QT.sections
   * ==================================================================== */
  function kindRank(s) { return s.kind === 'builtin' ? 0 : 1; }
  function sectionDoc(id) { return col('sections')[id] || null; }
  /* "Answered" = there is an answers/<qid> document (same rule as the menu numbers made by QT.status.badgeCount). */
  function isAnswered(qid) { return !!col('answers')[qid]; }
  function isDone(qid) { var s = col('status')[qid]; return !!s && s.state === 'done'; }
  function isAnswerable(q) {
    if (!q || q.kind === 'readonly' || q.sectionId === 'kathy') return false;
    var s = sectionDoc(q.sectionId);
    return !(s && s.readOnly);
  }
  /** Something she can still answer: answerable, not answered, and Claude has not closed it. */
  function needsAnswer(q) { return isAnswerable(q) && !isAnswered(q.id) && !isDone(q.id); }
  function listSections() {
    return vals(col('sections')).filter(function (s) { return !s.archived; })
      .sort(function (a, b) { return (kindRank(a) - kindRank(b)) || byOrder(a, b); });
  }
  function questionsOf(id) { return vals(col('questions')).filter(function (q) { return q.sectionId === id; }).sort(byOrder); }
  /** Questions she can answer and has not answered yet, in order. */
  function waitingOf(id) { return questionsOf(id).filter(needsAnswer); }
  function nextUnanswered(fromQid) {
    var from = col('questions')[fromQid];
    var seq = [];
    var order = listSections().map(function (s) { return s.id; });
    if (from) {
      var same = questionsOf(from.sectionId);
      var i = 0;
      for (var k = 0; k < same.length; k++) if (same[k].id === fromQid) { i = k; break; }
      seq = seq.concat(same.slice(i + 1), same.slice(0, i));
      var at = order.indexOf(from.sectionId);
      order = at >= 0 ? order.slice(at + 1) : order;
    }
    order.forEach(function (sid) { seq = seq.concat(questionsOf(sid)); });
    for (var j = 0; j < seq.length; j++) {
      var q = seq[j];
      if (q.id !== fromQid && needsAnswer(q)) return q.id;
    }
    return null;
  }
  /* "I'm not sure yet", "Explain another way", "None of them - change this", "Check again to make sure it's safe" (recheck) and "This is a question
     for Miss Cathy and Rob" (cathy) are replies, not answers: Claude cannot start a Big section on them (the same rule as tools/read_answers.py),
     so the progress card does not count them either. */
  var OPEN_KEYS = { unsure: 1, help: 1, change: 1, recheck: 1, cathy: 1 };
  function isOpenReply(qid) { var a = col('answers')[qid]; return !!a && a.status !== 'skipped' && !!OPEN_KEYS[a.key]; }
  function requiredOf(id) { return questionsOf(id).filter(function (q) { return q.required && isAnswerable(q); }); }
  function progress(id) {
    var req = requiredOf(id);
    return { requiredTotal: req.length, requiredAnswered: req.filter(function (q) { return isDone(q.id) || (isAnswered(q.id) && !isOpenReply(q.id)); }).length };
  }
  /** How many important questions only have a reply like "not sure yet" so far. */
  function pendingRequired(id) { return requiredOf(id).filter(function (q) { return !isDone(q.id) && isOpenReply(q.id); }).length; }
  function isBig(id) { var s = sectionDoc(id); return !!s && s.size === 'big'; }
  /** The plan Claude posted for a section and what she answered: {plan, reply, replied, approved} or null. */
  function planOf(id) {
    var p = col('plans')[id];
    if (!p) return null;
    var r = col('planReplies')[id] || null;
    var replied = !!r && num(r.version, 0) >= num(p.version, 1);
    return { plan: p, reply: r, replied: replied, approved: replied && r.decision === 'ok' };
  }

  QT.sections = {
    list: listSections,
    questionsOf: questionsOf,
    nextUnanswered: nextUnanswered,
    progress: progress,
    pendingRequired: pendingRequired,
    isBig: isBig,
    /* extras used by the views (and free for others to use) */
    get: sectionDoc,
    isAnswered: isAnswered,
    isAnswerable: isAnswerable,
    needsAnswer: needsAnswer,
    waiting: waitingOf,
    firstUnanswered: function (id) { var w = waitingOf(id); return w.length ? w[0].id : null; },
    planOf: planOf,
    archived: function () { return vals(col('sections')).filter(function (s) { return s.archived; }).sort(byOrder); }
  };

  /* ======================================================================
   * Topics: the question lists of a section show ONE topic at a time (the owner's pick "One topic at a time")
   * ==================================================================== */
  var MORE_TOPIC = 'More questions';
  function topicOf(q) { return str(q && q.topic).trim() || MORE_TOPIC; }
  /** The topics of a list of questions, in the order they first appear: [{name, qs, waiting}] */
  function topicsOf(qs) {
    var by = {}, order = [];
    qs.forEach(function (q) { var t = topicOf(q); if (!by[t]) { by[t] = []; order.push(t); } by[t].push(q); });
    return order.map(function (t) { return { name: t, qs: by[t], waiting: by[t].filter(needsAnswer).length }; });
  }
  function rememberTopic(sid, name) { lsSet('qt.topic.' + sid, name); }
  /* opening a question (also with "Next question") makes its topic the one that is open when she comes back to the section */
  if (typeof QT.on === 'function') QT.on('route', function (r) {
    try {
      if (!r || r.view !== 'question' || !r.params || !r.params.id) return;
      var q = col('questions')[r.params.id], sc = q && sectionDoc(q.sectionId);
      if (q && sc && !sc.readOnly) rememberTopic(q.sectionId, topicOf(q));
    } catch (e) { /* nothing to remember */ }
  });

  /* ======================================================================
   * Pieces shared by the views
   * ==================================================================== */
  function qstate(qid) {
    try { if (QT.status && QT.status.state) return QT.status.state(qid); } catch (e) { /* fall through */ }
    var a = col('answers')[qid], s = col('status')[qid];
    if (!a) return 'waiting';
    if (!s) return 'answeredUnseen';
    if (s.state === 'working' || s.state === 'done' || s.state === 'followup' || s.state === 'held') return s.state;
    return str(a.answeredAt) > str(s.seenAt) ? 'answeredUnseen' : 'seen';
  }
  var FALLBACK_CHIP = {
    waiting: 'Waiting for you', answeredUnseen: 'You answered · waiting for Claude to see it', seen: 'Claude saw it ✓',
    working: 'Claude is working on it…', done: 'Done ✓', followup: 'Claude has a follow-up question', held: 'Paused – you asked Claude to wait'
  };
  function chipFor(qid) {
    /* a question she sent to Miss Cathy and Rob: once Claude has seen it, the chip says where it went (the other states keep the normal chip) */
    var a0 = col('answers')[qid];
    if (a0 && a0.status === 'answered' && a0.key === 'cathy' && qstate(qid) === 'seen') return el('span', { class: 'chip', 'data-state': 'sent', text: 'Sent to Miss Cathy and Rob' });
    try { if (QT.status && QT.status.chip) { var c = QT.status.chip(qid); if (c) return c; } } catch (e) { /* fall through */ }
    var st = qstate(qid), note = (col('status')[qid] || {}).note;
    return el('span', { class: 'chip' + (st === 'done' ? ' good' : '') }, (FALLBACK_CHIP[st] || '') + (st === 'working' && note ? ' ' + str(note) : ''));
  }
  function isNewQ(qid) {
    try { if (QT.status && typeof QT.status.isNew === 'function') return !!QT.status.isNew(qid); } catch (e) { /* none */ }
    return false;
  }
  function thumbs(images, max) {
    var raw = (Array.isArray(images) ? images : []).filter(function (i) { return i && typeof i.url === 'string' && i.url; }).slice(0, max || 4);
    if (!raw.length) return null;
    try {
      /* the picture helper makes thumbnails that open the big viewer (and checks the addresses itself) */
      if (QT.visual && typeof QT.visual.thumbRow === 'function') { var n = QT.visual.thumbRow(raw); if (n && !n.hidden) return n; }
    } catch (e) { /* use ours */ }
    var list = raw.filter(function (i) { return safeUrl(i.url); });
    if (!list.length) return null;
    return el('span', { class: 'sx-thumbs' }, list.map(function (i) {
      var im = el('img', { src: i.url, alt: str(i.alt), loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' });
      im.addEventListener('error', function () { im.hidden = true; });
      return im;
    }));
  }
  function sectionTitle(id) { var s = sectionDoc(id); return s ? str(s.title) : ''; }
  function empty(text, extra) { return el('div', { class: 'sx-empty' }, el('p', { text: text }), extra); }
  function h1(text, extra) { return el('div', { class: 'row between nowrap sx-head' }, el('h1', { class: 'grow sx-h1', dir: 'auto', text: text }), extra); }

  /** A question as a row: title (+ NEW) on top, the status chip under it (or at the right with opts.chipEnd). The whole row opens the question. */
  function qRow(q, opts) {
    opts = opts || {};
    var main = el('button', { type: 'button', class: 'sx-qmain', 'data-key': 'q:' + q.id, on: { click: function () { openQuestion(q.id); } } },
      el('span', { class: 'item-title sx-qtitle', dir: 'auto', text: str(q.title) }),
      opts.important && q.required ? el('span', { class: 'sx-imp', text: 'Important' }) : null,
      opts.ideaTag && fromIdea(q) ? el('span', { class: 'sx-imp sx-fromidea', text: 'New from your idea' }) : null,
      opts.noNew || !isNewQ(q.id) ? null : el('span', { class: 'badge-new', text: 'New' }));
    var sub = opts.sub ? el('div', { class: 'item-sub', dir: 'auto', text: opts.sub }) : null;
    var chip = (opts.noChip || (opts.skipWaitChip && qstate(q.id) === 'waiting')) ? null : el('div', { class: 'sx-qchip' }, chipFor(q.id));
    var row = el('div', { class: 'item sx-q' + (chip && opts.chipEnd ? ' chip-end' : '') },
      el('div', { class: 'item-main' }, main, sub, opts.chipEnd ? null : chip, opts.extra || null),
      opts.chipEnd ? chip : null);
    row.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('a,button,input,textarea,select')) return;   // buttons and links inside do their own thing
      openQuestion(q.id);
    });
    return row;
  }
  function list(rows) { return el('div', { class: 'list sx-list' }, rows); }

  /* ======================================================================
   * HOME
   * ==================================================================== */
  function sectionCard(sec) {
    var readOnly = !!sec.readOnly;
    var total = questionsOf(sec.id).length;
    var waiting = readOnly ? [] : waitingOf(sec.id);
    var pl_ = !readOnly && isBig(sec.id) ? planOf(sec.id) : null;
    var planWaits = !!(pl_ && !pl_.replied);
    var sub, chip = null, btn;
    var parked = !readOnly && sec.hold === true;   // paused: still counted and answerable, but not pushed at her
    if (readOnly) {
      sub = total ? 'To read only · ' + pl(total, 'question') : 'Nothing here yet.';
      btn = el('button', { type: 'button', class: 'btn small', 'data-key': 'sec:' + sec.id, on: { click: function () { go('section', { id: sec.id }); } } }, 'Read');
    } else if (waiting.length && parked) {
      chip = el('span', { class: 'chip sx-waitchip', text: waiting.length + ' waiting' });
      sub = blurbOf(sec) || (pl(waiting.length, 'question') + ' waiting, no hurry');
      btn = el('button', { type: 'button', class: 'btn small', 'data-key': 'sec:' + sec.id, 'aria-label': 'Open: ' + str(sec.title), on: { click: function () { go('section', { id: sec.id }); } } }, 'Open');
    } else if (waiting.length) {
      chip = el('span', { class: 'chip accent sx-waitchip', text: waiting.length + ' waiting' });
      sub = blurbOf(sec) || (pl(waiting.length, 'question') + ' waiting for you');
      btn = el('button', { type: 'button', class: 'btn primary small', 'data-key': 'sec:' + sec.id, 'aria-label': 'Answer: ' + str(sec.title),
        on: { click: function () { openQuestion(waiting[0].id); } } }, 'Answer');
    } else if (planWaits) {
      chip = el('span', { class: 'chip warn', text: 'Plan to read' });
      sub = 'Claude wrote a plan. Please read it.';
      btn = el('button', { type: 'button', class: 'btn primary small', 'data-key': 'sec:' + sec.id, on: { click: function () { go('section', { id: sec.id }); } } }, 'Read the plan');
    } else {
      chip = total ? el('span', { class: 'chip good', text: 'All answered ✓' }) : null;
      sub = total ? (blurbOf(sec) || 'Nothing is waiting here.') : (sec.kind === 'custom' ? 'No questions yet. Tell Claude your idea.' : 'No questions here yet.');
      btn = el('button', { type: 'button', class: 'btn small', 'data-key': 'sec:' + sec.id, 'aria-label': 'Open: ' + str(sec.title), on: { click: function () { go('section', { id: sec.id }); } } }, 'Open');
    }
    var extraPlan = (waiting.length && planWaits) ? el('span', { class: 'chip warn', text: 'Plan to read' }) : null;
    return el('div', { class: 'card tight sx-sec' + (waiting.length && !parked ? ' has-waiting' : '') + (parked ? ' is-parked' : '') },
      el('div', { class: 'sx-secmain' },
        el('div', { class: 'item-title ellipsis', dir: 'auto', text: str(sec.title) }),
        el('div', { class: 'item-sub clamp2', dir: 'auto', text: sub })),
      el('div', { class: 'sx-secend' }, extraPlan, chip, btn));
  }

  function renderHome(box) {
    var secs = listSections();
    var allQs = vals(col('questions'));
    var brandNew = !secs.length && !allQs.length;
    /* no connection and nothing to show: ONE calm message, no greeting over an empty page, nothing that cannot work */
    if (QT.offline && brandNew) { box.appendChild(offlineCard({ heading: 'Your questions' })); return; }
    box.appendChild(el('h1', { class: 'sx-h1', text: 'Hi! Here is what is waiting for you.' }));

    if (brandNew) {
      box.appendChild(el('div', { class: 'card sx-empty' },
        el('p', { class: 'strong', text: 'Nothing is here yet.' }),
        el('p', { class: 'muted', text: 'Claude will put your first questions here soon. You can also make a section of your own.' }),
        el('div', { class: 'row' }, el('button', { type: 'button', class: 'btn primary', on: { click: function () { go('newsection'); } } }, '+ New section'))));
      return;
    }

    var waitingTotal = 0, planTotal = 0;
    secs.forEach(function (s) {
      if (s.readOnly) return;
      waitingTotal += waitingOf(s.id).length;
      var p = isBig(s.id) ? planOf(s.id) : null;
      if (p && !p.replied) planTotal++;
    });
    if (!waitingTotal && !planTotal) {
      box.appendChild(el('div', { class: 'card good sx-caught', role: 'status' },
        el('p', { class: 'strong', text: 'You are all caught up. 🎉' }),
        el('p', { class: 'small', text: 'Claude will tell you here when there is something new.' })));
    } else {
      var bits = [];
      if (waitingTotal) bits.push(pl(waitingTotal, 'question') + (waitingTotal === 1 ? ' is' : ' are') + ' waiting');
      if (planTotal) bits.push(pl(planTotal, 'plan') + ' to read');
      box.appendChild(el('p', { class: 'muted sx-summary', text: bits.join(' · ') + '.' }));
    }
    box.appendChild(el('p', { class: 'small muted sx-safe', text: SAFE_LINE }));

    /* section cards: the ones with something waiting first, the read-only pile last */
    var rank = function (s) { if (s.readOnly) return 3; var w = waitingOf(s.id).length || (isBig(s.id) && planOf(s.id) && !planOf(s.id).replied); return w ? (s.hold === true ? 1 : 0) : 2; };
    var ordered = secs.map(function (s, i) { return { s: s, i: i, r: rank(s) }; })
      .sort(function (a, b) { return (a.r - b.r) || (a.i - b.i); }).map(function (x) { return x.s; });
    if (ordered.length) box.appendChild(el('div', { class: 'stack tight sx-seclist' }, ordered.map(sectionCard)));

    /* answers waiting for Claude */
    var unseen = allQs.filter(function (q) { return isAnswered(q.id) && qstate(q.id) === 'answeredUnseen'; }).length;
    if (unseen) {
      box.appendChild(el('p', { class: 'small muted sx-unseen' },
        'You answered ' + pl(unseen, 'question') + ' that Claude has not looked at yet. ',
        el('a', { href: '#', on: { click: function (e) { e.preventDefault(); go('done'); } } }, 'See the list')));
    }

    /* Claude is working on */
    var working = allQs.filter(function (q) { return qstate(q.id) === 'working'; }).sort(byOrder);
    if (working.length) {
      box.appendChild(el('section', { class: 'stack tight sx-working', 'aria-labelledby': 'sx-h-working' },
        el('h2', { id: 'sx-h-working', class: 'sx-h2', text: 'Claude is working on these' }),
        list(working.map(function (q) { return qRow(q, { noNew: true }); }))));
    }

    /* Recently done */
    var done = vals(col('status')).filter(function (s) { return s.state === 'done' && col('questions')[s.id || s.qid]; })
      .sort(function (a, b) { return str(b.at) < str(a.at) ? -1 : (str(b.at) > str(a.at) ? 1 : 0); }).slice(0, 5);
    if (done.length) {
      box.appendChild(el('section', { class: 'stack tight sx-recent', 'aria-labelledby': 'sx-h-done' },
        el('div', { class: 'row between' },
          el('h2', { id: 'sx-h-done', class: 'sx-h2', text: 'Recently finished' }),
          el('button', { type: 'button', class: 'btn quiet small', on: { click: function () { go('done'); } } }, 'See all')),
        list(done.map(function (s) { return doneRow(col('questions')[s.id], s); }))));
    }

    /* hidden sections can come back */
    var arch = QT.sections.archived();
    if (arch.length) {
      var key = 'home:archived';
      var d = el('details', { class: 'sx-archived' },
        el('summary', { text: 'Hidden sections (' + arch.length + ')', on: { click: function () { openState[key] = !d.open; } } }),
        list(arch.map(function (s) {
          return el('div', { class: 'item' },
            el('div', { class: 'item-main' }, el('div', { class: 'item-title', text: str(s.title) })),
            el('div', { class: 'item-end' }, el('button', { type: 'button', class: 'btn small', 'data-key': 'unhide:' + s.id,
              on: { click: function () { QT.write.section(s.id, { id: s.id, archived: false }).then(function () { go('section', { id: s.id }); }, function () { /* the page tells her about failed saves */ }); } } }, 'Bring it back')));
        })));
      d.open = !!openState[key];
      box.appendChild(d);
    }

    if (!QT.offline) box.appendChild(el('div', { class: 'row sx-more' }, el('button', { type: 'button', class: 'btn small', on: { click: function () { go('newsection'); } } }, '+ New section')));
  }

  function doneRow(q, s) {
    var note = str(s.doneNote);
    var th = thumbs(s.doneImages, 4);
    return qRow(q, {
      noNew: true, noChip: true,
      sub: [sectionTitle(q.sectionId), ago(s.at) ? 'done ' + ago(s.at) : ''].filter(Boolean).join(' · '),
      extra: [
        el('div', { class: 'sx-donenote' }, el('span', { class: 'chip good', text: 'Done ✓' }), note ? el('span', { class: 'sx-donetext', dir: 'auto', text: note }) : null),
        th
      ]
    });
  }

  QT.views.home = function (root) {
    var view = Regions(root);
    view.set([{ name: 'home', deps: ['sections', 'questions', 'answers', 'status', 'plans', 'planReplies'], render: renderHome }]);
    return function () { view.destroy(); };
  };

  /* ======================================================================
   * DONE
   * ==================================================================== */
  QT.views.done = function (root) {
    var ui = { more: 30 };
    var view = Regions(root);
    function render(box) {
      var qs = col('questions');
      box.appendChild(el('h1', { class: 'sx-h1', text: 'What Claude finished' }));
      var done = vals(col('status')).filter(function (s) { return s.state === 'done' && qs[s.id]; })
        .sort(function (a, b) { return str(b.at) < str(a.at) ? -1 : (str(b.at) > str(a.at) ? 1 : 0); });
      if (!done.length) {
        box.appendChild(empty('Nothing is finished yet. When Claude finishes something, you will see it here.'));
      } else {
        var shown = done.slice(0, ui.more);
        box.appendChild(el('section', { class: 'stack tight', 'aria-label': 'What Claude finished' },
          list(shown.map(function (s) { return doneRow(qs[s.id], s); })),
          done.length > shown.length ? el('button', { type: 'button', class: 'btn small', 'data-key': 'done:more',
            on: { click: function () { ui.more += 30; view.repaint('done'); } } }, 'Show ' + (done.length - shown.length) + ' more') : null));
      }

      var waiting = vals(qs).filter(function (q) {
        if (!isAnswered(q.id)) return false;
        var st = qstate(q.id);
        return st === 'answeredUnseen' || st === 'seen' || st === 'working' || st === 'held';
      }).sort(function (a, b) {
        var aa = str((col('answers')[a.id] || {}).answeredAt), bb = str((col('answers')[b.id] || {}).answeredAt);
        return aa < bb ? 1 : (aa > bb ? -1 : 0);
      });
      box.appendChild(el('section', { class: 'stack tight sx-answered', 'aria-labelledby': 'sx-h-answered' },
        el('h2', { id: 'sx-h-answered', class: 'sx-h2', text: 'You answered, Claude has not finished' }),
        waiting.length
          ? list(waiting.map(function (q) {
            var a = col('answers')[q.id] || {};
            return qRow(q, { noNew: true, sub: [sectionTitle(q.sectionId), ago(a.answeredAt) ? 'you answered ' + ago(a.answeredAt) : ''].filter(Boolean).join(' · ') });
          }))
          : empty('Nothing here. Claude has looked at everything you answered.')));
    }
    view.set([{ name: 'done', deps: ['sections', 'questions', 'answers', 'status'], render: render }]);
    return function () { view.destroy(); };
  };

  /* ======================================================================
   * NEW SECTION
   * ==================================================================== */
  var SIZE_TEXT = {
    small: 'Claude starts as soon as you answer one question.',
    big: 'Claude waits for your important answers and your OK on the plan.'
  };
  var SIZE_NAME = { small: 'Small', big: 'Big' };   // shown next to the word "Size" (and under "How big is this section?")
  var SAFE_LINE = 'Answering here never changes the real website. Claude only starts work after you answer.';
  var PARKED_LINE = 'Saved for later. Nothing starts here until you say so.';
  /** One sentence for each section, the same on the Home card and on the section page ("Ideas for later" always says the parked line). */
  function blurbOf(s) { return s && s.id === 'later' ? PARKED_LINE : str(s && s.blurb); }
  var MAXLEN = 4000;   // longest text box; the page itself refuses anything huge
  var retryNote = '';
  /** The offline card: the layout banner already says what is wrong, so this has a heading (Home only), a calm line and a button that asks again. */
  function offlineCard(opts) {
    opts = opts || {};
    var note = el('p', { class: 'small muted sx-retrynote', role: 'status', text: retryNote });
    var btn = el('button', { type: 'button', class: 'btn primary', 'data-key': 'retry' }, 'Try again');
    btn.addEventListener('click', function () {
      if (btn.getAttribute('aria-disabled') === 'true') return;
      btn.setAttribute('aria-disabled', 'true'); retryNote = '';
      var p;
      try { p = Promise.resolve(QT.retry ? QT.retry() : { ok: false }); } catch (e) { p = Promise.resolve({ ok: false }); }
      p.then(function (r) {
        btn.removeAttribute('aria-disabled');
        if (r && r.ok) { retryNote = ''; if (opts.onOnline) opts.onOnline(); return; }
        retryNote = 'Still not connected.'; note.textContent = retryNote;
      });
    });
    return el('div', { class: 'card stack sx-empty sx-offline' },
      opts.heading ? el('h1', { class: 'sx-h1', text: opts.heading }) : null,
      el('p', { class: 'muted', text: opts.heading ? 'Nothing is lost.' : 'Not connected yet.' }),
      el('div', { class: 'row' }, btn), note);
  }
  /** Plain words for the folded ideas box: how many were sent, what the newest one is doing, and a saved draft. */
  function ideasSummary(mine) {
    var sent = mine.filter(function (i) { return i.sentAt; }), drafts = mine.length - sent.length, parts = [], ready = false;
    if (sent.length) {
      var newest = sent.slice().sort(function (a, b) { return str(b.sentAt) < str(a.sentAt) ? -1 : (str(b.sentAt) > str(a.sentAt) ? 1 : 0); })[0];
      var st = col('ideaStatus')[newest.id];
      ready = !!st && st.state === 'questionsReady';
      parts.push(sent.length + ' sent \u00b7 ' + (ready ? 'Questions are ready \u2193' : (st && st.state === 'read' ? 'Claude read it' : 'waiting for Claude to read it')));
    }
    if (drafts) parts.push(drafts === 1 ? 'Draft saved' : drafts + ' drafts saved');
    return { text: parts.join(' \u00b7 '), ready: ready };
  }
  /** Is this a question Claude wrote from one of her ideas? (the idea says "Questions are ready" and the question came after it was sent; a question with an ideaId must match that idea) */
  function fromIdea(q) {
    var ideas = vals(col('ideas')).filter(function (i) { return i.sectionId === q.sectionId && i.sentAt; });
    for (var k = 0; k < ideas.length; k++) {
      var st = col('ideaStatus')[ideas[k].id];
      if (!st || st.state !== 'questionsReady') continue;
      if (q.ideaId) { if (q.ideaId === ideas[k].id) return true; continue; }
      var t = Date.parse(q.createdAt), a = Date.parse(ideas[k].sentAt), b = Date.parse(st.at);
      if (!isNaN(t) && !isNaN(a) && !isNaN(b) && t >= a && t <= b + 300000) return true;
    }
    return false;
  }
  /** A quiet note under a text box that shows only when the text is close to the limit. */
  function limitHint(ta) {
    var h = el('p', { class: 'hint sx-limit', hidden: true, text: 'That is long – Claude can read up to ' + MAXLEN + ' letters.' });
    var upd = function () { h.hidden = ta.value.length < MAXLEN * 0.9; };
    ta.addEventListener('input', upd); upd();
    return h;
  }
  var FAIL_TEXT = 'Not saved. Your words are still here. Please try again.';
  var FAIL_SHORT = 'Not saved. Please try again.';
  var PLAN_OK = 'Looks good, go ahead';
  var RESERVED = ['look', 'other', 'later', 'kathy', 'downloads', 'done', 'home'];
  function slugify(name) {
    var s = str(name).toLowerCase();
    try { s = s.normalize('NFKD').replace(/[̀-ͯ]/g, ''); } catch (e) { /* old browser */ }
    s = s.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40).replace(/-+$/, '');
    return s || 'section';
  }
  function freshSectionId(name) {
    var used = col('sections'), base = slugify(name), id = base, n = 2;
    while (used[id] || RESERVED.indexOf(id) >= 0) id = base + '-' + (n++);
    return id;
  }
  function nextOrder() {
    var m = 0;
    vals(col('sections')).forEach(function (s) { m = Math.max(m, num(s.order, 0)); });
    return m + 1;
  }

  QT.views.newsection = function (root) {
    root.classList.add('sx');
    var size = 'big', busy = false;
    var nameIn = el('input', { type: 'text', id: 'sx-new-name', maxlength: '60', autocomplete: 'off', placeholder: 'For example: Account features', 'data-key': 'newname', 'aria-describedby': 'sx-new-hint' });
    nameIn.value = getDraft('newname');
    var msg = el('div', { class: 'savestat bad', role: 'alert' });
    var create = el('button', { type: 'button', class: 'btn primary', 'data-key': 'create' }, 'Create section');

    function opt(value, label) {
      var input = el('input', { type: 'radio', name: 'sx-size', value: value, 'aria-describedby': 'sx-new-size-' + value });
      input.checked = size === value;
      input.addEventListener('change', function () { if (input.checked) size = value; sync(); });
      return el('label', { class: 'sx-opt', 'data-size': value }, input,
        el('span', { class: 'sx-opt-text' }, el('span', { class: 'strong', text: label }), el('span', { id: 'sx-new-size-' + value, class: 'small muted', text: SIZE_TEXT[value] })));
    }
    var optSmall = opt('small', SIZE_NAME.small), optBig = opt('big', SIZE_NAME.big);
    function sync() {
      [optSmall, optBig].forEach(function (o) { o.classList.toggle('on', o.getAttribute('data-size') === size); o.querySelector('input').checked = o.getAttribute('data-size') === size; });
    }
    sync();

    nameIn.addEventListener('input', function () { setDraft('newname', nameIn.value); if (msg.textContent) msg.textContent = ''; });
    nameIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
    function submit() {
      if (busy) return;
      var name = nameIn.value.replace(/\s+/g, ' ').trim();
      if (!name) { msg.textContent = 'Please give your section a name.'; nameIn.focus(); return; }
      busy = true; create.setAttribute('aria-disabled', 'true'); msg.textContent = '';
      var id = freshSectionId(name);
      var doc = { id: id, title: name, kind: 'custom', size: size, hold: false, readOnly: false, blurb: '', archived: false, order: nextOrder(), createdAt: nowIso(), createdBy: 'owner' };
      var p;
      try { p = Promise.resolve(QT.write.section(id, doc)); } catch (e) { p = Promise.reject(e); }
      p.then(function () { setDraft('newname', ''); go('section', { id: id }); },
        function () { msg.textContent = FAIL_TEXT; })
        .then(function () { busy = false; create.removeAttribute('aria-disabled'); });
    }
    create.addEventListener('click', submit);

    root.appendChild(el('h1', { class: 'sx-h1', text: 'New section' }));
    if (QT.offline) { root.appendChild(offlineCard({ onOnline: function () { if (root.isConnected !== false) { root.textContent = ''; QT.views.newsection(root); } } })); return function () {}; }
    root.appendChild(el('div', { class: 'card stack sx-new' },
      el('p', { class: 'muted', text: 'A section is a place for one topic. You tell Claude your ideas inside it, and Claude asks you questions.' }),
      el('div', { class: 'field' },
        el('label', { for: 'sx-new-name', text: 'Name of the section' }), nameIn,
        el('div', { class: 'hint', id: 'sx-new-hint', text: 'Keep it short, like “Account features”.' })),
      el('fieldset', { class: 'sx-fieldset' },
        el('legend', { text: 'How big is this section?' }),
        el('div', { class: 'stack tight' }, optSmall, optBig)),
      msg,
      el('div', { class: 'row' }, create, el('button', { type: 'button', class: 'btn quiet', on: { click: function () { go('home'); } } }, 'Cancel'))));
    return function () { /* nothing to clean up */ };
  };

  /* ======================================================================
   * SECTION
   * ==================================================================== */
  var WHO_LABEL = { kathy: 'Miss Cathy', rob: 'Rob', adviser: 'Their adviser', owner: 'You', unknown: 'Not sure who yet' };
  var WHO_ORDER = ['kathy', 'rob', 'adviser', 'owner', 'unknown'];

  function hasIdeas(sec) { return !!sec && !sec.readOnly && (sec.kind === 'custom' || sec.id === 'later'); }
  function shapeOf(sec) {
    return sec ? [1, !!sec.readOnly, sec.kind === 'custom', hasIdeas(sec), sec.id === 'kathy'].join() : 'none';
  }

  QT.views.section = function (root, params) {
    var sid = str(params && params.id);
    var ui = { renaming: false, menu: false, confirmArchive: false, allIdeas: false, editing: null, notes: {}, noteTimers: {}, busy: {}, pend: {}, filter: '' };
    var view, shape = null;
    var cleanups = [];

    function sec() { return sectionDoc(sid); }
    function say(region, key, text, kind, ms) {
      ui.notes[key] = text ? { text: text, kind: kind || 'ok' } : null;
      if (text) view.announce(text);
      clearTimeout(ui.noteTimers[key]);
      if (text && ms !== 0) ui.noteTimers[key] = setTimeout(function () { ui.notes[key] = null; if (!view.dead) view.repaint(region); }, ms || 7000);
      view.repaint(region);
    }
    function noteEl(key) {
      var n = ui.notes[key];
      return el('div', { class: 'savestat ' + (n ? (n.kind === 'bad' ? 'bad' : 'ok') : ''), text: n ? n.text : '' });
    }
    /* pending toggles: show what she chose at once, even before the notebook has answered */
    function pending(key, real) { return key in ui.pend ? ui.pend[key] : real; }
    function save(region, key, value, fields) {
      ui.pend[key] = value;
      view.repaint(region);
      var done = function () { setTimeout(function () { delete ui.pend[key]; if (!view.dead) view.repaint(region); }, 1500); };
      var p;
      try { p = Promise.resolve(QT.write.section(sid, Object.assign({ id: sid }, fields))); } catch (e) { p = Promise.reject(e); }
      p.then(done, function () {
        delete ui.pend[key];
        say(region, 'save:' + key, FAIL_SHORT, 'bad');
      });
    }

    /* ---------------- header ---------------- */
    function renderHead(box) {
      var s = sec();
      if (!s) return;
      var custom = s.kind === 'custom';
      var hold = !!pending('hold', s.hold);
      var titleRow;
      if (ui.renaming && custom) {
        var key = 'rename:' + sid;
        var inp = el('input', { type: 'text', maxlength: '60', 'data-key': key, 'aria-label': 'New name for this section', autocomplete: 'off' });
        inp.value = getDraft(key) || str(s.title);
        inp.addEventListener('input', function () { setDraft(key, inp.value); });
        var commit = function () {
          var name = inp.value.replace(/\s+/g, ' ').trim();
          if (!name) { say('head', 'rename', 'Please type a name.', 'bad'); return; }
          setDraft(key, '');
          ui.renaming = false;
          save('head', 'title', name, { title: name });
        };
        inp.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); commit(); }
          if (e.key === 'Escape') { e.preventDefault(); setDraft(key, ''); ui.renaming = false; view.repaint('head'); }
        });
        titleRow = el('div', { class: 'stack tight' },
          el('label', { for: 'sx-rename', text: 'Name of the section' }),
          el('div', { class: 'row nowrap' }, inp,
            el('button', { type: 'button', class: 'btn primary small', on: { click: commit } }, 'Save'),
            el('button', { type: 'button', class: 'btn quiet small', on: { click: function () { setDraft(key, ''); ui.renaming = false; view.repaint('head'); } } }, 'Cancel')),
          noteEl('rename'));
        inp.id = 'sx-rename';
      } else {
        var shownTitle = ('title' in ui.pend) ? ui.pend.title : str(s.title);
        titleRow = h1(shownTitle, custom ? menuButton() : null);
      }
      box.appendChild(titleRow);
      if (ui.menu && custom) box.appendChild(menuList());
      if (ui.confirmArchive && custom) {
        box.appendChild(el('div', { class: 'banner warn sx-confirm', role: 'group', 'aria-label': 'Hide this section?' },
          el('span', { class: 'banner-text', text: 'Hide this section? It goes away from the menu. Claude keeps everything, and you can bring it back later.' }),
          el('button', { type: 'button', class: 'btn primary small', 'data-key': 'archive-yes', on: { click: function () {
            ui.confirmArchive = false;
            var p;
            try { p = Promise.resolve(QT.write.section(sid, { id: sid, archived: true })); } catch (e) { p = Promise.reject(e); }
            p.then(function () { go('home'); }, function () { say('head', 'archive', FAIL_SHORT, 'bad'); });
          } } }, 'Hide it'),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'archive-no', on: { click: function () { ui.confirmArchive = false; view.repaint('head'); } } }, 'Keep it')));
        setTimeout(function () { var n = view.node('head'); if (n && ui.confirmArchive && !n.contains(document.activeElement)) focusKey(n, 'archive-no'); }, 0);
      }
      if (blurbOf(s)) box.appendChild(el('p', { class: 'muted sx-blurb', dir: 'auto', text: blurbOf(s) }));
      if (custom) box.appendChild(el('p', { class: 'small muted sx-safe', text: SAFE_LINE }));
      box.appendChild(noteEl('archive'));

      if (s.readOnly || !custom) return;   // Size and Pause are for her own sections only
      /* size + pause */
      var big = (pending('size', s.size) === 'big');
      var seg = el('div', { class: 'sx-seg', role: 'group', 'aria-label': 'How big is this section?' },
        ['small', 'big'].map(function (v) {
          return el('button', { type: 'button', class: 'btn small', 'data-key': 'size:' + v, 'aria-pressed': (big ? v === 'big' : v === 'small') ? 'true' : 'false',
            on: { click: function () { if ((v === 'big') !== big) save('head', 'size', v, { size: v }); } } }, SIZE_NAME[v]);
        }));
      var cb = el('input', { type: 'checkbox', role: 'switch', 'data-key': 'hold' });
      cb.checked = hold;
      cb.addEventListener('change', function () { save('head', 'hold', cb.checked, { hold: cb.checked }); });
      var sw = el('label', { class: 'switch' }, cb, el('span', { class: 'track', 'aria-hidden': 'true' }), el('span', { class: 'lbl', text: 'Pause: do not start anything here' }));
      var wk = 'controls:what';
      var whatOpen = !!openState[wk];
      var what = el('div', { class: 'sx-what', id: 'sx-what', hidden: !whatOpen },
        el('p', { class: 'small sx-expl' }, el('b', { text: SIZE_NAME.small }), ': ' + SIZE_TEXT.small),
        el('p', { class: 'small sx-expl' }, el('b', { text: SIZE_NAME.big }), ': ' + SIZE_TEXT.big),
        el('p', { class: 'small sx-expl sx-pausehint' }, el('b', { text: 'Pause' }), ': Claude waits and does not start. Your answers still save. Switch it off to let Claude start.'));
      what.hidden = !whatOpen;
      var whatBtn = el('button', { type: 'button', class: 'btn quiet small sx-whatbtn', 'data-key': 'what', 'aria-expanded': whatOpen ? 'true' : 'false', 'aria-controls': 'sx-what',
        on: { click: function () { openState[wk] = !openState[wk]; view.repaint('head'); } } }, 'What is this?');
      box.appendChild(el('div', { class: 'card tight sx-controls' + (hold ? ' is-paused' : '') },
        el('div', { class: 'row between' }, el('div', { class: 'row' }, el('span', { class: 'sx-lbl', text: 'Size' }), seg), sw),
        el('div', { class: 'row between nowrap sx-nowrow' },
          el('p', { class: 'small sx-expl on sx-now grow' }, el('b', { text: SIZE_NAME[big ? 'big' : 'small'] }), ': ' + SIZE_TEXT[big ? 'big' : 'small']), whatBtn),
        hold ? el('p', { class: 'small strong sx-paused', text: 'Paused. Claude will not start anything here. Your answers still save.' }) : null,
        what,
        noteEl('save:hold'), noteEl('save:size'), noteEl('save:title')));
    }
    function menuButton() {
      return el('button', { type: 'button', class: 'btn small sx-menubtn', id: 'sx-menubtn', 'data-key': 'menubtn', 'aria-haspopup': 'true', 'aria-expanded': ui.menu ? 'true' : 'false',
        'aria-label': 'More options for this section', on: { click: function (e) { e.stopPropagation(); ui.menu = !ui.menu; view.repaint('head'); } } },
        el('span', { 'aria-hidden': 'true', text: '⋯' }), 'More');
    }
    function menuList() {
      var items = [
        ['Rename this section', function () { ui.menu = false; ui.renaming = true; view.repaint('head'); setTimeout(function () { var n = view.node('head'); if (n) focusKey(n, 'rename:' + sid); }, 0); }],
        ['Hide this section', function () { ui.menu = false; ui.confirmArchive = true; view.repaint('head'); }]
      ];
      var m = el('div', { class: 'sx-menu card tight', role: 'menu', 'aria-label': 'More options for this section' },
        items.map(function (it, i) {
          return el('button', { type: 'button', class: 'btn quiet', role: 'menuitem', 'data-key': 'mi:' + i, on: { click: function (e) { e.stopPropagation(); it[1](); } } }, it[0]);
        }));
      m.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { ui.menu = false; view.repaint('head'); var n = view.node('head'); if (n) focusKey(n, 'menubtn'); }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          var bs = [].slice.call(m.querySelectorAll('button')), i = bs.indexOf(document.activeElement);
          if (i >= 0) { e.preventDefault(); bs[(i + (e.key === 'ArrowDown' ? 1 : bs.length - 1)) % bs.length].focus(); }
        }
      });
      setTimeout(function () { var f = m.querySelector('button'); if (f && ui.menu && !m.contains(document.activeElement)) f.focus(); }, 0);
      return m;
    }
    function onDocClick(e) {
      if (!ui.menu) return;
      var n = view && view.node('head');
      if (n && n.querySelector('.sx-menu') && n.querySelector('.sx-menu').contains(e.target)) return;
      ui.menu = false; view.repaint('head');
    }
    document.addEventListener('click', onDocClick);
    cleanups.push(function () { document.removeEventListener('click', onDocClick); });

    /* ---------------- progress (Big sections) ---------------- */
    function renderProgress(box) {
      var s = sec();
      if (!s || s.readOnly || s.id === 'later' || !(pending('size', s.size) === 'big')) return;
      var pr = progress(sid), pp = planOf(sid);
      var t = pr.requiredTotal, a = pr.requiredAnswered;
      if (!t) return;   // nothing important asked yet: no card
      var card = el('div', { class: 'card tight sx-progress stack tight' });
      card.appendChild(el('div', { class: 'strong', text: 'Before Claude starts: ' + a + ' of ' + t + ' important ' + (t === 1 ? 'question' : 'questions') + ' answered' }));
      var bar = el('div', { class: 'progress', role: 'progressbar', 'aria-label': 'Important questions answered', 'aria-valuemin': '0', 'aria-valuemax': String(t), 'aria-valuenow': String(a) }, el('i'));
      bar.firstChild.style.width = Math.round(100 * a / t) + '%';
      card.appendChild(bar);
      var line = '', kind = '';
      if (a < t) {
        var open = pendingRequired(sid);
        line = ((t - a) === 1 ? 'One more to go.' : (t - a) + ' more to go.') + ' Look for the “Important” tag. Claude waits for these before starting a big section.' +
          (open ? (open === 1 ? ' One answer (“I\'m not sure yet” or “Explain another way”) does not count yet.' : ' ' + open + ' answers (“I\'m not sure yet” or “Explain another way”) do not count yet.') : '');
      }
      else if (!pp) { line = 'All important questions answered. Waiting for Claude to write the plan.'; kind = 'wait'; }
      else if (!pp.replied) { line = 'All important questions answered. Please read the plan below.'; kind = 'warn'; }
      else if (pp.approved) { line = pending('hold', s.hold) ? 'You said OK to the plan. Pause is on, so Claude waits.' : 'All set. You said OK to the plan, so Claude can start.'; kind = 'good'; }
      else line = 'You asked for a change to the plan. Waiting for Claude.';
      card.appendChild(el('div', { class: 'small sx-progline ' + kind }, line, kind === 'wait' ? [' ', el('span', { class: 'dots', 'aria-hidden': 'true' }, el('i'), el('i'), el('i'))] : null));
      box.appendChild(card);
    }

    /* ---------------- plan ---------------- */
    function planSeen(reply) {
      var cand = [col('status')['plan-' + sid], col('status')['plan_' + sid]].filter(Boolean);
      var p = col('plans')[sid] || {};
      var st = cand[0] || null;
      var seenAt = st && (st.seenAt || st.at);
      if (st && (!reply || !seenAt || str(seenAt) >= str(reply.at))) return st;
      if (p.seenReplyAt && reply && str(p.seenReplyAt) >= str(reply.at)) return { state: 'seen', seenAt: p.seenReplyAt };
      return null;
    }
    function sendPlan(plan, decision) {
      var key = 'plan:' + sid + ':' + num(plan.version, 1);
      var text = str(getDraft(key)).trim();
      if (ui.busy.plan) return;
      if (decision === 'ok' && text) { say('plan', 'plan', 'You wrote a change. Press “Change this” to send it, or clear the box and press “' + PLAN_OK + '”.', 'bad', 12000); return; }
      if (decision === 'change' && !text) { say('plan', 'plan', 'Please write what should change, then press “Change this”.', 'bad', 9000); var n = view.node('plan'); if (n) focusKey(n, key); return; }
      ui.busy.plan = true;
      var p;
      try { p = Promise.resolve(QT.write.planReply(sid, { sectionId: sid, version: num(plan.version, 1), decision: decision, text: decision === 'change' ? text : '', at: nowIso() })); } catch (e) { p = Promise.reject(e); }
      p.then(function () {
        if (decision === 'change' && str(getDraft(key)).trim() === text) setDraft(key, '');
        ui.busy.plan = false;
        say('plan', 'plan', decision === 'ok' ? 'Saved ✓ Claude will see that you said OK.' : 'Saved ✓ Claude will read what you want changed.', 'ok');
      }, function () {
        ui.busy.plan = false;
        say('plan', 'plan', FAIL_TEXT, 'bad');
      });
    }
    function renderPlan(box) {
      var s = sec(), pp = planOf(sid);
      if (!s || !pp) return;
      var plan = pp.plan, ver = num(plan.version, 1);
      var key = 'plan:' + sid + ':' + ver;
      var card = el('div', { class: 'card sx-plan stack' + (pp.replied ? '' : ' needs-you') });
      card.appendChild(el('div', { class: 'row between' },
        el('h2', { class: 'sx-h2', text: 'Claude’s plan' }),
        el('span', { class: 'row' }, el('span', { class: 'chip', text: 'Plan ' + ver }), ago(plan.at) ? el('span', { class: 'tiny muted', text: 'written ' + ago(plan.at) }) : null)));
      if (plan.summary) card.appendChild(el('p', { class: 'sx-summary-text', dir: 'auto', text: str(plan.summary) }));
      var steps = (Array.isArray(plan.steps) ? plan.steps : []).filter(function (x) { return str(x).trim(); });
      if (steps.length) card.appendChild(el('ol', { class: 'sx-steps' }, steps.map(function (x) { return el('li', { dir: 'auto', text: str(x) }); })));
      var needs = (Array.isArray(plan.needs) ? plan.needs : []).filter(function (x) { return str(x).trim(); });
      if (needs.length) card.appendChild(el('div', { class: 'sx-needs' }, el('h3', { text: 'Claude still needs from you' }), el('ul', null, needs.map(function (x) { return el('li', { dir: 'auto', text: str(x) }); }))));

      /* what she already said */
      var r = pp.reply;
      if (r && pp.replied) {
        var seen = planSeen(r);
        var what = r.decision === 'ok' ? 'You said: ' + PLAN_OK + ' ✓' : 'You asked for a change' + (r.text ? ': “' + str(r.text) + '”' : '');
        var seenTxt;
        if (seen && seen.state === 'working') seenTxt = 'Claude is working on it' + (seen.note ? ': ' + str(seen.note) : '');
        else if (seen && seen.state === 'done') seenTxt = 'Done ✓' + (seen.doneNote ? ' ' + str(seen.doneNote) : '');
        else if (seen) seenTxt = 'Claude saw it ✓';
        else seenTxt = 'Waiting for Claude to see it';
        card.appendChild(el('div', { class: 'panel sx-said', role: 'status' },
          el('div', { class: 'strong', text: what }),
          el('div', { class: 'small ' + (seen ? 'sx-seen' : 'muted'), text: seenTxt + (ago(r.at) ? ' · you answered ' + ago(r.at) : '') })));
      } else if (r) {
        card.appendChild(el('div', { class: 'panel small sx-said' },
          'Earlier you said: ' + (r.decision === 'ok' ? PLAN_OK : 'Change this' + (r.text ? ' – “' + str(r.text) + '”' : '')) + '. Claude made a new plan, so please read it again.'));
      }
      /* the answer buttons (nothing that cannot work while there is no connection) */
      if (QT.offline) { card.appendChild(el('p', { class: 'muted small', text: 'Not connected yet.' })); box.appendChild(card); return; }
      var ta = el('textarea', { id: 'sx-plan-text', rows: '2', maxlength: String(MAXLEN), dir: 'auto', 'data-key': key, placeholder: 'If something should change, write it here.', 'aria-label': 'What should change in the plan?' });
      ta.value = getDraft(key).slice(0, MAXLEN);
      ta.addEventListener('input', function () { setDraft(key, ta.value); });
      var chosen = pp.replied ? pp.reply.decision : '';
      card.appendChild(el('div', { class: 'stack tight sx-reply' },
        ta, limitHint(ta),
        el('div', { class: 'row' },
          el('button', { type: 'button', class: 'btn primary', 'data-key': 'plan-ok', 'aria-pressed': chosen === 'ok' ? 'true' : 'false', on: { click: function () { sendPlan(plan, 'ok'); } } }, PLAN_OK),
          el('button', { type: 'button', class: 'btn', 'data-key': 'plan-change', 'aria-pressed': chosen === 'change' ? 'true' : 'false', on: { click: function () { sendPlan(plan, 'change'); } } }, 'Change this')),
        el('p', { class: 'hint sx-planhint' }, el('b', { text: PLAN_OK + ':' }), ' Claude starts only after you press it. You can still ask for changes. ', el('b', { text: 'Change this:' }), ' Claude reads your words and makes a new plan.'),
        noteEl('plan')));
      box.appendChild(card);
    }

    /* ---------------- ideas ---------------- */
    function ideaState(i) {
      if (!i.sentAt) return { label: 'Draft', cls: '' };
      var st = col('ideaStatus')[i.id];
      if (st && st.state === 'questionsReady') return { label: 'Questions are ready ↓', cls: 'good' };
      if (st && st.state === 'read') return { label: 'Claude read it', cls: 'info' };
      return { label: 'Sent', cls: '' };
    }
    function writeIdea(obj) {
      try { return Promise.resolve(QT.write.idea(obj)); } catch (e) { return Promise.reject(e); }
    }
    function updateIdea(i, text) {
      try {
        if (QT.write.updateIdea) return Promise.resolve(QT.write.updateIdea(i.id, { text: text }));
        return Promise.resolve(QT.write.idea({ id: i.id, sectionId: i.sectionId, text: text, createdAt: i.createdAt, sentAt: null }));
      } catch (e) { return Promise.reject(e); }
    }
    function saveIdea(send) {
      var s = sec(); if (!s || ui.busy.idea) return;
      var key = 'idea:' + sid;
      var text = str(getDraft(key)).trim();
      if (!text) { say('ideas', 'idea', 'Please type your idea first.', 'bad'); var n = view.node('ideas'); if (n) focusKey(n, key); return; }
      ui.busy.idea = true;
      writeIdea({ sectionId: sid, text: text, createdAt: nowIso(), sentAt: null }).then(function (id) {
        if (str(getDraft(key)).trim() === text) setDraft(key, '');
        if (!send) { ui.busy.idea = false; say('ideas', 'idea', 'Saved ✓ It is a draft in your list below. Send it when you are ready.', 'ok'); return null; }
        return Promise.resolve(QT.write.sendIdea(id)).then(function () {
          ui.busy.idea = false; say('ideas', 'idea', 'Sent ✓ Claude will read it soon. Watch the list below for “Claude read it”.', 'ok');
        }, function () {
          ui.busy.idea = false; say('ideas', 'idea', 'Saved, but not sent. Press “Send to Claude” next to it in the list.', 'bad', 12000);
        });
      }).catch(function () {
        ui.busy.idea = false; say('ideas', 'idea', FAIL_TEXT, 'bad');
      });
    }
    function sendDraft(i) {
      if (ui.busy['send:' + i.id]) return;
      ui.busy['send:' + i.id] = true;
      var p;
      try { p = Promise.resolve(QT.write.sendIdea(i.id)); } catch (e) { p = Promise.reject(e); }
      p.then(function () { ui.busy['send:' + i.id] = false; say('ideas', 'idea', 'Sent ✓ Claude will read it soon. Watch the list below for “Claude read it”.', 'ok'); },
        function () { ui.busy['send:' + i.id] = false; say('ideas', 'idea', 'Not sent. Please try again.', 'bad'); });
    }
    function ideaRow(i) {
      var st = ideaState(i);
      var stat = col('ideaStatus')[i.id];
      if (ui.editing === i.id && !i.sentAt) {
        var key = 'ideaedit:' + i.id;
        var ta = el('textarea', { rows: '3', maxlength: String(MAXLEN), dir: 'auto', 'data-key': key, 'aria-label': 'Edit this idea' });
        ta.value = getDraft(key).slice(0, MAXLEN);
        ta.addEventListener('input', function () { setDraft(key, ta.value); });
        return el('div', { class: 'item sx-idea' }, el('div', { class: 'item-main stack tight' }, ta, limitHint(ta),
          el('div', { class: 'row' },
            el('button', { type: 'button', class: 'btn primary small', 'data-key': 'ie-save:' + i.id, on: { click: function () {
              var text = ta.value.trim();
              if (!text) { say('ideas', 'idea', 'Please type your idea first.', 'bad'); return; }
              updateIdea(i, text).then(function () {
                setDraft(key, ''); ui.editing = null; say('ideas', 'idea', 'Saved ✓', 'ok');
              }, function () { say('ideas', 'idea', FAIL_TEXT, 'bad'); });
            } } }, 'Save changes'),
            el('button', { type: 'button', class: 'btn quiet small', on: { click: function () { setDraft(key, ''); ui.editing = null; view.repaint('ideas'); } } }, 'Cancel'))));
      }
      return el('div', { class: 'item sx-idea' },
        el('div', { class: 'item-main' },
          el('div', { class: 'sx-idea-text', dir: 'auto', text: str(i.text) }),
          el('div', { class: 'row sx-idea-meta' },
            el('span', { class: 'chip ' + st.cls, text: st.label }),
            ago(i.sentAt || i.createdAt) ? el('span', { class: 'tiny muted', text: (i.sentAt ? 'sent ' : 'saved ') + ago(i.sentAt || i.createdAt) }) : null,
            stat && stat.note && i.sentAt ? el('span', { class: 'tiny muted', text: '\u00b7 ' + str(stat.note) }) : null),
          !i.sentAt ? el('div', { class: 'row' },
            el('button', { type: 'button', class: 'btn small', 'data-key': 'ie-edit:' + i.id, on: { click: function () { setDraft('ideaedit:' + i.id, str(i.text)); ui.editing = i.id; view.repaint('ideas'); setTimeout(function () { var n = view.node('ideas'); if (n) focusKey(n, 'ideaedit:' + i.id); }, 0); } } }, 'Edit'),
            el('button', { type: 'button', class: 'btn primary small', 'data-key': 'ie-send:' + i.id, on: { click: function () { sendDraft(i); } } }, 'Send to Claude')) : null));
    }
    function renderIdeas(box) {
      var s = sec(); if (!hasIdeas(s)) return;
      var key = 'idea:' + sid;
      var ta = el('textarea', { id: 'sx-idea-text', class: 'sx-idea-box', rows: '3', maxlength: String(MAXLEN), dir: 'auto', 'data-key': key, placeholder: 'Write it in your own words. Short is fine.' });
      ta.value = getDraft(key).slice(0, MAXLEN);
      ta.addEventListener('input', function () { setDraft(key, ta.value); if (ui.notes.idea) { ui.notes.idea = null; var n = box.querySelector('.sx-idea-note'); if (n) n.textContent = ''; } });
      var mine = vals(col('ideas')).filter(function (i) { return i.sectionId === sid; })
        .sort(function (a, b) { return str(b.createdAt) < str(a.createdAt) ? -1 : (str(b.createdAt) > str(a.createdAt) ? 1 : 0); });
      var shown = ui.allIdeas ? mine : mine.slice(0, 3);
      var note = noteEl('idea'); note.classList.add('sx-idea-note');
      /* once an idea has been sent the box is folded ("Your ideas (3)") so the questions stay near the top; a new section, or one with only drafts, keeps it open */
      var summ = ideasSummary(mine);
      var fk = 'ideas:' + sid, folded = mine.some(function (i) { return i.sentAt; });
      var isOpen = (fk in openState) ? !!openState[fk] : !folded;
      var body = QT.offline
        ? [el('p', { class: 'muted', text: 'Not connected yet.' })]
        : [el('div', { class: 'field' },
          el('label', { for: 'sx-idea-text', text: 'Tell Claude what you want here' }), ta, limitHint(ta),
          el('div', { class: 'hint', text: 'Save keeps it as a draft. Send tells Claude to read it and write questions.' })),
        el('div', { class: 'row' },
          el('button', { type: 'button', class: 'btn', 'data-key': 'idea-save', on: { click: function () { saveIdea(false); } } }, 'Save idea'),
          el('button', { type: 'button', class: 'btn primary', 'data-key': 'idea-send', on: { click: function () { saveIdea(true); } } }, 'Send to Claude')),
        note];
      var d = el('details', { class: 'card sx-ideas' },
        el('summary', { 'data-key': 'ideas-sum', on: { click: function () { openState[fk] = !d.open; } } },
          el('span', { class: 'sx-h2', text: mine.length ? 'Your ideas (' + mine.length + ')' : 'Your ideas' }),
          summ.text ? el('span', { class: 'small sx-sumstat' + (summ.ready ? ' ready' : ''), text: summ.text }) : null),
        el('div', { class: 'stack sx-ideas-body' }, body,
          mine.length ? el('div', { class: 'stack tight' },
            el('h3', { class: 'sx-h3', text: 'Ideas you saved or sent' }),
            el('div', { class: 'list sx-list' }, shown.map(ideaRow)),
            mine.length > 3 ? el('button', { type: 'button', class: 'btn quiet small', 'data-key': 'ideas-all', on: { click: function () { ui.allIdeas = !ui.allIdeas; view.repaint('ideas'); } } },
              ui.allIdeas ? 'Show fewer' : 'Show all ' + mine.length + ' ideas') : null) : null));
      d.open = isOpen;
      box.appendChild(d);
    }

    /* ---------------- questions (normal sections) ---------------- */
    function currentTopic(topics) {
      var mem = lsGet('qt.topic.' + sid), i;
      if (mem) for (i = 0; i < topics.length; i++) if (topics[i].name === mem) return topics[i];
      for (i = 0; i < topics.length; i++) if (topics[i].waiting) return topics[i];   // the first topic with something waiting
      return topics[0];
    }
    function pickTopic(name, focusIdx) {
      rememberTopic(sid, name);
      view.repaint('questions');
      if (focusIdx !== undefined) setTimeout(function () { var n = view.node('questions'); if (n) focusKey(n, 'topic:' + focusIdx); }, 0);
    }
    function topicStrip(topics, cur) {
      var tl = el('div', { class: 'sx-topics', role: 'tablist', 'aria-label': 'Topics' }, topics.map(function (t, i) {
        var on = t === cur;
        return el('button', { type: 'button', role: 'tab', id: 'sx-tab-' + i, class: 'sx-tchip' + (on ? ' on' : ''), 'aria-selected': on ? 'true' : 'false', 'aria-controls': 'sx-tabpanel',
          tabindex: on ? '0' : '-1', 'data-key': 'topic:' + i, 'aria-label': t.name + ', ' + (t.waiting ? t.waiting + ' waiting' : 'nothing waiting'),
          on: { click: function () { pickTopic(t.name); } } },
          el('span', { class: 'sx-tname', dir: 'auto', text: t.name }), el('span', { class: 'count' + (t.waiting ? '' : ' calm'), 'aria-hidden': 'true', text: t.waiting ? String(t.waiting) : '\u2713' }));
      }));
      tl.addEventListener('keydown', function (e) {
        var i = -1; topics.forEach(function (t, k) { if (t === cur) i = k; });
        var j = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? (i + 1) % topics.length : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? (i + topics.length - 1) % topics.length : e.key === 'Home' ? 0 : e.key === 'End' ? topics.length - 1 : -1;
        if (j < 0) return;
        e.preventDefault(); pickTopic(topics[j].name, j);
      });
      return tl;
    }
    function renderQuestions(box) {
      var s = sec(); if (!s || s.readOnly) return;
      var qs = questionsOf(sid);
      var topics = topicsOf(qs), byTopic = topics.length >= 2;
      var showAll = !byTopic || lsGet('qt.topicall.' + sid) === '1';
      var cur = byTopic && !showAll ? currentTopic(topics) : null;
      var scope = cur ? cur.qs : qs;
      var done = scope.filter(function (q) { return isDone(q.id); });
      var waiting = scope.filter(needsAnswer);
      var rest = scope.filter(function (q) { return !isDone(q.id) && !needsAnswer(q); });
      var allWaiting = qs.filter(needsAnswer);
      var first = waiting[0] || allWaiting[0];
      var wrap = el('section', { class: 'stack sx-questions', 'aria-labelledby': 'sx-h-q' });
      wrap.appendChild(el('div', { class: 'row between' },
        el('h2', { id: 'sx-h-q', class: 'sx-h2', text: 'Questions' + (qs.length ? ' (' + qs.length + ')' : '') }),
        el('span', { class: 'row sx-qhead' },
          byTopic ? el('button', { type: 'button', class: 'btn quiet small', 'data-key': 'topicall', 'aria-pressed': showAll ? 'true' : 'false',
            on: { click: function () { lsSet('qt.topicall.' + sid, showAll ? '' : '1'); view.repaint('questions'); } } }, showAll ? 'One topic at a time' : 'Show everything') : null,
          first ? el('button', { type: 'button', class: 'btn primary small', 'data-key': 'start', on: { click: function () { openQuestion(first.id); } } }, 'Answer the first one') : null)));
      if (!qs.length) {
        wrap.appendChild(empty(hasIdeas(s) ? 'No questions yet. Write your idea above and press “Send to Claude”. Claude will make the questions.' : 'No questions here yet.'));
        box.appendChild(wrap);
        return;
      }
      var body = wrap;
      if (cur) {
        wrap.appendChild(topicStrip(topics, cur));
        body = el('div', { class: 'stack sx-tabpanel', role: 'tabpanel', id: 'sx-tabpanel', 'aria-labelledby': 'sx-tab-' + topics.indexOf(cur) });
        wrap.appendChild(body);
      }
      if (waiting.length) body.appendChild(group('Waiting for you', waiting, true, true, byTopic && !cur));
      else body.appendChild(el('div', { class: 'card good tight small strong', text: cur ? 'Nothing is waiting for you in this topic. \u2713' : 'Nothing is waiting for you here. \u2713' }));
      if (rest.length) body.appendChild(group('You answered', rest, true, false, byTopic && !cur));
      if (done.length) {
        var dk = 'q:' + sid + ':done';
        var d = el('details', { class: 'sx-group' },
          el('summary', { on: { click: function () { openState[dk] = !d.open; } } }, el('span', { text: 'Done' }), el('span', { class: 'count calm', text: String(done.length) })),
          list(done.map(function (q) { return qRow(q, { noNew: true, important: true, sub: byTopic && !cur ? topicOf(q) : null }); })));
        d.open = !!openState[dk];
        body.appendChild(d);
      }
      if (cur) {
        /* the next topic: the next one with something waiting, else simply the next one */
        var i = topics.indexOf(cur), nxt = null, k;
        for (k = 1; k < topics.length && !nxt; k++) { var c = topics[(i + k) % topics.length]; if (c.waiting) nxt = c; }
        if (!nxt) nxt = topics[(i + 1) % topics.length];
        body.appendChild(el('div', { class: 'row sx-nexttopic' },
          el('button', { type: 'button', class: 'btn small' + (cur.waiting ? '' : ' primary'), 'data-key': 'nexttopic', on: { click: function () { pickTopic(nxt.name); window.scrollTo(0, 0); } } }, 'Next topic: ' + nxt.name)));
      }
      box.appendChild(wrap);
    }
    function group(title, qs, withNew, chipEnd, showTopic) {
      return el('div', { class: 'stack tight sx-qgroup' },
        el('h3', { class: 'sx-h3' }, title + ' ', el('span', { class: 'count calm', text: String(qs.length) })),
        list(qs.map(function (q) { return qRow(q, { noNew: !withNew, chipEnd: chipEnd, important: true, skipWaitChip: !!chipEnd, ideaTag: !!chipEnd, sub: showTopic ? topicOf(q) : null }); })));
    }

    /* ---------------- Kathy list (read only) ---------------- */
    function words(t) { return str(t).toLowerCase().split(/\s+/).filter(Boolean); }
    function matcher() {
      var ws = words(ui.filter);
      return function (q) {
        if (!ws.length) return true;
        var hay = [q.title, q.topic, q.needs, q.why, WHO_LABEL[q.who] || '', (q.story || []).join(' ')].join(' ').toLowerCase();
        return ws.every(function (w) { return hay.indexOf(w) >= 0; });
      };
    }
    function renderKathyHead(box) {
      var s = sec(); if (!s) return;
      box.appendChild(h1(str(s.title)));
      box.appendChild(el('div', { class: 'banner info sx-readonly' }, el('span', { class: 'banner-text', text: 'These are for Miss Cathy and Rob. You can read them, but you do not need to answer.' })));
    }
    /* "You sent these": every question she answered with "This is a question for Miss Cathy and Rob" (answer key cathy), newest first.
       They are already answered, so they are never counted as "waiting for you". Claude copies each one into the list below and marks it done. */
    var SENT_FIRST = 5;
    function sentByHer() {
      var A = col('answers'), Q = col('questions');
      return Object.keys(A).map(function (k) { return A[k]; })
        .filter(function (a) { return a && a.key === 'cathy' && a.status === 'answered' && Q[a.id]; })
        .sort(function (a, b) { return str(b.answeredAt) < str(a.answeredAt) ? -1 : (str(b.answeredAt) > str(a.answeredAt) ? 1 : 0); });
    }
    function sentRow(a) {
      var q = col('questions')[a.id], added = isDone(a.id), from = sectionTitle(q.sectionId), note = str(a.note).trim();
      var main = el('button', { type: 'button', class: 'sx-qmain', 'data-key': 'sent:' + q.id, on: { click: function () { openQuestion(q.id); } } },
        el('span', { class: 'item-title sx-qtitle', dir: 'auto', text: str(q.title) }),
        el('span', { class: 'sx-go', 'aria-hidden': 'true', text: 'Open \u2192' }));   // a quiet "Open →" so the row looks tappable
      var row = el('div', { class: 'item sx-q sx-sent' },
        el('div', { class: 'item-main' }, main,
          note ? el('div', { class: 'item-sub clamp2 sx-sentnote', dir: 'auto', text: 'Your note: ' + note }) : null,
          from ? el('div', { class: 'item-sub', dir: 'auto', text: 'From: ' + from }) : null,
          el('div', { class: 'sx-qchip' }, el('span', { class: 'chip ' + (added ? 'good' : 'info'), text: added ? 'Added to the list ✓' : 'Claude will add it to the list' }))));
      row.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('button')) return; openQuestion(q.id); });
      return row;
    }
    function renderKathySent(box) {
      var mine = sentByHer();
      if (!mine.length) return;
      var shown = ui.allSent ? mine : mine.slice(0, SENT_FIRST);
      box.appendChild(el('section', { class: 'stack tight sx-sentbox', 'aria-labelledby': 'sx-h-sent' },
        el('h2', { id: 'sx-h-sent', class: 'sx-h2' }, 'You sent these ', el('span', { class: 'count calm', 'aria-label': pl(mine.length, 'question'), text: String(mine.length) })),
        list(shown.map(sentRow)),
        mine.length > SENT_FIRST ? el('button', { type: 'button', class: 'btn quiet small', 'data-key': 'sent-all', on: { click: function () { ui.allSent = !ui.allSent; view.repaint('ksent'); } } },
          ui.allSent ? 'Show fewer' : 'Show all ' + mine.length) : null));
    }
    function renderKathyFind(box) {
      var inp = el('input', { type: 'search', id: 'sx-find', 'data-key': 'find', placeholder: 'Type words to find a question', autocomplete: 'off', 'aria-label': 'Find a question' });
      inp.value = ui.filter;
      inp.addEventListener('input', function () { ui.filter = inp.value; setDraft('kfilter:' + sid, inp.value); view.repaint('klist'); });
      box.appendChild(el('div', { class: 'field sx-find' }, el('label', { for: 'sx-find', class: 'sr', text: 'Find a question' }), inp));
    }
    function renderKathyList(box) {
      var s = sec(); if (!s) return;
      var all = questionsOf(sid);
      var test = matcher(), filtering = words(ui.filter).length > 0;
      var hits = all.filter(test);
      box.appendChild(el('p', { class: 'small muted sx-count', role: 'status', 'aria-live': 'polite',
        text: !all.length ? '' : (filtering ? 'Showing ' + hits.length + ' of ' + pl(all.length, 'question') : pl(all.length, 'question') + ' in all') }));
      if (!all.length) { box.appendChild(empty('No questions here yet.')); return; }
      if (!hits.length) {
        box.appendChild(empty('No question matches those words.', el('button', { type: 'button', class: 'btn small', on: { click: function () { ui.filter = ''; setDraft('kfilter:' + sid, ''); view.repaint('kfind'); view.repaint('klist'); } } }, 'Clear the search')));
        return;
      }
      /* group by who, then topic */
      var byWho = {};
      hits.forEach(function (q) { var w = WHO_LABEL[q.who] ? q.who : 'unknown'; (byWho[w] = byWho[w] || []).push(q); });
      var whoKeys = WHO_ORDER.filter(function (w) { return byWho[w]; });
      var totals = {};
      all.forEach(function (q) { var w = WHO_LABEL[q.who] ? q.who : 'unknown'; totals[w] = (totals[w] || 0) + 1; });
      whoKeys.forEach(function (w) {
        var gk = 'k:' + sid + ':' + w;
        var topics = {}, order = [];
        byWho[w].forEach(function (q) { var t = str(q.topic).trim() || 'General'; if (!topics[t]) { topics[t] = []; order.push(t); } topics[t].push(q); });
        var dflt = whoKeys.length === 1 || all.length <= 12;   // a small pile is open at once; a big one starts closed
        var d = el('details', { class: 'sx-group sx-who', 'data-who': w });
        d.appendChild(el('summary', { on: { click: function () { if (!filtering) openState[gk] = !d.open; } } },
          el('span', { class: 'sx-gtitle', text: WHO_LABEL[w] }),
          el('span', { class: 'count calm', 'aria-label': (filtering ? byWho[w].length + ' of ' + totals[w] : String(byWho[w].length)) + ' questions', text: filtering ? byWho[w].length + ' of ' + totals[w] : String(byWho[w].length) })));
        var body = el('div', { class: 'stack tight sx-gbody' });
        order.forEach(function (t) {
          var tk = gk + ':' + t;
          var td = el('details', { class: 'sx-group sx-topic' });
          var allT = all.filter(function (q) { return (WHO_LABEL[q.who] ? q.who : 'unknown') === w && (str(q.topic).trim() || 'General') === t; }).length;
          td.appendChild(el('summary', { on: { click: function () { if (!filtering) openState[tk] = !td.open; } } },
            el('span', { class: 'sx-gtitle', dir: 'auto', text: t }),
            el('span', { class: 'count calm', text: filtering ? topics[t].length + ' of ' + allT : String(topics[t].length) })));
          td.appendChild(list(topics[t].map(kathyRow)));
          td.open = filtering || (tk in openState ? !!openState[tk] : true);
          body.appendChild(td);
        });
        d.appendChild(body);
        d.open = filtering || (gk in openState ? !!openState[gk] : dflt);
        box.appendChild(d);
      });
    }
    function kathyRow(q) {
      var main = el('button', { type: 'button', class: 'sx-qmain', 'data-key': 'q:' + q.id, on: { click: function () { openQuestion(q.id); } } },
        el('span', { class: 'item-title sx-qtitle', dir: 'auto', text: str(q.title) }),
        isNewQ(q.id) ? el('span', { class: 'badge-new', text: 'New' }) : null);
      var row = el('div', { class: 'item sx-q sx-k' },
        el('div', { class: 'item-main' }, main,
          q.needs ? el('div', { class: 'item-sub clamp2', dir: 'auto', text: 'What Claude needs: ' + str(q.needs) }) : null,
          q.previouslyNotSure ? el('div', { class: 'sx-tag' }, el('span', { class: 'chip quiet', text: 'You said “not sure” before' })) : null));
      row.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('button')) return; openQuestion(q.id); });
      return row;
    }

    /* ---------------- build ---------------- */
    function defsFor(s) {
      if (!s) return [{ name: 'missing', deps: ['sections'], render: function (b) {
        if (QT.offline) { b.appendChild(offlineCard({ heading: 'Your questions' })); return; }
        b.appendChild(el('div', { class: 'card stack sx-missing' },
          el('p', { class: 'strong', text: 'That section is not here.' }),
          el('p', { class: 'muted', text: 'It may be hidden, or not made yet.' }),
          el('div', { class: 'row' }, el('button', { type: 'button', class: 'btn primary', on: { click: function () { go('home'); } } }, 'Back to the start'))));
      } }];
      if (s.readOnly) {
        ui.filter = ui.filter || getDraft('kfilter:' + sid);
        return [
          { name: 'khead', deps: ['sections'], render: renderKathyHead }
        ].concat(sid === 'kathy' ? [{ name: 'ksent', deps: ['sections', 'questions', 'answers', 'status'], render: renderKathySent }] : []).concat([
          { name: 'kfind', deps: [], render: renderKathyFind },
          { name: 'klist', deps: ['sections', 'questions'], render: renderKathyList }
        ]);
      }
      /* the questions come right after the set-up cards, so she sees what to answer without scrolling past the plan and the ideas */
      var d = [{ name: 'head', deps: ['sections'], render: renderHead },
        { name: 'progress', deps: ['sections', 'questions', 'answers', 'plans', 'planReplies'], render: renderProgress },
        { name: 'questions', deps: ['sections', 'questions', 'answers', 'status', 'ideas', 'ideaStatus'], render: renderQuestions },
        { name: 'plan', deps: ['sections', 'plans', 'planReplies', 'status'], render: renderPlan }];
      if (hasIdeas(s)) d.push({ name: 'ideas', deps: ['sections', 'ideas', 'ideaStatus'], render: renderIdeas });
      return d;
    }
    function rebuild() { var s = sec(); shape = shapeOf(s); keepFocus(root, function () { view.set(defsFor(s)); }); }
    view = Regions(root, function (e) {
      if (e && (e.collection === 'sections' || e.ready) && shapeOf(sec()) !== shape) { rebuild(); return true; }
      return false;
    });
    rebuild();
    return function () { view.destroy(); cleanups.forEach(function (f) { f(); }); Object.keys(ui.noteTimers).forEach(function (k) { clearTimeout(ui.noteTimers[k]); }); };
  };

  /* small helpers shared with 52-tasks.js (same owner): the DOM builder that skips nulls, drafts, focus keeping, the region painter */
  QT.sxKit = { el: el, col: col, vals: vals, num: num, str: str, pl: pl, ago: ago, nowIso: nowIso, go: go, getDraft: getDraft, setDraft: setDraft, keepFocus: keepFocus, focusKey: focusKey, isTyping: isTyping, Regions: Regions, openState: openState };
})();
