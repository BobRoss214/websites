/* 52-tasks.js  (owner: sections)
 * The Tasks part: QT.views.tasks. A tree of big ideas -> tasks -> smaller tasks, with a detail panel, forms to add / change / ask,
 * and (second step) a map. Everything on screen comes from the collections tasks, taskAdds, taskEdits, asks, replies, workers, questions.
 * Text from documents is untrusted: it only goes in with textContent (through el()).
 * Uses the helper kit that 30-sections.js puts on QT.sxKit.
 */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  QT.views = QT.views || {};
  var K = QT.sxKit;
  if (!K) {
    QT.views.tasks = function (root) { root.appendChild(document.createTextNode('This page is not ready yet. Please try again in a moment.')); return function () {}; };
    return;
  }
  var el = K.el, col = K.col, vals = K.vals, str = K.str, ago = K.ago, pl = K.pl, getDraft = K.getDraft, setDraft = K.setDraft, nowIso = K.nowIso;

  var FAIL_TEXT = 'Not saved. Your words are still here. Please try again.';
  var FAIL_SHORT = 'Not saved. Please try again.';
  var T_MAX = 80, PLAIN_MAX = 300, ASK_MAX = 600;

  /* ---------------------------------------------------------------- small helpers */
  function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* private window */ } }
  function loadJSON(k, d) { try { var v = JSON.parse(lsGet(k)); return v && typeof v === 'object' ? v : d; } catch (e) { return d; } }
  function narrow() { try { return window.matchMedia('(max-width: 559.98px)').matches; } catch (e) { return false; } }
  function reduced() { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }
  function call(fn, args) { try { return Promise.resolve(fn.apply(null, args)); } catch (e) { return Promise.reject(e); } }
  function byOrder(a, b) {
    var d = (typeof a.order === 'number' ? a.order : 1e9) - (typeof b.order === 'number' ? b.order : 1e9);
    if (d) return d;
    var ca = str(a.createdAt), cb = str(b.createdAt);
    if (ca !== cb) return ca < cb ? -1 : 1;
    return str(a.id) < str(b.id) ? -1 : 1;
  }
  function chip(text, cls, icon) { return el('span', { class: 'chip tk-chip' + (cls ? ' ' + cls : '') }, icon ? el('span', { class: 'tk-ico', 'aria-hidden': 'true', text: icon }) : null, text); }
  function goPart(part, params) { if (QT.parts && QT.parts.go) { try { QT.parts.go(part, params); return; } catch (e) { /* fall back */ } } K.go(part, params); }

  var LONG_LIST = 150;   // from this many tasks on, cards that are off screen are not laid out until she scrolls to them (css: .tk-long)

  /* ---------------------------------------------------------------- the model: tasks as she sees them */
  /** Effective tasks: Claude's tasks, her pending adds, and her edits laid on top. Returns { by, kids, roots, list, n }. */
  function model() {
    var tasks = col('tasks'), adds = col('taskAdds'), edits = col('taskEdits'), by = {};
    Object.keys(tasks).forEach(function (id) { var t = tasks[id]; if (t) by[id] = Object.assign({}, t, { id: id }); });
    Object.keys(adds).forEach(function (id) {
      var a = adds[id];
      if (!a || by[id]) return;
      by[id] = { id: id, parentId: a.parentId || null, title: str(a.title), plain: str(a.plain), state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 1e6,
        createdAt: a.createdAt, updatedAt: a.createdAt, doneAt: null, createdBy: 'owner', seenAt: null, _addPending: true };
    });
    Object.keys(by).forEach(function (id) {
      var t = by[id], e = edits[id];
      if (!Array.isArray(t.workerIds)) t.workerIds = [];
      if (!Array.isArray(t.questionIds)) t.questionIds = [];
      if (!e) return;
      t._edit = e;
      if (typeof e.title === 'string' && e.title.trim()) t.title = e.title;
      if (typeof e.plain === 'string') t.plain = e.plain;
      if (e.paused === true) { t._paused = true; t.state = 'paused'; }
      if (e.paused === false && t.state === 'paused') t._resume = true;   // she asked to resume what Claude paused
      if (e.removed === true) t._removed = true;
      if (!t._addPending && (!t.seenAt || str(t.seenAt) < str(e.updatedAt))) t._editPending = true;
    });
    var kids = {}, roots = [];
    Object.keys(by).forEach(function (id) {
      var t = by[id], p = t.parentId;
      if (p && p !== id && by[p]) (kids[p] = kids[p] || []).push(t); else roots.push(t);
    });
    Object.keys(kids).forEach(function (id) { kids[id].sort(byOrder); });
    roots.sort(byOrder);
    var seen = {}, list = [];
    function agg(t, depth) {
      if (seen[t.id]) return; seen[t.id] = 1;
      list.push(t); t._depth = depth;
      var ks = (kids[t.id] || []).filter(function (k) { return !seen[k.id]; });
      ks.forEach(function (k) { agg(k, depth + 1); });
      var all = kids[t.id] || [];
      t._leafDone = 0; t._leafTotal = 0;
      var activeKid = false, kidsFinished = true;
      all.forEach(function (k) { t._leafDone += k._leafDone || 0; t._leafTotal += k._leafTotal || 0; if (k._active) activeKid = true; if (!k._finished) kidsFinished = false; });
      if (!all.length && !t._removed) { t._leafTotal = 1; t._leafDone = t.state === 'done' ? 1 : 0; }
      t._active = (!t._removed && (t.state === 'working' || t.state === 'waiting' || t.state === 'paused')) || activeKid;
      t._finished = (t.state === 'done' || t._removed) && kidsFinished;
    }
    roots.forEach(function (r) { agg(r, 1); });
    var n = { all: 0, working: 0, waitingYou: 0, waiting: 0, done: 0, paused: 0 };
    list.forEach(function (t) {
      if (t._removed) return;
      n.all += 1;
      if (t.state === 'working') n.working += 1;
      if (t.state === 'waiting') { n.waiting += 1; if (t.waitingFor === 'owner') n.waitingYou += 1; }
      if (t.state === 'done') n.done += 1;
      if (t.state === 'paused') n.paused += 1;
    });
    return { by: by, kids: kids, roots: roots, list: list, n: n };
  }

  function wordOf(t) {
    if (t._removed) return 'You asked to remove this';
    if (t._paused) return 'You paused this';
    if (t._resume) return 'Paused \u00b7 you asked to keep going';
    if (t.state === 'waiting') return t.waitingFor === 'owner' ? 'Waiting for you' : t.waitingFor === 'cathy' ? 'Waiting for Miss Cathy' : t.waitingFor === 'rob' ? 'Waiting for Rob' : 'Waiting';
    return { todo: 'To do', working: 'Working', done: 'Done', paused: 'Paused' }[t.state] || 'To do';
  }
  function stateKey(t) { return { todo: 1, working: 1, waiting: 1, done: 1, paused: 1 }[t.state] ? t.state : 'todo'; }
  /** The question she must answer for a task that waits for her (the first one without an answer). */
  function questionToAnswer(t) {
    if (!(t.state === 'waiting' && t.waitingFor === 'owner')) return null;
    var Q = col('questions'), A = col('answers');
    for (var i = 0; i < t.questionIds.length; i++) { var id = t.questionIds[i]; if (Q[id] && !A[id]) return id; }
    return null;
  }
  function initials(name) { var w = str(name).trim().split(/\s+/).filter(Boolean); return ((w[0] || '?').charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase(); }
  function workerBadge(w, big) {
    var icon = str(w.icon).trim();
    return el('span', { class: 'tk-wk st-' + (w.state || 'resting') + (big ? ' big' : ''), title: str(w.name), 'aria-hidden': 'true', dir: 'auto' }, icon && icon.length <= 8 ? icon : initials(w.name));
  }

  /* ---------------------------------------------------------------- the view */
  QT.views.tasks = function (root, params) {
    root.classList.add('tk-view');
    var ui = {
      filter: 'all', q: '', sel: null, focus: null, add: null, edit: null, ask: null, remove: null, notes: {}, noteTimers: {}, busy: {}, first: true,
      open: loadJSON('qt.tasks.open', {}), prev: null, mode: lsGet('qt.tasks.mode') === 'map' ? 'map' : 'list', mapScroll: { x: 0, y: 0 }
    };
    var view, M = model();
    var mDirty = false;   // the model is made once per change of the notebook (three regions ask for it)
    function getModel() { if (mDirty) { M = model(); mDirty = false; } return M; }
    var cleanups = [];
    var wide = false, mq = null;
    try { mq = window.matchMedia('(min-width: 1100px)'); wide = mq.matches; } catch (e) { mq = null; }
    var P = params || {};

    function saveOpen() { lsSet('qt.tasks.open', JSON.stringify(ui.open)); }
    function say(region, key, text, kind) {
      ui.notes[key] = text ? { text: text, kind: kind || 'ok' } : null;
      clearTimeout(ui.noteTimers[key]);
      if (text) { view.announce(text); ui.noteTimers[key] = setTimeout(function () { ui.notes[key] = null; if (!view.dead) view.repaint(region); }, 7000); }
      view.repaint(region);
    }
    function noteEl(key) { var n = ui.notes[key]; return el('div', { class: 'savestat ' + (n ? (n.kind === 'bad' ? 'bad' : 'ok') : ''), text: n ? n.text : '' }); }
    function words() { return ui.q.toLowerCase().split(/\s+/).filter(Boolean); }
    function filtering() { return ui.filter !== 'all' || words().length > 0; }

    function selfMatches(t) {
      if (ui.filter === 'working' && t.state !== 'working') return false;
      if (ui.filter === 'waiting' && t.state !== 'waiting') return false;
      if (ui.filter === 'you' && !(t.state === 'waiting' && t.waitingFor === 'owner')) return false;   // the counter "Waiting for you": only what waits for her
      if (ui.filter === 'done' && t.state !== 'done') return false;
      if (ui.filter === 'paused' && t.state !== 'paused') return false;
      var ws = words();
      if (!ws.length) return true;
      var hay = (str(t.title) + ' ' + str(t.plain) + ' ' + str(t.note)).toLowerCase();
      return ws.every(function (w) { return hay.indexOf(w) >= 0; });
    }
    var visCache = null;
    function visible(t) {
      if (!visCache) visCache = {};
      if (t.id in visCache) return visCache[t.id];
      visCache[t.id] = false;   // guards against a loop
      var v = selfMatches(t) || (M.kids[t.id] || []).some(visible);
      visCache[t.id] = v;
      return v;
    }
    function isOpen(t) {
      if (filtering()) return true;
      if (t.id in ui.open) return !!ui.open[t.id];
      return !t._finished && t._active;
    }
    function ancestors(id) { var out = [], t = M.by[id], guard = 0; while (t && t.parentId && M.by[t.parentId] && guard++ < 30) { t = M.by[t.parentId]; out.push(t.id); } return out; }
    function mustSee(id) { ancestors(id).forEach(function (a) { ui.open[a] = true; }); saveOpen(); }
    function treeEl() { var b = view && view.node('body'); return b ? b.querySelector('.tk-tree') : null; }
    function liFor(id) { var t = treeEl(); if (!t) return null; var all = t.querySelectorAll('li.tk-node'); for (var i = 0; i < all.length; i++) if (all[i].getAttribute('data-id') === id) return all[i]; return null; }

    /* ------------------------------------------------ how to read this */
    var howKey = 'qt.tasks.howto';
    function renderHowto(box) {
      var mem = lsGet(howKey), closed = mem === 'closed' || (mem === null && narrow());   // first visit: open, except on a narrow screen where it would push the tasks off the first screen
      var ex = el('div', { class: 'tk-example', 'aria-hidden': 'true' },
        el('div', { class: 'tk-ex-row l1' }, el('i', { class: 'tk-ex-dot done' }), el('b', { text: 'Big idea' })),
        el('div', { class: 'tk-ex-row l2' }, el('i', { class: 'tk-ex-dot work' }), el('b', { text: 'Task' })),
        el('div', { class: 'tk-ex-row l3' }, el('i', { class: 'tk-ex-dot done' }), el('b', { text: 'Smaller task' })),
        el('div', { class: 'tk-ex-row l3' }, el('i', { class: 'tk-ex-dot todo' }), el('b', { text: 'Smaller task' })));
      var body = el('div', { class: 'tk-how-body', id: 'tk-how-body', hidden: closed },
        el('div', { class: 'tk-how-grid' },
          el('ol', { class: 'tk-how-list' },
            el('li', { text: 'A big idea sits at the top, like the barn.' }),
            el('li', { text: 'It breaks into tasks, like rows to plant.' }),
            el('li', { text: 'Tasks break into smaller tasks, like seeds.' }),
            el('li', { text: 'When the small ones are done, the big one is done. The little bar shows how many.' }),
            el('li', { text: 'Tap a task to open it. You can add a smaller task, change a task, or ask about it.' })),
          ex),
        el('ul', { class: 'tk-legend' },
          [['todo', 'To do'], ['working', 'Working'], ['waiting', 'Waiting for you, Miss Cathy or Rob'], ['done', 'Done'], ['paused', 'Paused']].map(function (x) {
            return el('li', null, el('span', { class: 'tk-dot st-' + x[0], 'aria-hidden': 'true' }), x[1]);
          })),
        el('p', { class: 'small muted', text: 'Nothing here changes your real website. Your changes go to Claude, and Claude passes them on.' }));
      var btn = el('button', { type: 'button', class: 'btn quiet small tk-howbtn', 'data-key': 'how', 'aria-expanded': closed ? 'false' : 'true', 'aria-controls': 'tk-how-body',
        on: { click: function () { lsSet(howKey, closed ? 'open' : 'closed'); view.repaint('howto'); } } }, closed ? 'Show' : 'Hide');
      box.appendChild(el('section', { class: 'card tk-how', 'aria-labelledby': 'tk-how-h' },
        el('div', { class: 'row between nowrap' }, el('h2', { id: 'tk-how-h', class: 'sx-h2', text: 'How to read this' }), btn), body));
    }

    /* ------------------------------------------------ summary strip, filters, search, tools */
    function counter(key, label, n, filter) {
      var prevN = ui.prev ? ui.prev[key] : n;
      var num = el('b', { class: 'tk-num' + (prevN !== n ? ' bump' : ''), text: String(n) });
      return el('button', { type: 'button', class: 'tk-count c-' + key, 'aria-pressed': ui.filter === filter ? 'true' : 'false', 'data-key': 'ct:' + key,
        'aria-label': label + ': ' + n + '. Tap to show only these.' + (ui.filter === filter ? ' (on)' : ''),
        on: { click: function () { ui.filter = ui.filter === filter ? 'all' : filter; view.repaint('strip'); view.repaint('tools'); view.repaint('body'); } } },
        num, el('span', { class: 'tk-clabel', text: label }));
    }
    function renderStrip(box) {
      var n = M.n;
      box.appendChild(el('div', { class: 'tk-strip', role: 'group', 'aria-label': 'Task counts. Tap a number to see only those tasks.' },
        counter('working', 'Working now', n.working, 'working'),
        counter('waitingYou', 'Waiting for you', n.waitingYou, 'you'),
        counter('done', 'Done', n.done, 'done')));
      ui.prev = { working: n.working, waitingYou: n.waitingYou, done: n.done };
    }
    function renderTools(box) {
      var n = M.n;
      var seg = el('div', { class: 'tk-seg', role: 'group', 'aria-label': 'Show' },
        [['all', 'All', n.all], ['working', 'Working', n.working], ['waiting', 'Waiting (anyone)', n.waiting], ['done', 'Done', n.done], ['paused', 'Paused', n.paused]].map(function (f) {
          return el('button', { type: 'button', class: 'btn small', 'aria-pressed': ui.filter === f[0] ? 'true' : 'false', 'data-key': 'f:' + f[0], title: f[0] === 'waiting' ? 'Waiting for you, Miss Cathy or Rob' : null,
            on: { click: function () { ui.filter = f[0]; view.repaint('strip'); view.repaint('tools'); view.repaint('body'); } } }, f[1] + ' ' + f[2]);
        }));
      var search = el('input', { type: 'search', id: 'tk-search', 'data-key': 'tk-search', placeholder: 'Search the tasks', autocomplete: 'off', 'aria-label': 'Search the tasks' });
      search.value = ui.q;
      search.addEventListener('input', function () { ui.q = search.value; view.repaint('body'); });
      var offline = !!QT.offline;
      box.appendChild(el('div', { class: 'tk-tools' },
        el('div', { class: 'tk-toolrow' }, search,
          el('button', { type: 'button', class: 'btn small', 'data-key': 'openall', on: { click: function () { setAll(true); } } }, 'Open all'),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'closeall', on: { click: function () { setAll(false); } } }, 'Close all'),
          offline ? null : el('button', { type: 'button', class: 'btn primary small tk-addbtn', 'data-key': 'add-top', on: { click: function () { openAdd('top', ui.sel && M.by[ui.sel] && !M.by[ui.sel]._removed ? ui.sel : null); } } }, '+ Add a task')),
        el('div', { class: 'tk-seg-row' },
          el('div', { class: 'tk-modes', role: 'group', 'aria-label': 'How to show the tasks' },
            [['list', 'List'], ['map', 'Map']].map(function (m) {
              return el('button', { type: 'button', class: 'btn small', 'aria-pressed': ui.mode === m[0] ? 'true' : 'false', 'data-key': 'mode:' + m[0], on: { click: function () { setMode(m[0]); } } }, m[1]);
            })),
          seg)));
    }
    function setMode(m) {
      if (ui.mode === m) return;
      ui.mode = m; lsSet('qt.tasks.mode', m);
      view.announce(m === 'map' ? 'Showing the map.' : 'Showing the list.');
      view.repaint('tools'); view.repaint('body');
      if (ui.sel) setTimeout(function () { if (!view.dead) reveal(ui.sel); }, 0);
    }
    function setAll(open) {
      M.list.forEach(function (t) { if ((M.kids[t.id] || []).length) ui.open[t.id] = open; });
      saveOpen();
      if (ui.mode === 'map') { view.repaint('body'); return; }
      var tree = treeEl(); if (!tree) return;
      [].slice.call(tree.querySelectorAll('li.tk-node[aria-expanded]')).forEach(function (li) { setLi(li, open, true); });
    }

    /* ------------------------------------------------ the tree */
    function setLi(li, open, quiet) {
      var wrap = null;
      for (var i = 0; i < li.children.length; i++) if (li.children[i].classList.contains('tk-wrap')) wrap = li.children[i];
      if (!wrap) return;
      li.setAttribute('aria-expanded', String(open));
      wrap.setAttribute('data-open', String(open));
      var c = li.querySelector('.tk-caret'); if (c) c.setAttribute('data-open', String(open));
      if (!quiet) { ui.open[li.getAttribute('data-id')] = open; saveOpen(); }
    }
    function toggleLi(li) { setLi(li, li.getAttribute('aria-expanded') !== 'true'); }

    function select(id) {
      ui.sel = ui.sel === id ? null : id;
      ui.edit = ui.ask = ui.remove = null; if (ui.add && ui.add.where === 'panel') ui.add = null;
      view.repaint('body');
      if (ui.sel && !wide) setTimeout(function () { var b = view.node('body'), d = b && b.querySelector('.tk-detail'); if (d && d.scrollIntoView) d.scrollIntoView({ block: 'nearest', behavior: reduced() ? 'auto' : 'smooth' }); }, 30);
    }

    function nodeLi(t, level, size, pos) {
      var kids = (M.kids[t.id] || []).filter(visible);
      var hasKids = kids.length > 0, open = hasKids && isOpen(t);
      var sel = ui.sel === t.id;
      var q = questionToAnswer(t);
      var key = stateKey(t);
      var li = el('li', { class: 'tk-node st-' + key + (t._finished ? ' finished' : '') + (t._removed ? ' removed' : '') + (t._active ? ' active' : '') + (sel ? ' selected' : ''), role: 'treeitem',
        'aria-level': String(level), 'aria-setsize': String(size), 'aria-posinset': String(pos), 'aria-selected': sel ? 'true' : 'false', 'aria-labelledby': 'tk-t-' + t.id,
        tabindex: (ui.focus || ui.sel || (M.roots[0] && M.roots[0].id)) === t.id ? '0' : '-1', 'data-id': t.id, 'data-key': 'n:' + t.id });
      if (hasKids) li.setAttribute('aria-expanded', String(open));

      /* the card */
      var caret = hasKids
        ? el('button', { type: 'button', class: 'tk-caret', tabindex: '-1', 'aria-hidden': 'true', 'data-open': String(open), on: { click: function (e) { e.stopPropagation(); toggleLi(li); li.focus({ preventScroll: true }); } } }, el('span', { class: 'tk-tri', 'aria-hidden': 'true' }))
        : el('span', { class: 'tk-leafmark', 'aria-hidden': 'true' });
      var meta = el('div', { class: 'tk-meta' },
        el('span', { class: 'tk-state st-' + key }, el('i', { class: 'tk-dot st-' + key, 'aria-hidden': 'true' }), el('span', { text: wordOf(t) }),
          key === 'working' && !t._removed ? el('span', { class: 'dots', 'aria-hidden': 'true' }, el('i'), el('i'), el('i')) : null),
        q ? el('button', { type: 'button', class: 'tk-flag', 'aria-label': 'Answer the question for: ' + str(t.title), on: { click: function (e) { e.stopPropagation(); K.go('question', { id: q }); } } }, 'Answer it →') : null,
        t._addPending ? chip('You added this · waiting for Claude to see it', 'pend', '◷') : (t._editPending ? chip('Your change · waiting for Claude to see it', 'pend', '◷') : null),
        workersEl(t, 3));
      var prog = null;
      if (t._leafTotal > 1 || (hasKids && t._leafTotal > 0)) {
        var pct = Math.round(100 * t._leafDone / t._leafTotal);
        var bar = el('i'); bar.style.width = pct + '%';
        prog = el('div', { class: 'tk-prog' },
          el('span', { class: 'tk-prog-text', text: t._leafDone + ' of ' + t._leafTotal + ' done' }),
          el('span', { class: 'tk-bar', role: 'progressbar', 'aria-label': 'Smaller tasks done in ' + str(t.title), 'aria-valuemin': '0', 'aria-valuemax': String(t._leafTotal), 'aria-valuenow': String(t._leafDone) }, bar));
      }
      var card = el('div', { class: 'tk-card' }, caret,
        el('div', { class: 'tk-main' },
          el('div', { id: 'tk-t-' + t.id, class: 'tk-title', dir: 'auto', text: str(t.title) }),
          t.plain ? el('div', { class: 'tk-plain', dir: 'auto', text: str(t.plain) }) : null,
          t.note && (t.state === 'working' || t.state === 'waiting') ? el('div', { class: 'tk-note', dir: 'auto', text: str(t.note) }) : null,
          meta),
        prog);
      card.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('button,a,input,textarea,select')) return; select(t.id); li.focus({ preventScroll: true }); });
      li.appendChild(card);
      if (sel && !wide) li.appendChild(detailEl(t));
      if (hasKids) {
        li.appendChild(el('div', { class: 'tk-wrap', 'data-open': String(open) },
          el('div', { class: 'tk-inner' }, el('ul', { class: 'tk-kids', role: 'group' }, kids.map(function (k, i) { return nodeLi(k, level + 1, kids.length, i + 1); })))));
      }
      return li;
    }
    function workersEl(t, max) {
      var W = col('workers'), ids = t.workerIds.filter(function (id) { return W[id]; });
      if (!ids.length) return null;
      var wrap = el('span', { class: 'tk-wks', title: ids.map(function (id) { return str(W[id].name); }).join(', ') });
      ids.slice(0, max).forEach(function (id) { wrap.appendChild(workerBadge(W[id])); });
      if (ids.length > max) wrap.appendChild(el('span', { class: 'tk-more', 'aria-hidden': 'true', text: '+' + (ids.length - max) }));
      wrap.appendChild(el('span', { class: 'sr', text: 'Workers: ' + ids.map(function (id) { return str(W[id].name); }).join(', ') }));
      return wrap;
    }

    function renderBody(box) {
      M = getModel(); visCache = null;
      if (ui.sel && !M.by[ui.sel]) ui.sel = null;
      var roots = M.roots.filter(visible);
      var col1 = el('div', { class: 'tk-treecol' });
      if (!M.list.length) {
        col1.appendChild(el('div', { class: 'sx-empty tk-empty' }, el('p', { class: 'strong', text: 'No tasks yet.' }), el('p', { class: 'muted', text: QT.offline ? 'They will show up here when Claude is connected.' : 'Add the first one with the + button.' })));
      } else if (!roots.length) {
        col1.appendChild(el('div', { class: 'sx-empty tk-empty' }, el('p', { text: 'Nothing matches that.' }),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'clearf', on: { click: function () { ui.filter = 'all'; ui.q = ''; view.repaint('strip'); view.repaint('tools'); view.repaint('body'); } } }, 'Show everything')));
      } else if (ui.mode === 'map') {
        col1.appendChild(el('p', { class: 'small muted tk-maphint', text: 'Scroll the map sideways and up and down. Tap a task to open it. The arrow keys move around.' }));
        col1.appendChild(mapEl(roots));
        if (!wide && ui.sel && M.by[ui.sel]) col1.appendChild(detailEl(M.by[ui.sel]));
      } else {
        var ul = el('ul', { class: 'tk-tree' + (M.list.length > LONG_LIST ? ' tk-long' : ''), role: 'tree', 'aria-label': 'Tasks' }, roots.map(function (t, i) { return nodeLi(t, 1, roots.length, i + 1); }));
        ul.addEventListener('keydown', onKey);
        col1.appendChild(ul);
        if (!ul.querySelector('li[tabindex="0"]')) ul.querySelector('li').setAttribute('tabindex', '0');
      }
      if (wide) {
        var aside = el('aside', { class: 'tk-aside', 'aria-label': 'Task details' }, ui.sel && M.by[ui.sel] ? detailEl(M.by[ui.sel])
          : el('div', { class: 'tk-hint card' }, el('p', { class: 'strong', text: 'Tap a task' }), el('p', { class: 'muted', text: 'Its details show up here: who works on it, questions, and buttons to add, change or ask.' })));
        box.appendChild(el('div', { class: 'tk-split' }, col1, aside));
      } else box.appendChild(col1);
      if (ui.mode === 'map') { var mb = box.querySelector('.tk-mapbox'); if (mb) { mb.scrollLeft = ui.mapScroll.x; mb.scrollTop = ui.mapScroll.y; } }   // a redraw keeps the map where she scrolled it
      if (ui.first) {
        ui.first = false;
        var f = P.focus && M.by[P.focus] ? P.focus : null;
        if (f) { ui.sel = f; mustSee(f); setTimeout(function () { view.repaint('body'); reveal(f); }, 0); }
      }
    }
    /** Bring a task into view: in the list the page scrolls to it; in the map the map box scrolls so it is in the middle. */
    function reveal(id) {
      if (ui.mode === 'map') { revealMap(id); return; }
      var li = liFor(id); if (li) li.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' });
    }

    /* ------------------------------------------------ the map: the same tasks drawn from left to right, each level a column */
    var MK = { w: 14, h: 4.25, gx: 3.5, gy: 0.75, pad: 0.75, head: 2.25, right: 3 };   // all in rem, so the map grows with the text size
    var LEVEL_NAMES = ['Big ideas', 'Tasks', 'Smaller tasks', 'Even smaller tasks'];
    function r3(n) { return Math.round(n * 1000) / 1000; }
    function rem(n) { return r3(n) + 'rem'; }
    function svgEl(tag, attrs) { var n = document.createElementNS('http://www.w3.org/2000/svg', tag); Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); }); return n; }
    function mapBox() { var b = view && view.node('body'); return b ? b.querySelector('.tk-mapbox') : null; }
    function mapLiFor(id) { var b = mapBox(); if (!b) return null; var all = b.querySelectorAll('li.tk-mn'); for (var i = 0; i < all.length; i++) if (all[i].getAttribute('data-id') === id) return all[i]; return null; }
    function revealMap(id) {
      var b = mapBox(), li = b && mapLiFor(id); if (!li) return;
      var br = b.getBoundingClientRect(), r = li.getBoundingClientRect();
      b.scrollLeft += (r.left - br.left) - (b.clientWidth - r.width) / 2;
      b.scrollTop += (r.top - br.top) - (b.clientHeight - r.height) / 2;
      ui.mapScroll = { x: b.scrollLeft, y: b.scrollTop };
      try { b.scrollIntoView({ block: 'nearest', behavior: reduced() ? 'auto' : 'smooth' }); } catch (e) { /* old browser */ }
    }
    function toggleMap(id, open) { ui.open[id] = open; saveOpen(); view.repaint('body'); }

    function mapEl(roots) {
      var row = 0, maxLevel = 1, maxRow = 0, pitch = MK.h + MK.gy, edges = [];
      /* a leaf takes the next row; a parent sits in the middle of the rows of its children */
      function place(t, level, guard) {
        var kids = (M.kids[t.id] || []).filter(visible);
        var open = kids.length > 0 && isOpen(t) && guard < 12;
        var r = { t: t, level: level, kids: [], nKids: kids.length, open: open, row: 0 };
        if (level > maxLevel) maxLevel = level;
        if (open) {
          kids.forEach(function (k) { var c = place(k, level + 1, guard + 1); r.kids.push(c); edges.push([r, c]); });
          r.row = (r.kids[0].row + r.kids[r.kids.length - 1].row) / 2;
        } else { r.row = row; row += 1; }
        if (r.row > maxRow) maxRow = r.row;
        return r;
      }
      var tops = roots.map(function (t) { var r = place(t, 1, 0); row += 0.3; return r; });
      var W = MK.pad * 2 + maxLevel * MK.w + (maxLevel - 1) * MK.gx + MK.right, H = MK.pad * 2 + maxRow * pitch + MK.h;
      function X(level) { return MK.pad + (level - 1) * (MK.w + MK.gx); }
      function Y(rw) { return MK.pad + rw * pitch; }

      /* the curved lines (a picture only: the tree below says the same in words) */
      var onPath = {}; ancestors(ui.sel || '').concat(ui.sel ? [ui.sel] : []).forEach(function (id) { onPath[id] = true; });
      var svg = svgEl('svg', { class: 'tk-mlinks', 'aria-hidden': 'true', focusable: 'false', viewBox: '0 0 ' + r3(W) + ' ' + r3(H), preserveAspectRatio: 'none' });
      svg.style.width = rem(W); svg.style.height = rem(H);
      var hl = [];
      edges.forEach(function (e) {
        var p = e[0], c = e[1], x1 = X(p.level) + MK.w, y1 = Y(p.row) + MK.h / 2, x2 = X(c.level), y2 = Y(c.row) + MK.h / 2, xm = (x1 + x2) / 2;
        var on = !!onPath[c.t.id] || p.t.id === ui.sel;
        var path = svgEl('path', { class: 'tk-mlink st-' + stateKey(c.t) + (on ? ' hl' : ''), d: 'M' + r3(x1) + ' ' + r3(y1) + ' C' + r3(xm) + ' ' + r3(y1) + ' ' + r3(xm) + ' ' + r3(y2) + ' ' + r3(x2) + ' ' + r3(y2) });
        if (on) hl.push(path); else svg.appendChild(path);
      });
      hl.forEach(function (p) { svg.appendChild(p); });

      /* the nodes: a tree (ul / li) so that screen readers get levels and "open / closed"; every li sits at its own place on the map */
      var focusId = ui.focus || ui.sel || (tops[0] && tops[0].t.id);
      function node(r, parent, size, pos) {
        var t = r.t, key = stateKey(t), sel = ui.sel === t.id, pend = !!(t._addPending || t._editPending);
        var li = el('li', { class: 'tk-mn st-' + key + (t._finished ? ' finished' : '') + (t._removed ? ' removed' : '') + (t._active ? ' active' : '') + (sel ? ' selected' : '') + (pend ? ' pending' : ''),
          role: 'treeitem', 'aria-level': String(r.level), 'aria-setsize': String(size), 'aria-posinset': String(pos), 'aria-selected': sel ? 'true' : 'false',
          'aria-labelledby': 'tk-t-' + t.id, 'aria-describedby': 'tk-m-' + t.id, tabindex: focusId === t.id ? '0' : '-1', 'data-id': t.id, 'data-row': String(r3(r.row)), 'data-key': 'm:' + t.id });
        li.style.left = rem(parent ? MK.w + MK.gx : X(1)); li.style.top = rem(parent ? (r.row - parent.row) * pitch : Y(r.row));
        li.style.width = rem(MK.w); li.style.height = rem(MK.h);
        if (r.nKids) li.setAttribute('aria-expanded', String(r.open));
        var showProg = t._leafTotal > 1 || (r.nKids > 0 && t._leafTotal > 0);
        var meta = el('div', { class: 'tk-mmeta', id: 'tk-m-' + t.id },
          el('span', { class: 'tk-state st-' + key }, el('i', { class: 'tk-dot st-' + key, 'aria-hidden': 'true' }), el('span', { class: 'tk-mword', text: wordOf(t) })),
          pend ? el('span', { class: 'tk-mpend' }, el('span', { 'aria-hidden': 'true', text: '\u25f7 Not seen yet' }), el('span', { class: 'sr', text: t._addPending ? 'You added this. Waiting for Claude to see it.' : 'Your change. Waiting for Claude to see it.' })) : null,
          showProg ? el('span', { class: 'tk-mprog' }, el('span', { 'aria-hidden': 'true', text: t._leafDone + ' of ' + t._leafTotal }), el('span', { class: 'sr', text: t._leafDone + ' of ' + t._leafTotal + ' smaller tasks done' })) : null);
        var card = el('div', { class: 'tk-mcard', title: str(t.title) },
          el('div', { id: 'tk-t-' + t.id, class: 'tk-mtitle', dir: 'auto', text: str(t.title) }), meta);
        if (showProg) { var bar = el('i'); bar.style.width = Math.round(100 * t._leafDone / t._leafTotal) + '%'; card.appendChild(el('span', { class: 'tk-mbar', 'aria-hidden': 'true' }, bar)); }
        card.addEventListener('click', function () { select(t.id); li.focus({ preventScroll: true }); });
        li.appendChild(card);
        if (r.nKids && !filtering()) {
          li.appendChild(el('button', { type: 'button', class: 'tk-mtog', tabindex: '-1', 'aria-hidden': 'true', 'data-open': String(r.open), on: { click: function (e) { e.stopPropagation(); li.focus({ preventScroll: true }); toggleMap(t.id, !r.open); } } },
            el('span', { class: 'tk-mtog-dot', text: r.open ? '\u2212' : (r.nKids < 10 ? '+' + r.nKids : '+') })));
        }
        if (r.open && r.kids.length) li.appendChild(el('ul', { class: 'tk-mkids', role: 'group' }, r.kids.map(function (k, i) { return node(k, r, r.kids.length, i + 1); })));
        return li;
      }
      var tree = el('ul', { class: 'tk-mtree', role: 'tree', 'aria-label': 'Tasks' }, tops.map(function (r, i) { return node(r, null, tops.length, i + 1); }));
      tree.addEventListener('keydown', onMapKey);
      if (!tree.querySelector('li[tabindex="0"]')) tree.querySelector('li').setAttribute('tabindex', '0');

      var heads = el('div', { class: 'tk-mheads', 'aria-hidden': 'true' });
      heads.style.width = rem(W);
      for (var l = 1; l <= maxLevel; l++) {
        var hd = el('span', { class: 'tk-mhead', text: LEVEL_NAMES[l - 1] || 'Smaller still' });
        hd.style.left = rem(X(l)); hd.style.width = rem(MK.w); heads.appendChild(hd);
      }
      var canvas = el('div', { class: 'tk-mcanvas' }, svg, tree);
      canvas.style.width = rem(W); canvas.style.height = rem(H);
      var boxEl = el('div', { class: 'tk-mapbox', role: 'region', 'aria-label': 'Map of the tasks' }, el('div', { class: 'tk-mapin' }, heads, canvas));
      boxEl.addEventListener('scroll', function () { ui.mapScroll = { x: boxEl.scrollLeft, y: boxEl.scrollTop }; }, { passive: true });
      return boxEl;
    }
    /* keys on the map: up / down = the next task in the same column, right = into the smaller tasks (opens them first), left = back to the bigger task (or closes) */
    function mapMove(tree, li) {
      [].slice.call(tree.querySelectorAll('li.tk-mn[tabindex="0"]')).forEach(function (x) { x.setAttribute('tabindex', '-1'); });
      li.setAttribute('tabindex', '0'); li.focus(); ui.focus = li.getAttribute('data-id');
    }
    function onMapKey(e) {
      var li = e.target.closest ? e.target.closest('li.tk-mn') : null;
      if (!li || e.target !== li) return;
      var tree = e.currentTarget, id = li.getAttribute('data-id'), k = e.key, lvl = li.getAttribute('aria-level');
      var colm = [].slice.call(tree.querySelectorAll('li.tk-mn')).filter(function (x) { return x.getAttribute('aria-level') === lvl; })
        .sort(function (a, b) { return Number(a.getAttribute('data-row')) - Number(b.getAttribute('data-row')); });
      var i = colm.indexOf(li), hasKids = li.hasAttribute('aria-expanded'), open = li.getAttribute('aria-expanded') === 'true', handled = true;
      if (k === 'ArrowDown') { if (i < colm.length - 1) mapMove(tree, colm[i + 1]); }
      else if (k === 'ArrowUp') { if (i > 0) mapMove(tree, colm[i - 1]); }
      else if (k === 'Home') mapMove(tree, colm[0]);
      else if (k === 'End') mapMove(tree, colm[colm.length - 1]);
      else if (k === 'ArrowRight') { if (hasKids && !open) { ui.focus = id; toggleMap(id, true); } else if (hasKids) { var c = li.querySelector(':scope > ul > li.tk-mn'); if (c) mapMove(tree, c); } }
      else if (k === 'ArrowLeft') {
        if (hasKids && open && !filtering()) { ui.focus = id; toggleMap(id, false); }
        else { var par = li.parentElement && li.parentElement.closest ? li.parentElement.closest('li.tk-mn') : null; if (par) mapMove(tree, par); }
      }
      else if (k === 'Enter' || k === ' ') select(id);
      else handled = false;
      if (handled) e.preventDefault();
    }

    /* keyboard: the tree pattern */
    function visibleLis(tree) {
      return [].slice.call(tree.querySelectorAll('li.tk-node')).filter(function (li) { var p = li.parentElement; while (p && p !== tree) { if (p.classList && p.classList.contains('tk-wrap') && p.getAttribute('data-open') === 'false') return false; p = p.parentElement; } return true; });
    }
    function moveTo(tree, li) {
      [].slice.call(tree.querySelectorAll('li.tk-node[tabindex="0"]')).forEach(function (x) { x.setAttribute('tabindex', '-1'); });
      li.setAttribute('tabindex', '0'); li.focus(); ui.focus = li.getAttribute('data-id');
    }
    function onKey(e) {
      var li = e.target.closest ? e.target.closest('li.tk-node') : null;
      if (!li || e.target !== li) return;
      var tree = e.currentTarget, items = visibleLis(tree), i = items.indexOf(li), k = e.key, hasKids = li.hasAttribute('aria-expanded'), open = li.getAttribute('aria-expanded') === 'true';
      var handled = true;
      if (k === 'ArrowDown') { if (i < items.length - 1) moveTo(tree, items[i + 1]); }
      else if (k === 'ArrowUp') { if (i > 0) moveTo(tree, items[i - 1]); }
      else if (k === 'Home') moveTo(tree, items[0]);
      else if (k === 'End') moveTo(tree, items[items.length - 1]);
      else if (k === 'ArrowRight') { if (hasKids && !open) { setLi(li, true); } else if (hasKids && open) { var f = items[i + 1]; if (f) moveTo(tree, f); } }
      else if (k === 'ArrowLeft') { if (hasKids && open) setLi(li, false); else { var par = li.parentElement && li.parentElement.closest ? li.parentElement.closest('li.tk-node') : null; if (par) moveTo(tree, par); } }
      else if (k === 'Enter' || k === ' ') select(li.getAttribute('data-id'));
      else if (k === '*') { var sibs = li.parentElement ? [].slice.call(li.parentElement.children) : []; sibs.forEach(function (s) { if (s.hasAttribute && s.hasAttribute('aria-expanded')) setLi(s, true); }); }
      else handled = false;
      if (handled) e.preventDefault();
    }

    /* ------------------------------------------------ the detail panel */
    function dateLine(t) {
      var bits = [];
      if (t.createdAt && ago(t.createdAt)) bits.push('Added ' + ago(t.createdAt) + (t.createdBy === 'owner' ? ' by you' : ''));
      if (t.state === 'done' && t.doneAt && ago(t.doneAt)) bits.push('Done ' + ago(t.doneAt));
      else if (t.updatedAt && ago(t.updatedAt) && !t._addPending) bits.push('Updated ' + ago(t.updatedAt));
      return bits.join(' · ');
    }
    function asksFor(id) {
      var A = col('asks');
      return vals(A).filter(function (a) { return a.targetKind === 'task' && a.targetId === id; }).sort(function (a, b) { return str(b.createdAt) < str(a.createdAt) ? -1 : (str(b.createdAt) > str(a.createdAt) ? 1 : 0); });
    }
    function bubble(kind, who, text) { return el('div', { class: 'tk-bubble ' + kind }, who ? el('div', { class: 'tk-bwho', text: who }) : null, el('div', { class: 'tk-btext', dir: 'auto', text: str(text) })); }
    function askBlock(a) {
      var r = col('replies')[a.id];
      var wrap = el('div', { class: 'tk-ask' }, bubble('mine', 'You asked', a.text));
      if (!r) wrap.appendChild(chip('Sent · waiting for Claude to see it', 'pend', '◷'));
      else if (r.state === 'answered' && str(r.text)) wrap.appendChild(bubble('answer', 'Answer from ' + (str(r.from) || 'Claude'), r.text));
      else wrap.appendChild(chip(r.state === 'working' ? 'Claude is working on your answer' : 'Claude saw it ✓', r.state === 'working' ? 'work' : 'seen'));
      return wrap;
    }
    function detailEl(t) {
      var offline = !!QT.offline, own = t.createdBy === 'owner';
      var W = col('workers'), Q = col('questions'), A = col('answers');
      var kids = M.kids[t.id] || [];
      var d = el('section', { class: 'card tk-detail st-' + stateKey(t), 'aria-label': 'Details: ' + str(t.title), 'data-key': 'detail:' + t.id });
      d.appendChild(el('div', { class: 'row between nowrap' },
        el('h3', { class: 'tk-dtitle', dir: 'auto', text: str(t.title) }),
        el('button', { type: 'button', class: 'btn quiet small', 'data-key': 'dclose', 'aria-label': 'Close the details', on: { click: function () { select(t.id); } } }, 'Close')));
      d.appendChild(el('div', { class: 'tk-dchips' },
        el('span', { class: 'tk-state st-' + stateKey(t) }, el('i', { class: 'tk-dot st-' + stateKey(t), 'aria-hidden': 'true' }), el('span', { text: wordOf(t) })),
        t._addPending ? chip('You added this · waiting for Claude to see it', 'pend', '◷') : (t._editPending ? chip('Your change · waiting for Claude to see it', 'pend', '◷')
          : ((own || t._edit) && t.seenAt ? chip('Claude saw it ✓', 'seen') : null))));
      d.appendChild(el('p', { class: 'tk-dplain', dir: 'auto', text: str(t.plain) || 'No more words about this one yet.' }));
      if (t.note) d.appendChild(el('p', { class: 'tk-dnote', dir: 'auto' }, el('b', { text: 'Right now: ' }), str(t.note)));
      if (t._leafTotal > 1) d.appendChild(el('p', { class: 'small muted', text: t._leafDone + ' of ' + t._leafTotal + ' smaller tasks done.' }));
      var wk = t.workerIds.filter(function (id) { return W[id]; });
      if (wk.length) d.appendChild(el('div', { class: 'tk-drow' }, el('span', { class: 'tk-dlabel', text: 'Who works on it' }),
        el('span', { class: 'tk-wlist' }, wk.map(function (id) {
          return el('button', { type: 'button', class: 'tk-wbtn', 'aria-label': 'Open worker: ' + str(W[id].name), on: { click: function () { goPart('workers', { focus: id }); } } }, workerBadge(W[id]), el('span', { text: str(W[id].name), dir: 'auto' }));
        }))));
      var qs = t.questionIds.filter(function (id) { return Q[id]; });
      if (qs.length) d.appendChild(el('div', { class: 'tk-drow' }, el('span', { class: 'tk-dlabel', text: 'Questions about it' }),
        el('span', { class: 'tk-qlist' }, qs.map(function (id) {
          return el('button', { type: 'button', class: 'tk-qbtn', on: { click: function () { K.go('question', { id: id }); } } }, el('span', { text: str(Q[id].title), dir: 'auto' }), el('span', { class: 'small muted', text: A[id] ? 'You answered ✓' : 'Waiting for you' }));
        }))));
      if (dateLine(t)) d.appendChild(el('p', { class: 'tiny muted', text: dateLine(t) }));

      /* buttons */
      if (offline) d.appendChild(el('p', { class: 'muted small', text: 'Not connected yet.' }));
      else if (!t._removed) {
        d.appendChild(el('div', { class: 'tk-actions' },
          el('button', { type: 'button', class: 'btn small', 'data-key': 'a-add', on: { click: function () { openAdd('panel', t.id); } } }, 'Add a smaller task'),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'a-edit', on: { click: function () { closeTopForm(); ui.edit = t.id; ui.ask = ui.remove = null; setDraft('tkE:' + t.id + ':title', str(t.title)); setDraft('tkE:' + t.id + ':plain', str(t.plain)); view.repaint('body'); } } }, 'Change this task'),
          t.state === 'paused' && !t._resume
            ? el('button', { type: 'button', class: 'btn small', 'data-key': 'a-resume', on: { click: function () { writeEdit(t, { paused: false }, 'You asked to keep going. Claude will see it soon.'); } } }, 'Keep going')
            : (t._resume ? null : el('button', { type: 'button', class: 'btn small', 'data-key': 'a-pause', on: { click: function () { writeEdit(t, { paused: true }, 'Paused. Claude will see it soon.'); } } }, 'Pause')),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'a-ask', on: { click: function () { closeTopForm(); ui.ask = t.id; ui.edit = ui.remove = null; view.repaint('body'); } } }, 'Ask about this task'),
          own && !kids.length ? el('button', { type: 'button', class: 'btn small danger', 'data-key': 'a-remove', on: { click: function () { closeTopForm(); ui.remove = t.id; ui.edit = ui.ask = null; view.repaint('body'); } } }, 'Remove') : null));
      } else {
        d.appendChild(el('div', { class: 'tk-actions' }, el('button', { type: 'button', class: 'btn small', 'data-key': 'a-undo', on: { click: function () { writeEdit(t, { removed: false }, 'Kept. Claude will see it soon.'); } } }, 'Keep it after all')));
      }
      d.appendChild(noteEl('d:' + t.id));
      if (!offline) {
        if (ui.add && ui.add.where === 'panel' && ui.add.parentId === t.id) d.appendChild(addForm('panel'));
        if (ui.edit === t.id) d.appendChild(editForm(t));
        if (ui.ask === t.id) d.appendChild(askForm(t));
        if (ui.remove === t.id) d.appendChild(el('div', { class: 'banner warn tk-confirm', role: 'group', 'aria-label': 'Remove this task?' },
          el('span', { class: 'banner-text', text: 'Take this task off the list? Claude will remove it.' }),
          el('button', { type: 'button', class: 'btn primary small', 'data-key': 'rm-yes', on: { click: function () { ui.remove = null; writeEdit(t, { removed: true }, 'Asked to remove it. Claude will see it soon.'); } } }, 'Remove it'),
          el('button', { type: 'button', class: 'btn small', 'data-key': 'rm-no', on: { click: function () { ui.remove = null; view.repaint('body'); } } }, 'Keep it')));
      }
      var asks = asksFor(t.id);
      if (asks.length) d.appendChild(el('div', { class: 'tk-asks' }, el('h4', { class: 'sx-h3', text: 'Your questions (' + asks.length + ')' }), asks.map(askBlock)));
      return d;
    }

    function writeEdit(t, patch, okText) {
      if (!QT.write || !QT.write.taskEdit) { say('body', 'd:' + t.id, FAIL_SHORT, 'bad'); return; }
      call(QT.write.taskEdit, [t.id, patch]).then(function () { say('body', 'd:' + t.id, okText, 'ok'); }, function () { say('body', 'd:' + t.id, FAIL_SHORT, 'bad'); });
    }

    /* ------------------------------------------------ forms */
    function limited(ta, max) { ta.setAttribute('maxlength', String(max)); var h = el('p', { class: 'hint sx-limit', hidden: true, text: 'That is long – Claude can read up to ' + max + ' letters.' }); var u = function () { h.hidden = ta.value.length < max * 0.9; }; ta.addEventListener('input', u); u(); return h; }
    /* only one form is open at a time (what she typed is kept as a draft) */
    function closeTopForm() { if (ui.add && ui.add.where === 'top') { ui.add = null; view.repaint('form'); } }
    function openAdd(where, parentId) {
      ui.add = { where: where, parentId: parentId || null };
      ui.edit = ui.ask = ui.remove = null;
      view.repaint('form'); view.repaint('body');
      setTimeout(function () { var n = where === 'top' ? view.node('form') : view.node('body'); if (n) { var f = n.querySelector('.tk-form input'); if (f) { f.focus(); } } }, 0);
    }
    function parentOptions(select, current) {
      select.appendChild(el('option', { value: '', text: 'A new big idea' }));
      function walk(list, depth) { list.forEach(function (t) { if (t._removed) return; select.appendChild(el('option', { value: t.id, text: new Array(depth + 1).join('– ') + str(t.title) })); walk(M.kids[t.id] || [], depth + 1); }); }
      walk(M.roots, 0);
      select.value = current && M.by[current] ? current : '';
    }
    function addForm(where) {
      var pk = 'tkA:' + where;
      var title = el('input', { type: 'text', id: 'tk-new-title-' + where, maxlength: String(T_MAX), 'data-key': pk + ':t', autocomplete: 'off', dir: 'auto', 'aria-describedby': 'tk-new-hint-' + where });
      title.value = getDraft(pk + ':title').slice(0, T_MAX);
      title.addEventListener('input', function () { setDraft(pk + ':title', title.value); });
      var plain = el('textarea', { id: 'tk-new-plain-' + where, rows: '2', dir: 'auto', 'data-key': pk + ':p' });
      plain.value = getDraft(pk + ':plain').slice(0, PLAIN_MAX);
      plain.addEventListener('input', function () { setDraft(pk + ':plain', plain.value); });
      var sel = el('select', { id: 'tk-new-parent-' + where, 'data-key': pk + ':s' });
      parentOptions(sel, ui.add && ui.add.parentId);
      sel.addEventListener('change', function () { if (ui.add) ui.add.parentId = sel.value || null; });
      var go = function () {
        var tt = title.value.replace(/\s+/g, ' ').trim();
        if (!tt) { say(where === 'top' ? 'form' : 'body', 'add:' + where, 'Please give the task a name.', 'bad'); title.focus(); return; }
        if (ui.busy.add) return;
        if (!QT.write || !QT.write.taskAdd) { say(where === 'top' ? 'form' : 'body', 'add:' + where, FAIL_TEXT, 'bad'); return; }
        ui.busy.add = true;
        var parentId = sel.value || null;
        call(QT.write.taskAdd, [{ parentId: parentId, title: tt, plain: plain.value.trim() }]).then(function (id) {
          ui.busy.add = false;
          setDraft(pk + ':title', ''); setDraft(pk + ':plain', '');
          ui.add = null;
          if (parentId) { ui.open[parentId] = true; saveOpen(); }
          if (id) { ui.sel = id; ui.focus = id; }
          ui.filter = 'all'; ui.q = '';
          view.repaint('strip'); view.repaint('tools'); view.repaint('form'); view.repaint('body');
          say('body', 'top', 'Added ✓ Claude will see it soon.', 'ok');
          if (id) setTimeout(function () { if (!view.dead) reveal(id); }, 60);
        }, function () { ui.busy.add = false; say(where === 'top' ? 'form' : 'body', 'add:' + where, FAIL_TEXT, 'bad'); });
      };
      var f = el('form', { class: 'tk-form', novalidate: true, 'aria-label': 'Add a task' },
        el('div', { class: 'field' }, el('label', { for: 'tk-new-title-' + where, text: 'Name of the task' }), title, el('div', { class: 'hint', id: 'tk-new-hint-' + where, text: 'A few words, like “Pick the holiday photos”.' })),
        el('div', { class: 'field' }, el('label', { for: 'tk-new-plain-' + where, text: 'What does it mean? (optional)' }), plain, limited(plain, PLAIN_MAX)),
        el('div', { class: 'field' }, el('label', { for: 'tk-new-parent-' + where, text: 'Where does it go?' }), sel),
        el('div', { class: 'row' },
          el('button', { type: 'submit', class: 'btn primary', 'data-key': pk + ':go' }, 'Add task'),
          el('button', { type: 'button', class: 'btn quiet', 'data-key': pk + ':x', on: { click: function () { ui.add = null; view.repaint('form'); view.repaint('body'); } } }, 'Cancel')),
        noteEl('add:' + where));
      f.addEventListener('submit', function (e) { e.preventDefault(); go(); });
      return f;
    }
    function renderForm(box) {
      if (QT.offline || !ui.add || ui.add.where !== 'top') return;
      box.appendChild(el('div', { class: 'card tk-formcard' }, el('h2', { class: 'sx-h2', text: 'Add a task' }), addForm('top')));
    }
    function editForm(t) {
      var k = 'tkE:' + t.id;
      var title = el('input', { type: 'text', maxlength: String(T_MAX), 'data-key': k + ':t', 'aria-label': 'Name of the task', dir: 'auto' });
      title.value = getDraft(k + ':title').slice(0, T_MAX);
      title.addEventListener('input', function () { setDraft(k + ':title', title.value); });
      var plain = el('textarea', { rows: '2', 'data-key': k + ':p', 'aria-label': 'What does it mean?', dir: 'auto' });
      plain.value = getDraft(k + ':plain').slice(0, PLAIN_MAX);
      plain.addEventListener('input', function () { setDraft(k + ':plain', plain.value); });
      var f = el('form', { class: 'tk-form', novalidate: true, 'aria-label': 'Change this task' },
        el('div', { class: 'field' }, el('label', { text: 'Name of the task' }), title),
        el('div', { class: 'field' }, el('label', { text: 'What does it mean?' }), plain, limited(plain, PLAIN_MAX)),
        el('div', { class: 'row' }, el('button', { type: 'submit', class: 'btn primary', 'data-key': k + ':go' }, 'Save change'),
          el('button', { type: 'button', class: 'btn quiet', on: { click: function () { ui.edit = null; view.repaint('body'); } } }, 'Cancel')),
        noteEl('e:' + t.id));
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var tt = title.value.replace(/\s+/g, ' ').trim();
        if (!tt) { say('body', 'e:' + t.id, 'The task needs a name.', 'bad'); return; }
        var patch = {};
        if (tt !== str(t.title)) patch.title = tt;
        if (plain.value.trim() !== str(t.plain).trim()) patch.plain = plain.value.trim();
        if (!Object.keys(patch).length) { ui.edit = null; view.repaint('body'); return; }
        if (!QT.write || !QT.write.taskEdit) { say('body', 'e:' + t.id, FAIL_TEXT, 'bad'); return; }
        call(QT.write.taskEdit, [t.id, patch]).then(function () { ui.edit = null; say('body', 'd:' + t.id, 'Saved ✓ Claude will see your change soon.', 'ok'); },
          function () { say('body', 'e:' + t.id, FAIL_TEXT, 'bad'); });
      });
      return f;
    }
    function askForm(t) {
      var k = 'tkQ:' + t.id;
      var ta = el('textarea', { rows: '3', 'data-key': k, id: 'tk-ask-' + t.id, dir: 'auto', 'aria-label': 'Your question about this task', placeholder: t.state === 'done' ? 'This task is finished. Claude will answer from the notes.' : 'What would you like to know?' });
      ta.value = getDraft(k).slice(0, ASK_MAX);
      ta.addEventListener('input', function () { setDraft(k, ta.value); });
      var f = el('form', { class: 'tk-form', novalidate: true, 'aria-label': 'Ask about this task' },
        el('div', { class: 'field' }, el('label', { for: 'tk-ask-' + t.id, text: 'Ask about this task' }), ta, limited(ta, ASK_MAX), el('div', { class: 'hint', text: 'Your question goes to Claude first. Claude passes it on and writes the answer back here.' })),
        el('div', { class: 'row' }, el('button', { type: 'submit', class: 'btn primary', 'data-key': k + ':go' }, 'Send'),
          el('button', { type: 'button', class: 'btn quiet', on: { click: function () { ui.ask = null; view.repaint('body'); } } }, 'Cancel')),
        noteEl('q:' + t.id));
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var text = ta.value.trim();
        if (!text) { say('body', 'q:' + t.id, 'Please type your question first.', 'bad'); ta.focus(); return; }
        if (!QT.write || !QT.write.ask) { say('body', 'q:' + t.id, FAIL_TEXT, 'bad'); return; }
        call(QT.write.ask, [{ targetKind: 'task', targetId: t.id, text: text }]).then(function () { setDraft(k, ''); ui.ask = null; say('body', 'd:' + t.id, 'Sent ✓ Claude will answer here.', 'ok'); },
          function () { say('body', 'q:' + t.id, FAIL_TEXT, 'bad'); });
      });
      return f;
    }

    /* ------------------------------------------------ build */
    view = K.Regions(root, function () { mDirty = true; return false; });
    view.set([
      { name: 'head', deps: [], render: function (b) { b.appendChild(el('div', { class: 'tk-head' }, el('h1', { class: 'sx-h1', text: 'Tasks' }), el('p', { class: 'muted tk-lead', text: 'Everything Claude and the crew are working on, and what is already finished.' }))); } },
      { name: 'howto', deps: [], render: renderHowto },
      { name: 'strip', deps: ['tasks', 'taskAdds', 'taskEdits'], render: function (b) { M = getModel(); renderStrip(b); } },
      { name: 'tools', deps: ['tasks', 'taskAdds', 'taskEdits'], render: function (b) { M = getModel(); renderTools(b); } },
      { name: 'form', deps: [], render: renderForm },
      { name: 'body', deps: ['tasks', 'taskAdds', 'taskEdits', 'asks', 'replies', 'workers', 'questions', 'answers'], render: renderBody }
    ]);
    function onMq() { wide = mq.matches; view.repaint('body'); }
    if (mq && mq.addEventListener) { mq.addEventListener('change', onMq); cleanups.push(function () { mq.removeEventListener('change', onMq); }); }
    function onOnline() { view.repaint(); }
    QT.on('online', onOnline); QT.on('offline', onOnline); cleanups.push(function () { QT.off('online', onOnline); QT.off('offline', onOnline); });
    return function () { view.destroy(); cleanups.forEach(function (f) { f(); }); Object.keys(ui.noteTimers).forEach(function (k) { clearTimeout(ui.noteTimers[k]); }); };
  };
})();
