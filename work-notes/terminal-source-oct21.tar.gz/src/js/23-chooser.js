/* 23-chooser.js  (owner: visual)
   The PICTURE CHOOSER: a question of kind "chooser" where SHE picks the photo(s) herself, sees a live preview, and only then commits.
     QT.chooser.render(el, q) -> cleanup        draws preview + slot tabs + gallery + commit bar into el (called by 20-question.js for kind "chooser")
     QT.chooser.parse(q), QT.chooser.clampOverlay(o)     the pure parts (tested)
   q.chooser = { slots:[{id,label,hint}] (1-4), gallery:[{id,url,alt,w,h,label,people}] (<= 60), allowNone,
                 preview:{ base:{url,alt,w,h}, overlays:[{slot,x,y,w,h,rotate,frame:"none"|"white"|"yellow"}] (percent of the base) } },  q.peopleNote
   Nothing is saved until she presses "Use these photos": then answers/<qid> = {status:"answered", key:"picks", label:"My picture choice",
   picks:{slotId:galleryId}, pickLabels:{slotId:label}, ...} through QT.write.answer. A draft is remembered in localStorage (try/catch).
   Safety: QT.el/textContent only; picture addresses must be https://, data:image/ or /_blob/<id> (QT.visual.safeUrl), else a calm box. */
(function () {
  'use strict';
  var QT = window.QT = window.QT || {};
  var el = function () { return QT.el.apply(QT, arguments); };
  var MAX_SLOTS = 4, MAX_GALLERY = 60;
  var LABEL = 'My picture choice';
  var PEOPLE_NOTE = 'Miss Cathy and Rob have not said yes to photos with people yet.';
  function dict() { return Object.create(null); }     // lookup tables keyed by ids from the question: an id like "constructor" must not find something that was never put in
  var FRAMES = ['none', 'white', 'yellow'];
  function esc(v) {                                      // an id inside a [data-x="..."] selector
    v = String(v);
    try { if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(v); } catch (e) { /* fall through */ }
    return v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/(["\\])/g, '\\$1');
  }

  /* ---------- small helpers ---------- */
  function str(v) { return v == null ? '' : String(v); }
  function isObj(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
  function num(v, def) { return typeof v === 'number' && isFinite(v) ? v : def; }
  function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
  function safeUrl(u) {
    if (QT.visual && typeof QT.visual.safeUrl === 'function') return QT.visual.safeUrl(u);
    u = str(u).trim();
    return /^https:\/\//i.test(u) || /^data:image\//i.test(u) || /^\/_blob\/[0-9a-f]{32}$/i.test(u) ? u : '';
  }
  function ls(op, key, val) {
    try {
      if (op === 'get') return window.localStorage.getItem(key);
      if (op === 'set') window.localStorage.setItem(key, val);
      if (op === 'del') window.localStorage.removeItem(key);
    } catch (e) { /* no storage: the page still works */ }
    return null;
  }
  function reduced() { try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
  function dim(n) { n = Number(n); return n > 0 && n <= 20000 ? Math.round(n) : 0; }

  var ICON = {
    check: [['path', { d: 'M5 12.5l4.5 4.5L19 7.5' }]],
    zoom: [['circle', { cx: 10.5, cy: 10.5, r: 6.5 }], ['path', { d: 'M21 21l-5.2-5.2' }]],
    people: [['circle', { cx: 9, cy: 8, r: 3 }], ['path', { d: 'M3.5 19c.4-3.2 2.6-5 5.5-5s5.1 1.8 5.5 5' }], ['circle', { cx: 17, cy: 9, r: 2.3 }], ['path', { d: 'M16 14.2c2.6-.2 4.2 1.3 4.6 4' }]],
    image: [['rect', { x: 3, y: 4, width: 18, height: 16, rx: 2 }], ['path', { d: 'M3 16l5-5 4 4 3-3 6 6' }], ['circle', { cx: 15.5, cy: 9, r: 1.5 }]],
    plus: [['path', { d: 'M12 6v12M6 12h12' }]],
    undo: [['path', { d: 'M9 7L4 12l5 5' }], ['path', { d: 'M4 12h10a6 6 0 0 1 0 12', transform: 'translate(0 -4)' }]]
  };
  function svg(name, size) {
    var s = size || 16;
    return el('svg', { viewBox: '0 0 24 24', width: s, height: s, fill: 'none', stroke: 'currentColor', 'stroke-width': 2.4, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false', class: 'chs-ic' },
      (ICON[name] || []).map(function (p) { return el(p[0], p[1]); }));
  }

  /* ---------- the question's chooser data, cleaned (pure) ---------- */
  function clampOverlay(o, fallback) {
    o = isObj(o) ? o : {};
    var f = fallback || { x: 5, y: 5, w: 40, h: 40, rotate: 0, frame: 'none' };
    var w = clamp(num(o.w, f.w), 4, 100), h = clamp(num(o.h, f.h), 4, 100);
    return {
      w: w, h: h,
      x: clamp(num(o.x, f.x), 0, 100 - w), y: clamp(num(o.y, f.y), 0, 100 - h),
      rotate: clamp(num(o.rotate, f.rotate || 0), -45, 45),
      frame: FRAMES.indexOf(o.frame) >= 0 ? o.frame : (FRAMES.indexOf(f.frame) >= 0 ? f.frame : 'none')
    };
  }
  function parse(q) {
    var c = isObj(q && q.chooser) ? q.chooser : {};
    var slots = [], seen = dict();
    (Array.isArray(c.slots) ? c.slots : []).forEach(function (s, i) {
      if (!isObj(s) || slots.length >= MAX_SLOTS) return;
      var id = /^(?!__)[a-z0-9_-]{1,40}$/.test(str(s.id)) ? str(s.id) : 's' + (i + 1);
      if (seen[id]) return;
      seen[id] = 1;
      slots.push({ id: id, label: str(s.label).trim() || 'Place ' + (slots.length + 1), hint: str(s.hint).trim() });
    });
    if (!slots.length) slots.push({ id: 'photo', label: 'Photo', hint: '' });
    var gallery = [], gseen = dict();
    (Array.isArray(c.gallery) ? c.gallery : []).forEach(function (g) {
      if (!isObj(g) || gallery.length >= MAX_GALLERY) return;
      var id = str(g.id).trim(), url = safeUrl(g.url);
      if (!id || gseen[id] || !url) return;
      gseen[id] = 1;
      gallery.push({ id: id, url: url, alt: str(g.alt).trim(), w: dim(g.w), h: dim(g.h), label: str(g.label).trim() || str(g.alt).trim() || 'Photo ' + (gallery.length + 1), people: g.people === true });
    });
    var pv = isObj(c.preview) ? c.preview : {};
    var base = null;
    if (isObj(pv.base) && safeUrl(pv.base.url)) base = { url: safeUrl(pv.base.url), alt: str(pv.base.alt).trim(), w: dim(pv.base.w), h: dim(pv.base.h) };
    var ratio = base && base.w && base.h ? base.w / base.h : 16 / 9;
    var given = dict();
    (Array.isArray(pv.overlays) ? pv.overlays : []).forEach(function (o) { if (isObj(o) && seen[str(o.slot)]) given[str(o.slot)] = o; });
    var n = slots.length, overlays = dict();
    slots.forEach(function (s, i) {
      // no overlay in the question: the places sit side by side along the lower part of the picture
      var w = n === 1 ? 38 : Math.floor(90 / n), h = clamp(w * ratio * 0.75, 4, 60);
      var def = { x: n === 1 ? 5 : 5 + i * (100 / n), y: 100 - h - 5, w: w, h: h, rotate: 0, frame: 'white' };
      overlays[s.id] = clampOverlay(given[s.id], def);
    });
    return { slots: slots, gallery: gallery, base: base, ratio: ratio, overlays: overlays, allowNone: c.allowNone === true, peopleNote: str(q && q.peopleNote).trim() || PEOPLE_NOTE };
  }

  /* ---------- the view ---------- */
  function render(host, q) {
    if (!host || !host.appendChild || !q) return function () {};
    var C = parse(q), qid = str(q.id);
    var byId = dict(); C.gallery.forEach(function (g) { byId[g.id] = g; });
    var slotById = dict(); C.slots.forEach(function (s) { slotById[s.id] = s; });
    var DRAFT = 'qt.chooser.d.' + qid;

    function answersDoc() { var d = QT.store && QT.store.answers && QT.store.answers[qid]; return isObj(d) ? d : null; }
    function savedPicks() {
      var d = answersDoc(), out = dict();
      if (d && d.status === 'answered' && d.key === 'picks' && isObj(d.picks)) Object.keys(d.picks).forEach(function (k) { if (slotById[k] && typeof d.picks[k] === 'string' && byId[d.picks[k]]) out[k] = d.picks[k]; });
      return out;
    }
    function same(a, b) { var ka = Object.keys(a).sort(), kb = Object.keys(b).sort(); return ka.length === kb.length && ka.every(function (k, i) { return k === kb[i] && a[k] === b[k]; }); }

    var S = { picks: dict(), base: dict(), cur: C.slots[0].id, msg: null, msgTimer: 0, dead: false, undoing: false };
    (function loadDraft() {
      var d = null;
      try { d = JSON.parse(ls('get', DRAFT) || 'null'); } catch (e) { d = null; }
      if (isObj(d) && isObj(d.picks)) { Object.keys(d.picks).forEach(function (k) { if (slotById[k] && typeof d.picks[k] === 'string' && byId[d.picks[k]]) S.picks[k] = d.picks[k]; }); }
      else S.picks = savedPicks();
      S.base = savedPicks();          // the saved choice that the picks on screen started from
      var first = C.slots.filter(function (s) { return !S.picks[s.id]; })[0];
      if (first) S.cur = first.id;
    })();
    function saveDraft() {
      if (same(S.picks, savedPicks())) ls('del', DRAFT);
      else ls('set', DRAFT, JSON.stringify({ picks: S.picks }));
    }
    function usedBy(gid) { var r = ''; C.slots.forEach(function (s) { if (S.picks[s.id] === gid) r = s.id; }); return r; }
    function filled() { return C.slots.filter(function (s) { return S.picks[s.id]; }).length; }
    function ready() { return C.allowNone || filled() === C.slots.length; }
    function dirty() { return !same(S.picks, savedPicks()); }
    function hasSaved() { var d = answersDoc(); return !!d && d.status === 'answered' && d.key === 'picks'; }
    function nextEmpty(after) {
      var order = C.slots.map(function (s) { return s.id; }), i = order.indexOf(after);
      for (var k = 1; k <= order.length; k++) { var id = order[(i + k) % order.length]; if (!S.picks[id]) return id; }
      return null;
    }
    var many = C.slots.length > 1;

    /* ----- pieces ----- */
    var root = el('section', { class: 'chs', 'aria-label': 'Choose your pictures', 'data-qid': qid, style: '--chs-ratio:' + C.ratio });
    var live = el('div', { class: 'sr', role: 'status', 'aria-live': 'polite' });
    var stage = el('div', { class: 'chs-stage' });
    if (C.base) {
      var baseImg = el('img', { class: 'chs-base', alt: C.base.alt || 'The picture your choice goes on', draggable: 'false' });
      baseImg.referrerPolicy = 'no-referrer';
      baseImg.src = C.base.url;       // set here, not through QT.el: the address was checked by safeUrl() already
      stage.appendChild(baseImg);
    }
    else stage.classList.add('is-plain');
    var slotEls = dict();
    C.slots.forEach(function (s) {
      var o = C.overlays[s.id];
      var b = el('button', { type: 'button', class: 'chs-slot f-' + o.frame, 'data-slot': s.id, 'data-fid': 'slot-' + s.id,
        style: 'left:' + o.x + '%;top:' + o.y + '%;width:' + o.w + '%;height:' + o.h + '%;transform:rotate(' + o.rotate + 'deg)',
        on: { click: function () { S.cur = s.id; paint(); } } });
      slotEls[s.id] = b;
      stage.appendChild(b);
    });
    var tabs = null;
    if (many) {
      tabs = el('div', { class: 'chs-tabs', role: 'tablist', 'aria-label': 'Which place are you choosing for?' });
      C.slots.forEach(function (s) {
        tabs.appendChild(el('button', { type: 'button', class: 'chs-tab', role: 'tab', 'data-tab': s.id, 'data-fid': 'tab-' + s.id,
          on: { click: function () { S.cur = s.id; paint(); }, keydown: tabKey } }, el('span', { class: 'chs-tab-t', text: s.label }), el('span', { class: 'chs-tab-m', 'aria-hidden': 'true' })));
      });
    }
    var status = el('p', { class: 'chs-status' });
    var prev = el('div', { class: 'chs-prev' }, tabs, el('div', { class: 'chs-frame-wrap' }, stage), status);

    /* gallery */
    var peopleAny = C.gallery.some(function (g) { return g.people; });
    var grid = el('ul', { class: 'chs-grid', role: 'list', 'aria-label': 'Your photos' });
    var thumbs = [];
    C.gallery.forEach(function (g, i) {
      var img = el('img', { class: 'chs-img', alt: '', draggable: 'false', loading: i < 12 ? 'eager' : 'lazy', decoding: 'async' });
      var holder = el('span', { class: 'chs-pic' }, img, el('span', { class: 'chs-badge', 'aria-hidden': 'true' }));
      img.addEventListener('error', function () { holder.classList.add('is-bad'); if (img.parentNode) img.parentNode.removeChild(img); holder.appendChild(el('span', { class: 'chs-ph' }, el('span', { text: g.label }), el('span', { class: 'chs-ph-m', text: 'Picture did not load' }))); });
      img.referrerPolicy = 'no-referrer';     // a photo from another website does not learn which page it is shown on
      img.src = g.url;
      var btn = el('button', { type: 'button', class: 'chs-thumb', 'data-gid': g.id, 'data-fid': 'g-' + g.id, tabindex: i === 0 ? '0' : '-1', 'aria-pressed': 'false' }, holder, g.people ? el('span', { class: 'chs-people' }, svg('people', 13), el('span', { text: 'Shows people' })) : null, el('span', { class: 'chs-cap', text: g.label }));
      var big = el('button', { type: 'button', class: 'chs-big', 'aria-label': 'See ' + g.label + ' big', 'data-fid': 'big-' + g.id, tabindex: '-1' }, svg('zoom', 16));
      var li = el('li', { class: 'chs-li', 'data-gid': g.id }, btn, big);
      var pressTimer = 0, pressed = false;
      btn.addEventListener('click', function (e) { if (pressed) { pressed = false; e.preventDefault(); return; } toggle(g.id); });
      btn.addEventListener('pointerdown', function (e) { if (e.pointerType === 'mouse') return; pressed = false; clearTimeout(pressTimer); pressTimer = setTimeout(function () { pressed = true; openBig(i, big); }, 550); });
      ['pointerup', 'pointercancel', 'pointerleave', 'pointermove'].forEach(function (t) { btn.addEventListener(t, function () { clearTimeout(pressTimer); }); });
      btn.addEventListener('contextmenu', function (e) { if (pressed) e.preventDefault(); });
      big.addEventListener('click', function () { openBig(i, big); });
      btn.addEventListener('keydown', gridKey);
      big.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); btn.focus(); } });
      grid.appendChild(li);
      thumbs.push({ g: g, btn: btn, big: big, li: li, holder: holder });
    });
    var galHead = el('div', { class: 'chs-galhead' }, el('h2', { class: 'chs-h', text: 'Your photos' }), el('span', { class: 'chs-count tiny muted', text: C.gallery.length ? plural(C.gallery.length) : '' }));
    var galHint = el('p', { class: 'chs-galhint tiny muted', text: C.gallery.length ? 'Tap a photo to try it in the picture. Tap it again to take it out. Nothing is saved until you press “Use these photos”.' : '' });
    var peopleLine = peopleAny ? el('p', { class: 'chs-peopleline tiny' }, svg('people', 14), el('span', { text: 'Photos marked “Shows people”: ' + C.peopleNote })) : null;
    var empty = !C.gallery.length ? el('p', { class: 'chs-empty muted', text: 'There are no photos to choose from yet. Claude will add some.' }) : null;
    var gal = el('div', { class: 'chs-gal' }, galHead, galHint, peopleLine, grid, empty);

    /* commit bar */
    var commitBtn = el('button', { type: 'button', class: 'btn primary chs-commit', 'data-fid': 'commit', on: { click: commit } });
    var startBtn = el('button', { type: 'button', class: 'btn chs-start', 'data-fid': 'start', on: { click: startOver } }, 'Start over');
    var undoBtn = el('button', { type: 'button', class: 'btn small chs-undo', 'data-fid': 'undo', hidden: true, on: { click: undo } }, 'Undo');
    var nextBtn = el('button', { type: 'button', class: 'btn primary chs-next', 'data-fid': 'chs-next', hidden: true, on: { click: goNext } }, 'Next question →');
    var savedTag = el('span', { class: 'chip good chs-savedtag', hidden: true }, svg('check', 14), el('span', { text: 'Saved ✓' }));     // takes the place of the big button while the choice on the screen is the saved one
    var msgEl = el('p', { class: 'savestat chs-msg', role: 'status', 'aria-live': 'polite' });
    var bar = el('div', { class: 'chs-bar' }, el('div', { class: 'chs-msgrow' }, msgEl, undoBtn), el('div', { class: 'chs-btns' }, startBtn, nextBtn, savedTag, commitBtn));

    root.appendChild(el('div', { class: 'chs-main' }, prev, gal));
    root.appendChild(bar);
    root.appendChild(live);
    host.appendChild(root);

    /* ----- painting (in place: no redraw, so focus and scroll stay) ----- */
    function plural(n) { return n + (n === 1 ? ' photo' : ' photos'); }
    function peopleChosen() { return C.slots.some(function (s) { var g = byId[S.picks[s.id]]; return g && g.people; }); }
    function paint() {
      C.slots.forEach(function (s) {
        var b = slotEls[s.id], g = byId[S.picks[s.id]], cur = s.id === S.cur;
        b.classList.toggle('is-current', cur && many);
        b.classList.toggle('is-filled', !!g);
        b.setAttribute('data-gid', g ? g.id : '');
        var shown = g ? g.id : '';
        if (b.__shown !== shown) {
          b.textContent = '';
          b.__shown = shown;
          b.classList.remove('is-bad');
          if (g) {
            var im = el('img', { class: 'chs-pimg', alt: '', draggable: 'false' });
            im.addEventListener('error', function () { b.classList.add('is-bad'); });
            im.referrerPolicy = 'no-referrer';
            im.src = g.url;
            b.appendChild(im);
          } else b.appendChild(el('span', { class: 'chs-pick' }, svg('plus', 16), el('span', { text: 'Pick a photo' }), many ? el('span', { class: 'chs-pick-s', text: s.label }) : null));
        }
        b.setAttribute('aria-label', s.label + ': ' + (g ? g.label + ' chosen. Press to choose another photo for this place.' : 'empty. Press to choose a photo for this place.'));
        if (many) b.setAttribute('aria-pressed', cur ? 'true' : 'false');
      });
      if (tabs) Array.prototype.forEach.call(tabs.children, function (t) {
        var id = t.getAttribute('data-tab'), on = id === S.cur, g = byId[S.picks[id]];
        t.setAttribute('aria-selected', on ? 'true' : 'false'); t.tabIndex = on ? 0 : -1;
        t.classList.toggle('is-on', on); t.classList.toggle('is-filled', !!g);
        t.lastChild.textContent = g ? '✓' : '';
        t.setAttribute('aria-label', slotById[id].label + (g ? ', chosen: ' + g.label : ', empty'));
      });
      thumbs.forEach(function (t) {
        var sid = usedBy(t.g.id), s = sid ? slotById[sid] : null;
        t.btn.classList.toggle('is-picked', !!s);
        t.btn.classList.toggle('in-current', sid === S.cur);
        t.btn.setAttribute('aria-pressed', s ? 'true' : 'false');
        t.btn.setAttribute('aria-label', t.g.label + (t.g.people ? ', shows people' : '') + (s ? ', in ' + s.label + '. Press to take it out.' : '. Press to put it in ' + (many ? slotById[S.cur].label : 'the picture') + '.'));
        var badge = t.holder.querySelector('.chs-badge');
        badge.textContent = s ? (many ? '✓ ' + s.label : '✓') : '';
      });
      // the line under the preview
      var cur = slotById[S.cur], n = filled(), left = C.slots.length - n, bits = [];
      if (n === C.slots.length) { if (many) bits.push('Every place has a photo.'); }
      else bits.push((many ? 'Choosing for: ' + cur.label + '. ' : '') + (cur.hint ? cur.hint + '. ' : '') + 'Tap a photo below.');
      status.textContent = bits.join(' ').trim();
      if (peopleChosen()) { status.appendChild(el('span', { class: 'chs-people-note' }, svg('people', 14), el('span', { text: 'Shows people. ' + C.peopleNote }))); }
      // the commit bar
      var d = dirty(), saved = hasSaved(), off = !!QT.offline;
      commitBtn.textContent = !n && C.allowNone ? 'Use no photo' : 'Use these photos';
      commitBtn.disabled = !ready() || off || (!d && saved) || !!(S.msg && S.msg.kind === 'saving');
      commitBtn.setAttribute('aria-disabled', commitBtn.disabled ? 'true' : 'false');
      startBtn.disabled = !n;
      var m = S.msg, text = '', kind = '', clean = saved && !d && !(m && m.kind === 'saving');
      commitBtn.hidden = clean;
      savedTag.hidden = !(clean && !(m && m.kind === 'saved'));
      if (off) { text = 'No connection right now, so this cannot be saved. You can still look and choose.'; kind = 'bad'; }
      else if (m) { text = m.text; kind = m.kind === 'error' ? 'bad' : m.kind === 'saving' ? '' : 'ok'; }
      else if (!ready()) { text = left === C.slots.length && many ? 'Pick a photo for each of the ' + left + ' places first.' : 'Pick a photo for ' + (left === 1 ? 'the last place' : left + ' more places') + ' first.'; }
      else if (d && saved) { text = 'You changed something. Press the big button to keep it.'; }
      else if (!d && saved) { text = 'This is your saved choice. Pick another photo to change it.'; kind = 'ok'; }
      else { text = 'Nothing is saved until you press the big button.'; }
      msgEl.textContent = text; msgEl.className = 'savestat chs-msg' + (kind ? ' ' + kind : '');
      undoBtn.hidden = !(m && m.kind === 'saved' && !off);
      undoBtn.disabled = off;
      var showNext = saved && !d && !(m && m.kind === 'saving');
      nextBtn.hidden = !showNext;
      if (showNext) { var nid = nextId(); nextBtn.textContent = nid ? 'Next question →' : 'Back to the list'; }
      if (root.isConnected) measure();
    }

    /* ----- actions ----- */
    function say(t) { live.textContent = ''; setTimeout(function () { live.textContent = t; }, 30); }
    function toggle(gid) {                        // a tap on a photo in the grid
      var g = byId[gid], used = usedBy(gid);
      if (used === S.cur) { delete S.picks[S.cur]; say(g.label + ' taken out of ' + slotById[S.cur].label + '.'); }
      else {
        if (used) delete S.picks[used];     // a photo sits in one place only: tapping it moves it
        S.picks[S.cur] = gid;
        say(g.label + ' put in ' + slotById[S.cur].label + '.');
        var nx = nextEmpty(S.cur);
        if (nx && many) S.cur = nx;
      }
      S.msg = null;
      saveDraft(); paint();
    }
    function viewerRun(gid) {                     // the button in the big viewer: puts the photo in the current place, or takes it out of the place it is in
      var g = byId[gid], used = usedBy(gid);
      if (used) { delete S.picks[used]; S.cur = used; say(g.label + ' taken out of ' + slotById[used].label + '.'); }
      else { S.picks[S.cur] = gid; say(g.label + ' put in ' + slotById[S.cur].label + '.'); var nx = nextEmpty(S.cur); if (nx && many) S.cur = nx; }
      S.msg = null;
      saveDraft(); paint();
    }
    function startOver() { S.picks = dict(); S.cur = C.slots[0].id; S.msg = null; saveDraft(); paint(); say('Started over. Nothing is chosen.'); focusFid('g-' + (C.gallery[0] ? C.gallery[0].id : '')); }
    function focusFid(f) { var t = root.querySelector('[data-fid="' + esc(f) + '"]'); if (t && !t.disabled) { try { t.focus(); } catch (e) { /* ignore */ } } }
    function labelsOf(picks) { var o = {}; Object.keys(picks).forEach(function (k) { o[k] = byId[picks[k]].label || byId[picks[k]].alt; }); return o; }
    function noteValue() {
      var grid0 = host.closest ? host.closest('.qv-grid') : null, ta = (grid0 || document).querySelector('textarea.qa-note-ta');
      var v = ta ? ta.value.trim() : '';
      return v || (answersDoc() && answersDoc().note ? str(answersDoc().note) : '');
    }
    function setMsg(m) { S.msg = m; clearTimeout(S.msgTimer); if (m && m.until) S.msgTimer = setTimeout(function () { if (S.msg === m) { S.msg = null; paint(); } }, Math.max(30, m.until - Date.now() + 30)); }
    function commit() {
      if (!ready() || QT.offline || (S.msg && S.msg.kind === 'saving')) return;
      if (!QT.write || typeof QT.write.answer !== 'function') { setMsg({ kind: 'error', text: 'Saving is not ready yet. Please try again in a minute.' }); paint(); return; }
      var prevDoc = answersDoc() ? JSON.parse(JSON.stringify(answersDoc())) : null;
      var picks = {}; Object.keys(S.picks).forEach(function (k) { picks[k] = S.picks[k]; });
      var doc = { id: qid, status: 'answered', key: 'picks', label: LABEL, picks: picks, pickLabels: labelsOf(picks), ownText: '', changeText: '', note: noteValue(), round: q.round || 1, answeredAt: new Date().toISOString() };
      setMsg({ kind: 'saving', text: 'Saving…' }); paint();
      var p; try { p = QT.write.answer(qid, doc); } catch (e) { p = Promise.reject(e); }
      Promise.resolve(p).then(function (res) {
        if (res && res.ok === false) throw new Error('not saved');
        if (S.dead) return;
        S.base = picks; ls('del', DRAFT);
        setMsg({ kind: 'saved', text: 'Saved ✓', prev: prevDoc, until: Date.now() + 8000 });
        paint();
      }).catch(function () {
        if (S.dead) return;
        setMsg({ kind: 'error', text: 'Not saved. Your choice is still here. Please try again.' });
        paint();
      });
    }
    function undo() {
      var m = S.msg;
      if (!m || m.kind !== 'saved' || QT.offline) return;
      var prevDoc = m.prev;
      if (prevDoc) prevDoc.note = noteValue() || prevDoc.note || '';      // a note she added after saving stays
      setMsg({ kind: 'saving', text: 'Undoing…' }); S.undoing = true; paint();
      var p; try { p = prevDoc ? QT.write.answer(qid, prevDoc) : QT.write.clearAnswer(qid); } catch (e) { p = Promise.reject(e); }
      Promise.resolve(p).then(function () {
        S.undoing = false;
        if (S.dead) return;
        S.base = savedPicks();         // what is saved again; the picks on screen stay (as a try-out that is not saved)
        setMsg({ kind: 'undone', text: prevDoc ? 'Back to your earlier saved choice. Your new picks are still here.' : 'Not saved any more. Your picks are still here.', until: Date.now() + 5000 });
        saveDraft(); paint();
        focusFid('commit');
      }, function () { S.undoing = false; if (!S.dead) { setMsg({ kind: 'error', text: 'Could not undo. Please try again.' }); paint(); } });
    }
    function nextId() { var id = null; try { id = QT.sections && QT.sections.nextUnanswered ? QT.sections.nextUnanswered(qid) : null; } catch (e) { id = null; } return id && id !== qid ? id : null; }
    function goNext() {
      var id = nextId();
      if (id) QT.route.go('question', { id: id }); else if (q.sectionId) QT.route.go('section', { id: q.sectionId }); else QT.route.go('home', {});
    }

    /* ----- the big viewer (22-lightbox): every photo, with a "Use this photo" button ----- */
    function openBig(i, opener) {
      if (!QT.lightbox || typeof QT.lightbox.open !== 'function') return;
      var items = C.gallery.map(function (g) { return { url: g.url, alt: g.alt, caption: g.people ? 'Shows people. ' + C.peopleNote : '', label: g.label, w: g.w, h: g.h }; });
      QT.lightbox.open(items, i, {
        opener: opener,
        focusFor: function (k) { return thumbs[k] ? thumbs[k].btn : null; },
        action: {
          label: function (k) { var u = usedBy(C.gallery[k].id); return u ? '✓ Chosen' + (many ? ' for ' + slotById[u].label : '') + ' · take it out' : 'Use this photo' + (many ? ' for ' + slotById[S.cur].label : ''); },
          pressed: function (k) { return !!usedBy(C.gallery[k].id); },
          run: function (k) { viewerRun(C.gallery[k].id); }
        }
      });
    }

    /* ----- keyboard ----- */
    function tabKey(e) {
      var ids = C.slots.map(function (s) { return s.id; }), i = ids.indexOf(S.cur), k = e.key;
      if (k !== 'ArrowLeft' && k !== 'ArrowRight' && k !== 'Home' && k !== 'End') return;
      e.preventDefault();
      i = k === 'Home' ? 0 : k === 'End' ? ids.length - 1 : (i + (k === 'ArrowRight' ? 1 : -1) + ids.length) % ids.length;
      S.cur = ids[i]; paint(); focusFid('tab-' + S.cur);
    }
    function cols() { var t0 = thumbs[0] && thumbs[0].li, n = 0; if (!t0) return 1; thumbs.forEach(function (t) { if (Math.abs(t.li.offsetTop - t0.offsetTop) < 4) n++; }); return Math.max(1, n); }
    function gridKey(e) {
      var k = e.key, idx = -1;
      thumbs.forEach(function (t, i) { if (t.btn === e.currentTarget) idx = i; });
      if (idx < 0) return;
      var to = -1;
      if (k === 'ArrowRight') to = idx + 1; else if (k === 'ArrowLeft') to = idx - 1;
      else if (k === 'ArrowDown') to = idx + cols(); else if (k === 'ArrowUp') to = idx - cols();
      else if (k === 'Home') to = 0; else if (k === 'End') to = thumbs.length - 1;
      else if (k === '+' || k === 'e' || k === 'E') { e.preventDefault(); openBig(idx, thumbs[idx].big); return; }
      else return;
      e.preventDefault();
      to = clamp(to, 0, thumbs.length - 1);
      thumbs.forEach(function (t, i) { t.btn.tabIndex = i === to ? 0 : -1; t.big.tabIndex = i === to ? 0 : -1; });
      thumbs[to].btn.focus();
    }
    grid.addEventListener('focusin', function (e) {
      var li = e.target.closest && e.target.closest('.chs-li');
      thumbs.forEach(function (t) { var on = t.li === li; t.btn.tabIndex = on ? 0 : -1; t.big.tabIndex = on ? 0 : -1; });
    });

    /* ----- stay under the sticky bars while she scrolls the gallery: measure them once and on resize ----- */
    function measure() {
      var top = 0;
      Array.prototype.forEach.call(document.querySelectorAll('.topbar, .pt-strip, .qbar'), function (n) {
        var cs = getComputedStyle(n);
        if ((cs.position === 'sticky' || cs.position === 'fixed') && n.getClientRects().length) { var r = n.getBoundingClientRect(); if (r.top < 220) top = Math.max(top, r.bottom); }
      });
      root.style.setProperty('--chs-top', Math.round(top + 8) + 'px');
      // keep the preview and the big button in view only when that leaves room for the photos (a small or short window: they scroll with the page)
      var twoCols = false;
      try { twoCols = getComputedStyle(root.firstChild).display === 'grid'; } catch (e) { twoCols = false; }
      var used = top + 8 + prev.offsetHeight + bar.offsetHeight + 16, vh = window.innerHeight || 700;
      root.classList.toggle('is-loose', twoCols ? used > vh : vh - used < 190);
    }
    function onResize() { measure(); }
    window.addEventListener('resize', onResize);
    var mt = setTimeout(measure, 60), mt2 = setTimeout(measure, 600), ro = null;
    try { if (window.ResizeObserver) { ro = new ResizeObserver(function () { measure(); }); Array.prototype.forEach.call(document.querySelectorAll('.topbar, .pt-strip, .qbar'), function (n) { ro.observe(n); }); } } catch (e) { ro = null; }

    /* ----- live: another place saved or removed her answer (Undo, another window) ----- */
    function onStore(ev) {
      if (S.dead) return;
      if (ev && ev.collection && ev.collection !== 'answers') return;
      if (ev && ev.ids && ev.ids.length && ev.ids.indexOf(qid) < 0) return;
      var sp = savedPicks();
      if (!same(sp, S.base)) {
        // the saved choice changed (Claude, another window, Undo): follow it only if she has not changed the picks on screen herself
        var mine = S.undoing || (S.msg && S.msg.kind === 'saving');       // our own save or Undo is on its way
        if (!mine && S.msg && S.msg.kind === 'saved') S.msg = null;      // somebody else changed the answer since: our "Saved ✓ · Undo" is out of date
        if (same(S.picks, S.base) && !mine) { S.picks = dict(); Object.keys(sp).forEach(function (k) { S.picks[k] = sp[k]; }); saveDraft(); }
        S.base = sp;
      }
      paint();
    }
    function onConn() { if (!S.dead) paint(); }
    var offs = [];
    [['store', onStore], ['offline', onConn], ['online', onConn]].forEach(function (pair) { if (typeof QT.on === 'function') { var u = QT.on(pair[0], pair[1]); offs.push(typeof u === 'function' ? u : function () { if (QT.off) QT.off(pair[0], pair[1]); }); } });

    paint();
    return function cleanup() {
      S.dead = true;
      clearTimeout(S.msgTimer); clearTimeout(mt); clearTimeout(mt2);
      window.removeEventListener('resize', onResize);
      if (ro) { try { ro.disconnect(); } catch (e) { /* ignore */ } }
      offs.forEach(function (f) { try { f(); } catch (e) { /* ignore */ } });
      if (QT.lightbox && QT.lightbox.isOpen && QT.lightbox.isOpen()) QT.lightbox.close();
      if (root.parentNode) root.parentNode.removeChild(root);
    };
  }

  QT.chooser = { render: render, parse: parse, clampOverlay: clampOverlay };
})();
