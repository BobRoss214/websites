# Question Terminal — blueprint (read this fully before you write anything)

Owner: a farm-website owner who is NOT tech-savvy. She keeps this page open beside a chat with Claude. Claude (the lead) adds questions; she answers; Claude reads answers and keeps working. Everything she sees must be plain, short, friendly words. No jargon (no "database", "JSON", "sync", "API", "token", "deploy", "commit").

Work folder: `/tmp/claude-0/-home-user-websites/0370289f-5c48-5314-b3f5-bb8be7afd39d/scratchpad/terminal/` (call it `T/`). Never edit `/home/user/websites`.

## 1. What it is
One single-page web page (vanilla JS + CSS, no framework, no external scripts) that is published as an Artifact. Build output: ONE file `T/dist/index.html` made by `python3 T/build.py` from `T/src/shell.html`, `T/src/css/*.css` (alphabetical), `T/src/js/*.js` (alphabetical, so file names start with 2 digits). It talks to `window.claude.use("db")` (live notebook), `window.claude.use("comments")` (to nudge Claude), `window.claude.use("user")`. Pictures are never bundled: every picture is a URL stored in a question document (`https://…`, uploaded by Claude as an asset). The page must also render fully, with a friendly message, when `use("db")` returns null.

## 2. What she sees
Target sizes: (a) beside the chat ≈ **700 px wide × 800 px high** (MOST important), (b) laptop 1366×768, (c) big monitor 1920×1080. Phone is NOT a goal now, but nothing may break at 400 px (nav collapses to a drop-down; no sideways scroll).

**Fit rule (the owner complained the old page was "too big, I had to scroll and forgot the question"):**
- Compact type: base 16 px, line-height 1.45, buttons ≥ 40 px tall, small paddings.
- A **sticky question bar** (always visible while scrolling) shows the question title (1–2 lines) + its status chip. She never loses the question.
- A visual question with 4 pictures must fit in 700×800 with NO page scroll: pictures are a 2×2 grid of thumbnails (each ≤ 300×170) – click/tap opens a big viewer; answers are a compact row/grid under them. Scrolling is fine only when there is a lot of text.
- Wide screens (≥ 1100 px): two columns – pictures left, question text + answer buttons right.

**Frame:** top bar (44 px): "Question Terminal", a green "Live" dot, "Claude last looked: 2 min ago" (from `meta/heartbeat`), sound toggle 🔔, "Test connection" button. Left menu (200 px; becomes a drop-down under 820 px): built-in sections with a number of waiting questions each, her own sections, "+ New section", and "Done". Main area on the right.

**Built-in sections** (ids fixed): `look` "Look and feel" (pictures I made, 4 versions to pick), `other` "Other questions", `later` "Ideas for later" (parked brainstorming), `kathy` "Questions for Miss Kathy and Rob" (READ-ONLY: she can read them, cannot answer; shows who should answer + why it matters + what we need). "Done" is a view (all questions whose status is `done`, newest first, with what Claude did).

**Her own sections ("topics")**: "+ New section" asks for a name (e.g. "Account features") and a size (Small / Big, default Big, with one-line explanations: *Small = I start as soon as you answer a question. Big = I wait until you answered all the important questions AND you said OK to my plan.*). Inside a section she sees:
1. An **Ideas box**: big text area "Tell Claude what you want here" + button **Send to Claude**. Sent ideas are listed under it with a state: "Sent", "Claude read it", "Questions are ready ↓".
2. The section's questions (made by Claude from her ideas), as a list; click one to answer it.
3. A **progress card** for Big sections: "Before I start: 3 of 7 important questions answered".
4. A **Plan card** when Claude posts a plan (`plans/<sectionId>`): plain steps, then buttons **Looks good, start** / **Change this** (+ text box). Her choice is saved to `planReplies/<sectionId>`.
5. A **Pause** switch (`hold`): "Pause: do not start anything here." Section size can be switched Small/Big at any time.
Flow she wants: ideas → Claude writes questions → she answers → Claude posts a plan (+ maybe more questions) → repeat until she is happy; Claude starts work after an answer for Small sections, and for Big sections only after all `required` questions are answered AND the plan is approved. Never start a Big section from one answered question.

**Status chips (she must SEE that Claude noticed and is working)** on every question (in lists and in the sticky bar):
- no answer yet → "Waiting for you" (neutral)
- answered, Claude has not looked yet → "You answered · waiting for Claude to see it" (gray, with a small clock)
- `status/<qid>.state == "seen"` → "Claude saw it ✓" (+ time)
- `"working"` → "Working on it…" (animated dots, respects reduced-motion) + `note` line (e.g. "Making version B bigger")
- `"done"` → "Done ✓" + `doneNote` (+ optional `doneImages` as a "See the result" thumbnail row)
- `"followup"` → "Claude has a follow-up question" + link to the child question (`status.followupId`)
- `"held"` → "Paused (you asked me to wait)"
Compute "answered but not seen": `answers/<qid>.answeredAt > status/<qid>.seenAt` (or no status doc).
The top bar shows "Claude last looked: X min ago" from `meta/heartbeat.at`; if older than 20 min show it in amber with "(Claude may be busy)".

**Sound & attention:** `QT.sound.chime()` = a short happy two/three-note rising chime made with Web Audio (no audio files). Sound toggle starts OFF with a tooltip "Turn on a happy sound when something new arrives" (browsers need one click first); remembered in localStorage (wrapped in try/catch). Chime plays when: a NEW question appears (not on first load), or a status becomes `done`, or a plan is posted. Browser tab title shows "(N) Question Terminal" where N = unanswered questions she can answer (not the Kathy ones). New items get a gentle "NEW" badge until opened.

**Test connection:** button calls `comments.canSendToClaude()`; if "available", `comments.sendToClaude(...)` with the text "Question Terminal test ping" (first time creates a thread via `comments.anchorFor(el)` and saves `threadId` in `meta/ping`; later pings reply into that thread: `{threadId, text}`). Shows plain result: "Claude was notified ✓" or "Could not notify Claude — I will still see your answers when I check (every few minutes)". The same ping (short text, e.g. `Answered: <title> → <label>`) is sent automatically after each answer ONLY if the test succeeded this session, throttled to at most one per 20 s (batch: "Answered 3 questions"). Never put long private text in the ping.

## 3. Words rules (all text in the UI and in seed content)
Short sentences, everyday words, 6th–8th grade reading level, friendly, never bossy. Buttons are verbs ("Send to Claude", "Save", "Next question"). Say "pictures", not "screenshots/assets". Say "Claude" for the assistant. Explain anything unusual in one line. English only.

## 4. Data (the shared notebook = db). Collections and who writes them
To avoid two writers on one document: **Claude writes** `questions`, `status`, `ideaStatus`, `plans`, `meta/heartbeat`, and the 4 built-in `sections`; **the page writes** `answers`, `ideas`, `planReplies`, `meta/ping`, her own custom `sections` (and edits `title/size/hold/archived` on any section – except it never edits Claude-owned fields). IDs: lowercase letters, digits, `-`, `_` only.

```
sections/<id>    { id, title, kind:"builtin"|"custom", order:Number, size:"small"|"big", hold:Boolean,
                   readOnly:Boolean, blurb:String, archived:Boolean, createdAt:ISO, createdBy:"claude"|"owner" }
questions/<id>   { id, sectionId, kind:"choice"|"visual"|"readonly", order:Number, createdAt:ISO,
                   title:String,                       // the question, ≤ 110 chars
                   story:[String],                     // 1–4 short paragraphs
                   why:String,                         // "Why I am asking" (1–2 sentences) — optional
                   ownTip:String,                      // hint under the type-your-own box — optional
                   choices:[{key:"A"|"B"|"C"|"D", label:String, explain:String}],   // exactly 4 for kind "choice"
                   versions:[{key:"A"|"B"|"C"|"D", label:String, caption:String,
                              images:[{url,alt,w,h}]}],                              // kind "visual": 2–4 versions
                   beforeImages:[{url,alt,w,h,caption}],   // optional "How it looks today"
                   required:Boolean,                   // counts toward unlocking a Big section
                   round:Number, parentId:String|null, // "Round 2" chains
                   who:"owner"|"kathy"|"rob"|"adviser"|"unknown",   // for kathy section: who should answer
                   needs:String,                       // for kathy section: what we need from them
                   previouslyNotSure:Boolean,          // true if she said "not sure" in the first questionnaire
                   topic:String,                       // optional grouping label, e.g. "Prices and menu" (used by the kathy list)
                   oldId:String|null }                 // e.g. "d05" from the first questionnaire
answers/<qid>    { id:qid, status:"answered"|"skipped", key:"A"|"B"|"C"|"D"|"own"|"unsure"|"help"|"change",
                   ownText:String, changeText:String, note:String, label:String (text of the chosen option),
                   answeredAt:ISO, round:Number }
status/<qid>     { id:qid, state:"seen"|"working"|"done"|"followup"|"held", seenAt:ISO, note:String, doneNote:String,
                   doneImages:[{url,alt,w,h}], followupId:String|null, at:ISO }
ideas/<id>       { id, sectionId, text:String, createdAt:ISO, sentAt:ISO|null }
ideaStatus/<id>  { id, state:"read"|"questionsReady", at:ISO, note:String }
plans/<sectionId>    { sectionId, version:Number, summary:String, steps:[String], needs:[String], at:ISO }
planReplies/<sectionId> { sectionId, version:Number, decision:"ok"|"change", text:String, at:ISO }
meta/heartbeat   { at:ISO, note:String }
meta/ping        { threadId:String|null }
```
Base CSS tokens (defined by layout, used by everyone): --bg --card --ink --soft --line --line-strong --accent --accent-ink --accent-soft --good --good-bg --warn --warn-bg --info-bg --focus --shadow --overlay --font. Base classes defined by layout: .btn .btn.primary .btn.quiet .card .chip .sr .row .stack. Each other helper puts its OWN component rules in its own css file `T/src/css/NN-name.css` (NN = same number as its js file) and uses only these tokens.

Choices are the same four as the first questionnaire: the 4th choice is usually "Explain this to me another way" (key D) — but the page ALSO always shows (outside the 4 choices) these buttons: **I'm not sure yet** (key `unsure`), **Explain another way** (key `help`), a **Type my own answer** box (key `own`), and for visual questions **I don't like any of them – change this** (key `change`, with a text box). For `kathy`/readonly questions none of these exist.

When she clicks a choice it is saved IMMEDIATELY (`answers/<qid>` set) and the page shows "Saved ✓ · Undo" for 8 s; then "Next question →" goes to the next unanswered question in the same section (or the next section). Her note box is saved with a short pause (debounce 600 ms), never from a render or snapshot callback.

## 5. Page code API (global namespace `QT`; file `00-core.js` creates it; every module attaches to it)
```
QT.store = { sections:{}, questions:{}, answers:{}, status:{}, ideas:{}, ideaStatus:{}, plans:{}, planReplies:{}, meta:{} }   // objects keyed by doc id, always present
QT.on(evt, fn) / QT.off(evt, fn) / QT.emit(evt, data)       // events: "store" {collection, ids, initial:Boolean}, "route" {view, params}, "ready"
QT.ready  // Promise resolved after the first snapshot of every collection (or immediately with QT.offline=true if db is null)
QT.write.answer(qid, obj) -> Promise     // sets answers/<qid> (adds id, answeredAt if missing)
QT.write.clearAnswer(qid) -> Promise     // the Undo button (deletes answers/<qid>)
QT.write.section(id, obj) -> Promise     // custom sections and edits of title/size/hold/archived (merge)
QT.write.idea(obj) -> Promise<id>        // new idea (draft) ; QT.write.sendIdea(id) sets sentAt and pings
QT.write.planReply(sectionId, obj) -> Promise
QT.write.ping(text) -> Promise<{ok,reason}>   // throttled; see Test connection
QT.route.go(view, params)    // views: "home" | "section" {id} | "question" {id} | "done" | "newsection"   (in-memory routing + remembered last view in localStorage, NOT the URL hash)
QT.views = { home(el,params), section(el,params), question(el,params), done(el,params), newsection(el,params) }   // each returns an optional cleanup function; the layout calls them
QT.el(tag, attrs, ...children)   // tiny DOM builder; attrs: class, text, on:{click:fn}, aria-*, data-*, hidden…; NEVER build DOM with innerHTML from document data (use textContent) — all data is untrusted text
QT.fmt.ago(iso) -> "2 min ago" | QT.fmt.time(iso) | QT.fmt.plural(n,"question")
QT.sound = { enabled():Boolean, set(Boolean), chime() }
QT.status = { chip(qid) -> Element (live-updating), state(qid) -> "waiting"|"answeredUnseen"|"seen"|"working"|"done"|"followup"|"held",
              badgeCount(sectionId) -> Number of unanswered answerable questions, heartbeatLabel() -> {text, stale:Boolean} }
QT.sections = { list() -> ordered sections (not archived), questionsOf(sectionId) -> ordered questions, nextUnanswered(fromQid) -> qid|null,
                progress(sectionId) -> {requiredTotal, requiredAnswered}, isBig(sectionId) }
QT.visual = { render(el, question) }     // draws ONLY the pictures: "how it looks today" strip + 2×2 version grid + zoom viewer; called by views.question when kind==="visual"
QT.answerUI = { render(el, question) }   // draws ALL answer controls (choice buttons A–D, or for visual questions one pick button per version; Type-my-own; I'm not sure; Explain another way; "None of them – change this" for visual; note box; Saved+Undo; Next). Owned by the question helper; used for every kind except readonly
QT.layout = { mount(rootEl) }            // draws top bar, left menu, main area; calls QT.views.* ; handles narrow screens
```
Module ownership (one helper per row; do NOT edit another helper's file — ask Claude in your report if you need a change):
| file(s) | owner | what |
|---|---|---|
| `T/build.py`, `T/src/shell.html`, `T/src/js/00-core.js`, `T/test/mock-claude.js` | **core** | namespace, store, db subscribe/write wrappers, events, routing state, `QT.el`, `QT.fmt`, build script, in-memory fake of `window.claude` for tests |
| `T/src/css/*.css`, `T/src/js/10-layout.js` | **layout** | colour tokens (light+dark+explicit `data-theme`), compact type scale, top bar, left menu, responsive collapse, sticky bars, focus styles, reduced-motion, `QT.layout.mount` |
| `T/src/js/20-question.js` | **question** | `QT.views.question` (all kinds) + `QT.answerUI`: story, choices, own-answer box, note, unsure/help/change, saved+undo, next/prev, round chain, readonly look (kathy), "Which version is best? A B C D" buttons for visual |
| `T/src/js/21-visual.js`, `T/src/js/22-lightbox.js` | **visual** | `QT.visual.render`: "how it looks today" strip, 2×2 versions, zoom viewer (keyboard ←/→/Esc, focus trap, caption, click to toggle fit / full size). Pictures only – answer buttons come from `QT.answerUI` |
| `T/src/js/30-sections.js` | **sections** | `QT.views.home/section/done/newsection`, `QT.sections`, ideas box, plan card, progress card, pause switch, size switch, Kathy list view (grouped by who/topic) |
| `T/src/js/40-status.js` | **status** | `QT.status`, chips, heartbeat label, `QT.sound`, tab-title count, NEW badges, Test connection + automatic ping |
| `T/tools/*` | **tools** | `snap.mjs`, `post_question.py`, `status.py`, `read_answers.py` (+ `T/tools/README.md`) |
| `T/seed/kathy.json` | **kathy** | the "Questions for Miss Kathy and Rob" pile |
| `T/seed/later.json` | **later** | "Ideas for later" starter questions |
| `T/seed/other.json`, `T/seed/sections.json` | **other** | first regular questions + the 5 built-in section docs + a welcome/test question |
| `T/test/*.mjs` (except mock) | **tester** | browser tests: fit at 3 sizes, live updates, writes, a11y, offline |

Until `00-core.js` exists, code against this API as written; the core helper delivers it first (target: 15 minutes) and the other helpers re-run their tests against it.

## 6. Styling basics (layout helper owns the CSS; others only add class names that exist or add scoped rules in their own `T/src/css/NN-name.css` file with the same number prefix as their js)
Reuse the look of the first questionnaire (`../qsite/site/src/style.css` – warm cream/brown/red farm colours, very readable) but tighter. All colours are tokens on `:root` with dark overrides under `@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){…}}` and `:root[data-theme="dark"]{…}`; `body` has an explicit background; `[hidden]{display:none!important}`; visible focus rings; touch targets ≥ 40 px; `prefers-reduced-motion` respected. The page is published inside a skeleton, so `shell.html` has `<title>Question Terminal</title>`, a `<style>` and the markup – NO `<html>/<head>/<body>` tags.

## 7. Seed content format (all seed files are JSON arrays of documents exactly as in section 4, plus `"_collection":"questions"` on each so the loader knows where it goes)
Question text rules: title = the question in plain words; `story` = what is going on, concrete ("On the home page, under the pizza picture, the site says …"); `why` = why it matters; exactly 4 choices with `explain` = "what happens if you pick this" in one sentence; no choice recommends itself. Never invent farm facts, prices, dates or hours – if something is unknown, the question is for Miss Kathy/Rob. Source material for the first 102 questions: `../qsite/out/chunk-*.json` (same fields: title, story[], why, choices[{key,kind,original,label,explain}], ownTip, needs, urgency…), answers: `../qsite/real-answers-final/answers/*.json`, plan-only report: `../work/a2a-final/PLAN.md`, owner's own typed answers: `../work/a2a-final/own-answers.md`.

## 8. Tests (tester + everyone)
Run with `NODE_PATH=/opt/node22/lib/node_modules node T/test/<file>.mjs` (see `T/test/lib.mjs`: `launch()`, `startServer()`, `ok()`, `info()`, `finish()`). Use your OWN port (never 8765, 8790, 8899, 8931, 8941; use 9100+ for the core helper, 9200+ layout, 9300+ question, 9400+ visual, 9500+ sections, 9600+ status, 9700+ tester). Tests load `T/dist/index.html` with `test/mock-claude.js` injected before the page runs. Chromium is pre-installed (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`); never run `playwright install`.
