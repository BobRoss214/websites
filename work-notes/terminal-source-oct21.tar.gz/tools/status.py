#!/usr/bin/env python3
"""Tell the owner what Claude is doing: writes a batch file of status notes for ArtifactData.

    python3 -I status.py seen|working|held   QID [QID ...] [--note TEXT]
    python3 -I status.py done                QID [QID ...] --done-note TEXT [--images pics.json]
    python3 -I status.py followup            QID [QID ...] --followup NEWQID [--note TEXT]
    python3 -I status.py heartbeat           [--heartbeat-note TEXT]
    python3 -I status.py idea-read|idea-ready IDEA_ID [IDEA_ID ...] [--note TEXT]
    python3 -I status.py applied BATCHFILE [--results RESULTS.json] [--again]
    python3 -I status.py plan-seen SECTION [--state seen|working|done] [--note TEXT] [--done-note TEXT]
    python3 -I status.py plan SECTION --summary TEXT --step TEXT [--step TEXT ...] [--need TEXT ...] [--plan-version N]

Common options:
    --heartbeat             also refresh meta/heartbeat ("Claude last looked: just now")
    --versions FILE         versions.json made by read_answers.py: documents that already exist are
                            written with "update" + if_version instead of "set"
                            (default: <outbox>/versions.json when it exists; --no-versions ignores it)
    --version PATH=N        one version by hand, e.g. meta/heartbeat=7 (repeatable)
    --export DIR            the folder read_answers.py read: warns about unknown ids, numbers plans
    --outbox DIR            where to write (default: T/outbox)
    --allow-words a,b       let a word past the no-jargon check

Prints the path of the batch file (T/outbox/status-<time>.json). Exit 0 = written, 2 = bad request.
"""
import argparse
import importlib.util as _iu
import re
import sys
import time
from pathlib import Path

_spec = _iu.spec_from_file_location("qtlib", Path(__file__).resolve().parent / "qtlib.py")
qt = _iu.module_from_spec(_spec)
sys.modules["qtlib"] = qt
_spec.loader.exec_module(qt)

STATES = ("seen", "working", "done", "followup", "held")
OTHER = ("heartbeat", "idea-read", "idea-ready", "plan", "plan-seen", "applied")


def _images(path):
    try:
        raw = qt.read_json(path)
    except (OSError, ValueError) as e:
        qt.die(f"Could not read --images {path}: {e}")
    if isinstance(raw, dict):
        raw = raw.get("images") or raw.get("doneImages") or [raw]
    out = []
    for i, im in enumerate(raw if isinstance(raw, list) else [], 1):
        if isinstance(im, str):
            im = {"url": im}
        url = im.get("url") if isinstance(im, dict) else None
        if not isinstance(url, str) or not (url.startswith("https://") or re.fullmatch(r"/_blob/[0-9a-f]{32}", url)):
            qt.die(f"--images entry {i} needs a url starting with https:// (or /_blob/<id> from an upload)")
        w, h = im.get("w"), im.get("h")
        out.append({"url": url, "alt": (im.get("alt") or "Picture of the result").strip(),
                    "w": w if isinstance(w, int) else 0, "h": h if isinstance(h, int) else 0})
    if not out:
        qt.die(f"--images {path} has no pictures in it. Expected a list like [{{\"url\": \"https://...\", \"alt\": \"...\", \"w\": 1200, \"h\": 800}}].")
    return out[:6]


def _known_ids(export, coll):
    if not export:
        return None
    d = Path(export) / coll
    return {p.stem for p in d.glob("*.json")} if d.is_dir() else None


def main(argv=None):
    ap = argparse.ArgumentParser(description="Write status notes for the Question Terminal.")
    ap.add_argument("state", choices=list(STATES) + list(OTHER))
    ap.add_argument("ids", nargs="*", help="question ids (idea ids for idea-*, the section id for plan)")
    ap.add_argument("--note", help="short line shown to her (what Claude is doing)")
    ap.add_argument("--state", dest="plan_state", choices=["seen", "working", "done"], default="seen", help="plan-seen: seen (default), working or done")
    ap.add_argument("--done-note", help="done: what Claude did, in plain words")
    ap.add_argument("--images", help="done: JSON file with pictures of the result")
    ap.add_argument("--followup", help="followup: id of the new question")
    ap.add_argument("--heartbeat", action="store_true", help="also refresh meta/heartbeat")
    ap.add_argument("--heartbeat-note", default="", help="text stored with the heartbeat")
    ap.add_argument("--versions")
    ap.add_argument("--no-versions", action="store_true", help="do not use T/outbox/versions.json automatically")
    ap.add_argument("--version", action="append", default=[], metavar="PATH=N")
    ap.add_argument("--export")
    ap.add_argument("--outbox")
    ap.add_argument("--allow-words")
    ap.add_argument("--results", help="applied: JSON map path -> version copied from the ArtifactData result")
    ap.add_argument("--again", action="store_true", help="applied: record a batch file that was recorded before")
    ap.add_argument("--summary", help="plan: one or two plain sentences")
    ap.add_argument("--step", action="append", default=[], help="plan: one step (repeatable)")
    ap.add_argument("--need", action="append", default=[], help="plan: something Claude still needs from her (repeatable)")
    ap.add_argument("--plan-version", type=int, help="plan: version number (default: one more than the last plan, or the time)")
    a = ap.parse_args(argv)

    if a.state == "applied":   # after ArtifactData accepted a batch file: move versions.json on
        if len(a.ids) != 1:
            print("applied needs exactly one batch file (the one ArtifactData just accepted)", file=sys.stderr)
            return 2
        lines, vpath = qt.apply_batch(a.ids[0], a.results, a.outbox, a.again)
        print(f"Recorded {len(lines)} write(s) in {vpath}:")
        for l in lines:
            print("  " + l)
        return 0
    now = qt.now_iso()
    outbox = qt.outbox_dir(a.outbox)
    versions = qt.load_versions(a.versions, a.version, outbox=outbox, auto=not a.no_versions)
    allow = qt.parse_allow(a.allow_words)
    writes, errs, warns, shown = [], [], [], []

    ids = a.ids
    for i in ids:
        if not qt.ID_RE.match(i):
            errs.append(f"'{i}' is not a valid id (lowercase letters, digits, - and _ only)")
    if a.state in STATES or a.state in ("idea-read", "idea-ready", "plan", "plan-seen"):
        if not ids:
            errs.append("give at least one id" if a.state not in ("plan", "plan-seen") else "give the section id")
    if a.state == "heartbeat" and ids:
        errs.append("heartbeat takes no ids")
    if a.state in ("plan", "plan-seen") and len(ids) > 1:
        errs.append(f"{a.state} takes one section id")
    if a.state == "plan-seen" and ids and not qt.ID_RE.match("plan-" + ids[0]):
        errs.append("that section id is too long")

    if a.state in STATES:
        note, done_note, images, fu = a.note or "", a.done_note or "", [], a.followup
        if a.state == "done":
            if not done_note and note:
                done_note, note = note, ""
            if not done_note:
                errs.append("done needs --done-note 'what I did' (she reads it in the Done list)")
            if a.images:
                images = _images(a.images)
        elif a.images:
            errs.append("--images is only for done")
        if a.state == "followup":
            if not fu or not qt.ID_RE.match(fu):
                errs.append("followup needs --followup NEWQID (the id of the new question)")
            elif fu in ids:
                errs.append("--followup must be a different question than the one being marked")
        elif fu:
            errs.append("--followup is only for the followup state")
        if a.state != "done" and a.done_note:
            errs.append("--done-note is only for done")
        known = _known_ids(a.export, "questions")
        for q in ids:
            if known is not None and q not in known:
                warns.append(f"question '{q}' is not in the export folder (a typo?)")
        for q in ids:
            doc = qt.status_doc(q, a.state, note=note, done_note=done_note, done_images=images, followup_id=fu, now=now)
            shown += [("note", note), ("done note", done_note)]
            writes.append(qt.make_write("update" if f"status/{q}" in versions else "set", "status", q, doc, versions))
    elif a.state in ("idea-read", "idea-ready"):
        st = "read" if a.state == "idea-read" else "questionsReady"
        known = _known_ids(a.export, "ideas")
        for i in ids:
            if known is not None and i not in known:
                warns.append(f"idea '{i}' is not in the export folder (a typo?)")
            doc = {"id": i, "state": st, "at": now, "note": a.note or ""}
            shown.append(("note", a.note))
            writes.append(qt.make_write("set", "ideaStatus", i, doc, versions))
    elif a.state == "plan-seen":
        # "Claude saw it" on the plan card: status/plan-<sectionId>
        sec = ids[0] if ids else ""
        note, done_note = a.note or "", a.done_note or ""
        if a.plan_state == "done" and not done_note and note:
            done_note, note = note, ""
        if a.plan_state == "done" and not done_note:
            errs.append("done needs --done-note 'what I did'")
        if a.plan_state != "done" and done_note:
            errs.append("--done-note is only for --state done")
        did = "plan-" + sec
        doc = {"id": did, "state": a.plan_state, "seenAt": now, "at": now, "note": note, "doneNote": done_note}
        shown += [("note", note), ("done note", done_note)]
        writes.append(qt.make_write("update" if f"status/{did}" in versions else "set", "status", did, doc, versions))
    elif a.state == "plan":
        sec = ids[0] if ids else ""
        steps = [s.strip() for s in a.step if s.strip()]
        needs = [s.strip() for s in a.need if s.strip()]
        if not (a.summary or "").strip():
            errs.append("plan needs --summary")
        if not 1 <= len(steps) <= 10:
            errs.append("plan needs 1 to 10 --step lines")
        ver = a.plan_version
        if ver is None:
            if not a.export:
                errs.append("plan needs --plan-version N, or --export DIR so the number can count up from the last plan "
                            "(a new number keeps an old 'looks good' from counting for a changed plan)")
            else:
                last = 0
                try:
                    old = qt.read_json(Path(a.export) / "plans" / f"{sec}.json")
                    old = old.get("data", old) if isinstance(old, dict) else {}
                    last = old.get("version") if isinstance(old.get("version"), int) else 0
                except (OSError, ValueError):
                    last = 0
                ver = last + 1
        shown += [("summary", a.summary)] + [(f"step {i}", s) for i, s in enumerate(steps, 1)] + [(f"need {i}", s) for i, s in enumerate(needs, 1)]
        doc = {"sectionId": sec, "version": ver, "summary": (a.summary or "").strip(), "steps": steps, "needs": needs, "at": now}
        writes.append(qt.make_write("set", "plans", sec, doc, versions))

    if a.heartbeat or a.state == "heartbeat":
        hb = {"at": now, "note": a.heartbeat_note or ""}
        shown.append(("heartbeat note", a.heartbeat_note))
        writes.append(qt.make_write("set", "meta", "heartbeat", hb, versions))

    for where, word in qt.jargon_hits(shown, allow):
        errs.append(f"the word '{word}' is in the {where}; she should not read it. Say it in everyday words")
    if errs:
        print("Not written:", file=sys.stderr)
        for e in errs:
            print("  - " + e, file=sys.stderr)
        return 2
    for w in warns:
        print("Note: " + w)

    made = qt.write_batches(outbox, writes, prefix="status", with_files=False, clean=False, name_stamp=qt.stamp())
    for inline, _, n in made:
        print(f"{inline}   ({n} writes)")
    if a.export:
        for w in writes:
            f = Path(a.export) / w["collection"] / f"{w['doc_id']}.json"
            if f.is_file() and not w.get("if_version"):
                print(f"Note: {w['collection']}/{w['doc_id']} already exists but no version is known; "
                      "ArtifactData will refuse it. Pass --versions (from read_answers.py) or --version PATH=N.")
    elif any(w["collection"] == "meta" and not w.get("if_version") for w in writes):
        print("Note: if meta/heartbeat already exists, add --version meta/heartbeat=N (or --versions versions.json).")
    print("Next: ArtifactData action=batch, url=<Question Terminal page>, writes=<the writes list in that file>.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
