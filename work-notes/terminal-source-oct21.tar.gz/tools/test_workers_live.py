#!/usr/bin/env python3
"""Self-test for tools/workers_live.py. Uses ONLY made-up transcripts (test/fixtures/workers-live/), never real ones.

    python3 T/tools/test_workers_live.py            (about 5 seconds)
    python3 T/tools/test_workers_live.py states     (only tests whose name contains "states")

Plain asserts. The fixture files are (re)written on every run by build_fixtures() and stay on disk for inspection.
Every private-looking marker (SECRET-...) hidden in prompts, commands, results and thoughts must NEVER show up in the
tool's output or in the workers file it writes.
"""
import datetime
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
T = HERE.parent
FIX = T / "test" / "fixtures" / "workers-live"
TRANS = FIX / "transcripts"
PY = [sys.executable, "-I"]
TMP = Path(tempfile.mkdtemp(prefix="wl-test-"))
NOW = "2026-10-07T12:00:00Z"
NOW_DT = datetime.datetime(2026, 10, 7, 12, 0, 0, tzinfo=datetime.timezone.utc)

spec = importlib.util.spec_from_file_location("workers_live", HERE / "workers_live.py")
wl = importlib.util.module_from_spec(spec)
sys.modules["workers_live"] = wl
spec.loader.exec_module(wl)

# fake agent ids (an 'a' and 16 hex digits, like the real ones)
A_WORKING = "a0000000000000001"
A_DONE = "a0000000000000002"
A_REWOKEN = "a0000000000000003"
A_RESTING = "a0000000000000004"
A_WAITING = "a0000000000000005"
A_WAITEXP = "a0000000000000006"
A_LONGCMD = "a0000000000000007"
A_LONGCMD2 = "a0000000000000008"
A_DAMAGED = "a0000000000000009"
A_NODESC = "a000000000000000a"
A_BGBASH = "a000000000000000b"
A_HUMANWAIT = "a000000000000000c"
A_STOPPED = "a000000000000000d"
A_FOUND = "a000000000000000e"
A_NOBODY = "a000000000000000f"
A_EMPTY = "a0000000000000010"
A_NOANSWER = "a0000000000000011"
A_OTHEREND = "a0000000000000012"
A_TEXTEND = "a0000000000000013"
A_BIG = "a0000000000000014"
A_MISSING = "a0000000000000015"
A_JARGON = "a000000000000030"
A_JARGON2 = "a000000000000031"
A_NOUNS = "a000000000000032"

SECRETS = ["SECRET-PROMPT", "SECRET-COMMAND", "SECRET-OUTPUT", "SECRET-THOUGHT", "SECRET-TEXT", "SECRET-ATTACH", "SECRET-DESC"]


# ---------------------------------------------------------------------------------------------- fixture builder
def at(hhmmss, day="2026-10-07"):
    h, m, s = (hhmmss.split(":") + ["0", "0"])[:3]
    return f"{day}T{int(h):02d}:{int(m):02d}:{int(s):02d}.250Z"


class Tx:
    """Writes one fake transcript in the same shape as the real ones (only the parts the tool looks at)."""

    def __init__(self, agent):
        self.agent, self.lines, self.n = agent, [], 0

    def _id(self):
        self.n += 1
        return f"toolu_{self.agent}_{self.n}"

    def _rec(self, typ, ts, message, **extra):
        o = {"parentUuid": "00000000-0000-0000-0000-000000000000", "isSidechain": True, "agentId": self.agent, "type": typ}
        o["message"] = message
        o.update({"uuid": f"u{len(self.lines)}", "timestamp": ts})
        o.update(extra)
        self.lines.append(json.dumps(o))

    def prompt(self, ts, text="SECRET-PROMPT: build the thing"):
        self._rec("user", ts, {"role": "user", "content": text}, promptId="p1")

    def wake(self, ts):
        self._rec("user", ts, {"role": "user", "content": "SECRET-TEXT: new job from the boss"}, isMeta=True, origin={"kind": "coordinator"})

    def think(self, ts):
        self._rec("assistant", ts, {"role": "assistant", "content": [{"type": "thinking", "thinking": "SECRET-THOUGHT"}], "stop_reason": None})

    def text(self, ts, stop=None):
        self._rec("assistant", ts, {"role": "assistant", "content": [{"type": "text", "text": "SECRET-TEXT"}], "stop_reason": stop})

    def call(self, ts, name="Bash", desc=None, result_at=None, **inp):
        cid = self._id()
        body = {"command": "cat /etc/SECRET-COMMAND"} if name == "Bash" else {"file_path": "/x/SECRET-COMMAND"}
        if name == "Monitor":
            body = {"command": "SECRET-COMMAND"}
        body.update(inp)
        if desc is not None:
            body["description"] = desc
        self._rec("assistant", ts, {"role": "assistant", "content": [{"type": "tool_use", "id": cid, "name": name, "input": body}], "stop_reason": None})
        if result_at:
            self.result(result_at, cid)
        return cid

    def result(self, ts, cid, ends=False):
        extra = {"toolEndsTurn": True} if ends else {}
        self._rec("user", ts, {"role": "user", "content": [{"type": "tool_result", "tool_use_id": cid, "content": "SECRET-OUTPUT"}]}, **extra)

    def handback(self, ts, result_at=None):
        cid = self._id()
        self._rec("assistant", ts, {"role": "assistant", "content": [{"type": "tool_use", "id": cid, "name": "SubagentHandback", "input": {"message": "SECRET-TEXT report"}}], "stop_reason": None})
        self.result(result_at or ts, cid, ends=True)

    def attach(self, ts):
        self.lines.append(json.dumps({"parentUuid": "x", "isSidechain": True, "agentId": self.agent,
                                      "attachment": {"type": "total_tokens_reminder", "text": "SECRET-ATTACH"}, "type": "attachment",
                                      "uuid": "a", "timestamp": ts}))

    def raw(self, text):
        self.lines.append(text)

    def save(self, trailing_newline=True):
        TRANS.mkdir(parents=True, exist_ok=True)
        (TRANS / f"{self.agent}.output").write_text("\n".join(self.lines) + ("\n" if trailing_newline else ""), encoding="utf-8")


def worker(wid, name, kind="helper", parent="team-a", state="working", **kw):
    d = {"id": wid, "name": name, "parentId": parent, "kind": kind, "icon": "🌾", "role": f"Role of {name}.", "state": state,
         "now": "The lead's own words." if state in ("working", "waiting") else "", "waitingFor": "none", "startedAt": None,
         "updatedAt": "2026-10-07T11:00:00Z", "finishedAt": None, "activity": [], "result": "", "taskIds": ["t1"], "brain": "Sonnet",
         "progress": None, "order": 1}
    d.update(kw)
    return d


def build_fixtures():
    shutil.rmtree(FIX, ignore_errors=True)
    TRANS.mkdir(parents=True)
    # 1. working: clean + dirty descriptions, repeats, thinking, attachments; the last 3 calls have unusable descriptions
    t = Tx(A_WORKING)
    t.prompt(at("11:00"))
    t.attach(at("11:00:01"))
    t.think(at("11:00:02"))
    t.call(at("11:10"), desc="Run the status test alone", result_at=at("11:10:05"))
    t.call(at("11:20"), desc="Look at the winter picture", result_at=at("11:20:05"))
    t.call(at("11:30"), desc="Run the status test alone", result_at=at("11:30:05"))       # repeat
    t.call(at("11:40"), desc="Open /home/user/notes/SECRET-DESC.md", result_at=at("11:40:05"))    # path
    t.call(at("11:50"), desc="Fetch https://example.com/page?SECRET-DESC", result_at=at("11:50:05"))   # link
    t.call(at("11:55"), desc="Use the key ghp_abcdefghijklmnop12345", result_at=at("11:55:05"))   # token
    t.call(at("11:56"), desc="Deploy the repo to the database", result_at=at("11:56:05"))   # jargon
    t.call(at("11:58"), name="Read", result_at=at("11:58:05"))                               # no description at all
    t.save()
    # 2. done: handed back at 09:30 (2.5 hours before NOW)
    t = Tx(A_DONE)
    t.prompt(at("08:00"))
    t.call(at("08:10"), desc="Check the farm map picture", result_at=at("08:10:05"))
    t.call(at("09:00"), desc="Count the lit trees", result_at=at("09:00:05"))
    t.handback(at("09:30"), result_at=at("09:30:01"))
    t.attach(at("09:30:02"))                      # a note after the hand-back must not undo "done"
    t.save()
    # 3. woken again after a hand-back
    t = Tx(A_REWOKEN)
    t.prompt(at("07:00"))
    t.call(at("07:30"), desc="Draw the first sketch", result_at=at("07:30:05"))
    t.handback(at("08:00"), result_at=at("08:00:01"))
    t.wake(at("11:55"))
    t.call(at("11:56"), desc="Edit the second sketch", result_at=at("11:56:05"))
    t.save()
    # 4. resting: no hand-back, nothing for 40 minutes
    t = Tx(A_RESTING)
    t.prompt(at("10:00"))
    t.call(at("11:20"), desc="Compare the two pictures", result_at=at("11:20:05"))
    t.save()
    # 5. waiting: a Monitor (1 hour limit) started 10 minutes ago, helper said a closing word
    t = Tx(A_WAITING)
    t.prompt(at("11:00"))
    cid = t.call(at("11:50"), name="Monitor", desc="Watch the long test run", timeout_ms=3600000)
    t.result(at("11:50:01"), cid)
    t.text(at("11:50:05"))
    t.save()
    # 6. a Monitor whose own time limit ran out long ago: resting, not waiting
    t = Tx(A_WAITEXP)
    t.prompt(at("09:00"))
    cid = t.call(at("10:00"), name="Monitor", desc="Watch the old run", timeout_ms=600000)
    t.result(at("10:00:01"), cid)
    t.save()
    # 7a. a long command (limit 10 minutes) with no answer yet, started 9 minutes ago: still working
    t = Tx(A_LONGCMD)
    t.prompt(at("11:00"))
    t.call(at("11:51"), desc="Run the big test", timeout=600000)
    t.save()
    # 7b. the same with the normal 2 minute limit: nothing for 9 minutes means resting
    t = Tx(A_LONGCMD2)
    t.prompt(at("11:00"))
    t.call(at("11:51"), desc="Run the small test")
    t.save()
    # 8. damaged lines: a spliced line (cut-off record, then a whole one), a broken line, and a half-written last line
    t = Tx(A_DAMAGED)
    t.prompt(at("11:00"))
    t.call(at("11:10"), desc="Check the first page", result_at=at("11:10:05"))
    whole = Tx(A_DAMAGED)
    whole.n = 50
    whole.call(at("11:20"), desc="Check the second page")
    t.raw('{"parentUuid":"cut-off","isSidechain":true,"message":{"role":"assista' + whole.lines[0])
    t.raw('{"this is": not json at all SECRET-TEXT')
    t.call(at("11:30"), desc="Check the third page", result_at=at("11:30:05"))
    t.raw('{"parentUuid":"half-written","type":"assistant","message":{"content":[{"type":"tool_use","name":"Bash","input":{"descr')
    t.save(trailing_newline=False)
    # 9. working without any description
    t = Tx(A_NODESC)
    t.prompt(at("11:00"))
    t.call(at("11:57"), name="Read", result_at=at("11:57:05"))
    t.call(at("11:58"), name="WebSearch", result_at=at("11:58:05"))
    t.save()
    # 10. a command run in the background
    t = Tx(A_BGBASH)
    t.prompt(at("11:00"))
    cid = t.call(at("11:54"), desc="Build the big pictures in the background", run_in_background=True, timeout=1800000)
    t.result(at("11:54:01"), cid)
    t.save()
    # 11. a helper whose own file says "done" but the lead set "waiting for the owner"
    t = Tx(A_HUMANWAIT)
    t.prompt(at("08:00"))
    t.call(at("08:10"), desc="Write the two questions", result_at=at("08:10:05"))
    t.handback(at("09:00"))
    t.save()
    # 12. stopped by the lead, still looks busy in its file
    t = Tx(A_STOPPED)
    t.prompt(at("11:00"))
    t.call(at("11:59"), desc="Keep drawing", result_at=at("11:59:05"))
    t.save()
    # 13. found by its start time only (no map entry)
    t = Tx(A_FOUND)
    t.prompt(at("10:11:12"))
    t.call(at("11:59"), desc="Look at the barn photo", result_at=at("11:59:05"))
    t.save()
    # 14. a transcript that belongs to nobody
    t = Tx(A_NOBODY)
    t.prompt(at("10:00:01"))
    t.save()
    # 15. the lead's real examples of jargon: only the plain one may reach the page
    t = Tx(A_JARGON)
    t.prompt(at("11:00"))
    t.call(at("11:50"), desc="Running a11y and flow tests", result_at=at("11:50:05"))
    t.call(at("11:55"), desc="Reading the chime and known-state code", result_at=at("11:55:05"))
    t.call(at("11:57"), desc="Check the F3 schema", result_at=at("11:57:05"))
    t.call(at("11:58"), desc="Fixing test expectations and re-run dated", result_at=at("11:58:05"))
    t.call(at("11:59"), desc="Watch the test's child processes", result_at=at("11:59:05"))
    t.save()
    # 16. every description is jargon: `now` falls back to the role line
    t = Tx(A_JARGON2)
    t.prompt(at("11:00"))
    t.call(at("11:58"), desc="Check the F3 schema", result_at=at("11:58:05"))
    t.call(at("11:59"), desc="Reading the chime and known-state code", result_at=at("11:59:05"))
    t.save()
    # 17. plain words but no verb at the start: not used
    t = Tx(A_NOUNS)
    t.prompt(at("11:00"))
    t.call(at("11:58"), desc="Games check result for the winter copy", result_at=at("11:58:05"))
    t.save()
    # an empty file
    (TRANS / f"{A_EMPTY}.output").write_text("", encoding="utf-8")

    docs = [
        worker("claude", "Claude", "lead", None, startedAt=None, brain="Claude"),
        worker("team-a", "Team A", "team", "claude"),
        worker("w-working", "Working one"),
        worker("w-done", "Done one", state="working"),
        worker("w-rewoken", "Rewoken one", state="done", result="Handed back once.", finishedAt="2026-10-07T08:00:00Z"),
        worker("w-resting", "Resting one", state="working"),
        worker("w-waiting", "Waiting one"),
        worker("w-waitexp", "Expired one", state="waiting", waitingFor="claude"),
        worker("w-longcmd", "Long command one"),
        worker("w-longcmd2", "Short command one"),
        worker("w-damaged", "Damaged one"),
        worker("w-nodesc", "No words one", role="Draws the farm map in one quick sample."),
        worker("w-jargon", "Jargon one", role="Checks the farm map pictures for mistakes."),
        worker("w-jargon2", "Jargon two", role="Checks the farm map pictures for mistakes."),
        worker("w-nouns", "Noun one", role="Built the farm map once."),
        worker("w-bgbash", "Background one", state="resting"),
        worker("w-humanwait", "Waits for her", state="waiting", waitingFor="owner", now="Waiting for your answer about the strip."),
        worker("w-stopped", "Stopped one", state="stopped", now=""),
        worker("w-found", "Found by time", startedAt=at("10:11:12")),
        worker("w-nomap", "Nobody knows", startedAt="2026-10-07T01:02:03.004Z"),
    ]
    for d in docs:
        if d["kind"] == "helper" and d["id"] != "w-found" and d["id"] != "w-nomap":
            d["startedAt"] = None
    mapping = {"w-working": A_WORKING, "w-done": A_DONE, "w-rewoken": A_REWOKEN, "w-resting": A_RESTING,
               "w-waiting": A_WAITING, "w-waitexp": A_WAITEXP, "w-longcmd": A_LONGCMD, "w-longcmd2": A_LONGCMD2,
               "w-damaged": A_DAMAGED, "w-nodesc": A_NODESC, "w-bgbash": A_BGBASH, "w-humanwait": A_HUMANWAIT,
               "w-stopped": A_STOPPED, "w-jargon": A_JARGON, "w-jargon2": A_JARGON2, "w-nouns": A_NOUNS, "_note": "keys starting with _ are ignored"}
    (FIX / "workers.json").write_text(json.dumps(docs, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (FIX / "worker-agents.json").write_text(json.dumps(mapping, indent=2) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------------------------- helpers
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def jload(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def summary(agent):
    return wl.read_transcript(TRANS / f"{agent}.output", agent)


def verdict(agent, now=NOW_DT, idle=8):
    return summary(agent).verdict(now, idle)[0]


def run(*args, expect=0, cwd=None):
    cmd = PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--now", NOW] + [str(a) for a in args]
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd or str(TMP), timeout=120)
    assert p.returncode == expect, f"exit {p.returncode}, wanted {expect}\n{p.stdout}\n{p.stderr}"
    for text in (p.stdout, p.stderr):
        for marker in SECRETS:
            assert marker not in text, f"private marker {marker} leaked into the output"
    return p.stdout


def work_copy(name):
    d = TMP / name
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    shutil.copy(FIX / "workers.json", d / "workers.json")
    shutil.copy(FIX / "worker-agents.json", d / "worker-agents.json")
    return d


def by_id(path):
    return {d["id"]: d for d in jload(path)}


# ---------------------------------------------------------------------------------------------- tests
def test_scrub_keeps_plain_words_only():
    ok = {
        "Run the status test alone": "Run the status check alone",
        "  check   the farm map.  ": "Check the farm map",
        "Ask Kathy about the photos": "Ask Cathy about the photos",
        "Take the pictures at 1366, 700 and 390": "Take the pictures at 1366, 700 and 390",
    }
    for raw, want in ok.items():
        got, why = wl.scrub(raw)
        assert got == want and why == "ok", (raw, got, why)
    bad = {
        "Open /home/user/notes.md": "symbols", "Open C:\\Users\\x": "symbols", "Fetch https://example.com": "symbols",
        "Read notes.md now": "dotted", "Call example.com": "dotted", "Version 1.2.3 check": "dotted", "Run it with --headless": "flag",
        "Use the key ghp_abcdefghijklmnopqrst": "codelike", "Use the key ghp_abcdefgh12345": "numbers", "Check a0662bf910688676f": "numbers", "Check a1b2c3d4e5f6": "codelike", "Open build_page now": "codelike",
        "Fix camelCaseThing": "codelike", "Check the JSON output": "codelike", "Check the json output": "jargon", "Deploy the repo": "jargon", "Sync the database": "jargon",
        "Call the API": "codelike", "Ask the agent": "jargon", "Check the model": "jargon", "Install the package": "jargon",
        "Start the server": "jargon", "Use the token": "jargon", "Look at the HTML": "codelike", "Check 123456789": "numbers",
        "Call 919-555-1234": "numbers", "": "empty", "   ": "empty", "x" * 300: "long", "Mail me@example.com": "symbols",
        "Run `ls`": "symbols", 'Open "file"': "symbols", "OK": "short", None: "none", 42: "none", "Check password reset": "jargon",
        "echo $HOME": "symbols", "a | b": "symbols", "Run the tests in the console": "jargon",
        "Wait": "short", "Take pictures": "short", "Check the F3 schema": "jargon", "Look at the i18n files": "jargon",
        "Fixing test expectations and re-run dated": "jargon", "Reading the chime and known-state code": "jargon",
        "Watch the test's child processes": "jargon", "Look at the src files": "jargon", "Run the unit tests": "jargon",
    }
    for raw, why in bad.items():
        got, reason = wl.scrub(raw)
        assert got is None and reason == why, (raw, got, reason, why)
    assert wl.scrub("Check the farm map")[0] and wl.scrub("Waiting for the old suite")[0]


def test_age_text():
    assert [wl.age_text(x) for x in (0, 44, 89, 90, 115, 3599, 7199, 7200, 9000, 172799, 180000, None)] == \
        ["0s", "44s", "89s", "2m", "2m", "60m", "2h00m", "2h00m", "2h30m", "2d0h", "2d2h", "?"], \
        [wl.age_text(x) for x in (0, 44, 89, 90, 115, 3599, 7199, 7200, 9000, 172799, 180000, None)]


def test_phrase_changes_only_the_first_verb():
    assert wl.phrase("Run the status check alone", 0) == "Running the status check alone"
    assert wl.phrase("Run the status check alone", 1) == "Ran the status check alone"
    assert wl.phrase("Running the checks", 1) == "Ran the checks", "already '-ing': used for activity too"
    assert wl.phrase("Ran the checks", 0) == "Running the checks"
    assert wl.phrase("Look up the opening day", 0) == "Looking up the opening day"
    assert wl.phrase("Double-check the photos", 1) == "Double-checked the photos"
    assert wl.phrase("Zoom the strip under the card", 0) == "Zooming in on the strip under the card"
    assert wl.phrase("Poll for the games result", 0) == "Waiting for the games result"
    assert wl.phrase("Add the hostile check and run it", 0) == "Adding the hostile check and running it"
    assert wl.phrase("Add the hostile check and run it", 1) == "Added the hostile check and ran it"
    assert wl.phrase("Check the pictures and test results", 0) == "Checking the pictures and test results", "a noun after 'and' is left alone"
    assert wl.phrase("Snap mutated C", 0) is None, "an unknown first word: the line is not used"
    assert wl.phrase("Games check result for the winter copy", 0) is None, "no verb first: not used"
    long = "Check " + "word " * 60
    assert len(wl.cap(long)) <= 140 and wl.cap(long).endswith("…")
    assert wl.cap("short") == "short"


def test_swaps_make_plain_words_and_us_spelling():
    want = {
        "Running a11y and flow tests": "Running access checks and flow checks",
        "Run a11y checks": "Run access checks",
        "Run the status test alone": "Run the status check alone",
        "Testing the tested tester": "Checking the checked checker",
        "Run the full test suite": "Run the full set of checks",
        "Run the old suites": "Run the old sets of checks",
        "Re-running the non-browser checks on the final copy": "Running the non-browser checks on the final copy again",
        "Re-ran the full test suite": "Ran the full set of checks again",
        "Fix the pictures and re-run them": "Fix the pictures and run them again",
        "Fix the pictures, then re-run": "Fix the pictures, then run again",
        "Rerun the winter check": "Run the winter check again",
        "Read the code": "Read the page files",
        "Read the source code now": "Read the page files now",
        "Checking colour contrast": "Checking color contrast",
        "Match the colours and the coloured boxes": "Match the colors and the colored boxes",
        "Look at the neighbours' houses and the centre": "Look at the neighbors' houses and the center",
        "Organised the favourite things": "Organized the favorite things",
        "Analysing the licence": "Analyzing the license",
        "Cancelled and labelled": "Canceled and labeled",
        "Update the docs": "Update the notes",
        "Ask the helper about the job": "Ask the worker about the task",
        "Helpers finished two jobs": "Workers finished two tasks",
        "Paint the grey roads and the greyish fence": "Paint the gray roads and the grayish fence",
    }
    for raw, out in want.items():
        got = wl.swap(" ".join(raw.split()))
        assert got == out, (raw, got, out)
    for raw in ("latest", "contest", "decoded", "Check the barn", "Jobless", "Greyhound", "Helperx"):       # whole words only
        assert wl.swap(raw) == raw, raw


def test_lead_examples_from_the_plain_words_review():
    # lines the review found full of jargon: dropped, or turned into plain words
    for raw in ("Fixing test expectations and re-run dated", "Reading the chime and known-state code", "Check the F3 schema",
                "Watch the test's child processes", "Look at the F3 schema", "Running hero, i18n and languages"):
        assert wl.scrub(raw) == (None, "jargon"), raw
    assert wl.scrub("Running a11y and flow tests") == ("Running access checks and flow checks", "ok")
    got = wl.scrub("Checking colour contrast of the hero")[0]
    assert got == "Checking color contrast of the hero", got
    # no banned word survives any swap
    banned = re.compile(r"\b(tests?|testing|tested|suites?|a11y|schema|colou?r(?!s?\b)\w*|colour\w*|re-?run\w*|code|states?|processes)\b", re.I)
    for raw in ("Run the test suite again", "Re-run a11y tests", "Fix the code", "Testing the colour of the code"):
        got = wl.scrub(raw)[0]
        assert got is None or not banned.search(got), (raw, got)


def test_states_follow_the_rules():
    build_fixtures()
    expect = {
        A_WORKING: "working", A_DONE: "done", A_REWOKEN: "working", A_RESTING: "resting",
        A_WAITING: "waiting", A_WAITEXP: "resting", A_LONGCMD: "working", A_LONGCMD2: "resting",
        A_DAMAGED: "resting", A_NODESC: "working", A_BGBASH: "waiting", A_HUMANWAIT: "done",
        A_STOPPED: "working", A_FOUND: "working",
    }
    for agent, want in expect.items():
        got = verdict(agent)
        assert got == want, f"{agent}: {got}, wanted {want}"
    assert verdict(A_EMPTY) is None
    # time passes: the same files
    later = NOW_DT + datetime.timedelta(hours=1)
    assert verdict(A_WORKING, later) == "resting"
    assert verdict(A_DONE, later) == "done"                        # done stays done
    assert verdict(A_WAITING, NOW_DT + datetime.timedelta(minutes=30)) == "waiting"      # the Monitor's 1 hour limit is not over
    assert verdict(A_WAITING, later) == "resting"                  # 70 minutes after the start: over


def test_states_waiting_limit_is_exact():
    s = summary(A_WAITING)
    start = NOW_DT - datetime.timedelta(minutes=10)
    assert s.verdict(start + datetime.timedelta(minutes=60, seconds=30))[0] == "waiting"
    assert s.verdict(start + datetime.timedelta(minutes=62))[0] == "resting"
    # a helper that only just went quiet may still be thinking: working, not waiting
    soon = start + datetime.timedelta(minutes=0, seconds=30)
    assert s.verdict(soon)[0] == "working"


def test_states_done_needs_clear_evidence():
    # a hand-back call without its answer is not "done"
    t = Tx(A_NOANSWER)
    t.prompt(at("08:00"))
    cid = t._id()
    t._rec("assistant", at("08:30"), {"role": "assistant", "content": [{"type": "tool_use", "id": cid, "name": "SubagentHandback", "input": {}}]})
    t.save()
    assert verdict(A_NOANSWER) == "resting"
    # a result with toolEndsTurn that does not belong to a hand-back call is not "done" either
    t = Tx(A_OTHEREND)
    t.prompt(at("08:00"))
    c = t.call(at("08:10"), desc="Something", result_at=None)
    t.result(at("08:11"), c, ends=True)
    t.save()
    assert verdict(A_OTHEREND) == "resting"
    # a new message after the hand-back means it is not done any more
    assert verdict(A_REWOKEN) == "working"
    # the plain end of the file with a final text but no hand-back is not "done"
    t = Tx(A_TEXTEND)
    t.prompt(at("08:00"))
    t.text(at("08:30"), stop="end_turn")
    t.save()
    assert verdict(A_TEXTEND) == "resting"
    for n in (A_NOANSWER, A_OTHEREND, A_TEXTEND):
        (TRANS / f"{n}.output").unlink()


def test_one_transcript_facts():
    s = summary(A_WORKING)
    assert s.first[0] == at("11:00") and s.last[0] == at("11:58:05"), (s.first, s.last)
    assert s.steps == 8 and s.lines == 19, (s.steps, s.lines)
    # the 3 newest descriptions are unusable, so `now` comes from the newest clean one inside the last 12 calls
    assert s.now_line() == "Running the status check alone", s.now_line()
    assert s.tool_phrase() == "Reading files"          # --tool-words: a fixed phrase for the newest call
    acts = s.activity()
    texts = [a["text"] for a in acts]
    assert texts == ["Ran the status check alone", "Looked at the winter picture", "Got the task"], texts
    assert acts[0]["at"] == "2026-10-07T11:30:00Z", acts[0]            # the repeat kept its NEWEST time
    assert dict(s.rejects) == {"symbols": 2, "numbers": 1, "jargon": 1}, dict(s.rejects)
    d = summary(A_DONE)
    assert d.steps == 2, d.steps                       # the hand-back call is not a step
    assert d.ended[0] == at("09:30:01"), d.ended
    assert [a["text"] for a in d.activity()] == ["Handed back its report", "Counted the lit trees", "Checked the farm map picture", "Got the task"]
    r = summary(A_REWOKEN)
    assert [a["text"] for a in r.activity()][:3] == ["Edited the second sketch", "Got a new task", "Handed back its report"]


def test_one_transcript_damaged_lines():
    dm = summary(A_DAMAGED)
    # lines: spliced (bad, but the whole record after the cut is kept), plain garbage (bad), half-written last line (bad)
    assert dm.bad == 3, dm.bad
    assert dm.steps == 3, dm.steps          # the first, the whole record found after the cut-off one, and the third
    texts = [a["text"] for a in dm.activity()]
    assert "Checked the second page" in texts and "Checked the third page" in texts and "Checked the first page" in texts, texts


def test_cli_end_to_end():
    build_fixtures()
    d = work_copy("e2e")
    before = sha(d / "workers.json")
    out = d / "out.json"
    text = run("--in", d / "workers.json", "--out", out, "--tool-words")
    assert out.is_file() and sha(d / "workers.json") == before, "the input must not change"
    old, new = by_id(d / "workers.json"), by_id(out)
    assert list(old) == list(new), "same documents, same order"
    live = set(wl.LIVE_KEYS)
    for i in old:
        assert list(old[i]) == list(new[i]), i
        for k in old[i]:
            if k not in live:
                assert old[i][k] == new[i][k], f"{i}.{k} must not change"
    st = {i: new[i]["state"] for i in new}
    assert st["w-working"] == "working" and st["w-done"] == "done" and st["w-rewoken"] == "working" and st["w-resting"] == "resting"
    assert st["w-waiting"] == "waiting" and st["w-waitexp"] == "resting" and st["w-longcmd"] == "working" and st["w-longcmd2"] == "resting"
    assert st["w-damaged"] == "resting" and st["w-nodesc"] == "working" and st["w-bgbash"] == "waiting"
    assert st["w-humanwait"] == "waiting", "waiting for her stays while the file shows nothing new"
    assert st["w-stopped"] == "stopped", "stopped is never overwritten"
    assert st["w-found"] == "working", "found by its start time"
    assert st["w-nomap"] == "working" and st["claude"] == "working" and st["team-a"] == "working", "no transcript: untouched"
    assert new["w-nomap"] == old["w-nomap"] and new["claude"] == old["claude"] and new["team-a"] == old["team-a"]
    # now / finishedAt / waitingFor rules
    n = new["w-working"]
    assert n["now"] == "Running the status check alone" and n["startedAt"] == at("11:00") and n["updatedAt"] == at("11:58:05")
    assert n["finishedAt"] is None and len(n["activity"]) == 3 and n["activity"][0]["at"].endswith("Z")
    assert new["w-done"]["now"] == "" and new["w-done"]["finishedAt"] == at("09:30:01") and new["w-done"]["startedAt"] == at("08:00")
    assert new["w-rewoken"]["finishedAt"] is None and new["w-rewoken"]["now"] == "Editing the second sketch"
    assert new["w-resting"]["now"] == "" and new["w-waitexp"]["waitingFor"] == "none", "no longer waiting: nobody is waited for"
    assert new["w-waiting"]["state"] == "waiting" and new["w-waiting"]["now"] == "Watching the long check run"
    assert new["w-bgbash"]["now"] == "Building the big pictures in the background" and new["w-bgbash"]["waitingFor"] == "none"
    assert new["w-nodesc"]["now"] == "Drawing the farm map in one quick sample", new["w-nodesc"]["now"]    # no description: the role line
    assert new["w-nouns"]["now"] == "Working on its task", new["w-nouns"]["now"]      # --tool-words is the last resort
    assert new["w-humanwait"]["now"] == "Waiting for your answer about the strip." and new["w-humanwait"]["waitingFor"] == "owner"
    assert new["w-humanwait"]["activity"][0]["text"] == "Handed back its report", "its activity still refreshes"
    assert new["w-stopped"]["now"] == "" and new["w-stopped"]["state"] == "stopped"
    # the lead's jargon examples: only the plain one reaches the page, the rest fall back to the role line
    assert new["w-jargon"]["now"] == "Running access checks and flow checks", new["w-jargon"]["now"]
    assert [e["text"] for e in new["w-jargon"]["activity"]] == ["Ran access checks and flow checks", "Got the task"], new["w-jargon"]["activity"]
    assert new["w-jargon2"]["now"] == "Checking the farm map pictures for mistakes", new["w-jargon2"]["now"]
    assert [e["text"] for e in new["w-jargon2"]["activity"]] == ["Got the task"]
    assert new["w-nouns"]["now"] == "Working on its task", "a past-tense role is not a 'right now' line; a line with no verb first is not used"
    assert [e["text"] for e in new["w-nouns"]["activity"]] == ["Got the task"]
    banned = re.compile(r"\b(tests?|testing|suites?|a11y|schema|colour\w*|re-?run\w*|code|states?|processes|expectations?)\b", re.I)
    for i, doc in new.items():
        for line in [doc["now"]] + [e["text"] for e in doc["activity"]]:
            if i not in ("claude", "team-a", "w-nomap", "w-rewoken"):          # untouched documents keep the lead's own words
                assert not banned.search(line), (i, line)
    for i, doc in new.items():
        assert len(doc["activity"]) <= 8
        assert len(doc["now"]) <= 140 and "\n" not in doc["now"]
        if doc["state"] not in ("working", "waiting"):
            assert doc["now"] == "", (i, doc["now"])
        for e in doc["activity"]:
            assert re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", e["at"]) and e["text"]
        times = [e["at"] for e in doc["activity"]]
        assert times == sorted(times, reverse=True), i
    # the report
    assert "NOT MAPPED" in text and "w-nomap" in text, text
    assert f"w-found={A_FOUND}" in text
    assert A_NOBODY in text, "a transcript with no worker is reported"
    assert re.search(r"w-working\s+working\s+2m\s+8\s", text), text
    assert re.search(r"w-done\s+working > done\s+2h30m\s+2\s", text), text
    assert "Left as they are" in text and "claude" in text
    # the file passes the Terminal's own check
    chk = d / "chk"
    chk.mkdir()
    shutil.copy(out, chk / "workers.json")
    (chk / "tasks.json").write_text("[]", encoding="utf-8")
    p = subprocess.run(PY + [str(HERE / "terminal_state.py"), "check", "--state-dir", str(chk), "--export", str(d / "none"), "--outbox", str(d / "ob")],
                       capture_output=True, text=True, timeout=120)
    assert p.returncode == 0, p.stdout + p.stderr
    for marker in SECRETS:
        assert marker not in out.read_text(encoding="utf-8")


def test_cli_without_tool_words_uses_the_role_line():
    d = work_copy("notw")
    out = d / "out.json"
    run("--in", d / "workers.json", "--out", out)
    new = by_id(out)
    assert new["w-nodesc"]["state"] == "working"
    assert new["w-working"]["now"] == "Running the status check alone"      # the newest plain one among the last 12 calls
    assert new["w-nodesc"]["now"] == "Drawing the farm map in one quick sample", new["w-nodesc"]["now"]    # the role line, as a last resort
    assert new["w-nouns"]["now"] == "", "a past-tense role is not a 'right now' line: left empty without --tool-words"
    assert "used its role line" in run("--in", d / "workers.json", "--dry-run", "--only", "w-nodesc")


def test_cli_dry_run_and_defaults_write_nothing():
    d = work_copy("dry")
    out = d / "out.json"
    text = run("--in", d / "workers.json", "--out", out, "--dry-run")
    assert not out.exists() and "Dry run" in text
    assert not (TMP / "outbox").exists()
    # --dry-run --write-map saves only the map
    (d / "worker-agents.json").unlink()
    text = run("--in", d / "workers.json", "--dry-run", "--write-map")
    assert (d / "worker-agents.json").is_file() and jload(d / "worker-agents.json") == {"w-found": A_FOUND}
    assert not out.exists()
    # a second run uses the map
    text = run("--in", d / "workers.json", "--dry-run")
    assert "Matched by exact start time" not in text and "w-found" in text


def test_cli_only_skip_since():
    d = work_copy("sel")
    out = d / "out.json"
    run("--in", d / "workers.json", "--out", out, "--only", "w-done,w-resting")
    new, old = by_id(out), by_id(d / "workers.json")
    changed = [i for i in new if new[i] != old[i]]
    assert sorted(changed) == ["w-done", "w-resting"], changed
    run("--in", d / "workers.json", "--out", out, "--skip", "w-working", "--skip", "w-done")
    new = by_id(out)
    assert new["w-working"] == old["w-working"] and new["w-done"] == old["w-done"] and new["w-resting"] != old["w-resting"]
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--now", NOW, "--in", str(d / "workers.json"), "--only", "nobody-here"],
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "Not in the workers file" in p.stderr
    # --since: transcripts untouched since then are left alone (file times are "now" here, so make some old)
    old_time = datetime.datetime(2026, 10, 7, 9, 0, 0).timestamp()
    for n in (A_DONE, A_RESTING):
        os.utime(TRANS / f"{n}.output", (old_time, old_time))
    run("--in", d / "workers.json", "--out", out, "--since", "2026-10-07T10:00:00Z")
    new = by_id(out)
    assert new["w-done"] == old["w-done"], "its file is older than --since"
    assert new["w-resting"] == old["w-resting"]
    assert new["w-working"] != old["w-working"]
    # even when the file is new, activity older than --since does not count: the helper's last event decides
    run("--in", d / "workers.json", "--out", out, "--since", "20m")
    assert by_id(out)["w-damaged"] == old["w-damaged"], "last event 11:30 is older than 20 minutes"
    assert by_id(out)["w-working"] != old["w-working"]
    assert wl.parse_since("2h", NOW_DT) == NOW_DT - datetime.timedelta(hours=2)
    assert wl.parse_since("2026-10-07T10:00:00Z", NOW_DT) == datetime.datetime(2026, 10, 7, 10, 0, tzinfo=datetime.timezone.utc)
    build_fixtures()        # restore the file times


def test_cli_handed_back_and_keep_activity():
    d = work_copy("opts")
    out = d / "out.json"
    run("--in", d / "workers.json", "--out", out, "--handed-back", "resting", "--keep-activity")
    new, old = by_id(out), by_id(d / "workers.json")
    assert new["w-done"]["state"] == "resting" and new["w-done"]["finishedAt"] is None and new["w-done"]["now"] == ""
    assert new["w-working"]["activity"] == old["w-working"]["activity"] == []
    assert new["w-working"]["state"] == "working"


def test_cli_in_place_makes_a_backup_and_refuses_overwrite():
    d = work_copy("inplace")
    ob = d / "ob"
    before = (d / "workers.json").read_bytes()
    run("--in", d / "workers.json", "--in-place", "--outbox", ob)
    after = by_id(d / "workers.json")
    assert after["w-done"]["state"] == "done"
    backups = list((ob / "backup-state").glob("workers-*.json"))
    assert len(backups) == 1 and backups[0].read_bytes() == before
    assert not list(d.glob("*.tmp"))
    # --out equal to --in without --in-place
    d2 = work_copy("inplace2")
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--now", NOW, "--in", str(d2 / "workers.json"),
                             "--out", str(d2 / "workers.json")], capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "overwrite" in p.stderr, p.stderr
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--in", str(d2 / "workers.json"), "--in-place",
                             "--out", str(d2 / "x.json")], capture_output=True, text=True, timeout=60)
    assert p.returncode == 2


def test_cli_bad_input_is_a_clear_message():
    d = work_copy("bad")
    (d / "workers.json").write_text("{not json", encoding="utf-8")
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--in", str(d / "workers.json"), "--out", str(d / "o.json")],
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "Could not read" in p.stderr and "Traceback" not in p.stderr
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TMP / "nope"), "--in", str(FIX / "workers.json"), "--out", str(d / "o.json")],
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "no folder with transcripts" in p.stderr
    p = subprocess.run(PY + [str(HERE / "workers_live.py"), "--tasks-dir", str(TRANS), "--in", str(FIX / "workers.json"), "--since", "yesterday", "--dry-run"],
                       capture_output=True, text=True, timeout=60)
    assert p.returncode == 2 and "--since" in p.stderr


def test_map_file_is_safe():
    d = work_copy("map")
    (d / "worker-agents.json").write_text(json.dumps({"w-working": "../../etc/passwd", "w-done": A_MISSING}), encoding="utf-8")
    text = run("--in", d / "workers.json", "--dry-run", "--no-discover")
    assert "transcript file not found" in text and f"w-done ({A_MISSING})" in text
    assert wl.transcript_path(TRANS, "../../etc/passwd") is None and wl.transcript_path(TRANS, "") is None
    assert wl.transcript_path(TRANS, A_WORKING) is not None


def test_discovery_needs_an_exact_unique_match():
    docs = jload(FIX / "workers.json")
    found, problems = wl.discover(docs, {}, TRANS)
    assert found.get("w-found") == A_FOUND and "w-nomap" not in found, found
    # two helpers with the same start time: not guessed
    twin = dict(docs[0], id="w-twin", kind="helper", startedAt=at("10:11:12"), parentId="team-a")
    found, problems = wl.discover(docs + [twin], {}, TRANS)
    assert "w-found" not in found and "w-twin" not in found and problems, (found, problems)
    # a teams' start time is never used
    team = dict(docs[1], startedAt=at("10:11:12"))
    found, problems = wl.discover([team], {}, TRANS)
    assert found == {}


def test_guard_blocks_changes_outside_the_live_fields():
    old = worker("w-x", "X")
    new = dict(old, name="Other")
    try:
        wl.guard(old, new)
    except RuntimeError:
        pass
    else:
        raise AssertionError("guard let a name change through")
    new = dict(old, now="Deploy the database")
    try:
        wl.guard(old, new)
    except RuntimeError:
        pass
    else:
        raise AssertionError("guard let jargon through")
    wl.guard(old, dict(old, now="Drawing the hills", state="working"))


def test_speed_on_a_big_fixture():
    import time
    t = Tx(A_BIG)
    t.prompt(at("08:00"))
    for i in range(3000):
        t.call(at("09:00"), desc=f"Check page number {i % 7}", result_at=at("09:00:01"))
    t.save()
    t0 = time.time()
    s = summary(A_BIG)
    assert time.time() - t0 < 5 and s.steps == 3000
    assert len(s.activity()) == 8 and len({a["text"] for a in s.activity()}) == 8
    (TRANS / f"{A_BIG}.output").unlink()


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else ""
    build_fixtures()
    names = [n for n in sorted(globals()) if n.startswith("test_") and only in n]
    failed = 0
    for n in names:
        try:
            globals()[n]()
            print("PASS", n)
        except Exception:
            failed += 1
            print("FAIL", n)
            traceback.print_exc()
    shutil.rmtree(TMP, ignore_errors=True)
    print(f"{len(names) - failed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
