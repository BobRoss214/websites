#!/usr/bin/env node
/* snap.mjs - take pictures of a web page (or of a folder served on the fly).

   NODE_PATH=/opt/node22/lib/node_modules node snap.mjs --url <address|file> --out shot.png [options]

   --url X            address (https://, http://, file://, data:) or a file on disk. With --serve, a path inside that folder (default "/")
   --out FILE.png     where to save the picture (.jpg also works). Not needed when --steps has {shot:...} steps
   --w 1366 --h 768   window size in pixels (default 1366 x 768)
   --scale 1          pixel density (2 = sharper, twice the pixels)
   --full             the whole page, not only the window
   --selector CSS     only this element
   --clip x,y,w,h     only this rectangle
   --wait 500         pause (ms) before each shot so animations settle (default 400)
   --wait-for CSS     wait until this element is visible before anything else
   --dark             dark colour scheme          --reduced-motion   ask the page for less movement
   --no-webp          pretend this browser cannot draw WebP (every .webp file arrives broken): shows what an old Mac sees
   --still            freeze CSS animations at their end before each shot (steady pictures of moving dots)
   --lang en-US       browser language            --tz America/New_York   time zone (default New York)
   --eval "JS"        run this in the page before the shot (use @file.js to read it from a file)
   --init FILE.js     run this file before the page's own scripts (repeatable; e.g. test/mock-claude.js)
   --steps FILE.json  a list of steps, run in order, each one of:
                        {"click":"css"}  {"hover":"css"}  {"type":{"sel":"css","text":"hello"}}  {"press":"Enter"}
                        {"wait":300}  {"eval":"js"}  {"scroll":"css"|number}  {"viewport":"700x800"}  {"goto":"url"}
                        {"shot":"out.png"}   (also: "selector", "clip":[x,y,w,h], "full":true next to "shot")
   --serve DIR        serve this folder on 127.0.0.1 for the run, then stop it (port: --port N, default the first free one in 9800-9899)
   --set-date YYYY-MM-DD[THH:MM]   make the page believe it is that day (default time 12:00); the clock then keeps running
   --freeze           with --set-date: stop the clock at that moment
   --timeout 90000    give up after this many ms (default 90000)

   Exit code 0 = every picture saved. 1 = something failed (a plain message on stderr). 2 = wrong options. */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const BOOL = new Set(['full', 'dark', 'reduced-motion', 'freeze', 'still', 'no-webp', 'help']);
let STILL = false;   // --still: finish or stop CSS animations before each shot
const VALUE = new Set(['url', 'out', 'w', 'h', 'scale', 'selector', 'clip', 'wait', 'wait-for', 'eval', 'steps', 'serve', 'port', 'set-date', 'tz', 'lang', 'timeout', 'init']);

class Usage extends Error {}
const fail = (m) => { throw new Error(m); };

function parseArgs(argv) {
  const o = { init: [] };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (!a.startsWith('--')) throw new Usage(`unexpected "${a}" (options start with --; see --help)`);
    let key = a.slice(2), val;
    const eq = key.indexOf('=');
    if (eq > 0) { val = key.slice(eq + 1); key = key.slice(0, eq); }
    if (BOOL.has(key)) { o[key] = true; continue; }
    if (!VALUE.has(key)) throw new Usage(`unknown option --${key} (see --help)`);
    if (val === undefined) { val = argv[++i]; if (val === undefined) throw new Usage(`--${key} needs a value`); }
    if (key === 'init') o.init.push(val); else o[key] = val;
  }
  return o;
}

function num(o, key, def, { min = -Infinity, int = false } = {}) {
  if (o[key] === undefined) return def;
  const n = Number(o[key]);
  if (!Number.isFinite(n) || n < min || (int && !Number.isInteger(n))) throw new Usage(`--${key} must be ${int ? 'a whole ' : 'a '}number${min > -Infinity ? ' of at least ' + min : ''} (got "${o[key]}")`);
  return n;
}

function loadPlaywright() {
  const req = createRequire(import.meta.url);
  const dirs = [...(process.env.NODE_PATH || '').split(path.delimiter), '/opt/node22/lib/node_modules', '/usr/lib/node_modules', '/usr/local/lib/node_modules'].filter(Boolean);
  try { return req('playwright'); } catch (e) { /* try the global folders */ }
  for (const d of dirs) {
    try { return req(path.join(d, 'playwright')); } catch (e) { /* next */ }
  }
  fail('Playwright was not found. Run with NODE_PATH=/opt/node22/lib/node_modules (it is installed there).');
}

/* ---------- tiny static server ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml', '.webmanifest': 'application/manifest+json', '.mp4': 'video/mp4' };

function startServer(root, port) {
  root = path.resolve(root);
  if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) fail(`--serve: "${root}" is not a folder`);
  const srv = http.createServer((req, res) => {
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); res.end('Bad request'); return; }
    let file = path.join(root, pathname);
    if (file !== root && !file.startsWith(root + path.sep)) { res.writeHead(403); res.end('Forbidden'); return; }
    try { if (fs.statSync(file).isDirectory()) file = path.join(file, 'index.html'); } catch (e) { /* 404 below */ }
    fs.readFile(file, (err, body) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return; }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  });
  const listen = (p) => new Promise((resolve, reject) => { srv.once('error', reject); srv.listen(p, '127.0.0.1', () => { srv.removeAllListeners('error'); resolve(p); }); });
  return (async () => {
    if (port) { try { await listen(port); } catch (e) { fail(`--port ${port} is not free (${e.code || e.message})`); } }
    else {
      let ok = false;
      for (let p = 9800; p <= 9899 && !ok; p++) { try { await listen(p); port = p; ok = true; } catch (e) { /* in use: next */ } }
      if (!ok) fail('no free port between 9800 and 9899 for --serve');
    }
    return { port, url: `http://127.0.0.1:${port}/`, close: () => new Promise((r) => { srv.closeAllConnections && srv.closeAllConnections(); srv.close(() => r()); }) };
  })();
}

/* ---------- the date trick ---------- */
function dateScript(spec, freeze) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{1,2}):(\d{2}))?$/.exec(spec);
  if (!m) throw new Usage(`--set-date must look like 2026-12-15 or 2026-12-15T09:30 (got "${spec}")`);
  const parts = [Number(m[1]), Number(m[2]), Number(m[3]), m[4] === undefined ? 12 : Number(m[4]), m[5] === undefined ? 0 : Number(m[5])];
  const probe = new Date(parts[0], parts[1] - 1, parts[2]);
  if (probe.getMonth() !== parts[1] - 1 || probe.getDate() !== parts[2] || parts[3] > 23 || parts[4] > 59) throw new Usage(`--set-date "${spec}" is not a real date`);
  return `(() => {
    const R = Date, p = ${JSON.stringify(parts)}, frozen = ${freeze ? 'true' : 'false'};
    const T0 = new R(p[0], p[1] - 1, p[2], p[3], p[4], 0, 0).getTime(), start = R.now();
    const now = () => (frozen ? T0 : T0 + (R.now() - start));
    const P = new Proxy(R, {
      construct(t, args, nt) { return args.length === 0 ? new t(now()) : Reflect.construct(t, args, nt === P ? t : nt); },
      apply() { return new R(now()).toString(); },
      get(t, k) { return k === 'now' ? now : Reflect.get(t, k, t); },
    });
    Object.defineProperty(window, 'Date', { value: P, configurable: true, writable: true });
  })();`;
}

/* ---------- pictures ---------- */
function describeShot(file) {
  const buf = fs.readFileSync(file);
  let dim = '';
  if (buf.length > 24 && buf.toString('latin1', 1, 4) === 'PNG') dim = `${buf.readUInt32BE(16)}x${buf.readUInt32BE(20)}, `;
  return `${path.resolve(file)}  (${dim}${Math.max(1, Math.round(buf.length / 1024))} KB)`;
}

async function shoot(page, file, opt, saved) {
  if (!file) fail('a shot needs a file name');
  const abs = path.resolve(file);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  const type = /\.jpe?g$/i.test(abs) ? 'jpeg' : 'png';
  if (!/\.(png|jpe?g)$/i.test(abs)) fail(`"${file}": pictures must be saved as .png or .jpg`);
  const base = { path: abs, type, ...(type === 'jpeg' ? { quality: 88 } : {}), ...(STILL ? { animations: 'disabled' } : {}) };
  if (opt.selector) {
    const loc = page.locator(opt.selector).first();
    try { await loc.waitFor({ state: 'visible', timeout: 5000 }); } catch (e) { fail(`nothing visible matches "${opt.selector}" on the page`); }
    await loc.screenshot(base);
  } else {
    let clip;
    if (opt.clip) {
      const c = (Array.isArray(opt.clip) ? opt.clip : String(opt.clip).split(',')).map(Number);
      if (c.length !== 4 || c.some((n) => !Number.isFinite(n)) || c[2] <= 0 || c[3] <= 0) throw new Usage('--clip needs x,y,width,height, for example 0,0,700,400');
      clip = { x: c[0], y: c[1], width: c[2], height: c[3] };
    }
    await page.screenshot({ ...base, fullPage: !!opt.full, ...(clip ? { clip } : {}) });
  }
  saved.push(abs);
  console.log('saved ' + describeShot(abs));
}

async function settle(page, ms) {
  await page.evaluate(async () => {
    const cap = (p, t) => Promise.race([p, new Promise((r) => setTimeout(r, t))]);
    try { await cap(document.fonts.ready, 3000); } catch (e) { /* no fonts API */ }
    const pending = [...document.images].filter((i) => !i.complete);
    await cap(Promise.all(pending.map((i) => new Promise((r) => { i.addEventListener('load', r); i.addEventListener('error', r); }))), 8000);
  }).catch(() => {});
  if (ms > 0) await page.waitForTimeout(ms);
}

async function runStep(page, st, i, ctx) {
  const where = `step ${i + 1}`;
  if (!st || typeof st !== 'object' || Array.isArray(st)) fail(`${where} is not an object like {"click":"#go"}`);
  const keys = Object.keys(st).filter((k) => !['selector', 'clip', 'full'].includes(k));
  if (keys.length !== 1) fail(`${where} must have exactly one of click, hover, type, press, wait, eval, scroll, viewport, goto, shot (got ${keys.join(', ') || 'nothing'})`);
  const k = keys[0], v = st[k];
  const named = `${where} (${k}${typeof v === 'string' ? ' "' + v.slice(0, 40) + '"' : ''})`;
  try {
    switch (k) {
      case 'click': await page.click(v, { timeout: 5000 }); break;
      case 'hover': await page.hover(v, { timeout: 5000 }); break;
      case 'type': {
        if (!v || typeof v.sel !== 'string' || typeof v.text !== 'string') fail('type needs {"sel":"css","text":"..."}');
        if (v.keys) { await page.click(v.sel, { timeout: 5000 }); await page.keyboard.type(v.text, { delay: 10 }); } else await page.fill(v.sel, v.text, { timeout: 5000 });
        break;
      }
      case 'press': await page.keyboard.press(String(v)); break;
      case 'wait': await page.waitForTimeout(Number(v) || 0); return;
      case 'eval': { const r = await page.evaluate(v); if (r !== undefined) console.log('eval result: ' + JSON.stringify(r)); break; }
      case 'scroll': if (typeof v === 'number') await page.evaluate((y) => window.scrollTo(0, y), v); else await page.locator(v).first().scrollIntoViewIfNeeded({ timeout: 5000 }); break;
      case 'viewport': {
        const m = /^(\d+)\s*x\s*(\d+)$/i.exec(String(v));
        if (!m) fail('viewport must look like "700x800"');
        await page.setViewportSize({ width: Number(m[1]), height: Number(m[2]) });
        break;
      }
      case 'goto': await page.goto(ctx.resolve(v), { waitUntil: 'load', timeout: 30000 }); break;
      case 'shot': await settle(page, ctx.wait); await shoot(page, v, { selector: st.selector, clip: st.clip, full: st.full }, ctx.saved); return;
      default: fail(`${where}: unknown step "${k}"`);
    }
  } catch (e) {
    if (e instanceof Usage) throw e;
    const first = String(e.message).split('\n')[0];
    throw new Error(`${named} failed: ${/Timeout/.test(first) ? 'nothing matching it was ready within 5 s' : first}`);
  }
  await page.waitForTimeout(150);
}

async function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.help) { console.log(fs.readFileSync(new URL(import.meta.url), 'utf8').split('*/')[0].replace(/^\/\*\s?/, '')); return; }
  const W = num(o, 'w', 1366, { min: 100, int: true }), H = num(o, 'h', 768, { min: 100, int: true });
  const scale = num(o, 'scale', 1, { min: 0.5 }), wait = num(o, 'wait', 400, { min: 0 }), timeout = num(o, 'timeout', 90000, { min: 1000 });
  const port = o.port === undefined ? 0 : num(o, 'port', 0, { min: 1024, int: true });
  let steps = [];
  if (o.steps) {
    try { steps = JSON.parse(fs.readFileSync(o.steps, 'utf8')); } catch (e) { throw new Usage(`--steps ${o.steps}: ${e.message}`); }
    if (!Array.isArray(steps)) throw new Usage('--steps file must hold a list [ {...}, {...} ]');
  }
  const hasShotStep = steps.some((s) => s && s.shot);
  if (!o.out && !hasShotStep) throw new Usage('nothing to save: give --out FILE.png (or {"shot":"file.png"} steps)');
  if (!o.url && !o.serve) throw new Usage('give --url (an address or a file), or --serve DIR');
  for (const f of o.init) if (!fs.existsSync(f)) throw new Usage(`--init file not found: ${f}`);
  let evalText = o.eval;
  if (evalText && evalText.startsWith('@')) { try { evalText = fs.readFileSync(evalText.slice(1), 'utf8'); } catch (e) { throw new Usage(`--eval ${evalText}: ${e.message}`); } }
  STILL = !!o.still;
  const initDate = o['set-date'] ? dateScript(o['set-date'], !!o.freeze) : null;
  if (o.freeze && !o['set-date']) throw new Usage('--freeze only makes sense with --set-date');

  let server = null, browser = null;
  const saved = [], notes = [];
  const watchdog = setTimeout(() => { console.error(`snap: stopped after ${Math.round(timeout / 1000)} s (use --timeout to allow more)`); process.exit(1); }, timeout);
  try {
    if (o.serve) server = await startServer(o.serve, port);
    const resolve = (u) => {
      if (/^(https?:|file:|data:|about:)/i.test(u)) return u;
      if (server) return server.url + String(u).replace(/^\/+/, '');
      const f = path.resolve(u);
      if (!fs.existsSync(f)) fail(`file not found: ${u}`);
      return pathToFileURL(f).href;
    };
    const target = resolve(o.url || '/');

    const pw = loadPlaywright();
    if (!process.env.PLAYWRIGHT_BROWSERS_PATH && fs.existsSync('/opt/pw-browsers')) process.env.PLAYWRIGHT_BROWSERS_PATH = '/opt/pw-browsers';
    try { browser = await pw.chromium.launch({ executablePath: process.env.WA_CHROME || undefined, timeout: 45000 }); }
    catch (e) { fail('could not start the browser (' + String(e.message).split('\n')[0] + ')'); }
    const ctx = await browser.newContext({
      viewport: { width: W, height: H }, deviceScaleFactor: scale, colorScheme: o.dark ? 'dark' : 'light',
      reducedMotion: o['reduced-motion'] ? 'reduce' : 'no-preference', locale: o.lang || 'en-US', timezoneId: o.tz || 'America/New_York',
    });
    if (o['no-webp']) await ctx.route(/\.webp(\?.*)?$/i, (r) => r.fulfill({ status: 200, contentType: 'image/webp', body: 'this is not a picture' }));
    const page = await ctx.newPage();
    page.setDefaultTimeout(10000);
    page.on('pageerror', (e) => notes.push('the page reported an error: ' + String(e.message).split('\n')[0]));
    page.on('requestfailed', (r) => { if (!/^data:/.test(r.url())) notes.push(`could not load ${r.url().slice(0, 120)} (${r.failure() && r.failure().errorText})`); });
    page.on('response', (r) => { if (r.status() >= 400 && r.request().resourceType() !== 'document') notes.push(`${r.status()} for ${r.url().slice(0, 120)}`); });
    if (initDate) await page.addInitScript(initDate);
    for (const f of o.init) await page.addInitScript({ path: path.resolve(f) });

    let resp;
    try { resp = await page.goto(target, { waitUntil: 'load', timeout: 30000 }); }
    catch (e) { fail(`could not open ${target.slice(0, 150)} (${String(e.message).split('\n')[0]})`); }
    if (resp && resp.status() >= 400) fail(`${target.slice(0, 150)} answered with error ${resp.status()}`);
    if (o['wait-for']) { try { await page.locator(o['wait-for']).first().waitFor({ state: 'visible', timeout: 10000 }); } catch (e) { fail(`"${o['wait-for']}" never showed up on the page`); } }
    await settle(page, 0);
    if (evalText) {
      try { const r = await page.evaluate(evalText); if (r !== undefined) console.log('eval result: ' + JSON.stringify(r)); }
      catch (e) { fail('--eval failed: ' + String(e.message).split('\n')[0]); }
    }
    const sctx = { wait, saved, resolve };
    for (let i = 0; i < steps.length; i++) await runStep(page, steps[i], i, sctx);
    if (o.out) { await settle(page, wait); await shoot(page, o.out, { selector: o.selector, clip: o.clip, full: o.full }, saved); }
  } finally {
    clearTimeout(watchdog);
    for (const n of [...new Set(notes)].slice(0, 8)) console.error('note: ' + n);
    if (browser) await browser.close().catch(() => {});
    if (server) await server.close();
  }
}

main().then(() => process.exit(0), (e) => {
  console.error('snap: ' + (e && e.message ? e.message : e));
  process.exit(e instanceof Usage ? 2 : 1);
});
