#!/usr/bin/env python3
"""Keep the Workers and Tasks parts of the Terminal true. Scripts only PREPARE files; Claude then calls ArtifactData.

Claude keeps two plain files, state/workers.json and state/tasks.json (lists of documents, see SPEC2.md section 3).
This tool compares them with the live copy and writes ready-to-send batch files. It never writes the owner's
collections (taskAdds, taskEdits, asks): those are hers.

    python3 -I terminal_state.py export  [--only a,b] [--url URL]       the ArtifactData "list" calls that fetch the live copy
    python3 -I terminal_state.py check                                  look for mistakes in the state files
    python3 -I terminal_state.py sync    [--only workers|tasks] [--dry-run] [--skip-bad]
    python3 -I terminal_state.py worker  ID [--name .. --kind .. --parent ID|none --role .. --icon ..]
                                         [--state working|waiting|resting|done|stopped] [--now TEXT] [--waiting-for who]
                                         [--activity TEXT]... [--result TEXT] [--task ID]... [--drop-task ID]...
                                         [--brain Claude|Sonnet|Opus] [--progress N|none] [--order N] [--sync]
    python3 -I terminal_state.py task    ID [ID ...] [--title .. --plain .. --parent ID|none]
                                         [--state todo|working|waiting|done|paused] [--waiting-for who] [--note TEXT]
                                         [--worker ID]... [--drop-worker ID]... [--question ID]... [--drop-question ID]...
                                         [--seen] [--order N] [--sync]
    python3 -I terminal_state.py adopt   TASKADD_ID [TASKADD_ID ...] [--state ..] [--note ..] [--worker ID]... [--sync]
    python3 -I terminal_state.py reply   ASK_ID --state seen|working|answered [--text TEXT] [--from NAME]
    python3 -I terminal_state.py reply   --file replies.json            [{"ask":"..","state":"answered","text":"..","from":".."}, ...]
    python3 -I terminal_state.py applied BATCHFILE [--results RESULTS.json] [--again]

Where things are (change with the options, or the environment variables in brackets):
    --state-dir DIR   state/workers.json and state/tasks.json   (default: state/ next to tools/)   [QT_STATE_DIR]
    --export DIR      the live copy ArtifactData wrote with out_dir (default: outbox/export)      [QT_EXPORT]
    --outbox DIR      where batch files go: <outbox>/state-<time>/batch-N.json                    [QT_OUTBOX]
    --versions FILE / --version PATH=N / --no-versions   same as status.py (default: outbox/versions.json and the live copy)
    --allow-words a,b  let a word past the "no jargon" check

The usual round:  export (then the list calls)  ->  worker / task / adopt / reply (edit the state files)  ->  sync
                  ->  ArtifactData batch  ->  applied.   See notes/STATE-FILES.md.
Exit 0 = done, 1 = nothing to do or already recorded, 2 = a request that cannot be done (the reason is printed in plain words).
"""
import argparse
import copy
import json
import os
import re
import sys
import importlib.util as _iu
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _load(name):
    spec = _iu.spec_from_file_location(name, HERE / (name + ".py"))
    mod = _iu.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


qt = _load("qtlib")
ra = _load("read_answers")

# ------------------------------------------------------------------------------------------------ the words of the data
WORKER_STATES = ("working", "waiting", "resting", "done", "stopped")
WORKER_KINDS = ("lead", "team", "helper")
WORKER_WAIT = ("owner", "cathy", "rob", "claude", "none")
BRAINS = ("Claude", "Sonnet", "Opus", "")
TASK_STATES = ("todo", "working", "waiting", "done", "paused")
TASK_WAIT = ("owner", "cathy", "rob", "none")
REPLY_STATES = ("seen", "working", "answered")
REPLY_ORDER = {"seen": 1, "working": 2, "answered": 3}
TARGET_KINDS = ("worker", "task")

WORKER_FIELDS = ("id", "name", "parentId", "kind", "icon", "role", "state", "now", "waitingFor", "startedAt", "updatedAt", "finishedAt",
                 "activity", "result", "taskIds", "brain", "progress", "order")
TASK_FIELDS = ("id", "parentId", "title", "plain", "state", "waitingFor", "workerIds", "questionIds", "note", "order", "createdAt",
               "updatedAt", "doneAt", "createdBy", "seenAt")
WRITABLE = ("workers", "tasks", "replies")                 # the only collections this tool may write
LIVE_COLLS = ("workers", "tasks", "replies", "taskAdds", "taskEdits", "asks")   # what `export` fetches
SEPARATE_ONE_LINE = ("name", "role", "now", "title", "note")
MARK = ".qt-export"
STALE_MIN = 45

# (warn above, error above) in characters; None = no limit of that kind
LIMITS = {
    ("workers", "name"): (60, 80), ("workers", "role"): (None, 90), ("workers", "now"): (None, 140), ("workers", "result"): (None, 300),
    ("workers", "activity"): (200, 300), ("tasks", "title"): (None, 80), ("tasks", "plain"): (300, 600), ("tasks", "note"): (200, 400),
    ("replies", "text"): (None, 1200), ("replies", "from"): (None, 60),
}
MAX_WORD = 120   # one "word" with no spaces longer than this can freeze the page layout

# the spec bans a few more words than status.py checks (SPEC2 section 1)
EXTRA_JARGON = re.compile(r"\b(agents?|sub-?agents?|models?)\b", re.I)
SAY_INSTEAD = {"agent": "worker", "agents": "workers", "subagent": "worker", "sub-agent": "worker", "subagents": "workers", "sub-agents": "workers",
               "model": "leave it out", "repo": "the files", "repos": "the files", "deploy": "put online", "commit": "save",
               "sync": "update", "token": "a code", "database": "the notebook", "api": "the connection"}
WRONG_NAME = re.compile(r"\b(Ms\.?\s+Cathy|Kathy|Miss\s+Kathy)\b")   # she is "Miss Cathy"
# plain-words house rules for what she reads (a NOTE, not a mistake): "worker" never "helper", "task" never "job", "Claude" never "I" or "we", US spelling
HOUSE_WORDS = [
    (re.compile(r"\b(helpers?)\b", re.I), lambda w: "worker" + ("s" if w.lower().endswith("s") else "")),
    (re.compile(r"\b(jobs?)\b", re.I), lambda w: "task" + ("s" if w.lower().endswith("s") else "")),
    (re.compile(r"\b(I|I'm|I've|I'll|I'd)\b|\b(?i:we|we're|we've|we'll|our|ours|let's|my|me)\b"), lambda w: "Claude"),
    (re.compile(r"\b(grey(?:s|ish)?|colou?r\w*|centre[sd]?|neighbou?r\w*|favou?rite\w*|organis\w+|recognis\w+|licen[cs]es?|behaviour\w*|analys(?:e|ed|es|ing)|"
                r"programme\w*|catalogue\w*|cancell?ed|travell?ed|labell?ed)\b", re.I), None),   # US spelling: checked below by what each word is
]
UK_TO_US = [(re.compile(r"grey"), "gray"), (re.compile(r"colour"), "color"), (re.compile(r"centre"), "center"), (re.compile(r"neighbour"), "neighbor"),
            (re.compile(r"favourite"), "favorite"), (re.compile(r"organis"), "organiz"), (re.compile(r"recognis"), "recogniz"), (re.compile(r"behaviour"), "behavior"),
            (re.compile(r"analys(?=e|ed|es|ing)"), "analyz"), (re.compile(r"programme"), "program"), (re.compile(r"catalogue"), "catalog"),
            (re.compile(r"cancelled"), "canceled"), (re.compile(r"travelled"), "traveled"), (re.compile(r"labelled"), "labeled"), (re.compile(r"licence"), "license")]


def house_word_hint(rx_index, w):
    """What to say instead of w (a word found by HOUSE_WORDS[rx_index]), or None when w is fine."""
    fixer = HOUSE_WORDS[rx_index][1]
    if fixer is not None:
        return fixer(w)
    low = w.lower()
    for rx, us in UK_TO_US:
        if rx.search(low):
            new = rx.sub(us, low, count=1)
            return new if new != low else None
    return None   # already US spelling (color, license, ...)


# ------------------------------------------------------------------------------------------------ small helpers
def Q(v, n=60):
    """A value taken from a document, made safe to print inside a message: one line, no quote, short."""
    return ra.clean(v, n)


def say(*lines):
    for l in lines:   # a value from a document can hold a line break: it must never start a line of its own
        print(ra.single_line(l))


def fail(*lines):
    print("Not done:", file=sys.stderr)
    for l in lines:
        print("  - " + ra.single_line(l), file=sys.stderr)
    sys.exit(2)


def me(cmd):
    """The short command as it is typed (from the terminal folder)."""
    return "python3 -I tools/terminal_state.py " + cmd


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def state_dir(a):
    return Path(a.state_dir or os.environ.get("QT_STATE_DIR") or (qt.T / "state")).expanduser().resolve()


def default_export(outbox, home=None):
    """outbox/export (this tool's own folder), or T/export (the question cycle's folder) when only that one exists.
    Both there: the one fetched more recently."""
    cands = [Path(outbox) / "export", Path(home or qt.T) / "export"]
    here = [c for c in cands if c.is_dir()]
    if len(here) < 2:
        return (here or cands)[0]
    ages = [export_age(c) for c in here]
    newest = min(range(2), key=lambda i: ages[i] if ages[i] is not None else 10 ** 9)
    return here[newest]


def export_dir(a):
    given = getattr(a, "export", None) or os.environ.get("QT_EXPORT")
    return (Path(given) if given else default_export(qt.outbox_dir(a.outbox))).expanduser().resolve()


def pick(doc, keys):
    return {k: doc[k] for k in keys if k in doc}


def strip(doc):
    return {k: v for k, v in doc.items() if k != "_collection"}


def minutes_since(iso):
    d = qt.parse_iso(iso)
    if d is None:
        return None
    now = qt.parse_iso(qt.now_iso())
    return int((now - d).total_seconds() // 60)


# ------------------------------------------------------------------------------------------------ the state files
def read_list(path, what):
    if not path.is_file():
        return []
    try:
        raw = qt.read_json(path)
    except (OSError, ValueError) as e:
        fail(f"{path} cannot be read ({Q(e, 120)}). It should be a list of {what} documents between [ and ].")
    if isinstance(raw, dict) and isinstance(raw.get(what), list):
        raw = raw[what]
    if not isinstance(raw, list):
        fail(f"{path} should be a list of {what} documents between [ and ].")
    return raw


def load_state(a):
    d = state_dir(a)
    return read_list(d / "workers.json", "workers"), read_list(d / "tasks.json", "tasks"), d


def save_state(a, name, docs):
    """Write state/<name>.json (a copy of the old file goes to <outbox>/backup-state/ first)."""
    d = state_dir(a)
    path = d / (name + ".json")
    if path.is_file():
        bk = qt.outbox_dir(a.outbox) / "backup-state"
        bk.mkdir(parents=True, exist_ok=True)
        (bk / f"{name}-{qt.stamp()}.json").write_bytes(path.read_bytes())
        for old in sorted(bk.glob(name + "-*.json"))[:-20]:
            old.unlink()
    qt.write_json(path, docs)
    return path


def by_id(docs):
    return {d["id"]: d for d in docs if isinstance(d, dict) and isinstance(d.get("id"), str)}


# ------------------------------------------------------------------------------------------------ the live copy
def load_live(export):
    """The folders ArtifactData wrote with out_dir -> (docs by collection, versions, problems, question ids)."""
    root = Path(export)
    live = {c: {} for c in LIVE_COLLS}
    versions, problems = {}, []
    for c in LIVE_COLLS:
        d = root / c
        if not d.is_dir():
            continue
        for f in sorted(d.glob("*.json")):
            if not ra.SAFE_ID.match(f.stem):
                problems.append(f"{c}/{Q(f.name)} has a name that is not an id (lowercase letters, digits, - and _ only); ignored")
                continue
            try:
                raw = qt.read_json(f)
            except (OSError, ValueError) as e:
                problems.append(f"{c}/{f.name} could not be read ({Q(e, 120)})")
                continue
            data, ver = ra.unwrap(raw)
            if data is None:
                problems.append(f"{c}/{f.name} is not a document")
                continue
            live[c][f.stem] = data
            if ver:
                versions[f"{c}/{f.stem}"] = ver
    qd = root / "questions"
    qids = {p.stem for p in qd.glob("*.json")} if qd.is_dir() else None
    return live, versions, problems, qids


def export_age(export):
    """Minutes since the live copy was made (from the marker, else from the newest file); None if unknown."""
    root = Path(export)
    try:
        m = qt.read_json(root / MARK)
        mins = minutes_since(m.get("begunAt"))
        if mins is not None:
            return mins
    except (OSError, ValueError, AttributeError):
        pass
    newest = 0.0
    for f in root.glob("*/*.json"):
        newest = max(newest, f.stat().st_mtime)
    if not newest:
        return None
    import time
    return int((time.time() - newest) // 60)


def need_export(a):
    export = export_dir(a)
    if not export.is_dir():
        fail(f"There is no copy of the page's notebook at {export}.",
             f"First run:  {me('export')}   and make the ArtifactData list calls it prints (skip a collection you know is empty).")
    return export


# ------------------------------------------------------------------------------------------------ checking
class Problems:
    def __init__(self):
        self.items = []   # (level, key, text)

    def error(self, key, text):
        self.items.append(("error", key, text))

    def note(self, key, text):
        self.items.append(("note", key, text))

    @property
    def errors(self):
        return [(k, t) for lv, k, t in self.items if lv == "error"]

    @property
    def notes(self):
        return [(k, t) for lv, k, t in self.items if lv == "note"]

    def bad_keys(self):
        return {k for lv, k, t in self.items if lv == "error"}


def _text_checks(P, key, coll, field, text, allow):
    if not isinstance(text, str):
        return
    lim = LIMITS.get((coll, field))
    if lim:
        warn_at, err_at = lim
        if err_at and len(text) > err_at:
            P.error(key, f"{field} is {len(text)} characters; the most is {err_at}. Make it shorter.")
        elif warn_at and len(text) > warn_at:
            P.note(key, f"{field} is {len(text)} characters; shorter reads better (about {warn_at} at most).")
    if field in SEPARATE_ONE_LINE and "\n" in text:
        P.error(key, f"{field} must be one line (it has a line break).")
    longest = max((len(w) for w in text.split()), default=0)
    if longest > MAX_WORD:
        P.error(key, f"{field} has one 'word' with no spaces that is {longest} characters long; the most is {MAX_WORD} (it could break the layout).")
    allowed = {w.strip().lower() for w in allow}
    seen = set()
    for m in list(qt.JARGON_RE.finditer(text)) + list(EXTRA_JARGON.finditer(text)):
        w = m.group(0)
        if w.lower() in allowed or w.lower() in seen:
            continue
        seen.add(w.lower())
        hint = SAY_INSTEAD.get(w.lower())
        P.error(key, f"the word '{w}' is in the {field}; she should not read it. Say it in everyday words" + (f" (for example: {hint})" if hint else "") + ".")
    if WRONG_NAME.search(text):
        P.note(key, f"{field} spells her name another way; she is \"Miss Cathy\".")
    said = set()
    for n, (rx, _fix) in enumerate(HOUSE_WORDS):
        for m in rx.finditer(text):
            w = m.group(0)
            hint = house_word_hint(n, w)
            if hint is None or (w.lower() in said):
                continue
            said.add(w.lower())
            P.note(key, f"the {field} says '{w}'; say '{hint}' (plain words for her: worker, task, Claude, US spelling).")


def _is_iso(v):
    return v is None or qt.parse_iso(v) is not None


def _cycles(parent_of):
    """parent_of {id: parentId or None} -> list of cycles, each a list of ids [a, b, a]."""
    out, done = [], set()
    for start in parent_of:
        path, cur = [], start
        while cur is not None and cur in parent_of and cur not in done:
            if cur in path:
                out.append(path[path.index(cur):] + [cur])
                break
            path.append(cur)
            cur = parent_of[cur]
        done.update(path)
    return out


def validate(workers, tasks, live, qids, allow=()):
    """Look for mistakes in the two state lists. live = docs of the live copy ({} when not exported)."""
    P = Problems()
    live = live or {}
    lw, lt, adds = live.get("workers", {}), live.get("tasks", {}), live.get("taskAdds", {})
    ids = {"workers": set(), "tasks": set()}

    def doc_ok(coll, d, n):
        if not isinstance(d, dict):
            P.error(f"{coll} #{n}", "this entry is not a document like {...}")
            return None
        i = d.get("id")
        if not isinstance(i, str) or not qt.ID_RE.match(i):
            P.error(f"{coll} #{n}", f"id must be 1-60 characters: lowercase letters, digits, - and _ only (got {i!r})")
            return None
        if i in ids[coll]:
            P.error(f"{coll}/{i}", "two documents have this same id")
            return None
        ids[coll].add(i)
        return i

    good_w = {i: d for n, d in enumerate(workers, 1) if (i := doc_ok("workers", d, n))}
    good_t = {i: d for n, d in enumerate(tasks, 1) if (i := doc_ok("tasks", d, n))}
    # everything the page will know (the state files win over the live copy)
    all_w = {**{k: v for k, v in lw.items()}, **good_w}
    all_t = {**{k: v for k, v in lt.items()}, **good_t}
    pending_t = set(adds)   # tasks she added that are not yet real: a parent may be one of them

    def common(key, d, fields, coll):
        for k in d:
            if k not in fields and k != "_collection":
                P.note(key, f"'{Q(k)}' is not a known field; the page ignores it.")

    # ---- workers
    for i, d in good_w.items():
        key = f"workers/{i}"
        common(key, d, WORKER_FIELDS, "workers")
        for f in ("name", "kind", "state", "updatedAt"):
            if f not in d:
                P.error(key, f"{f} is missing.")
        if "parentId" not in d:
            P.error(key, "parentId is missing (use null for the very top).")
        for f in WORKER_FIELDS:
            if f not in d and f not in ("name", "kind", "state", "updatedAt", "parentId", "id"):
                P.note(key, f"{f} is missing (the page treats it as empty).")
        st, kind, wf = d.get("state"), d.get("kind"), d.get("waitingFor", "none")
        if "name" in d and (not isinstance(d["name"], str) or not d["name"].strip()):
            P.error(key, "name must be some text.")
        if "kind" in d and kind not in WORKER_KINDS:
            P.error(key, f"kind must be one of {', '.join(WORKER_KINDS)} (got {kind!r}).")
        if "state" in d and st not in WORKER_STATES:
            P.error(key, f"state must be one of {', '.join(WORKER_STATES)} (got {st!r}).")
        if "waitingFor" in d and wf not in WORKER_WAIT:
            P.error(key, f"waitingFor must be one of {', '.join(WORKER_WAIT)} (got {wf!r}).")
        if "brain" in d and d["brain"] not in BRAINS:
            P.error(key, "brain must be Claude, Sonnet, Opus or empty.")
        pr = d.get("progress")
        if pr is not None and (not is_num(pr) or not 0 <= pr <= 100):
            P.error(key, "progress must be a number from 0 to 100, or null when Claude does not really know.")
        if "order" in d and not is_num(d["order"]):
            P.error(key, "order must be a number.")
        for f in ("startedAt", "updatedAt", "finishedAt"):
            if f in d and not _is_iso(d[f]):
                P.error(key, f"{f} must be a date and time like 2026-10-07T16:30:00Z, or null.")
        for f in ("name", "role", "now", "result"):
            _text_checks(P, key, "workers", f, d.get(f), allow)
        icon = d.get("icon")
        if isinstance(icon, str) and icon and (len(icon) > 8 or re.search(r"[A-Za-z0-9]", icon)):
            P.note(key, "icon should be ONE emoji (the page shows the initials when it is empty).")
        # activity
        act = d.get("activity", [])
        if not isinstance(act, list):
            P.error(key, "activity must be a list.")
        else:
            if len(act) > 8:
                P.error(key, f"activity has {len(act)} lines; the most is 8 (newest first).")
            last = None
            for n, e in enumerate(act, 1):
                if not isinstance(e, dict) or not isinstance(e.get("text"), str) or not _is_iso(e.get("at")) or e.get("at") is None:
                    P.error(key, f"activity line {n} must look like {{\"at\": \"2026-10-07T16:30:00Z\", \"text\": \"...\"}}.")
                    continue
                _text_checks(P, key, "workers", "activity", e["text"], allow)
                when = qt.parse_iso(e["at"])
                if last is not None and when > last:
                    P.note(key, "activity should be newest first.")
                last = when
        if "taskIds" in d and (not isinstance(d["taskIds"], list) or not all(isinstance(x, str) for x in d["taskIds"])):
            P.error(key, "taskIds must be a list of task ids.")
        # the rules of the states
        now_txt = d.get("now")
        if isinstance(now_txt, str) and now_txt.strip() and st not in ("working", "waiting"):
            P.error(key, f"'now' (\"{Q(now_txt, 40)}\") must be empty unless the worker is working or waiting; this one is {Q(st, 20)}. Clear it with --now \"\".")
        if st == "working":
            if not (isinstance(now_txt, str) and now_txt.strip()):
                P.note(key, "working, but 'now' is empty: she sees no \"Right now\" line.")
            if not d.get("startedAt"):
                P.note(key, "working, but startedAt is empty.")
            if d.get("finishedAt"):
                P.note(key, "working, but finishedAt is set.")
        if st == "waiting" and wf == "none":
            P.note(key, "waiting, but waitingFor says nobody (use owner, cathy, rob or claude).")
        if st not in ("waiting",) and wf not in ("none", None) and st in WORKER_STATES:
            P.note(key, f"waitingFor is '{Q(wf, 20)}' but the worker is {Q(st, 20)}.")
        if st in ("done", "stopped") and not d.get("finishedAt"):
            P.note(key, f"{Q(st, 20)}, but finishedAt is empty.")
        if st == "done" and not (isinstance(d.get("result"), str) and d["result"].strip()):
            P.note(key, "done, but 'result' is empty (what did they hand back?).")
    # worker tree
    parent_w = {i: d.get("parentId") for i, d in all_w.items()}
    for i, d in good_w.items():
        pid = d.get("parentId")
        if pid is None:
            continue
        if not isinstance(pid, str):
            P.error(f"workers/{i}", "parentId must be an id or null.")
        elif pid == i:
            P.error(f"workers/{i}", "it is its own boss (parentId is its own id).")
        elif pid not in all_w:
            P.error(f"workers/{i}", f"its boss '{Q(pid)}' does not exist (add that worker, or fix parentId).")
    for cyc in _cycles({k: (v if isinstance(v, str) else None) for k, v in parent_w.items()}):
        if len(cyc) > 2 or cyc[0] != cyc[1]:
            for i in dict.fromkeys(cyc[:-1]):
                if i in good_w:
                    P.error(f"workers/{i}", "the bosses go round in a circle: " + " -> ".join(cyc) + ".")
    leads = [i for i, d in all_w.items() if d.get("kind") == "lead"]
    if all_w and len(leads) != 1:
        P.note("workers", f"there should be exactly one lead (Claude); found {len(leads)}.")
    for i, d in good_w.items():
        if d.get("kind") == "lead" and d.get("parentId") is not None:
            P.note(f"workers/{i}", "the lead should have parentId null.")
        if d.get("kind") in ("team", "helper") and d.get("parentId") is None:
            P.note(f"workers/{i}", f"a {Q(d.get('kind'), 20)} with no boss would sit at the very top; give it a parentId.")

    # ---- tasks
    for i, d in good_t.items():
        key = f"tasks/{i}"
        common(key, d, TASK_FIELDS, "tasks")
        for f in ("title", "state", "updatedAt", "createdAt"):
            if f not in d:
                P.error(key, f"{f} is missing.")
        if "parentId" not in d:
            P.error(key, "parentId is missing (use null for a main idea).")
        for f in TASK_FIELDS:
            if f not in d and f not in ("title", "state", "updatedAt", "createdAt", "parentId", "id"):
                P.note(key, f"{f} is missing (the page treats it as empty).")
        st, wf = d.get("state"), d.get("waitingFor", "none")
        if "title" in d and (not isinstance(d["title"], str) or not d["title"].strip()):
            P.error(key, "title must be some text.")
        if "state" in d and st not in TASK_STATES:
            P.error(key, f"state must be one of {', '.join(TASK_STATES)} (got {st!r}).")
        if "waitingFor" in d and wf not in TASK_WAIT:
            P.error(key, f"waitingFor must be one of {', '.join(TASK_WAIT)} (got {wf!r}).")
        if "createdBy" in d and d["createdBy"] not in ("claude", "owner"):
            P.error(key, "createdBy must be claude or owner.")
        if "order" in d and not is_num(d["order"]):
            P.error(key, "order must be a number.")
        for f in ("createdAt", "updatedAt", "doneAt", "seenAt"):
            if f in d and not _is_iso(d[f]):
                P.error(key, f"{f} must be a date and time like 2026-10-07T16:30:00Z, or null.")
        for f in ("title", "plain", "note"):
            _text_checks(P, key, "tasks", f, d.get(f), allow)
        if not (isinstance(d.get("plain"), str) and d["plain"].strip()):
            P.note(key, "plain is empty: say in one or two everyday sentences what this is and why it matters.")
        for f, label in (("workerIds", "worker"), ("questionIds", "question")):
            v = d.get(f, [])
            if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
                P.error(key, f"{f} must be a list of {label} ids.")
        if st == "done" and not d.get("doneAt"):
            P.note(key, "done, but doneAt is empty.")
        if st != "done" and d.get("doneAt"):
            P.note(key, f"doneAt is set but the task is {Q(st, 20)}.")
        if st == "waiting" and wf == "none":
            P.note(key, "waiting, but waitingFor says nobody (use owner, cathy or rob).")
        if st != "waiting" and wf not in ("none", None) and st in TASK_STATES:
            P.note(key, f"waitingFor is '{Q(wf, 20)}' but the task is {Q(st, 20)}.")
        for w in d.get("workerIds", []) if isinstance(d.get("workerIds"), list) else []:
            if w not in all_w:
                P.note(key, f"worker '{Q(w)}' does not exist.")
            elif i not in (all_w[w].get("taskIds") or []):
                P.note(key, f"worker '{Q(w)}' is on this task, but that worker does not list the task back (use worker {Q(w)} --task {i}).")
        if qids is not None:
            for q in d.get("questionIds", []) if isinstance(d.get("questionIds"), list) else []:
                if q not in qids:
                    P.note(key, f"question '{Q(q)}' is not in the page's notebook (a typo?).")
    for i, d in good_w.items():
        for t in d.get("taskIds", []) if isinstance(d.get("taskIds"), list) else []:
            if t not in all_t and t not in pending_t:
                P.note(f"workers/{i}", f"task '{Q(t)}' does not exist.")
            elif t in good_t and i not in (good_t[t].get("workerIds") or []):
                P.note(f"workers/{i}", f"it lists task '{Q(t)}', but that task does not list the worker back (use task {Q(t)} --worker {i}).")
    # task tree
    parent_t = {i: d.get("parentId") for i, d in all_t.items()}
    parent_t.update({i: d.get("parentId") for i, d in adds.items() if i not in parent_t})
    for i, d in good_t.items():
        pid = d.get("parentId")
        if pid is None:
            continue
        if not isinstance(pid, str):
            P.error(f"tasks/{i}", "parentId must be an id or null.")
        elif pid == i:
            P.error(f"tasks/{i}", "it is its own parent (parentId is its own id).")
        elif pid not in all_t and pid not in pending_t:
            P.error(f"tasks/{i}", f"its parent '{Q(pid)}' does not exist (add that task, or fix parentId).")
        elif pid in good_t and good_t[pid].get("state") == "done" and st_of(d) != "done":
            P.note(f"tasks/{i}", f"its parent '{Q(pid)}' is done, but this task is {Q(st_of(d), 20)}.")
    for cyc in _cycles({k: (v if isinstance(v, str) else None) for k, v in parent_t.items()}):
        if len(cyc) > 2 or cyc[0] != cyc[1]:
            for i in dict.fromkeys(cyc[:-1]):
                if i in good_t:
                    P.error(f"tasks/{i}", "the parents go round in a circle: " + " -> ".join(cyc) + ".")
    return P


def st_of(d):
    return d.get("state")


def print_problems(P, limit_notes=15):
    for k, t in P.errors:
        say(f"  ERROR  {k}: {t}")
    for k, t in P.notes[:limit_notes]:
        say(f"  note   {k}: {t}")
    if len(P.notes) > limit_notes:
        say(f"  ... and {len(P.notes) - limit_notes} more note(s)")


# ------------------------------------------------------------------------------------------------ what to send
def _differs(k, sdoc, ldoc):
    if k == "seenAt":   # never goes back: only send a later time than the live one
        s, l = qt.parse_iso(sdoc.get("seenAt")), qt.parse_iso(ldoc.get("seenAt"))
        return s is not None and (l is None or s > l)
    return ldoc.get(k) != sdoc[k]


def plan_sync(coll, docs, live_docs, now, only_ids=None):
    """-> list of dicts {coll, id, kind: new|changed|same, op, data, fields}"""
    out = []
    for d in docs:
        i = d["id"]
        if only_ids is not None and i not in only_ids:
            continue
        s = strip(d)
        if i not in live_docs:
            out.append({"coll": coll, "id": i, "kind": "new", "op": "set", "data": s, "fields": sorted(s)})
            continue
        l = live_docs[i]
        fields = [k for k in s if k != "updatedAt" and _differs(k, s, l)]
        if not fields:
            out.append({"coll": coll, "id": i, "kind": "same", "op": None, "data": None, "fields": []})
            continue
        patch = {k: s[k] for k in fields}
        su, lu = qt.parse_iso(s.get("updatedAt")), qt.parse_iso(l.get("updatedAt"))
        patch["updatedAt"] = s["updatedAt"] if (su is not None and (lu is None or su > lu)) else now
        out.append({"coll": coll, "id": i, "kind": "changed", "op": "update", "data": patch, "fields": fields})
    return out


def guard(writes):
    """Last line of defence: only Claude's three collections, only set/update. Never hers."""
    for w in writes:
        if w["collection"] not in WRITABLE:
            qt.die(f"Stopped: this tool may not write '{w['collection']}' (that belongs to the page's owner).")
        if w["op"] not in ("set", "update"):
            qt.die(f"Stopped: this tool never uses '{w['op']}'.")


def order_key(d):
    o = d.get("order")
    return (o if is_num(o) else 10 ** 9, d.get("id", ""))


def versions_for(a, outbox, live_versions):
    """--version beats the live copy, which beats outbox/versions.json."""
    from_file = qt.load_versions(a.versions, [], outbox=outbox, auto=not a.no_versions)
    pairs = qt.load_versions(None, a.version, outbox=outbox, auto=False)
    return {**from_file, **live_versions, **pairs}


def new_folder(outbox):
    base = outbox / f"state-{qt.stamp()}"
    folder, n = base, 1
    while folder.exists():
        n += 1
        folder = Path(f"{base}-r{n}")
    return folder


def finish_batches(a, outbox, writes, extra_notes=()):
    guard(writes)
    folder = new_folder(outbox)
    made = qt.write_batches(folder, writes, prefix="batch", with_files=True)
    say(f"Ready: {len(writes)} write(s) in {len(made)} batch file(s).")
    for inline, files, n in made:
        say(f"  {inline}   ({n} writes, documents inline)")
        say(f"  {files}   (same writes; each document is read from a file: best for long or many documents)")
    for n in extra_notes:
        say("Note: " + n)
    say("Next: ArtifactData action=batch, url=<Question Terminal page>, writes=<the writes list of one batch file>; one call per batch file.")
    say("The batch is all or nothing. After EACH batch ArtifactData accepted, tell the tool (it keeps the version numbers right for the next change):")
    for inline, _, _ in made[:6]:
        say("  " + me("applied " + str(inline)))
    if len(made) > 6:
        say(f"  ... the same for the other {len(made) - 6} batch file(s)")
    return made


# ------------------------------------------------------------------------------------------------ sync
def cmd_sync(a):
    workers, tasks, sdir = load_state(a)
    export = need_export(a)
    live, live_versions, lproblems, qids = load_live(export)
    outbox = qt.outbox_dir(a.outbox)
    allow = qt.parse_allow(a.allow_words)
    P = validate(workers, tasks, live, qids, allow)
    bad = P.bad_keys()
    if bad and not a.skip_bad:
        say("The state files have mistakes, so nothing was prepared:")
        print_problems(P)
        say(f"Fix them (the commands worker / task change one thing at a time), or leave the bad ones out for now with --skip-bad.")
        return 2
    if bad:
        say(f"Leaving out {len(bad)} document(s) with mistakes (--skip-bad): " + ", ".join(sorted(bad)))
    now = qt.now_iso()
    versions = versions_for(a, outbox, live_versions)
    age = export_age(export)
    say(f"State: {sdir / 'workers.json'} ({len(workers)} workers), {sdir / 'tasks.json'} ({len(tasks)} tasks)")
    say(f"Live copy: {export}" + (f" (made {age} min ago)" if age is not None else ""))
    if age is not None and age > STALE_MIN:
        say(f"!! The live copy is {age} minutes old. If anything changed on the page since, export again first ({me('export')}).")
    for p in lproblems[:10]:
        say("!! " + p)
    plans = []
    for coll, docs in (("workers", workers), ("tasks", tasks)):
        if a.only and a.only != coll:
            continue
        ok_docs = [d for d in sorted((d for d in docs if isinstance(d, dict) and isinstance(d.get("id"), str)), key=order_key) if f"{coll}/{d['id']}" not in bad]
        plans += plan_sync(coll, ok_docs, live[coll], now)
    writes, shown = [], []
    for p in plans:
        if p["kind"] == "same":
            continue
        w = qt.make_write(p["op"], p["coll"], p["id"], p["data"], versions)
        writes.append(w)
        shown.append(p)
    for coll in ("workers", "tasks"):
        mine = [p for p in plans if p["coll"] == coll]
        if mine:
            say(f"{coll}: {sum(p['kind'] == 'new' for p in mine)} new, {sum(p['kind'] == 'changed' for p in mine)} changed, {sum(p['kind'] == 'same' for p in mine)} unchanged")
    extra = []
    for p in shown[:40]:
        label = "new    " if p["kind"] == "new" else "changed"
        say(f"  {label} {p['coll']}/{p['id']}" + ("" if p["kind"] == "new" else "   (" + ", ".join(Q(f, 30) for f in p["fields"][:8]) + ("..." if len(p["fields"]) > 8 else "") + ")"))
    if len(shown) > 40:
        say(f"  ... and {len(shown) - 40} more")
    # her words win on the page: tell Claude when a change of title / plain text is hidden behind them
    edits = live.get("taskEdits", {})
    for p in shown:
        if p["coll"] == "tasks" and p["kind"] == "changed" and p["id"] in edits:
            hidden = [f for f in ("title", "plain") if f in p["fields"] and isinstance(edits[p["id"]].get(f), str) and edits[p["id"]][f].strip()]
            if hidden:
                extra.append(f"tasks/{p['id']}: she changed the {' and '.join(hidden)} herself, so the page keeps showing her words on top of this change.")
            if edits[p["id"]].get("paused") is True and "state" in p["fields"] and p["data"].get("state") != "paused":
                extra.append(f"tasks/{p['id']}: she paused it herself, so the page keeps showing it as paused until she resumes it.")
    kept = [i for c, docs in (("workers", workers), ("tasks", tasks)) for i in sorted(set(live[c]) - {d.get("id") for d in docs if isinstance(d, dict)}) if not (a.only and a.only != c)]
    if kept:
        extra.append(f"{len(kept)} document(s) are on the page but not in the state files (they stay as they are; nothing is ever removed): " + ", ".join(kept[:8]) + ("..." if len(kept) > 8 else ""))
    lacking = [f"{w['collection']}/{w['doc_id']}" for w in writes if w["op"] == "update" and not w.get("if_version")]
    if lacking:
        extra.append(f"{len(lacking)} changed document(s) have no known version number. ArtifactData then refuses the WHOLE batch (it writes nothing and names the number). "
                     f"Export again with the list calls ({me('export')}), or add --version workers/ID=N.")
    if any(w["op"] == "set" for w in writes):
        extra.append("New documents are sent with set. If ArtifactData says one already exists, nothing in that batch was written: export again and run sync again.")
    if P.notes:
        say("Notes:")
        for k, t in P.notes[:10]:
            say(f"  {k}: {t}")
        if len(P.notes) > 10:
            say(f"  ... and {len(P.notes) - 10} more (run check to see all)")
    if not writes:
        say("Nothing to send: the page already shows everything in the state files.")
        return 1
    if a.dry_run:
        say(f"(dry run: {len(writes)} write(s) would be prepared; nothing was written)")
        return 0
    finish_batches(a, outbox, writes, extra)
    return 0


# ------------------------------------------------------------------------------------------------ export
def cmd_export(a):
    export = export_dir(a)
    outbox = qt.outbox_dir(a.outbox)
    only = [s.strip() for s in (a.only or "").split(",") if s.strip()] or list(LIVE_COLLS)
    for s in only:
        if s not in LIVE_COLLS:
            fail(f"--only knows these names: {', '.join(LIVE_COLLS)} (got '{s}')")
    marker = export / MARK
    ours = {(outbox / "export").resolve(), (qt.T / "export").resolve()}   # this tool's folder and the question cycle's
    for c in only:   # old files would show a document as it was, not as it is
        d = export / c
        old = list(d.glob("*.json")) if d.is_dir() else []
        if old and export not in ours and not marker.is_file():
            fail(f"{d} already holds {len(old)} file(s) and was not made by this tool. Use an empty folder (--export), or empty it yourself.")
        for f in old:
            f.unlink()
        d.mkdir(parents=True, exist_ok=True)
    if not marker.is_file():
        marker.write_text(json.dumps({"begunAt": qt.now_iso(), "by": "terminal_state.py export"}) + "\n", encoding="utf-8")
    else:   # same folder as the question cycle: keep its marker, but note the new fetch
        try:
            m = qt.read_json(marker)
            m["begunAt"] = qt.now_iso()
            marker.write_text(json.dumps(m) + "\n", encoding="utf-8")
        except (OSError, ValueError):
            marker.write_text(json.dumps({"begunAt": qt.now_iso(), "by": "terminal_state.py export"}) + "\n", encoding="utf-8")
    urlf = outbox / "page-url.txt"
    url = (a.url or os.environ.get("QT_URL") or "").strip()
    if a.url:
        urlf.write_text(url + "\n", encoding="utf-8")
    elif not url and urlf.is_file():
        url = urlf.read_text(encoding="utf-8").strip()
    calls = [{"action": "list", "url": url or "<URL>", "collection": c, "out_dir": str(export), "query": {"limit": 1000}} for c in only]
    qt.write_json(outbox / "state-export-calls.json", calls)
    say(f"Live copy folder ready: {export}")
    if not url:
        say("!! The page address is not known. Re-run with --url <the claude.ai/artifact/... address> (it is remembered), or replace <URL> below.")
    say(f"Make these {len(calls)} ArtifactData calls, one after the other (skip one you know is empty; the folder is already there):")
    for n, c in enumerate(calls, 1):
        say(f"CALL {n} of {len(calls)}  {c['collection']}")
        say(json.dumps(c, ensure_ascii=False, separators=(",", ":")))
    say("If a result says there is more (a next_cursor), repeat that call with \"query\":{\"limit\":1000,\"cursor\":\"<next_cursor>\"}.")
    say(f"Next: {me('sync')}   (or: python3 -I tools/read_answers.py {export}  to see what she added, changed or asked)")
    return 0


# ------------------------------------------------------------------------------------------------ check
def cmd_check(a):
    workers, tasks, sdir = load_state(a)
    export = export_dir(a)
    live, qids = {}, None
    if export.is_dir():
        live, _, _, qids = load_live(export)
    allow = qt.parse_allow(a.allow_words)
    P = validate(workers, tasks, live, qids, allow)
    say(f"Looked at {sdir / 'workers.json'} ({len(workers)} workers) and {sdir / 'tasks.json'} ({len(tasks)} tasks)" +
        (f" together with the live copy in {export}." if live else "; there is no live copy to compare with, so parents are only looked for in these files."))
    print_problems(P, limit_notes=60)
    if P.errors:
        say(f"{len(P.errors)} mistake(s) to fix, {len(P.notes)} note(s).")
        return 2
    say(f"OK: no mistakes ({len(P.notes)} note(s)).")
    return 0


# ------------------------------------------------------------------------------------------------ worker / task / adopt: edit the state files
def num(text):
    try:
        f = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"'{text}' is not a number")
    return int(f) if f == int(f) else f


def parent_arg(v):
    return None if v is None or v.strip().lower() in ("none", "null", "") else v.strip()


def next_order(docs, parent):
    sib = [d.get("order") for d in docs if d.get("parentId") == parent and is_num(d.get("order"))]
    return int(max(sib)) + 1 if sib else 1


def default_worker(i, now):
    return {"id": i, "name": "", "parentId": None, "kind": "helper", "icon": "", "role": "", "state": "resting", "now": "", "waitingFor": "none",
            "startedAt": None, "updatedAt": now, "finishedAt": None, "activity": [], "result": "", "taskIds": [], "brain": "", "progress": None, "order": 0}


def default_task(i, now):
    return {"id": i, "parentId": None, "title": "", "plain": "", "state": "todo", "waitingFor": "none", "workerIds": [], "questionIds": [],
            "note": "", "order": 0, "createdAt": now, "updatedAt": now, "doneAt": None, "createdBy": "claude", "seenAt": None}


def link(docs, doc_id, field, other_id, now):
    """Add other_id to docs[doc_id][field] (a list) and move its updatedAt on. Returns True when something changed."""
    for d in docs:
        if d.get("id") == doc_id:
            lst = d.setdefault(field, [])
            if other_id not in lst:
                lst.append(other_id)
                d["updatedAt"] = now
                return True
    return False


def unlink(docs, doc_id, field, other_id, now):
    for d in docs:
        if d.get("id") == doc_id and other_id in (d.get(field) or []):
            d[field].remove(other_id)
            d["updatedAt"] = now
            return True
    return False


def save_and_report(a, workers, tasks, touched_w, touched_t, before_w, before_t, notes, lines):
    """Check what was touched; write the state files only when nothing is wrong with the touched documents."""
    export = export_dir(a)
    live, qids = {}, None
    if export.is_dir():
        live, _, _, qids = load_live(export)
    P = validate(workers, tasks, live, qids, qt.parse_allow(a.allow_words))
    mine = {f"workers/{i}" for i in touched_w} | {f"tasks/{i}" for i in touched_t}
    errs = [(k, t) for k, t in P.errors if k in mine]
    if errs:
        fail(*[f"{k}: {t}" for k, t in errs], "Nothing was saved.")
    changed = []
    if workers != before_w:
        changed.append(("workers", workers))
    if tasks != before_t:
        changed.append(("tasks", tasks))
    if not changed:
        say("Nothing changed (the state files already say this).")
        return 1
    for name, docs in changed:
        path = save_state(a, name, docs)
        say(f"Saved {path}")
    for l in lines:
        say(l)
    for k, t in P.notes:
        if k in mine:
            say(f"note  {k}: {t}")
    for n in notes:
        say("Note: " + n)
    other = [(k, t) for k, t in P.errors if k not in mine]
    if other:
        say(f"!! {len(other)} mistake(s) in other documents already (run check): " + "; ".join(f"{k}" for k, _ in other[:6]))
    return 0


def after(a, rc):
    if rc == 0 and getattr(a, "sync", False):
        say("")
        return cmd_sync(argparse.Namespace(**{**vars(a), "only": None, "dry_run": False, "skip_bad": False}))
    if rc == 0:
        say(f"Next: {me('sync')}   (it works out what the page needs and prepares the batch)")
    return rc


def cmd_worker(a):
    workers, tasks, _ = load_state(a)
    before_w, before_t = copy.deepcopy(workers), copy.deepcopy(tasks)
    now = qt.now_iso()
    i = a.id
    if not qt.ID_RE.match(i):
        fail(f"'{i}' is not a valid id (lowercase letters, digits, - and _ only).")
    doc = next((d for d in workers if d.get("id") == i), None)
    new = doc is None
    notes, errs = [], []
    if new:
        for opt, label in ((a.name, "--name \"Map drawer A\""), (a.kind, "--kind lead|team|helper"), (a.role, "--role \"what the job is\"")):
            if not opt:
                errs.append(f"'{i}' is a new worker, so say {label}")
        if a.parent is None:
            errs.append("a new worker needs --parent ID (who it works for), or --parent none for the very top")
        if errs:
            fail(*errs)
        doc = default_worker(i, now)
        workers.append(doc)
    pre = copy.deepcopy(doc)
    if a.name is not None:
        doc["name"] = a.name.strip()
    if a.kind:
        doc["kind"] = a.kind
    if a.parent is not None:
        doc["parentId"] = parent_arg(a.parent)
    if a.icon is not None:
        doc["icon"] = a.icon.strip()
    if a.role is not None:
        doc["role"] = a.role.strip()
    if a.brain is not None:
        doc["brain"] = a.brain
    if a.order is not None:
        doc["order"] = a.order
    elif new:
        doc["order"] = next_order(workers[:-1], doc.get("parentId"))
    if a.progress is not None:
        if a.progress.lower() in ("none", "null", ""):
            doc["progress"] = None
        else:
            try:
                doc["progress"] = float(a.progress) if "." in a.progress else int(a.progress)
            except ValueError:
                fail(f"--progress needs a number from 0 to 100, or none (got '{a.progress}'). Only give a number when Claude really knows.")
    if a.state:
        old = doc.get("state")
        doc["state"] = a.state
        if a.state == "working":
            if not doc.get("startedAt") or old in ("done", "stopped"):
                doc["startedAt"] = now
            doc["finishedAt"] = None
            if a.waiting_for is None:
                doc["waitingFor"] = "none"
        elif a.state == "waiting":
            doc["finishedAt"] = None
            if a.waiting_for is None and doc.get("waitingFor", "none") == "none":
                fail("waiting needs --waiting-for owner|cathy|rob|claude (who is it waiting for?).")
        elif a.state == "resting":
            doc["finishedAt"] = None
            if a.now is None:
                doc["now"] = ""
            if a.waiting_for is None:
                doc["waitingFor"] = "none"
        else:   # done, stopped
            if old != a.state or not doc.get("finishedAt"):
                doc["finishedAt"] = now
            if a.now is None:
                doc["now"] = ""
            if a.waiting_for is None:
                doc["waitingFor"] = "none"
    if a.waiting_for is not None:
        doc["waitingFor"] = a.waiting_for
    if a.now is not None:
        doc["now"] = a.now.strip()
    if a.result is not None:
        doc["result"] = a.result.strip()
    for text in a.activity or []:
        act = [{"at": now, "text": text.strip()}] + list(doc.get("activity") or [])
        doc["activity"] = act[:8]
    touched_t = set()
    for t in a.task or []:
        if not any(d.get("id") == t for d in tasks):
            notes.append(f"task '{t}' is not in the task file yet; the link is saved on the worker only (add the task with: task {t} --title ... --plain ... --parent ...).")
        if t not in (doc.get("taskIds") or []):
            doc.setdefault("taskIds", []).append(t)
        if link(tasks, t, "workerIds", i, now):
            touched_t.add(t)
    for t in a.drop_task or []:
        if t in (doc.get("taskIds") or []):
            doc["taskIds"].remove(t)
        if unlink(tasks, t, "workerIds", i, now):
            touched_t.add(t)
    if doc != pre and not new:
        doc["updatedAt"] = now
    line = f"workers/{i}: {Q(doc.get('state'), 20)}" + (f", now: \"{Q(doc['now'], 80)}\"" if doc.get("now") else "")
    rc = save_and_report(a, workers, tasks, {i}, touched_t, before_w, before_t, notes, [line + ("   (new worker)" if new else "")])
    return after(a, rc)


def cmd_task(a):
    workers, tasks, _ = load_state(a)
    before_w, before_t = copy.deepcopy(workers), copy.deepcopy(tasks)
    now = qt.now_iso()
    ids = a.ids
    export = export_dir(a)
    live = load_live(export)[0] if export.is_dir() else {}
    for i in ids:
        if not qt.ID_RE.match(i):
            fail(f"'{i}' is not a valid id (lowercase letters, digits, - and _ only).")
    creating = [i for i in ids if not any(d.get("id") == i for d in tasks)]
    fields_given = any(x is not None for x in (a.title, a.plain, a.parent, a.order))
    if len(ids) > 1 and fields_given:
        fail("Give one task at a time when you set --title, --plain, --parent or --order.")
    notes, lines, touched_t, touched_w = [], [], set(), set()
    for i in ids:
        if i in creating and i in live.get("taskAdds", {}):
            fail(f"'{i}' is a task she added. Take it on with:  {me('adopt ' + i)}")
    for i in ids:
        doc = next((d for d in tasks if d.get("id") == i), None)
        new = doc is None
        if new:
            errs = []
            if not a.title:
                errs.append(f"'{i}' is a new task, so say --title \"short name\"")
            if not a.plain:
                errs.append("and --plain \"one or two everyday sentences: what this is and why it matters\"")
            if a.parent is None:
                errs.append("and --parent ID (the bigger task it belongs to), or --parent none for a main idea")
            if errs:
                fail(*errs)
            doc = default_task(i, now)
            tasks.append(doc)
        pre = copy.deepcopy(doc)
        if a.title is not None:
            doc["title"] = a.title.strip()
        if a.plain is not None:
            doc["plain"] = a.plain.strip()
        if a.parent is not None:
            doc["parentId"] = parent_arg(a.parent)
        if a.order is not None:
            doc["order"] = a.order
        elif new:
            doc["order"] = next_order([d for d in tasks if d is not doc], doc.get("parentId"))
        if a.state:
            doc["state"] = a.state
            doc["doneAt"] = now if a.state == "done" and (pre.get("state") != "done" or not pre.get("doneAt")) else (doc.get("doneAt") if a.state == "done" else None)
            if a.state != "waiting" and a.waiting_for is None:
                doc["waitingFor"] = "none"
            if a.state == "waiting" and a.waiting_for is None and doc.get("waitingFor", "none") == "none":
                fail("waiting needs --waiting-for owner|cathy|rob (who is it waiting for?).")
            ed = live.get("taskEdits", {}).get(i, {})
            if ed.get("paused") is True and a.state != "paused":
                notes.append(f"tasks/{i}: she paused it herself, so the page keeps showing it as paused until she resumes it.")
        if a.waiting_for is not None:
            doc["waitingFor"] = a.waiting_for
        if a.note is not None:
            doc["note"] = a.note.strip()
        if a.seen:
            doc["seenAt"] = now
        for q in a.question or []:
            if q not in doc.setdefault("questionIds", []):
                doc["questionIds"].append(q)
        for q in a.drop_question or []:
            if q in (doc.get("questionIds") or []):
                doc["questionIds"].remove(q)
        for w in a.worker or []:
            if w not in doc.setdefault("workerIds", []):
                doc["workerIds"].append(w)
            if not any(x.get("id") == w for x in workers):
                notes.append(f"worker '{w}' is not in the worker file yet; the link is saved on the task only.")
            elif link(workers, w, "taskIds", i, now):
                touched_w.add(w)
        for w in a.drop_worker or []:
            if w in (doc.get("workerIds") or []):
                doc["workerIds"].remove(w)
            if unlink(workers, w, "taskIds", i, now):
                touched_w.add(w)
        if a.title is not None or a.plain is not None:
            ed = live.get("taskEdits", {}).get(i, {})
            hidden = [f for f, v in (("title", a.title), ("plain", a.plain)) if v is not None and isinstance(ed.get(f), str) and ed[f].strip()]
            if hidden:
                notes.append(f"tasks/{i}: she changed the {' and '.join(hidden)} herself, so the page keeps showing her words on top of this change.")
        if doc != pre or new:
            if not new:
                doc["updatedAt"] = now
            touched_t.add(i)
            lines.append(f"tasks/{i}: {Q(doc.get('state'), 20)}" + (f"  \"{Q(doc['title'], 80)}\"" if new else "") + ("   (new task)" if new else ""))
    rc = save_and_report(a, workers, tasks, touched_w, touched_t, before_w, before_t, notes, lines)
    return after(a, rc)


def cmd_adopt(a):
    workers, tasks, _ = load_state(a)
    before_w, before_t = copy.deepcopy(workers), copy.deepcopy(tasks)
    export = need_export(a)
    live = load_live(export)[0]
    adds = live.get("taskAdds", {})
    now = qt.now_iso()
    errs, notes, lines, touched_w = [], [], [], set()
    for i in a.ids:
        ad = adds.get(i)
        if ad is None:
            errs.append(f"'{i}' is not among her task adds in {export}/taskAdds" + (f" (there are: {', '.join(sorted(adds)[:6])})" if adds else " (that folder is empty: export again first)"))
        elif any(d.get("id") == i for d in tasks):
            errs.append(f"'{i}' is already in the task file. To say Claude saw her latest changes use:  task {i} --seen")
    if errs:
        fail(*errs)
    for i in a.ids:
        ad = adds[i]
        pid = ad.get("parentId") or None
        if pid is not None and not (isinstance(pid, str) and qt.ID_RE.match(pid)):
            errs.append(f"'{i}': the place she chose for it is not a valid task id, so it cannot be taken on as it is. Look at it in {export}/taskAdds/{i}.json")
        if errs:
            continue
        created = ad.get("createdAt").strip() if qt.parse_iso(ad.get("createdAt")) is not None else now   # parse_iso refuses line breaks and control characters
        doc = default_task(i, now)
        doc.update({"parentId": pid, "title": ra.oneline(ad.get("title")), "plain": ra.oneline(ad.get("plain")),
                    "createdAt": created, "createdBy": "owner", "seenAt": now,
                    "order": next_order(tasks, pid)})
        if a.state:
            doc["state"] = a.state
            if a.state == "done":
                doc["doneAt"] = now
        if a.waiting_for is not None:
            doc["waitingFor"] = a.waiting_for
        if a.note is not None:
            doc["note"] = a.note.strip()
        doc["questionIds"] = list(a.question or [])
        for w in a.worker or []:
            doc["workerIds"].append(w)
            if link(workers, w, "taskIds", i, now):
                touched_w.add(w)
            elif not any(x.get("id") == w for x in workers):
                notes.append(f"worker '{w}' is not in the worker file yet; the link is saved on the task only.")
        tasks.append(doc)
        lines.append(f"tasks/{i}: taken on (\"{Q(doc['title'], 80)}\"), Claude saw it at {now}; her own words stay as she wrote them.")
        ed = live.get("taskEdits", {}).get(i)
        if ed:
            notes.append(f"tasks/{i}: she changed it after adding it (see read_answers.py); her changes stay on top of this task.")
    if errs:
        fail(*errs, "Nothing was saved.")
    rc = save_and_report(a, workers, tasks, touched_w, set(a.ids), before_w, before_t, notes, lines)
    return after(a, rc)


# ------------------------------------------------------------------------------------------------ reply
def cmd_reply(a):
    export = need_export(a)
    live, live_versions, _, _ = load_live(export)
    outbox = qt.outbox_dir(a.outbox)
    allow = qt.parse_allow(a.allow_words)
    workers, tasks, _ = load_state(a)
    wk_docs, tk_docs = {**live["workers"], **by_id(workers)}, {**live["tasks"], **by_id(tasks)}
    now = qt.now_iso()
    items = []
    if a.file:
        try:
            raw = qt.read_json(a.file)
        except (OSError, ValueError) as e:
            fail(f"Could not read {a.file}: {e}")
        if not isinstance(raw, list) or not raw:
            fail(f"{a.file} should be a list like [{{\"ask\": \"a-1\", \"state\": \"answered\", \"text\": \"...\", \"from\": \"Claude\"}}].")
        for n, e in enumerate(raw, 1):
            if not isinstance(e, dict) or not e.get("ask"):
                fail(f"entry {n} of {a.file} needs an \"ask\" (the id of her question).")
            items.append((e["ask"], e.get("state") or "answered", e.get("text") or "", e.get("from")))
    else:
        if not a.ask:
            fail("say which question: reply ASK_ID --state seen|working|answered [--text \"...\"]")
        if not a.state:
            fail("say what happened: --state seen, working or answered")
        items.append((a.ask, a.state, a.text or "", a.from_name))
    versions = versions_for(a, outbox, live_versions)
    errs, notes, writes, lines = [], [], [], []
    seen_ids = set()
    fields = []
    for ask_id, state, text, frm in items:
        if not isinstance(ask_id, str) or not qt.ID_RE.match(ask_id):
            errs.append(f"'{Q(ask_id)}' is not a valid id.")
            continue
        where = f"asks/{ask_id}"
        ask = live["asks"].get(ask_id)
        if ask_id in seen_ids:
            errs.append(f"{where} appears twice.")
            continue
        seen_ids.add(ask_id)
        if ask is None:
            errs.append(f"{where}: there is no such question in {export}/asks" + (f" (there are: {', '.join(sorted(live['asks'])[:6])})" if live["asks"] else " (that folder is empty: export again first)"))
            continue
        if state not in REPLY_STATES:
            errs.append(f"{where}: state must be seen, working or answered (got '{Q(state, 20)}').")
            continue
        text = text.strip()
        if state == "answered" and not text:
            errs.append(f"{where}: answered needs --text (the answer, in everyday words).")
            continue
        kind, target = ask.get("targetKind"), ask.get("targetId")
        if kind not in TARGET_KINDS or not isinstance(target, str) or not qt.ID_RE.match(target):
            errs.append(f"{where}: her question does not say clearly which worker or task it is about (its kind is '{Q(kind, 20)}', its target '{Q(target, 40)}').")
            continue
        old = live["replies"].get(ask_id)
        if old and REPLY_ORDER.get(old.get("state"), 0) > REPLY_ORDER[state]:
            errs.append(f"{where}: it is already marked '{Q(old.get('state'), 20)}'; it cannot go back to '{Q(state, 20)}'. To change an answer use --state answered with the new text.")
            continue
        frm = (frm or "Claude").strip()
        doc = {"id": ask_id, "targetKind": kind, "targetId": target, "state": state, "text": text, "from": frm, "at": now}
        P = Problems()
        _text_checks(P, where, "replies", "text", text, allow)
        _text_checks(P, where, "replies", "from", frm, allow)
        errs += [t for k, t in P.errors]
        if (target not in wk_docs) if kind == "worker" else (target not in tk_docs and target not in live["taskAdds"]):
            notes.append(f"{where}: {kind} '{target}' is not known (not in the state files and not on the page); the answer is still written.")
        op = "update" if old else "set"
        writes.append(qt.make_write(op, "replies", ask_id, doc, versions))
        if old and not writes[-1].get("if_version"):
            notes.append(f"replies/{ask_id} exists but its version number is not known, so ArtifactData will refuse it and name the number; add --version replies/{ask_id}=N.")
        lines.append(f"replies/{ask_id}: {state}" + (f"  (about {kind} \"{ra._name_of(kind, target, wk_docs, tk_docs, live['taskAdds'], live['taskEdits'])}\")"))
        fields.append(ask)
    if errs:
        fail(*errs, "Nothing was prepared.")
    for l, ask in zip(lines, fields):
        say(l)
        say(f"   her question: \"{ra.clean(ask.get('text'), 160)}\"")
    finish_batches(a, outbox, writes, notes)
    return 0


# ------------------------------------------------------------------------------------------------ applied
def _batch_writes(path):
    try:
        batch = qt.read_json(path)
    except (OSError, ValueError) as e:
        qt.die(f"Could not read the batch file {path}: {e}")
    out = []
    for w in (batch.get("writes") if isinstance(batch, dict) else None) or []:
        if "data" not in w and w.get("file_path"):
            try:
                w = {**w, "data": qt.read_json(w["file_path"])}
            except (OSError, ValueError):
                w = {**w, "data": None}
        out.append(w)
    return out


def _wrapped_style(export):
    """True when the live copy's files are {version, data} wrappers (so new ones should be too)."""
    for f in list(Path(export).glob("*/*.json"))[:30]:
        try:
            raw = qt.read_json(f)
        except (OSError, ValueError):
            continue
        if isinstance(raw, dict) and isinstance(raw.get("data"), dict) and "version" in raw:
            return True
        if isinstance(raw, dict):
            return False
    return True


def mirror(export, writes, versions):
    """After ArtifactData accepted a batch, make the live copy say the same, so the next sync compares with the truth."""
    wrapped = _wrapped_style(export)
    done = []
    for w in writes:
        c, i = w.get("collection"), w.get("doc_id")
        if c not in WRITABLE or not isinstance(i, str) or not isinstance(w.get("data"), dict) or w.get("op") not in ("set", "update"):
            continue
        d = Path(export) / c
        d.mkdir(parents=True, exist_ok=True)
        f = d / f"{i}.json"
        cur = {}
        if f.is_file():
            try:
                cur = ra.unwrap(qt.read_json(f))[0] or {}
            except (OSError, ValueError):
                cur = {}
        doc = dict(w["data"]) if w["op"] == "set" else {**cur, **w["data"]}
        ver = versions.get(f"{c}/{i}")
        body = {"collection": c, "doc_id": i, "version": ver, "data": doc} if (wrapped and ver) else doc
        qt.write_json(f, body)
        done.append(f"{c}/{i}")
    return done


def cmd_applied(a):
    if not a.batch:
        fail("applied needs the batch file that ArtifactData just accepted.")
    lines, vpath = qt.apply_batch(a.batch, a.results, a.outbox, a.again)
    say(f"Recorded {len(lines)} write(s) in {vpath}:")
    for l in lines[:40]:
        say("  " + l)
    if len(lines) > 40:
        say(f"  ... and {len(lines) - 40} more")
    export = export_dir(a)
    if export.is_dir():
        try:
            versions = qt.read_json(vpath)
        except (OSError, ValueError):
            versions = {}
        done = mirror(export, _batch_writes(a.batch), versions)
        if done:
            say(f"The live copy in {export} now says the same, so the next sync starts from what the page shows ({len(done)} document(s)).")
    else:
        say(f"(No live copy folder at {export}, so there was nothing to bring up to date. Export before the next sync.)")
    return 0


# ------------------------------------------------------------------------------------------------ main
def add_common(p, top):
    """The shared options. They work before or after the command name (the top copy holds the defaults)."""
    S = {} if top else {"default": argparse.SUPPRESS}
    p.add_argument("--state-dir", help="folder with workers.json and tasks.json (default: state/ next to tools/)", **S)
    p.add_argument("--export", help="the live copy ArtifactData wrote with out_dir (default: outbox/export)", **S)
    p.add_argument("--outbox", help="where batch files go (default: outbox/)", **S)
    p.add_argument("--versions", help="versions.json made by read_answers.py", **S)
    p.add_argument("--no-versions", action="store_true", help="do not use outbox/versions.json", **S)
    p.add_argument("--version", action="append", metavar="PATH=N", help="one version by hand, e.g. tasks/map=3", **({"default": []} if top else S))
    p.add_argument("--allow-words", help="comma list of words to let through the jargon check", **S)


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    add_common(common, False)

    ap = argparse.ArgumentParser(description="Keep the Workers and Tasks parts of the Terminal true.", epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_common(ap, True)
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("sync", parents=[common], help="compare the state files with the live copy and write batch files")
    p.add_argument("--only", choices=["workers", "tasks"], help="only this collection")
    p.add_argument("--dry-run", action="store_true", help="show what would be sent, write nothing")
    p.add_argument("--skip-bad", action="store_true", help="leave out documents with mistakes instead of stopping")
    p.set_defaults(fn=cmd_sync)

    p = sub.add_parser("export", parents=[common], help="print the ArtifactData list calls that fetch the live copy")
    p.add_argument("--only", help="comma list of collections (default: all six)")
    p.add_argument("--url", help="the page address (remembered in outbox/page-url.txt)")
    p.set_defaults(fn=cmd_export)

    p = sub.add_parser("check", parents=[common], help="look for mistakes in the state files")
    p.set_defaults(fn=cmd_check)

    p = sub.add_parser("worker", parents=[common], help="change (or add) one worker in state/workers.json")
    p.add_argument("id")
    p.add_argument("--name")
    p.add_argument("--kind", choices=WORKER_KINDS)
    p.add_argument("--parent", help="the boss's id, or none for the very top")
    p.add_argument("--icon")
    p.add_argument("--role")
    p.add_argument("--state", choices=WORKER_STATES)
    p.add_argument("--now", help="what they are doing right now (only while working or waiting; use \"\" to clear)")
    p.add_argument("--waiting-for", choices=WORKER_WAIT)
    p.add_argument("--activity", action="append", help="add a line to what they did (newest first, 8 kept); repeatable")
    p.add_argument("--result", help="when done: what they handed back")
    p.add_argument("--task", action="append", help="link a task (both ways); repeatable")
    p.add_argument("--drop-task", action="append")
    p.add_argument("--brain", choices=[b for b in BRAINS if b])
    p.add_argument("--progress", help="0-100, or none. Only when Claude really knows.")
    p.add_argument("--order", type=num)
    p.add_argument("--sync", action="store_true", help="run sync right after saving")
    p.set_defaults(fn=cmd_worker)

    p = sub.add_parser("task", parents=[common], help="change (or add) tasks in state/tasks.json")
    p.add_argument("ids", nargs="+", metavar="id")
    p.add_argument("--title")
    p.add_argument("--plain")
    p.add_argument("--parent", help="the bigger task's id, or none for a main idea")
    p.add_argument("--state", choices=TASK_STATES)
    p.add_argument("--waiting-for", choices=TASK_WAIT)
    p.add_argument("--note")
    p.add_argument("--worker", action="append", help="link a worker (both ways); repeatable")
    p.add_argument("--drop-worker", action="append")
    p.add_argument("--question", action="append", help="link a question id; repeatable")
    p.add_argument("--drop-question", action="append")
    p.add_argument("--seen", action="store_true", help="say Claude has looked at her latest changes to this task")
    p.add_argument("--order", type=num)
    p.add_argument("--sync", action="store_true")
    p.set_defaults(fn=cmd_task)

    p = sub.add_parser("adopt", parents=[common], help="take on a task she added (writes it to state/tasks.json with seenAt)")
    p.add_argument("ids", nargs="+", metavar="taskadd_id")
    p.add_argument("--state", choices=TASK_STATES)
    p.add_argument("--waiting-for", choices=TASK_WAIT)
    p.add_argument("--note")
    p.add_argument("--worker", action="append")
    p.add_argument("--question", action="append")
    p.add_argument("--sync", action="store_true")
    p.set_defaults(fn=cmd_adopt)

    p = sub.add_parser("reply", parents=[common], help="answer one of her questions to a worker or task")
    p.add_argument("ask", nargs="?", help="the ask id")
    p.add_argument("--state", choices=REPLY_STATES)
    p.add_argument("--text", help="the answer, in everyday words (up to 1200 characters)")
    p.add_argument("--from", dest="from_name", help="who answers: Claude (default) or the worker's name")
    p.add_argument("--file", help="several replies at once: a list of {ask, state, text, from}")
    p.set_defaults(fn=cmd_reply)

    p = sub.add_parser("applied", parents=[common], help="after ArtifactData accepted a batch file: keep the version numbers right")
    p.add_argument("batch", nargs="?")
    p.add_argument("--results", help="JSON map path -> version copied from the ArtifactData result")
    p.add_argument("--again", action="store_true", help="record a batch file that was recorded before")
    p.set_defaults(fn=cmd_applied)
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
