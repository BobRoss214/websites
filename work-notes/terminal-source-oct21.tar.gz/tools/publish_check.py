#!/usr/bin/env python3
"""Pre-publish checker for the Question Terminal (for Claude, not for the owner).

    python3 -I T/tools/publish_check.py [--url PAGE_URL] [--outbox DIR] [--skip-seed] [--keep-build FILE]
                                        [--export DIR] [--her-section ID ...] [--seed DIR] [--skip-page]

1. THE PAGE   builds the page into a temporary file (python3 T/build.py --out ...) and checks it:
              <title>Terminal</title> in the first 8 KB, under 2 MB, no <html>/<head>/<body> tags, nothing loaded from another web address
              (script, link, font, picture, import, url()), no eval / new Function / document.write / alert / confirm / prompt / print / timer with a string,
              every localStorage / sessionStorage / indexedDB use inside try { }, no syntax error in any script, colours only as tokens (light, both dark
              blocks the same, text pairs >= 4.5:1 and the layout's own test/layout-contrast.py), and prints the md5 (and whether T/dist/index.html is the same).
2. THE SEED   post_question.py check --many T/seed, then finish --many T/seed (plain "set" writes, no versions) and checks the batch files
              (<= 50 writes each, every file there, sections before questions, ids unique, counts agree with the seed files).
              A seed question may sit in one of HER OWN sections (she made it on the page, so it is not in the seed): its id must then be in the
              live notebook: give the export folder (--export DIR, default T/export when it has sections/) or name it (--her-section ID).
              Without either, such a section is a WARN (cannot be checked), never a pass.
3. THE CALLS  prints the exact Artifact publish call and the ArtifactData batch calls (also saved as ready-to-paste JSON in <outbox>/publish/),
              the heartbeat command, and the order to do things in.
FAIL = do not publish yet. WARN = look at it, you may publish. Exit code 1 when there is a FAIL, else 0. Needs only python3 (node + typescript for
the exact script check; without them it falls back to a rough text search and says so). Writes nothing in T/dist or T/src.
"""
import argparse
import ast
import collections
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
NODE_ENV = dict(os.environ, NODE_PATH=os.environ.get('NODE_PATH') or '/opt/node22/lib/node_modules')
NODE_ENV.pop('WA_URL', None)

PUBLISH_ICON = 'question'
PAGE_TITLE = 'Terminal'   # the <title> of the page (the page name Miss Cathy and Rob see)
PUBLISH_DESCRIPTION = 'Questions for the farm owner: Claude asks, she answers, and Claude sees every answer as soon as she gives it.'
CAPABILITIES = {'db': {}, 'comments': {}, 'assets': {}, 'user': {}}
MAX_BYTES = 2 * 1024 * 1024
BUILTIN_SECTIONS = ('look', 'other', 'later', 'kathy')
ID_OK = re.compile(r'^[a-z0-9_-]+$')

counts = collections.Counter()


def say(level, text, detail=''):
    counts[level] += 1
    line = '%-5s %s' % (level, text)
    if detail:
        line += '\n        ' + str(detail).replace('\n', '\n        ')
    print(line)


def ok(cond, text, detail='', level='FAIL'):
    """PASS when cond, else `level` (FAIL or WARN) with the detail."""
    if cond:
        say('PASS', text)
    else:
        say(level, text, detail)
    return bool(cond)


def head(title):
    print('\n== %s ==' % title)


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


# ------------------------------------------------------------------------------------------------ reading the built page
def split_blocks(html):
    """-> (scripts, styles, rest): script/style bodies with the line they start on, and the HTML left when both and all comments are taken out."""
    scripts, styles = [], []
    pat = re.compile(r'<(script|style)\b([^>]*)>(.*?)</\1\s*>', re.S | re.I)
    for m in pat.finditer(html):
        item = {'attrs': m.group(2), 'text': m.group(3), 'line': html.count('\n', 0, m.start(3)) + 1}
        (scripts if m.group(1).lower() == 'script' else styles).append(item)
    rest = pat.sub('', html)
    rest = re.sub(r'<!--.*?-->', '', rest, flags=re.S)
    return scripts, styles, rest


def tags(rest):
    for m in re.finditer(r'<([a-zA-Z][\w:-]*)\b((?:"[^"]*"|\'[^\']*\'|[^>"\'])*)>', rest):
        attrs = {}
        for a in re.finditer(r'([\w:.-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))', m.group(2)):
            attrs[a.group(1).lower()] = a.group(2) if a.group(2) is not None else a.group(3) if a.group(3) is not None else a.group(4)
        yield m.group(1).lower(), attrs


def is_external(v):
    return bool(re.match(r'^\s*(https?:)?//', v or '', re.I))


def is_relative_file(v):
    v = (v or '').strip()
    return bool(v) and not re.match(r'^(#|data:|mailto:|tel:|javascript:|blob:|about:|https?:|//)', v, re.I)


# ------------------------------------------------------------------------------------------------ the exact script check (TypeScript's own parser)
ANALYZER = r"""
const ts = require('typescript'); const fs = require('fs');
const blocks = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const out = { findings: [], urls: [], colours: [], syntax: [], used: {} };
const WIN = new Set(['window', 'self', 'globalThis', 'top', 'parent']);
const NAMED = ['eval', 'alert', 'confirm', 'prompt', 'print'];
const STORAGE = new Set(['localStorage', 'sessionStorage', 'indexedDB']);
const SRCATTR = new Set(['src', 'href', 'data', 'poster', 'srcset', 'action', 'formAction']);
for (const b of blocks) {
  const sf = ts.createSourceFile('b' + b.i + '.js', b.text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  (sf.parseDiagnostics || []).forEach((d) => out.syntax.push({ block: b.i, line: b.line + sf.getLineAndCharacterOfPosition(d.start || 0).line, msg: ts.flattenDiagnosticMessageText(d.messageText, ' ') }));
  const ln = (n) => b.line + sf.getLineAndCharacterOfPosition(n.getStart(sf)).line;
  const txt = (n) => n.getText(sf);
  const add = (kind, n, what) => out.findings.push({ kind, line: ln(n), what: what || txt(n).slice(0, 80).replace(/\s+/g, ' ') });
  const inTry = (n) => { for (let c = n, p = n.parent; p; c = p, p = p.parent) { if (ts.isTryStatement(p) && p.tryBlock === c) return true; } return false; };
  const strOf = (n) => (n && (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n))) ? n.text : null;
  const isWin = (e) => ts.isIdentifier(e) && WIN.has(e.text);
  const visit = (n) => {
    if (ts.isCallExpression(n) || ts.isNewExpression(n)) {
      const f = n.expression; const isNew = ts.isNewExpression(n);
      let name = null, obj = null;
      if (ts.isIdentifier(f)) name = f.text; else if (ts.isPropertyAccessExpression(f)) { name = f.name.text; obj = f.expression; }
      if (name === 'eval' && (!obj || isWin(obj))) add('eval', n);
      if (name === 'Function' && (!obj || isWin(obj))) add('Function', n);
      if (!isNew && NAMED.slice(1).includes(name) && (!obj || isWin(obj))) add(name === 'print' ? 'print' : 'dialog', n, name + '(...)');
      if (!isNew && (name === 'write' || name === 'writeln') && obj && (txt(obj) === 'document' || txt(obj) === 'window.document')) add('document.write', n);
      if (!isNew && (name === 'setTimeout' || name === 'setInterval') && (!obj || isWin(obj)) && n.arguments.length && (strOf(n.arguments[0]) !== null || ts.isTemplateExpression(n.arguments[0]))) add('timer-string', n);
      if (!isNew && name === 'fetch' && (!obj || isWin(obj))) add('network', n, 'fetch');
      if (!isNew && name === 'importScripts') add('network', n, 'importScripts');
      if (!isNew && name === 'sendBeacon') add('network', n, 'sendBeacon');
      if (isNew && ['XMLHttpRequest', 'WebSocket', 'EventSource', 'Worker', 'SharedWorker'].includes(name)) add('network', n, 'new ' + name);
      if (!isNew && f.kind === ts.SyntaxKind.ImportKeyword) add('network', n, 'import()');
      if (!isNew && name === 'insertAdjacentHTML') add('html', n, 'insertAdjacentHTML');
      if (!isNew && name === 'open' && obj && isWin(obj) && n.arguments.length && /^https?:/i.test(strOf(n.arguments[0]) || '')) add('open-url', n);
      if (!isNew && name === 'setAttribute' && n.arguments.length > 1) {
        const a = strOf(n.arguments[0]), v = strOf(n.arguments[1]);
        if (a && SRCATTR.has(a.toLowerCase()) && /^\s*(https?:)?\/\//i.test(v || '')) add('external-load', n, 'setAttribute(' + a + ', ' + v + ')');
      }
    }
    if (ts.isBinaryExpression(n) && n.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isPropertyAccessExpression(n.left)) {
      const nm = n.left.name.text; const v = strOf(n.right);
      if ((nm === 'innerHTML' || nm === 'outerHTML') && !(v !== null && !/[<&]/.test(v))) add('html', n, nm + ' = ' + txt(n.right).slice(0, 50).replace(/\s+/g, ' '));
      if (SRCATTR.has(nm) && /^\s*(https?:)?\/\//i.test(v || '')) add('external-load', n, '.' + nm + ' = ' + v);
    }
    // storage: every reference must sit inside the try { } part of a try statement
    let sname = null;
    if (ts.isIdentifier(n) && STORAGE.has(n.text)) {
      const p = n.parent;
      const declared = (ts.isPropertyAssignment(p) && p.name === n) || (ts.isVariableDeclaration(p) && p.name === n) || (ts.isParameter(p) && p.name === n) || (ts.isBindingElement(p)) || (ts.isPropertySignature && ts.isPropertySignature(p)) || (ts.isMethodDeclaration(p) && p.name === n);
      if (!declared) sname = n.text;
    } else if (ts.isElementAccessExpression(n) && strOf(n.argumentExpression) && STORAGE.has(strOf(n.argumentExpression))) sname = strOf(n.argumentExpression);
    if (sname) { out.used[sname] = (out.used[sname] || 0) + 1; if (!inTry(n)) add('storage-no-try', n, sname); }
    if (ts.isPropertyAccessExpression(n) && n.name.text === 'cookie' && txt(n.expression) === 'document') add('cookie', n);
    const s = (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) ? n.text : (ts.isTemplateHead(n) || ts.isTemplateMiddle(n) || ts.isTemplateTail(n)) ? n.text : null;
    if (s !== null) {
      const m = s.match(/(https?:)?\/\/[^\s"'<>)]+/g);
      if (m && /https?:\/\/|^\s*\/\//.test(s)) m.forEach((u) => { if (/^https?:/i.test(u) || /^\s*\/\//.test(s)) out.urls.push({ line: ln(n), url: u.slice(0, 120) }); });
      if (/^\s*(#[0-9a-fA-F]{3,8}|(rgb|hsl)a?\([^)]*\))\s*$/.test(s) || /(^|[\s:;,(])(#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}|rgba?\([^)]*\))(?![0-9a-zA-Z])/.test(s)) out.colours.push({ line: ln(n), text: s.slice(0, 60).replace(/\s+/g, ' ') });
    }
    ts.forEachChild(n, visit);
  };
  visit(sf);
}
process.stdout.write(JSON.stringify(out));
"""


def analyse_scripts(scripts, tmp):
    """-> dict from the TypeScript parser, or None when node / typescript is not there."""
    if not shutil.which('node'):
        return None
    src = os.path.join(tmp, 'analyze.js')
    data = os.path.join(tmp, 'blocks.json')
    with open(src, 'w', encoding='utf8') as f:
        f.write(ANALYZER)
    with open(data, 'w', encoding='utf8') as f:
        json.dump([{'i': i + 1, 'text': s['text'], 'line': s['line']} for i, s in enumerate(scripts)], f)
    r = run(['node', src, data], env=NODE_ENV, cwd=tmp)
    if r.returncode != 0:
        return None
    try:
        return json.loads(r.stdout)
    except ValueError:
        return None


def rough_scripts(scripts):
    """Fallback when typescript is missing: a text search that first throws away comments (roughly) and string contents are NOT understood."""
    out = {'findings': [], 'urls': [], 'colours': [], 'syntax': [], 'used': {}}
    for s in scripts:
        text = re.sub(r'/\*.*?\*/', lambda m: '\n' * m.group(0).count('\n'), s['text'], flags=re.S)
        text = re.sub(r'(?m)(^|[^:\'"\\])//.*$', r'\1', text)
        for kind, pat in (('eval', r'(?<![\w.])eval\s*\('), ('Function', r'(?<![\w.])Function\s*\('), ('document.write', r'document\.write(ln)?\s*\('),
                          ('dialog', r'(?<![\w.])(alert|confirm|prompt)\s*\('), ('print', r'window\.print\s*\('), ('network', r'(?<![\w.])fetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon')):
            for m in re.finditer(pat, text):
                out['findings'].append({'kind': kind, 'line': s['line'] + text.count('\n', 0, m.start()), 'what': m.group(0)})
        for m in re.finditer(r'(?<![\w.])(localStorage|sessionStorage|indexedDB)\b', text):
            out['findings'].append({'kind': 'storage-rough', 'line': s['line'] + text.count('\n', 0, m.start()), 'what': m.group(1)})
        for m in re.finditer(r'https?://[^\s"\'<>)]+', text):
            out['urls'].append({'line': s['line'] + text.count('\n', 0, m.start()), 'url': m.group(0)[:120]})
    return out


# ------------------------------------------------------------------------------------------------ CSS
NAMED_COLOURS = set('white black red green blue yellow orange purple pink gray grey silver gold brown navy teal maroon lime aqua cyan magenta olive beige ivory khaki tan salmon coral crimson indigo violet'.split())
COLOUR_PROPS = re.compile(r'^(color|background|background-color|background-image|border(-[a-z]+)*|outline(-[a-z]+)*|fill|stroke|box-shadow|text-shadow|caret-color|accent-color|text-decoration(-color)?|column-rule(-color)?|filter|drop-shadow|-webkit-text-stroke(-color)?|scrollbar-color|text-emphasis-color)$')


def css_parse(css, ctx=''):
    """Very small CSS reader -> [(context, selector, body)]. Enters @media / @supports; keeps @font-face, @keyframes as one entry."""
    out, i, n = [], 0, len(css)
    while i < n:
        j = css.find('{', i)
        if j < 0:
            break
        sel = css[i:j].strip()
        depth, k, q = 1, j + 1, None
        while k < n and depth:
            c = css[k]
            if q:
                if c == '\\':
                    k += 1
                elif c == q:
                    q = None
            elif c in '"\'':
                q = c
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            k += 1
        body = css[j + 1:k - 1]
        low = sel.lower()
        if low.startswith(('@media', '@supports', '@container', '@layer')):
            out += css_parse(body, ctx + ' ' + re.sub(r'\s+', ' ', sel))
        else:
            out.append((ctx.strip(), re.sub(r'\s+', ' ', sel), body))
        i = k
    return out


def decls(body):
    parts, cur, depth, q = [], '', 0, None
    for c in body:
        if q:
            cur += c
            if c == q:
                q = None
            continue
        if c in '"\'':
            q = c
        elif c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
        if c == ';' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += c
    parts.append(cur)
    for p in parts:
        if ':' in p:
            k, v = p.split(':', 1)
            if k.strip():
                yield k.strip().lower(), v.strip()


def colour_literals(prop, value):
    v = re.sub(r'url\([^)]*\)', ' ', value)
    found = re.findall(r'#[0-9a-fA-F]{3,8}\b|\b(?:rgba?|hsla?|hwb|lab|lch|oklab|oklch)\([^)]*\)', v)
    if COLOUR_PROPS.match(prop):
        found += [w for w in re.findall(r'[a-zA-Z]+', re.sub(r'var\([^)]*\)', ' ', v)) if w.lower() in NAMED_COLOURS]
    return found


def lum(hexc):
    h = hexc.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    r, g, b = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def ratio(a, b):
    la, lb = lum(a), lum(b)
    if la < lb:
        la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)


SCRIPT_NAMES = {'bg': 'bg', 'card': 'card', 'ink': 'ink', 'soft': 'soft', 'line': 'line', 'ls': 'line-strong', 'accent': 'accent', 'aink': 'accent-ink', 'asoft': 'accent-soft',
                'good': 'good', 'gbg': 'good-bg', 'warn': 'warn', 'wbg': 'warn-bg', 'info': 'info', 'ibg': 'info-bg', 'panel': 'panel', 'focus': 'focus'}
FALLBACK_PAIRS = [('ink', 'bg', 4.5), ('ink', 'card', 4.5), ('ink', 'panel', 4.5), ('soft', 'bg', 4.5), ('soft', 'card', 4.5), ('soft', 'panel', 4.5), ('aink', 'accent', 4.5),
                  ('accent', 'bg', 4.5), ('accent', 'card', 4.5), ('accent', 'asoft', 4.5), ('ink', 'asoft', 4.5), ('good', 'gbg', 4.5), ('good', 'bg', 4.5), ('good', 'card', 4.5),
                  ('warn', 'wbg', 4.5), ('warn', 'bg', 4.5), ('warn', 'card', 4.5), ('info', 'ibg', 4.5), ('info', 'bg', 4.5), ('info', 'card', 4.5), ('ink', 'gbg', 4.5),
                  ('ink', 'wbg', 4.5), ('ink', 'ibg', 4.5), ('soft', 'gbg', 4.5), ('soft', 'wbg', 4.5), ('soft', 'ibg', 4.5), ('ls', 'bg', 3), ('ls', 'card', 3), ('focus', 'bg', 3),
                  ('focus', 'card', 3), ('focus', 'accent', 3)]


def check_css(styles, scripts_text):
    chunks = []
    for s in styles:
        parts = re.split(r'/\*\s*====\s*(\S+)\s*====\s*\*/', s['text'])
        if len(parts) == 1:
            chunks.append(('(style)', parts[0]))
        else:
            chunks.append(('(style)', parts[0]))
            for k in range(1, len(parts), 2):
                chunks.append((parts[k], parts[k + 1]))
    rules = []
    for name, text in chunks:
        text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
        text = re.sub(r'@(import|charset|namespace)\b[^;{}]*;', '', text)
        for ctx, sel, body in css_parse(text):
            rules.append((name, ctx, sel, body))
    say('INFO', 'css: %d style block(s), %d rules, from %s' % (len(styles), len(rules), ', '.join(sorted({r[0] for r in rules if r[0] != '(style)'})) or 'one block'))

    light, dark_auto, dark_exp, defined = {}, {}, {}, set()
    for name, ctx, sel, body in rules:
        for k, v in decls(body):
            if k.startswith('--'):
                defined.add(k)
        if sel == ':root' and not ctx:
            light.update({k: v for k, v in decls(body) if k.startswith('--')})
        elif sel == ':root:not([data-theme="light"])' and 'prefers-color-scheme' in ctx and 'dark' in ctx:
            dark_auto.update({k: v for k, v in decls(body) if k.startswith('--')})
        elif sel == ':root[data-theme="dark"]' and not ctx:
            dark_exp.update({k: v for k, v in decls(body) if k.startswith('--')})
    colour_tok = {k: v for k, v in light.items() if re.match(r'^(#[0-9a-fA-F]{3,8}|rgba?\(|hsla?\()', v)}
    ok(len(colour_tok) >= 12, 'the colour tokens are defined on :root (%d found)' % len(colour_tok), 'expected --bg --card --ink --soft --line --line-strong --accent ... in the first :root block')
    ok(bool(dark_auto) and bool(dark_exp), 'there is a dark set for the system setting and for data-theme="dark"', 'auto-dark %d tokens, explicit dark %d tokens' % (len(dark_auto), len(dark_exp)))
    missing = sorted(k for k in colour_tok if k not in dark_auto or k not in dark_exp)
    ok(not missing, 'every colour token is redefined in both dark sets', ', '.join(missing))
    ok(dark_auto == dark_exp, 'the two dark sets are the same', ', '.join(sorted(k for k in set(dark_auto) | set(dark_exp) if dark_auto.get(k) != dark_exp.get(k))))

    # colours written outside the token blocks
    stray = collections.defaultdict(list)
    token_rule = lambda sel, ctx: sel in (':root', ':root:not([data-theme="light"])', ':root[data-theme="dark"]')
    for name, ctx, sel, body in rules:
        if sel.startswith('@keyframes') or sel.startswith('@-webkit-keyframes'):
            continue
        for k, v in decls(body):
            if k.startswith('--') and token_rule(sel, ctx):
                continue
            lit = colour_literals(k, v)
            if lit:
                stray[name].append('%s{%s: %s}' % (sel[:50], k, ','.join(lit[:2])))
    total = sum(len(v) for v in stray.values())
    ok(total == 0, 'no colour is written outside the tokens (%d place(s))' % total,
       '\n'.join('%s: %d, e.g. %s' % (n, len(v), '; '.join(v[:3])) for n, v in sorted(stray.items())), level='WARN')

    # tokens used but never defined
    used = set()
    for name, ctx, sel, body in rules:
        for m in re.finditer(r'var\(\s*(--[\w-]+)\s*\)', body):
            used.add(m.group(1))
    undefined = sorted(u for u in used if u not in defined and ('"' + u + '"' not in scripts_text and "'" + u + "'" not in scripts_text and u not in scripts_text))
    ok(not undefined, 'every var(--token) used without a fallback is defined somewhere (%d used)' % len(used), ', '.join(undefined), level='WARN')

    # text pairs, from the real tokens (both themes)
    pairs = FALLBACK_PAIRS
    sp = os.path.join(T, 'test', 'layout-contrast.py')
    pal_ok, script_out = None, None
    if os.path.exists(sp):
        src = open(sp, encoding='utf8').read()
        m = re.search(r'pairs\s*=\s*(\[.*?\])\s*\n', src, re.S)
        if m:
            try:
                pairs = ast.literal_eval(m.group(1))
            except (ValueError, SyntaxError):
                pairs = FALLBACK_PAIRS
        r = run([PY, '-I', sp])
        script_out = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr.strip()[:200]
        # does the script's palette still match the CSS?
        pal = {}
        for nm in ('L', 'D'):
            mm = re.search(r'\b%s=dict\((.*?)\)\n' % nm, src, re.S)
            if mm:
                try:
                    pal[nm] = dict(re.findall(r"(\w+)='(#[0-9a-fA-F]+)'", mm.group(1)))
                except ValueError:
                    pass
        diff = []
        for nm, tok in (('L', light), ('D', dark_auto)):
            for sname, cname in SCRIPT_NAMES.items():
                if nm in pal and sname in pal[nm] and tok.get('--' + cname, '').lower() != pal[nm][sname].lower():
                    diff.append('%s %s: css %s, script %s' % ('light' if nm == 'L' else 'dark', cname, tok.get('--' + cname), pal[nm][sname]))
        pal_ok = not diff
        ok(pal_ok, "test/layout-contrast.py uses the same colours as the page's tokens", '\n'.join(diff[:8]), level='WARN')
        say('INFO', 'test/layout-contrast.py itself says "%s"' % script_out)
    low, low_ui = [], []
    for theme, tok in (('light', light), ('dark', dark_auto)):
        for a, b, need in pairs:
            ca, cb = tok.get('--' + SCRIPT_NAMES.get(a, a)), tok.get('--' + SCRIPT_NAMES.get(b, b))
            if not (ca and cb and re.match(r'^#[0-9a-fA-F]{3,6}$', ca) and re.match(r'^#[0-9a-fA-F]{3,6}$', cb)):
                continue
            rr = ratio(ca, cb)
            if rr < need:
                (low if need >= 4.5 else low_ui).append('%s: %s on %s = %.2f (need %s)' % (theme, a, b, rr, need))
    ok(not low, 'TEXT colour pairs from the real tokens: %d pairs x 2 themes reach 4.5:1' % len([p for p in pairs if p[2] >= 4.5]), '\n'.join(low))
    ok(not low_ui, 'line / focus colour pairs reach 3:1', '\n'.join(low_ui) + '\n(focus on accent only matters where a focus ring is drawn on a red button with no gap; buttons use outline-offset 2px, so the ring sits on the page colour)', level='WARN')

    # nothing loaded from outside, no @import
    bad_url = []
    for s in styles:
        t = re.sub(r'/\*.*?\*/', '', s['text'], flags=re.S)
        if re.search(r'@import', t):
            bad_url.append('@import')
        for m in re.finditer(r'url\(\s*([\'"]?)([^)\'"]*)\1\s*\)', t):
            u = m.group(2).strip()
            if is_external(u):
                bad_url.append(u[:80])
            elif is_relative_file(u):
                bad_url.append('(not bundled) ' + u[:80])
    ok(not bad_url, 'the CSS loads nothing from outside (no @import, no url(http...), no font file)', ', '.join(bad_url[:6]))
    data_urls = sum(len(re.findall(r'url\(\s*[\'"]?data:', s['text'])) for s in styles)
    if data_urls:
        say('INFO', 'css has %d inline data: picture(s)' % data_urls)


# ------------------------------------------------------------------------------------------------ 1. the page
def check_page(tmp, args):
    head('1. THE PAGE')
    out = os.path.join(tmp, 'qt-build.html')
    cmd = [PY, os.path.join(T, 'build.py'), '--out', out] + (['--src', args.src] if args.src else [])
    r = run(cmd, cwd=T)
    if not ok(r.returncode == 0 and os.path.exists(out), 'python3 T/build.py builds the page (every script is also syntax-checked by node there)', (r.stdout + r.stderr).strip()[-600:]):
        return None
    data = open(out, 'rb').read()
    html = data.decode('utf8')
    md5 = hashlib.md5(data).hexdigest()
    ok(len(data) < MAX_BYTES, 'size %d bytes (%.1f KB), the limit is 2 MB' % (len(data), len(data) / 1024), 'too big for an artifact')
    if len(data) > 1024 * 1024:
        say('WARN', 'the page is over 1 MB: slow to open on a phone')
    title_tag = '<title>%s</title>' % PAGE_TITLE
    ok(title_tag in html[:8192], '%s is inside the first 8 KB' % title_tag, 'starts with: %r' % html[:80])
    scripts, styles, rest = split_blocks(html)
    ok(html.lower().count('<script') == len(scripts), 'every <script> has its end tag (%d script blocks, %d style blocks)' % (len(scripts), len(styles)), 'a script is cut short or nested')
    bad = [m.group(0) for m in re.finditer(r'<\s*/?\s*(html|head|body)\b[^>]*>', rest, re.I)]
    ok(not bad, 'no <html>, <head> or <body> tag in the page (the artifact adds them)', ', '.join(bad[:5]))
    inside = [m.group(0) for s in scripts + styles for m in re.finditer(r'<\s*(html|head|body)\b', s['text'], re.I)]
    if inside:
        say('WARN', '"<html|<head|<body" appears %d time(s) inside script text (a string, not a tag; check it is not written into the page)' % len(inside))
    ok(rest.lower().count('<title') == 1, 'exactly one <title>', 'found %d' % rest.lower().count('<title'))
    ok(not re.search(r'<!doctype', html[:200], re.I), 'no <!doctype> (the artifact adds it)', level='WARN')

    # markup: nothing loaded from another address
    ext, rel, links = [], [], 0
    for blk in scripts + styles:
        m = re.search(r'\b(src|href)\s*=\s*["\']?([^"\'\s>]+)', blk['attrs'], re.I)
        if m:
            (ext if is_external(m.group(2)) else rel).append('<script|style %s=%s> (the page must carry its code inside)' % (m.group(1), m.group(2)[:70]))
    for name, a in tags(rest):
        for attr in ('src', 'srcset', 'poster', 'data', 'action', 'formaction', 'xlink:href', 'href', 'background'):
            v = a.get(attr)
            if v is None:
                continue
            if name == 'a' and attr == 'href':
                if is_external(v):
                    links += 1
                continue
            if is_external(v):
                ext.append('<%s %s=%s>' % (name, attr, v[:70]))
            elif name in ('script', 'link', 'img', 'iframe', 'source', 'video', 'audio', 'embed', 'object') and is_relative_file(v):
                rel.append('<%s %s=%s>' % (name, attr, v[:70]))
        if name == 'meta' and (a.get('http-equiv') or '').lower() == 'refresh':
            ext.append('<meta http-equiv=refresh>')
        if name in ('iframe', 'embed', 'object', 'base'):
            say('WARN', '<%s> is in the page' % name)
    ok(not ext, 'nothing in the markup is loaded from another web address (script, link, font, picture, frame)', '\n'.join(ext[:8]))
    ok(not rel, 'no script / stylesheet / picture points at a file that would not be there (the page is one file)', '\n'.join(rel[:8]), level='WARN')
    if links:
        say('INFO', '%d plain link(s) <a href="https://..."> (taps, not loads)' % links)
    handlers = sorted({k for _n, a in tags(rest) for k in a if re.match(r'^on[a-z]+$', k)})
    ok(not handlers, 'no inline event handler attributes (onclick=...)', ', '.join(handlers), level='WARN')
    if re.search(r'data:image', rest):
        say('WARN', 'a picture is embedded as data: in the markup (pictures should be web addresses)')

    # scripts
    ana = analyse_scripts(scripts, tmp)
    if ana is None:
        say('WARN', 'node or typescript was not found: scripts were checked with a rough text search only (set NODE_PATH=/opt/node22/lib/node_modules)')
        ana = rough_scripts(scripts)
    else:
        say('INFO', 'scripts read with the TypeScript parser (comments and strings are understood)')
    ok(not ana['syntax'], 'every script block parses', '\n'.join('block %s line %s: %s' % (s['block'], s['line'], s['msg']) for s in ana['syntax'][:5]))
    by = collections.defaultdict(list)
    for f in ana['findings']:
        by[f['kind']].append('line %d: %s' % (f['line'], f['what']))
    for kind, label in (('eval', 'no eval(...)'), ('Function', 'no new Function(...)'), ('document.write', 'no document.write(...)'),
                        ('dialog', 'no alert( / confirm( / prompt('), ('print', 'no window.print()'), ('timer-string', 'no setTimeout / setInterval with a string')):
        ok(not by[kind], label, '\n'.join(by[kind][:6]))
    used = ana.get('used', {})
    if 'storage-rough' in by:
        say('WARN', 'storage use was found by text search only: cannot prove each use is inside try { }', '\n'.join(by['storage-rough'][:6]))
    else:
        ok(not by['storage-no-try'], 'every localStorage / sessionStorage / indexedDB use is inside try { } (%s)' % (', '.join('%s x%d' % kv for kv in sorted(used.items())) or 'none used'),
           '\n'.join(by['storage-no-try'][:8]))
    ok(not by['external-load'], 'no script sets a src / href to another web address', '\n'.join(by['external-load'][:6]))
    ok(not by['network'], 'no script uses the network itself (fetch, XMLHttpRequest, WebSocket, sendBeacon, import())', '\n'.join(by['network'][:6]), level='WARN')
    ok(not by['html'], 'no innerHTML / outerHTML / insertAdjacentHTML with anything but plain text', '\n'.join(by['html'][:8]), level='WARN')
    ok(not by['cookie'] and not by['open-url'], 'no cookies, no window.open to a web address', '\n'.join(by['cookie'] + by['open-url']), level='WARN')
    allowed = re.compile(r'^https?://www\.w3\.org/(2000/svg|1999/xlink|1998/Math/MathML|1999/xhtml)$')
    urls = [u for u in ana['urls'] if not allowed.match(u['url'].rstrip('/'))]
    ok(not urls, 'web addresses inside script text (strings, not loaded): %d besides the SVG name' % len(urls), '\n'.join('line %d: %s' % (u['line'], u['url']) for u in urls[:8]), level='WARN')
    cols = ana['colours']
    ok(not cols, 'no colour is written in script text (%d place(s))' % len(cols), '\n'.join('line %d: %s' % (c['line'], c['text']) for c in cols[:8]), level='WARN')

    check_css(styles, '\n'.join(s['text'] for s in scripts))

    # fingerprint
    print()
    dist = os.path.join(T, 'dist', 'index.html')
    same = os.path.exists(dist) and hashlib.md5(open(dist, 'rb').read()).hexdigest() == md5
    say('INFO', 'md5 of this build: %s  (%d bytes)' % (md5, len(data)))
    ok(same, 'T/dist/index.html is exactly this build (this is the file the publish call below uses)',
       'dist is missing or older than the sources: run  python3 %s/build.py  first (md5 of dist: %s)' % (T, hashlib.md5(open(dist, "rb").read()).hexdigest() if os.path.exists(dist) else 'none'), level='WARN')
    if args.keep_build:
        shutil.copyfile(out, args.keep_build)
        say('INFO', 'build kept at ' + args.keep_build)
    return {'md5': md5, 'bytes': len(data), 'dist_same': same}


# ------------------------------------------------------------------------------------------------ 2. the seed
def live_section_ids(args):
    """(ids of her sections in the live notebook, where they came from) - from --her-section and the export folder (sections/*.json); (None, ...) when nothing is known."""
    ids = set(args.her_section or [])
    where = ['--her-section'] if ids else []
    folder = args.export or os.path.join(T, 'export')
    sdir = os.path.join(folder, 'sections')
    if os.path.isdir(sdir):
        names = [f[:-5] for f in os.listdir(sdir) if f.endswith('.json')]
        if names or args.export:
            ids |= set(names)
            where.append('the export in %s (%d section(s))' % (folder, len(names)))
    elif args.export:
        say('WARN', '--export %s has no sections/ folder (run: cycle.py begin, and list the sections collection)' % folder)
    return (ids if where else None), where


def check_question_sections(args, secs, qs):
    """Every seed question belongs to a seed section or to one of HER sections, which only the live notebook knows."""
    unk = sorted({q.get('sectionId') for q in qs.values()} - set(secs), key=str)
    bad = [u for u in unk if not (isinstance(u, str) and ID_OK.match(u))]
    ok(not bad, 'every question names a section id that is well formed', ', '.join(map(repr, bad)))
    unk = [u for u in unk if u not in bad]
    if not unk:
        ok(not bad, 'every question belongs to a section that exists')
        return
    known, where = live_section_ids(args)
    if known is None:
        ok(False, 'sections her questions use are not in the seed: %s (her own sections? the live notebook cannot be checked)' % ', '.join(unk),
           'These ids are not seed sections. If they are sections she made on the page, check them against the live notebook: python3 -I tools/publish_check.py --export <export folder with sections/> '
           '(or --her-section ID for each).', level='WARN')
        return
    missing = [u for u in unk if u not in known]
    ok(not missing, 'every question belongs to a seed section or to one of her sections in the live notebook (%s)' % '; '.join(where),
       'not in the seed and not in the live notebook: ' + ', '.join(missing))
    if not missing:
        say('INFO', 'her own sections used by seed questions: %s' % ', '.join(unk))


def check_seed(args):
    head('2. THE SEED  (%s)' % ('T/seed' if not args.seed else args.seed))
    pq = os.path.join(T, 'tools', 'post_question.py')
    seed = os.path.abspath(args.seed) if args.seed else os.path.join(T, 'seed')
    r = run([PY, '-I', pq, 'check', '--many', seed])
    last = [l for l in r.stdout.strip().splitlines() if l.strip()][-1:] or ['(no output)']
    notes = len([l for l in r.stdout.splitlines() if l.startswith('  - ')])
    if not ok(r.returncode == 0, 'post_question.py check --many T/seed: %s' % last[0], (r.stdout + r.stderr).strip()[-1500:]):
        return None
    if notes:
        say('INFO', '%d note(s) from check (long labels or paragraphs; not errors)' % notes)
    m = re.search(r'(\d+) picture', r.stdout)
    pics = int(m.group(1)) if m else 0
    if pics:
        say('WARN', '%d picture(s) in the seed must be uploaded first (post_question.py prepare --many, Artifact asset upload, then finish --urls)' % pics)

    docs = collections.defaultdict(dict)
    for fn in sorted(os.listdir(seed)):
        if fn.endswith('.json'):
            try:
                arr = json.load(open(os.path.join(seed, fn), encoding='utf8'))
            except ValueError as e:
                ok(False, 'seed/%s is valid JSON' % fn, str(e))
                continue
            for d in arr:
                c = d.get('_collection')
                if d.get('id') in docs[c]:
                    ok(False, 'ids are unique in %s' % c, 'twice: %s (%s)' % (d.get('id'), fn))
                docs[c][d.get('id')] = d
    secs, qs = docs.get('sections', {}), docs.get('questions', {})
    ok(set(BUILTIN_SECTIONS) <= set(secs), 'the four built-in sections are in the seed (%s)' % ', '.join(sorted(secs)), 'missing: ' + ', '.join(set(BUILTIN_SECTIONS) - set(secs)))
    check_question_sections(args, secs, qs)
    ok(all(ID_OK.match(i or '') for c in docs.values() for i in c), 'every id uses only a-z 0-9 - _')
    par = sorted(q['id'] for q in qs.values() if q.get('parentId') and q['parentId'] not in qs)
    ok(not par, 'every parentId points at a question in the seed', ', '.join(par[:6]), level='WARN')
    ok('o-welcome' in qs, 'the welcome question o-welcome is there (used in the rehearsal)', level='WARN')
    bysec = collections.Counter((q['sectionId'], q.get('kind')) for q in qs.values())
    say('INFO', 'seed: %d section(s), %d question(s): %s' % (len(secs), len(qs), '; '.join('%s %s %d' % (s, k, n) for (s, k), n in sorted(bysec.items()))))

    # finish --many: plain "set" writes into <outbox>/many-seed
    outbox = os.path.abspath(args.outbox)
    r = run([PY, '-I', pq, 'finish', '--many', seed, '--outbox', outbox, '--no-versions'])
    if not ok(r.returncode == 0, 'post_question.py finish --many T/seed --no-versions (writes the batch files)', (r.stdout + r.stderr).strip()[-800:]):
        return None
    folder = os.path.join(outbox, 'many-seed')
    files = sorted((f for f in os.listdir(folder) if re.match(r'batch-\d+\.files\.json$', f)), key=lambda f: int(re.search(r'\d+', f).group(0)))
    ok(bool(files), '%d batch file(s) in %s' % (len(files), folder))
    order, batches, problems = [], [], []
    for f in files:
        w = json.load(open(os.path.join(folder, f), encoding='utf8')).get('writes', [])
        batches.append((f, w))
        if len(w) > 50:
            problems.append('%s has %d writes (limit 50)' % (f, len(w)))
        for x in w:
            order.append((x.get('collection'), x.get('doc_id')))
            if x.get('op') != 'set':
                problems.append('%s %s/%s: op is %r, not set' % (f, x.get('collection'), x.get('doc_id'), x.get('op')))
            fp = x.get('file_path')
            if not fp or not os.path.isabs(fp) or not os.path.exists(fp):
                problems.append('%s %s/%s: file_path missing or not on disk (%s)' % (f, x.get('collection'), x.get('doc_id'), fp))
            else:
                try:
                    d = json.load(open(fp, encoding='utf8'))
                    if d.get('id') != x.get('doc_id') or '_collection' in d:
                        problems.append('%s %s/%s: the document file has a different id or a leftover _collection' % (f, x.get('collection'), x.get('doc_id')))
                except ValueError:
                    problems.append('%s %s/%s: the document file is not JSON' % (f, x.get('collection'), x.get('doc_id')))
    ok(not problems, 'every batch has at most 50 writes, op "set", and a document file that exists and matches', '\n'.join(problems[:8]))
    seen_q = False
    sections_first = True
    for c, _i in order:
        if c == 'questions':
            seen_q = True
        elif c == 'sections' and seen_q:
            sections_first = False
    ok(sections_first, 'sections are written before any question')
    ok(len(order) == len(set(order)), 'no document is written twice')
    want = {c: len(v) for c, v in docs.items() if c}
    got = collections.Counter(c for c, _ in order)
    ok(dict(got) == want, 'the batches carry exactly the seed: %s' % ', '.join('%s %d' % kv for kv in sorted(got.items())), 'seed says %s' % want)
    return {'batches': batches, 'folder': folder, 'outbox': outbox, 'expected': dict(got), 'bysec': bysec}


# ------------------------------------------------------------------------------------------------ 3. what to do
def show_calls(page, seed, args):
    head('3. THE CALLS  (in this order)')
    url = args.url or '<URL>'
    dist = os.path.join(T, 'dist', 'index.html')
    publish = {'file_path': dist, 'icon': PUBLISH_ICON, 'description': PUBLISH_DESCRIPTION, 'capabilities': CAPABILITIES, 'label': 'First publish'}
    callsdir = os.path.join(os.path.abspath(args.outbox), 'publish')
    os.makedirs(callsdir, exist_ok=True)
    with open(os.path.join(callsdir, 'artifact-publish.json'), 'w', encoding='utf8') as f:
        json.dump(publish, f, indent=1, ensure_ascii=False)
    print('STEP 1  Artifact (publish the page; the title comes from <title>; page md5 %s)' % (page['md5'] if page else '?'))
    print(json.dumps(publish, indent=1, ensure_ascii=False))
    if page and not page['dist_same']:
        print('        !! first run  python3 %s/build.py  so that dist/index.html is the page that was checked above' % T)
    print('STEP 2  copy the page address from the result (claude.ai/artifact/...). Use it as <URL> below (or re-run this checker with --url).')
    print('        Also ask the user to share the page with the farm owner as an EDITOR: she needs it to save answers and for "Check Claude hears me".')
    if seed:
        n = len(seed['batches'])
        for i, (f, w) in enumerate(seed['batches'], 1):
            call = {'action': 'batch', 'url': url, 'writes': w}
            p = os.path.join(callsdir, 'artifactdata-%d.json' % i)
            with open(p, 'w', encoding='utf8') as fh:
                json.dump(call, fh, indent=1, ensure_ascii=False)
            kinds = collections.Counter(x['collection'] for x in w)
            what = 'sections first' if i == 1 else 'questions'
            print('STEP %d  ArtifactData batch %d of %d (%d writes: %s; %s)   arguments saved in %s' % (2 + i, i, n, len(w), ', '.join('%s %d' % kv for kv in sorted(kinds.items())), what, p))
            print('        {"action":"batch","url":"%s","writes":[ {"op":"set","collection":"%s","doc_id":"%s","file_path":"%s"}, ... %d entries, last doc_id "%s" ]}'
                  % (url, w[0]['collection'], w[0]['doc_id'], w[0]['file_path'], len(w), w[-1]['doc_id']))
        step = 3 + n
        print('STEP %d  heartbeat, written last so the time is fresh:' % step)
        print('        python3 -I %s/tools/status.py heartbeat --no-versions --heartbeat-note "Terminal is ready"' % T)
        print('        then ArtifactData {"action":"batch","url":"%s","writes":[<the writes list of the status-<time>.json it prints>]}' % url)
        print('STEP %d  ask the owner to open the page and press "Check Claude hears me" (expect "Claude heard you ✓")' % (step + 1))
        print('        expected afterwards, ArtifactData list per collection: ' + ', '.join('%s %d' % kv for kv in sorted(seed['expected'].items())) + ', meta 1 (heartbeat; meta 2 after the check = also "ping")')
    print('\nThe same, as a short runbook with the rehearsal after publishing: %s/notes/PUBLISH.md' % T)


def main():
    ap = argparse.ArgumentParser(description='Pre-publish checker for the Question Terminal')
    ap.add_argument('--url', help='the page address, once it is published (only fills in the printed calls)')
    ap.add_argument('--outbox', default=os.environ.get('QT_OUTBOX') or os.path.join(T, 'outbox'))
    ap.add_argument('--skip-seed', action='store_true')
    ap.add_argument('--keep-build', help='also save the checked build to this file')
    ap.add_argument('--src', help='build from this source folder instead of T/src (used to try the checker on a broken copy)')
    ap.add_argument('--seed', help='check this seed folder instead of T/seed')
    ap.add_argument('--export', help='an export of the live notebook (it needs sections/): her own sections used by seed questions are checked against it (default: T/export when it has sections/)')
    ap.add_argument('--her-section', action='append', default=[], metavar='ID', help='a section she made on the page that seed questions may use (repeatable)')
    ap.add_argument('--skip-page', action='store_true', help='do not build or check the page (only the seed)')
    args = ap.parse_args()
    tmp = tempfile.mkdtemp(prefix='qt-publish-')
    try:
        page = None if args.skip_page else check_page(tmp, args)
        seed = None if args.skip_seed else check_seed(args)
        if page is None and args.skip_page:
            head('3. THE CALLS')
            print('Not shown: the page was not checked (--skip-page).')
        elif page is None:
            head('3. THE CALLS')
            print('Not shown: the page could not be built. Fix the FAIL above first.')
        else:
            show_calls(page, seed, args)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    print('RESULT: %s   (%d PASS, %d WARN, %d FAIL)' % ('NOT READY' if counts['FAIL'] else 'READY to publish' + (' (look at the warnings)' if counts['WARN'] else ''), counts['PASS'], counts['WARN'], counts['FAIL']))
    sys.exit(1 if counts['FAIL'] else 0)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(errors='replace')
    except (AttributeError, ValueError, OSError):
        pass
    main()
