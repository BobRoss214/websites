#!/usr/bin/env python3
"""Make a picture small enough for the Question Terminal.

    python3 -I optimize_image.py in.png [--max-w 1600] [--quality 82] [--max-kb 350] [--out out.webp|out.jpg] [--exact] [--drop-profile]

Shrinks the picture when it is wider than --max-w, saves it as WebP (default) or JPEG and tries to stay
at or under --max-kb (350 KB). It lowers the quality a little first, and only then makes the picture
narrower (never below 800 px wide unless the original is smaller). Prints one line of JSON:

    {"file": "/abs/out.webp", "width": 1600, "height": 900, "bytes": 212345, "format": "webp", "quality": 82, ...}

--exact: encode once at --quality, same width and height as the original (no shrinking, no size goal): for a JPEG twin of a WebP photo.
The colour profile (for example Display P3 from a phone) is kept, so the colours do not change; --drop-profile removes it.
If the target cannot be reached, "over_budget": true is added (the file is still written).
Exit code 0 = done, 1 = problem (message on stderr).
"""
import argparse
import io
import json
import sys
from pathlib import Path

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover
    print("optimize_image: the Pillow library (PIL) is not installed", file=sys.stderr)
    sys.exit(1)


def _flatten(im, fmt):
    """Colour mode that the target format can store."""
    has_alpha = im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info)
    if fmt == "webp":
        return im.convert("RGBA" if has_alpha else "RGB")
    if has_alpha:  # JPEG has no transparency: put the picture on white
        rgba = im.convert("RGBA")
        bg = Image.new("RGB", rgba.size, (255, 255, 255))
        bg.paste(rgba, mask=rgba.split()[-1])
        return bg
    return im.convert("RGB")


def _encode(im, fmt, quality, icc=None):
    buf = io.BytesIO()
    extra = {"icc_profile": icc} if icc else {}
    if fmt == "webp":
        im.save(buf, "WEBP", quality=quality, method=6, **extra)
    else:
        im.save(buf, "JPEG", quality=quality, optimize=True, progressive=True, **extra)
    return buf.getvalue()


def optimize(src, dst=None, max_w=1600, quality=82, max_kb=350, min_w=800, exact=False, keep_profile=True):
    """Returns a dict (see the top of this file). Raises ValueError with a plain message on problems."""
    src = Path(src).expanduser()
    if not src.is_file():
        raise ValueError(f"file not found: {src}")
    try:
        im = Image.open(src)
        im.load()
    except Image.DecompressionBombError:
        raise ValueError(f"{src.name} is far too large to be a normal picture")
    except Exception as e:  # unreadable or not a picture
        raise ValueError(f"{src.name} is not a picture I can open ({e.__class__.__name__}: {e})")
    try:
        if getattr(im, "n_frames", 1) > 1:
            im.seek(0)  # moving pictures: first frame only
    except Exception:
        pass
    icc = im.info.get("icc_profile") if keep_profile and im.mode in ("RGB", "RGBA", "L", "LA", "P") else None
    im = ImageOps.exif_transpose(im)
    src_w, src_h = im.size

    if dst is None:
        dst = src.with_suffix(".webp")
        if dst.resolve() == src.resolve():
            dst = src.with_name(src.stem + "-opt.webp")
    dst = Path(dst).expanduser()
    ext = dst.suffix.lower()
    if ext == ".webp":
        fmt = "webp"
    elif ext in (".jpg", ".jpeg"):
        fmt = "jpg"
    else:
        raise ValueError(f"the output name must end in .webp, .jpg or .jpeg (got {dst.name})")
    if dst.resolve() == src.resolve():
        raise ValueError("the output file would overwrite the original; pick another --out name")

    im = _flatten(im, fmt)
    target = int(max_kb * 1024)
    max_w = max(64, int(max_w))
    quality = max(10, min(95, int(quality)))

    # widths to try: max_w (or the original, if narrower), then 15 % smaller steps down to min_w
    w0 = src_w if exact else min(src_w, max_w)
    widths = [w0]
    w = w0
    floor = min(w0, int(min_w))
    while w > floor and not exact:
        w = max(floor, int(w * 0.85))
        widths.append(w)
    qualities = [quality] + ([q for q in (72, 62) if q < quality] if not exact else [])
    if exact:
        target = 1 << 62

    best = None  # (bytes, data, w, h, q)
    chosen = None
    for tw in widths:
        th = max(1, round(src_h * tw / src_w))
        small = im if tw == src_w else im.resize((tw, th), Image.LANCZOS)
        for q in qualities:
            data = _encode(small, fmt, q, icc)
            if best is None or len(data) < best[0]:
                best = (len(data), data, tw, th, q)
            if len(data) <= target:
                chosen = (len(data), data, tw, th, q)
                break
        if chosen:
            break
    if not chosen:  # last resort at the smallest width
        small = im if widths[-1] == src_w else im.resize((widths[-1], max(1, round(src_h * widths[-1] / src_w))), Image.LANCZOS)
        for q in (50, 40):
            data = _encode(small, fmt, q, icc)
            if len(data) < best[0]:
                best = (len(data), data, small.size[0], small.size[1], q)
            if len(data) <= target:
                chosen = best
                break
    final = chosen or best
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(final[1])
    out = {
        "file": str(dst.resolve()),
        "width": final[2],
        "height": final[3],
        "bytes": final[0],
        "format": fmt,
        "quality": final[4],
        "source_width": src_w,
        "source_height": src_h,
    }
    if not chosen:
        out["over_budget"] = True
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="Shrink a picture and save it as WebP or JPEG.")
    ap.add_argument("input")
    ap.add_argument("--max-w", type=int, default=1600, help="widest allowed picture in pixels (default 1600)")
    ap.add_argument("--quality", type=int, default=82, help="starting quality 10-95 (default 82)")
    ap.add_argument("--max-kb", type=int, default=350, help="size goal in KB (default 350)")
    ap.add_argument("--out", help="output file ending in .webp, .jpg or .jpeg (default: same name, .webp)")
    ap.add_argument("--exact", action="store_true", help="one encode at --quality, original size, no size goal")
    ap.add_argument("--drop-profile", action="store_true", help="do not copy the colour profile into the new file")
    a = ap.parse_args(argv)
    try:
        res = optimize(a.input, a.out, a.max_w, a.quality, a.max_kb, exact=a.exact, keep_profile=not a.drop_profile)
    except ValueError as e:
        print(f"optimize_image: {e}", file=sys.stderr)
        return 1
    print(json.dumps(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
