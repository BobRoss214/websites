#!/usr/bin/env python3
"""Make the pictures and the question file for a "FOUR VERSIONS" picture question.

    python3 -I make_variants.py SPEC.json --plan                 show what would happen; nothing is made
    python3 -I make_variants.py SPEC.json --jobs 2               make it (2 versions at the same time)
    python3 -I make_variants.py SPEC.json --only B               make version B again (the others are kept)

For every version it makes a FRESH copy of the site (the original folder is only read, never written),
applies that version's change, photographs the page with snap.mjs at each window size, and does the same
once for "How it looks now" (the copy with no change). Then it checks the pictures fit the 350 KB budget,
makes a contact sheet to look at, writes the question file  <outbox>/<id>.json  and runs
`post_question.py check` on it. Next steps are the usual ones:  post_question.py prepare / finish.

SPEC.json (everything but id, title, story, repo and versions has a default):
  {"id": "look-hero-label",  "sectionId": "look",  "title": "...", "story": ["..."], "why": "...",
   "ownTip": "...", "required": true,                   (also copied if present: round, parentId, order, topic, oldId, ...)
   "repo": "/path/to/the/site",   "ref": "HEAD",        a git folder (committed files at `ref`) or a plain folder.
   "working_tree": false,                               true = a git folder as it is now, with changes not yet committed
   "serve_dir": ".",                                    the folder inside the copy that is the website (default: all of it)
   "page": "/index.html",                               the page to photograph (each version may have its own "page")
   "date": "2026-10-02",                                the page believes it is this day (optional; --date overrides)
   "serve_port": 9850,                                  first port to use (--port-base overrides)
   "viewports": [{"w": 1366, "h": 768, "label": "laptop"}, {"w": 700, "h": 800, "label": "beside the chat"}],
   "settle_ms": 700,  "still": true,  "timeout_s": 120,
   "steps": [ ... ],                                    default snap steps for versions that have none (default: just one picture)
   "versions": [                                        2 to 4 versions
     {"key": "A", "label": "...", "caption": "...", "alts": ["..."],
      "patch": ...,                                     what is different in this version (see below)
      "steps": [{"click": "#x"}, {"wait": 300}, {"scroll": ".hero"}, {"shot": "top", "selector": ".hero"}]}  ],
   "before": {"caption": "How it looks now", "steps": [...], "page": "/index.html"}     (optional)}

"patch" is one of these, or a list of them (applied in order):
  "changes.diff"                    a patch file (git apply)
  "files-folder/"                   a folder of files that replace/add files in the copy (same relative paths)
  {"css": "text or file.css"}       extra CSS added to every page (as if it was the last style sheet)
  {"js": "text or file.js"}         extra JavaScript run when the page has loaded
  {"html_replace": [{"file": "index.html", "find": "old text", "replace": "new text", "regex": false}]}
  {"files": {"css/extra.css": "text"}}     write these files into the copy
  Every {"find": ...} must be found, or the run stops with a clear message (so a version can never silently look like the old one).
  File names in a patch ("files", "html_replace", folder contents) are relative to the top of the site copy; "page" is relative to serve_dir.
"shot" steps (see tools/README.md part (a)) say what to photograph: each one gives one picture per window size.
A version may show at most 4 pictures (window sizes x shots). Paths in the spec are relative to the spec file.

Output (default folder <outbox>/<id>-variants/):  pics/*.png (full size, what the question uses), opt/*.webp (the 350 KB check),
contact.png (one look at all versions), report.json, logs/*.log, init/*.js, steps/*.json; copies/ only with --keep.
Exit code: 0 done, 1 something failed (plain message), 2 the spec or the options are wrong.
"""
import argparse
import concurrent.futures
import copy
import importlib.util as _iu
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
_spec = _iu.spec_from_file_location("qtlib", TOOLS / "qtlib.py")
qt = _iu.module_from_spec(_spec)
sys.modules["qtlib"] = qt
_spec.loader.exec_module(qt)

KEYS = ["A", "B", "C", "D"]
DEFAULT_VIEWPORTS = [{"w": 1366, "h": 768, "label": "laptop"}, {"w": 700, "h": 800, "label": "beside the chat"}]
PASS_THROUGH = ("ownTip", "required", "round", "parentId", "order", "topic", "who", "needs", "previouslyNotSure", "oldId", "createdAt")
MAX_PICTURES = 4
LOCK = threading.Lock()


class Problem(Exception):
    """A plain-words problem (spec mistake or a step that failed)."""


class SnapProblem(Problem):
    """The photographing itself failed (a slow computer, a page that was not ready): worth one more try."""


def say(msg=""):
    with LOCK:
        print(msg, flush=True)


def slug(text, default="x"):
    s = re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")
    return s[:24] or default


# ----------------------------------------------------------------------------- reading the spec
def _read_text_or_file(value, base):
    """A CSS/JS value: a file name (relative to the spec) when such a file exists, else the text itself."""
    if isinstance(value, str) and "\n" not in value and len(value) < 300:
        p = (base / value).expanduser()
        if p.suffix.lower() in (".css", ".js") and p.is_file():
            return p.read_text(encoding="utf-8")
    return value if isinstance(value, str) else None


def _norm_patch(raw, base, where, problems):
    """-> list of operations: ("diff", Path) ("overlay", Path) ("write", {rel: text}) ("replace", {...}) ("css", text) ("js", text)"""
    if raw in (None, "", [], {}):
        return []
    ops = []
    for item in (raw if isinstance(raw, list) else [raw]):
        if isinstance(item, str):
            p = (base / item).expanduser()
            if p.is_dir():
                ops.append(("overlay", p.resolve()))
            elif p.is_file() and p.suffix.lower() == ".css":
                ops.append(("css", p.read_text(encoding="utf-8")))
            elif p.is_file() and p.suffix.lower() == ".js":
                ops.append(("js", p.read_text(encoding="utf-8")))
            elif p.is_file():
                ops.append(("diff", p.resolve()))
            else:
                problems.append(f"{where}: patch file or folder not found: {item}")
        elif isinstance(item, dict):
            known = {"css", "js", "html_replace", "files", "diff", "overlay"}
            for k in item:
                if k not in known:
                    problems.append(f"{where}: unknown patch part \"{k}\" (use css, js, html_replace, files, diff or overlay)")
            if item.get("diff"):
                p = (base / item["diff"]).expanduser()
                ops.append(("diff", p.resolve())) if p.is_file() else problems.append(f"{where}: patch file not found: {item['diff']}")
            if item.get("overlay"):
                p = (base / item["overlay"]).expanduser()
                ops.append(("overlay", p.resolve())) if p.is_dir() else problems.append(f"{where}: patch folder not found: {item['overlay']}")
            if isinstance(item.get("files"), dict):
                for k in item["files"]:
                    if _bad_rel(k):
                        problems.append(f"{where}: \"{k}\" would leave the copy of the site; use a path inside it")
                ops.append(("write", {str(k): str(v) for k, v in item["files"].items()}))
            elif item.get("files") is not None:
                problems.append(f"{where}: \"files\" must be {{\"path\": \"text\"}}")
            for r in item.get("html_replace") or []:
                if not (isinstance(r, dict) and isinstance(r.get("file"), str) and isinstance(r.get("find"), str) and isinstance(r.get("replace"), str)):
                    problems.append(f"{where}: each html_replace needs file, find and replace (all text)")
                else:
                    if _bad_rel(r["file"]):
                        problems.append(f"{where}: html_replace file \"{r['file']}\" would leave the copy of the site")
                    ops.append(("replace", r))
            for kind in ("css", "js"):
                if item.get(kind):
                    txt = _read_text_or_file(item[kind], base)
                    ops.append((kind, txt)) if txt is not None else problems.append(f"{where}: {kind} must be text or a file name")
        else:
            problems.append(f"{where}: patch must be a file name, a folder name, an object or a list of those")
    return ops


def _bad_rel(rel):
    """True when a patch file name would leave the copy of the site."""
    r = str(rel).replace("\\", "/")
    return r.startswith("/") or ".." in r.split("/") or bool(re.match(r"^[A-Za-z]:", r))


def describe_ops(ops):
    if not ops:
        return "no change"
    parts = []
    for kind, v in ops:
        if kind == "diff":
            parts.append(f"patch file {v.name}")
        elif kind == "overlay":
            n = sum(1 for p in v.rglob("*") if p.is_file())
            parts.append(f"folder {v.name}/ ({n} file{'s' if n != 1 else ''} copied over)")
        elif kind == "write":
            parts.append(f"write {len(v)} file{'s' if len(v) != 1 else ''}")
        elif kind == "replace":
            parts.append(f"replace text in {v['file']}")
        else:
            parts.append(f"extra {kind.upper()} ({len(v)} characters)")
    return "; ".join(parts)


def _norm_steps(raw, where, problems):
    if raw in (None, ""):
        return None
    if not isinstance(raw, list):
        problems.append(f"{where}: steps must be a list like [{{\"click\": \"#x\"}}, {{\"shot\": \"top\"}}]")
        return None
    for i, s in enumerate(raw, 1):
        if not isinstance(s, dict):
            problems.append(f"{where}: step {i} is not an object like {{\"click\": \"#x\"}}")
        elif not any(k in s for k in ("click", "hover", "type", "press", "wait", "eval", "scroll", "viewport", "goto", "shot")):
            problems.append(f"{where}: step {i} has none of click, hover, type, press, wait, eval, scroll, viewport, goto, shot")
    return raw


def count_shots(steps):
    return sum(1 for s in (steps or [{"shot": "x"}]) if isinstance(s, dict) and "shot" in s) or 1


def load_spec(path, args):
    path = Path(path).expanduser()
    if not path.is_file():
        raise Problem(f"spec file not found: {path}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as e:
        raise Problem(f"{path.name} is not valid JSON ({e})")
    if not isinstance(raw, dict):
        raise Problem(f"{path.name} must hold one object {{...}}")
    base = path.resolve().parent
    P = []   # problems, all reported together
    S = {"base": base, "path": path.resolve(), "raw": raw}
    S["id"] = raw.get("id") or ""
    if not qt.ID_RE.match(str(S["id"])):
        P.append("id must be 1-60 characters from a-z 0-9 - _ (for example look-hero-label)")
    S["sectionId"] = raw.get("sectionId") or "look"
    for k in ("title", "why"):
        if k == "title" and not (isinstance(raw.get(k), str) and raw[k].strip()):
            P.append("title is missing (the question, 110 characters at most)")
    story = raw.get("story")
    if not (isinstance(story, list) and 1 <= len(story) <= 4 and all(isinstance(x, str) for x in story)):
        P.append("story must be a list of 1 to 4 short paragraphs")
    # the site
    repo = raw.get("repo")
    if not isinstance(repo, str) or not repo.strip():
        P.append("repo is missing (the folder of the website to photograph)")
        S["repo"] = None
    else:
        S["repo"] = Path(repo[4:] if repo.startswith("git:") else repo).expanduser()
        if not S["repo"].is_absolute():
            S["repo"] = (base / S["repo"]).resolve()
        if not S["repo"].is_dir():
            P.append(f"repo folder not found: {S['repo']}")
    S["ref"] = args.ref or raw.get("ref") or "HEAD"
    S["working_tree"] = bool(raw.get("working_tree"))
    S["serve_dir"] = str(raw.get("serve_dir") or ".")
    S["page"] = str(raw.get("page") or "/index.html")
    S["date"] = args.date or raw.get("date")
    S["port_base"] = int(args.port_base or raw.get("serve_port") or 9850)
    S["settle"] = int(raw.get("settle_ms", 700))
    S["still"] = bool(raw.get("still", True))
    try:   # optional "scale": 2 = twice as many pixels (a sharper close-up); the window size and clip areas stay in normal pixels
        S["scale"] = float(raw.get("scale") or 1)
    except (TypeError, ValueError):
        S["scale"] = 0
    if not 0.5 <= S["scale"] <= 4:
        P.append("scale must be a number from 0.5 to 4")
    S["timeout"] = int(args.timeout or raw.get("timeout_s") or 120)
    # window sizes
    vps = raw.get("viewports") or DEFAULT_VIEWPORTS
    S["viewports"] = []
    for i, v in enumerate(vps, 1):
        if isinstance(v, dict) and isinstance(v.get("w"), int) and isinstance(v.get("h"), int) and v["w"] >= 200 and v["h"] >= 200:
            S["viewports"].append({"w": v["w"], "h": v["h"], "label": str(v.get("label") or f"{v['w']}x{v['h']}")})
        else:
            P.append(f"viewports[{i}] must look like {{\"w\": 1366, \"h\": 768, \"label\": \"laptop\"}}")
    if len({slug(v["label"]) for v in S["viewports"]}) != len(S["viewports"]):
        P.append("two window sizes have the same label")
    S["steps"] = _norm_steps(raw.get("steps"), "steps", P)
    # versions
    vs = raw.get("versions")
    S["versions"] = []
    if not (isinstance(vs, list) and 2 <= len(vs) <= 4):
        P.append("versions must be a list of 2 to 4 versions")
        vs = []
    seen = set()
    for i, v in enumerate(vs):
        if not isinstance(v, dict):
            P.append(f"versions[{i + 1}] must be an object")
            continue
        key = str(v.get("key") or KEYS[i]).upper()
        where = f"version {key}"
        if key not in KEYS or key in seen:
            P.append(f"{where}: keys must be A, B, C, D, each used once")
        seen.add(key)
        if not (isinstance(v.get("label"), str) and v["label"].strip()):
            P.append(f"{where} has no label (2-4 plain words)")
        ver = {"key": key, "label": str(v.get("label") or "").strip(), "caption": str(v.get("caption") or "").strip(),
               "alts": [str(a) for a in (v.get("alts") or [])] if isinstance(v.get("alts") or [], list) else [],
               "page": str(v.get("page") or S["page"]),
               "ops": _norm_patch(v.get("patch"), base, where, P),
               "steps": _norm_steps(v.get("steps"), f"{where} steps", P) or S["steps"]}
        n = len(S["viewports"]) * count_shots(ver["steps"])
        if n > MAX_PICTURES:
            P.append(f"{where} would make {n} pictures ({len(S['viewports'])} window sizes x {count_shots(ver['steps'])} shots); a version can show 4 at most")
        ver["n"] = n
        S["versions"].append(ver)
    # "how it looks now"
    b = raw.get("before")
    S["before"] = None
    if b is not None and b is not False:   # {} means "yes, with the defaults"
        b = b if isinstance(b, dict) else {}
        steps = _norm_steps(b.get("steps"), "before steps", P) or S["steps"]
        n = len(S["viewports"]) * count_shots(steps)
        if n > MAX_PICTURES:
            P.append(f"before would make {n} pictures; at most 4")
        S["before"] = {"caption": str(b.get("caption") or "How it looks now"), "alts": [str(a) for a in (b.get("alts") or [])],
                       "page": str(b.get("page") or S["page"]), "steps": steps, "ops": _norm_patch(b.get("patch"), base, "before", P), "n": n}
    S["pass"] = {k: raw[k] for k in PASS_THROUGH if k in raw}
    S["texts"] = {k: raw[k] for k in ("title", "story", "why") if k in raw}
    # words she must never read (the same rule post_question.py check applies at the end; better to hear it before the pictures are made)
    fields = [("title", raw.get("title")), ("why", raw.get("why")), ("ownTip", raw.get("ownTip"))] + [(f"story {i + 1}", t) for i, t in enumerate(story if isinstance(story, list) else [])]
    for v in S["versions"]:
        fields += [(f"version {v['key']} label", v["label"]), (f"version {v['key']} caption", v["caption"])] + [(f"version {v['key']} alt", a) for a in v["alts"]]
    if S["before"]:
        fields.append(("before caption", S["before"]["caption"]))
    for where, word in qt.jargon_hits(fields):
        P.append(f"{where}: the word \"{word}\" is not for the owner's eyes (plain words only; see SPEC section 3)")
    if isinstance(raw.get("title"), str) and len(raw["title"]) > 110:
        P.append("title is longer than 110 characters")
    if P:
        raise Problem("The spec has problems:\n  - " + "\n  - ".join(P))
    return S


# ----------------------------------------------------------------------------- the site copy
def git(repo, *a, check=True):
    r = subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True)
    if check and r.returncode != 0:
        raise Problem(f"git {a[0]} failed in {repo}: {(r.stderr or r.stdout).strip().splitlines()[-1] if (r.stderr or r.stdout).strip() else 'no message'}")
    return r


def repo_kind(repo):
    r = subprocess.run(["git", "-C", str(repo), "rev-parse", "--show-toplevel"], capture_output=True, text=True)
    if r.returncode == 0 and Path(r.stdout.strip()).resolve() == Path(repo).resolve():
        return "git"
    return "folder"


def make_copy(S, dest):
    """A fresh copy of the site in `dest` (the original is only read)."""
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    repo = S["repo"]
    if S["kind"] == "git" and not S["working_tree"]:
        p1 = subprocess.Popen(["git", "-C", str(repo), "archive", "--format=tar", S["ref"]], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        p2 = subprocess.Popen(["tar", "-x", "-C", str(dest)], stdin=p1.stdout, stderr=subprocess.PIPE)
        p1.stdout.close()
        e2 = p2.communicate()[1].decode("utf-8", "replace")
        e1 = p1.stderr.read().decode("utf-8", "replace")
        p1.wait()
        if p1.returncode != 0:
            raise Problem(f"could not make a copy of {repo} at {S['ref']}: {e1.strip().splitlines()[-1] if e1.strip() else 'git archive failed'}")
        if p2.returncode != 0:
            raise Problem(f"could not unpack the copy: {e2.strip()[:200]}")
    elif S["kind"] == "git":   # working tree: every file git knows or would add, as it is now
        out = subprocess.run(["git", "-C", str(repo), "ls-files", "-z", "--cached", "--others", "--exclude-standard"], capture_output=True)
        if out.returncode != 0:
            raise Problem(f"git ls-files failed in {repo}")
        for rel in out.stdout.decode("utf-8", "replace").split("\0"):
            if rel and (repo / rel).is_file():
                (dest / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(repo / rel, dest / rel)
    else:
        shutil.copytree(repo, dest, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".git", "node_modules"), symlinks=False)
    return dest


def _safe(root, rel):
    p = (Path(root) / rel).resolve()
    if not str(p).startswith(str(Path(root).resolve()) + os.sep) and p != Path(root).resolve():
        raise Problem(f"\"{rel}\" points outside the copy of the site; paths must stay inside it")
    return p


def apply_ops(copy_dir, ops, label):
    """Apply the file changes. Returns (css_text, js_text) that must be injected when the page opens."""
    css, js = [], []
    for kind, v in ops:
        if kind == "diff":
            r = subprocess.run(["git", "apply", "--whitespace=nowarn", str(v)], cwd=str(copy_dir), capture_output=True, text=True)
            if r.returncode != 0:
                msg = [l for l in (r.stderr or r.stdout).strip().splitlines() if l][:3]
                raise Problem(f"{label}: the patch {v.name} does not fit this copy of the site ({' / '.join(msg)})")
        elif kind == "overlay":
            for src in sorted(v.rglob("*")):
                if src.is_file():
                    dst = _safe(copy_dir, src.relative_to(v))
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
        elif kind == "write":
            for rel, text in v.items():
                dst = _safe(copy_dir, rel)
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_text(text, encoding="utf-8")
        elif kind == "replace":
            f = _safe(copy_dir, v["file"])
            if not f.is_file():
                raise Problem(f"{label}: html_replace: the file {v['file']} is not in the copy of the site")
            text = f.read_text(encoding="utf-8")
            if v.get("regex"):
                new, n = re.subn(v["find"], v["replace"], text, flags=re.S)
            else:
                n = text.count(v["find"])
                new = text.replace(v["find"], v["replace"])
            if n == 0:
                raise Problem(f"{label}: html_replace: \"{v['find'][:50]}\" was not found in {v['file']} (so this version would look like the old one)")
            f.write_text(new, encoding="utf-8")
        elif kind == "css":
            css.append(v)
        elif kind == "js":
            js.append(v)
    return "\n".join(css), "\n".join(js)


def write_init(path, css, js):
    """A script for snap's --init: adds the extra CSS last (again after the page has loaded), then runs the extra JavaScript."""
    body = ("(function(){var CSS=%s,JS=%s,el=null;\n"
            "function addCss(){if(!CSS||!document.head)return;if(!el){el=document.createElement('style');el.setAttribute('data-variant','1');el.textContent=CSS;}document.head.appendChild(el);}\n"
            "document.addEventListener('DOMContentLoaded',function(){addCss();if(JS){try{(0,eval)(JS);}catch(e){console.error('variant js: '+e.message);}}});\n"
            "window.addEventListener('load',addCss);})();\n") % (json.dumps(css), json.dumps(js))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(body, encoding="utf-8")
    return Path(path)


# ----------------------------------------------------------------------------- photographing
def build_steps(S, item, key):
    """The snap steps for one version: for each window size: resize, open the page, settle, then the version's own steps."""
    steps, shots = [], []
    for i, vp in enumerate(S["viewports"]):
        steps.append({"viewport": f"{vp['w']}x{vp['h']}"})
        if i > 0:
            steps.append({"goto": item["page"]})
        steps.append({"wait": S["settle"]})
        n = 0
        for st in (item["steps"] or [{"shot": "page"}]):
            if "shot" in st:
                n += 1
                name = f"{key.lower()}-{slug(vp['label'])}-{n}.png"
                new = {**st, "shot": str(S["pics"] / name)}
                shots.append({"file": S["pics"] / name, "viewport": vp, "name": str(st["shot"]) if not str(st["shot"]).endswith(".png") else Path(str(st["shot"])).stem})
                steps.append(new)
            else:
                steps.append(dict(st))
        if n == 0:   # steps without any {"shot"}: one picture at the end
            name = f"{key.lower()}-{slug(vp['label'])}-1.png"
            steps.append({"shot": str(S["pics"] / name)})
            shots.append({"file": S["pics"] / name, "viewport": vp, "name": "page"})
    return steps, shots


def node_exe():
    n = shutil.which("node") or ("/opt/node22/bin/node" if Path("/opt/node22/bin/node").exists() else None)
    if not n:
        raise Problem("node is not installed (needed by snap.mjs)")
    return n


class Ports:
    def __init__(self, base):
        self.next, self.lock = base, threading.Lock()

    def take(self):
        with self.lock:
            for _ in range(200):
                p = self.next
                self.next += 1
                with socket.socket() as s:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    try:
                        s.bind(("127.0.0.1", p))
                        return p
                    except OSError:
                        continue
        raise Problem("no free port found near " + str(self.next))


def run_task(S, item, key, ports, args):
    """One version (or "now"): fresh copy -> change -> photographs. Returns a result dict; raises Problem on failure."""
    label = f"version {key}" if key != "now" else "how it looks now"
    t0 = time.time()
    copy_dir = S["work"] / "copies" / key
    log = S["work"] / "logs" / f"{key}.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    notes = []
    make_copy(S, copy_dir)
    css, js = apply_ops(copy_dir, item["ops"], label)
    init = write_init(S["work"] / "init" / f"{key}.js", css, js) if (css or js) else None
    serve = _safe(copy_dir, S["serve_dir"])
    if not serve.is_dir():
        raise Problem(f"{label}: serve_dir \"{S['serve_dir']}\" is not a folder in the site")
    steps, shots = build_steps(S, item, key)
    sf = S["work"] / "steps" / f"{key}.json"
    sf.parent.mkdir(parents=True, exist_ok=True)
    sf.write_text(json.dumps(steps, indent=1), encoding="utf-8")
    vp0 = S["viewports"][0]
    port = ports.take()
    cmd = [node_exe(), str(TOOLS / "snap.mjs"), "--serve", str(serve), "--port", str(port), "--url", item["page"], "--w", str(vp0["w"]), "--h", str(vp0["h"]),
           "--steps", str(sf), "--timeout", str(S["timeout"] * 1000)]
    if S["still"]:
        cmd.append("--still")
    if S["scale"] != 1:
        cmd += ["--scale", str(S["scale"])]
    if S["date"]:
        cmd += ["--set-date", str(S["date"])]
    if init:
        cmd += ["--init", str(init)]
    env = dict(os.environ)
    env.setdefault("NODE_PATH", "/opt/node22/lib/node_modules")
    env.pop("WA_URL", None)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=S["timeout"] + 60)
    except subprocess.TimeoutExpired:
        raise SnapProblem(f"{label}: took longer than {S['timeout']} s (the computer may be busy; try --timeout 240)")
    log.write_text(f"$ {' '.join(cmd)}\n--- stdout\n{r.stdout}\n--- stderr\n{r.stderr}\n", encoding="utf-8")
    for line in r.stderr.splitlines():
        if line.startswith("note:"):
            notes.append(line[5:].strip())
    if r.returncode != 0:
        msg = [l.replace(str(S["work"]), "<work>") for l in r.stderr.splitlines() if l.strip() and not l.startswith("note:")][-3:]
        raise SnapProblem(f"{label}: taking the pictures failed ({' / '.join(msg) or 'no message'}); see {log}")
    for s in shots:
        if not s["file"].is_file() or s["file"].stat().st_size < 500:
            raise SnapProblem(f"{label}: the picture {s['file'].name} was not made; see {log}")
    if not args.keep:
        shutil.rmtree(copy_dir, ignore_errors=True)
    return {"key": key, "shots": [{"file": str(s["file"]), "w": s["viewport"]["w"], "h": s["viewport"]["h"], "viewport": s["viewport"]["label"], "name": s["name"]} for s in shots],
            "notes": sorted(set(notes))[:6], "seconds": round(time.time() - t0, 1), "change": describe_ops(item["ops"])}


# ----------------------------------------------------------------------------- pictures -> question
def alt_for(S, item, shot, n):
    given = item["alts"]
    if n < len(given) and given[n].strip():
        return given[n].strip()
    what = shot["name"] if shot["name"] not in ("page", "") and not re.match(r"^[a-z]-", shot["name"]) else ""
    base = item["label"] if item.get("label") else "How it looks now"
    return f"{base}{': ' + what if what else ''} ({shot['viewport']} window)"


def optimise(S, results, args):
    opt = qt.load_sibling("optimize_image")
    over = []
    for res in results.values():
        for s in res["shots"]:
            if args.no_optimize:
                s["kb"] = Path(s["file"]).stat().st_size // 1024
                continue
            try:
                o = opt.optimize(s["file"], S["work"] / "opt" / (Path(s["file"]).stem + ".webp"))
            except ValueError as e:
                raise Problem(str(e))
            s["kb"], s["opt"] = o["bytes"] // 1024, o["file"]
            if o.get("over_budget"):
                over.append(Path(s["file"]).name)
    return over


def contact_sheet(S, results, path):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        return None
    tiles = []
    order = [v["key"] for v in S["versions"]] + (["now"] if S["before"] else [])
    for key in order:
        res = results.get(key)
        if not res or not res["shots"]:
            continue
        label = next((v["label"] for v in S["versions"] if v["key"] == key), "How it looks now")
        tiles.append((key, label, res["shots"][0]["file"]))
    if not tiles:
        return None
    W, H, pad = 640, 360, 16
    cols = 2 if len(tiles) > 2 else len(tiles)
    rows = (len(tiles) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (W + pad) + pad, rows * (H + 56 + pad) + pad), (251, 246, 234))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.load_default(size=26)
    except TypeError:
        font = ImageFont.load_default()
    for i, (key, label, f) in enumerate(tiles):
        x, y = pad + (i % cols) * (W + pad), pad + (i // cols) * (H + 56 + pad)
        im = Image.open(f).convert("RGB")
        im.thumbnail((W, H))
        sheet.paste(im, (x, y + 52))
        d.text((x, y + 8), f"{'Now' if key == 'now' else key}: {label}", fill=(47, 29, 16), font=font)
    sheet.save(path)
    return path


def write_question(S, results, outbox):
    q = {"id": S["id"], "sectionId": S["sectionId"], "kind": "visual", **S["texts"], **S["pass"], "versions": []}
    q.setdefault("required", True)
    for v in S["versions"]:
        res = results[v["key"]]
        q["versions"].append({"key": v["key"], "label": v["label"], "caption": v["caption"],
                              "files": [s["file"] for s in res["shots"]], "alts": [alt_for(S, v, s, i) for i, s in enumerate(res["shots"])]})
    if S["before"] and "now" in results:
        res = results["now"]
        q["beforeImages"] = [{"file": s["file"], "alt": alt_for(S, {"alts": S["before"]["alts"], "label": ""}, s, i), "caption": S["before"]["caption"]} for i, s in enumerate(res["shots"])]
    return qt.write_json(Path(outbox) / f"{S['id']}.json", q), q


# ----------------------------------------------------------------------------- plan
def plan(S, args, outbox):
    say(f"PLAN for {S['id']}   (nothing is made or changed by --plan)")
    kind = f"git folder, {'files as they are now (including changes not yet saved in git)' if S['working_tree'] else 'saved files at ' + S['ref']}" if S["kind"] == "git" else "plain folder"
    head = ""
    if S["kind"] == "git" and not S["working_tree"]:
        h = git(S["repo"], "rev-parse", "--short", S["ref"], check=False)
        head = f" = {h.stdout.strip()}" if h.returncode == 0 else ""
    say(f"  site       {S['repo']}  ({kind}{head}); it is only read, every picture is taken from a fresh copy")
    say(f"  page       {S['page']}" + (f"   date {S['date']}" if S["date"] else "") + f"   settle {S['settle']} ms" + ("   animations frozen" if S["still"] else ""))
    say("  windows    " + ", ".join(f"{v['w']}x{v['h']} {v['label']}" for v in S["viewports"]))
    say(f"  parallel   {args.jobs} at a time, ports from {S['port_base']}")
    say(f"  folders    work: {S['work']}   question file: {Path(outbox) / (S['id'] + '.json')}")
    say("  steps:")
    items = [(v["key"], v) for v in S["versions"]] + ([("now", S["before"])] if S["before"] else [])
    for key, it in items:
        if args.only and key.upper() not in args.only and key != "now":
            say(f"    {key:<4} skipped (--only)")
            continue
        names = f"{it['n']} picture{'s' if it['n'] != 1 else ''}"
        title = f"\"{it['label']}\"" if key != "now" else "How it looks now"
        say(f"    {key:<4} {title}: fresh copy, {describe_ops(it['ops'])}; {names} ({len(S['viewports'])} window sizes x {count_shots(it['steps'])} shot{'s' if count_shots(it['steps']) != 1 else ''}) -> pics/{key.lower()}-*.png")
    say("  then: check the 350 KB budget (webp copies), make contact.png, write the question file, run post_question.py check")
    problems = check_plan(S, items)
    if problems:
        say("  PROBLEMS found:")
        for p in problems:
            say("    - " + p)
        return 2
    say("  no problems found.")
    return 0


def check_plan(S, items):
    """Cheap checks that need no copy: html_replace texts are really in the site, the page exists, git ref is known."""
    P = []
    if S["kind"] == "git" and not S["working_tree"]:
        if git(S["repo"], "rev-parse", "--verify", "--quiet", S["ref"] + "^{commit}", check=False).returncode != 0:
            P.append(f"git does not know \"{S['ref']}\" in {S['repo']}")
            return P
    def read(rel, under=""):
        rel = under + str(rel).lstrip("/")
        if S["kind"] == "git" and not S["working_tree"]:
            r = subprocess.run(["git", "-C", str(S["repo"]), "show", f"{S['ref']}:{rel}"], capture_output=True)
            return r.stdout.decode("utf-8", "replace") if r.returncode == 0 else None
        p = S["repo"] / rel
        return p.read_text(encoding="utf-8", errors="replace") if p.is_file() else None
    under = "" if S["serve_dir"] in (".", "") else S["serve_dir"].strip("/") + "/"
    for key, it in items:
        page = it["page"].split("?")[0].split("#")[0]
        if page.endswith("/"):
            page += "index.html"
        if read(page, under) is None:
            P.append(f"{key}: the page {it['page']} is not in the site")
        for kind, v in it["ops"]:
            if kind == "replace":
                txt = read(v["file"])
                if txt is None:
                    P.append(f"{key}: html_replace: {v['file']} is not in the site")
                elif v.get("regex"):
                    if not re.search(v["find"], txt, flags=re.S):
                        P.append(f"{key}: html_replace: the pattern \"{v['find'][:40]}\" matches nothing in {v['file']}")
                elif v["find"] not in txt:
                    P.append(f"{key}: html_replace: \"{v['find'][:40]}\" is not in {v['file']}")
    return P


# ----------------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="Make the pictures and the question file for a four-versions picture question (see the top of this file).")
    ap.add_argument("spec")
    ap.add_argument("--plan", action="store_true", help="only list what would happen")
    ap.add_argument("--jobs", type=int, default=2, help="versions made at the same time (default 2)")
    ap.add_argument("--only", help="only these versions, for example B or A,C (the others are kept from the last run)")
    ap.add_argument("--outbox", help="where the question file goes (default T/outbox or $QT_OUTBOX)")
    ap.add_argument("--work", help="folder for pictures and logs (default <outbox>/<id>-variants)")
    ap.add_argument("--keep", action="store_true", help="keep the fresh copies of the site (for looking at them)")
    ap.add_argument("--date", help="the page believes it is this day, YYYY-MM-DD (overrides the spec)")
    ap.add_argument("--ref", help="git branch/commit to copy (overrides the spec; default HEAD)")
    ap.add_argument("--port-base", type=int, help="first port for the little web servers (default 9850)")
    ap.add_argument("--timeout", type=int, help="seconds one version may take (default 120)")
    ap.add_argument("--retries", type=int, default=1, help="how often a version is tried again when taking its pictures fails (default 1)")
    ap.add_argument("--no-optimize", action="store_true", help="skip the 350 KB check")
    ap.add_argument("--no-check", action="store_true", help="do not run post_question.py check at the end")
    args = ap.parse_args(argv)
    if args.jobs < 1:
        qt.die("--jobs must be 1 or more", 2)
    args.only = {x.strip().upper() for x in args.only.split(",") if x.strip()} if args.only else None
    try:
        S = load_spec(args.spec, args)
    except Problem as e:
        print(str(e), file=sys.stderr)
        return 2
    outbox = qt.outbox_dir(args.outbox)
    S["work"] = Path(args.work).expanduser().resolve() if args.work else outbox / f"{S['id']}-variants"
    S["pics"] = S["work"] / "pics"
    S["kind"] = repo_kind(S["repo"])
    if args.only:
        bad = args.only - {v["key"] for v in S["versions"]} - {"NOW"}
        if bad:
            print(f"--only: no version {', '.join(sorted(bad))} in the spec", file=sys.stderr)
            return 2
    # the original must never be touched: the work folder may not be inside it
    if str(S["work"]).startswith(str(S["repo"]) + os.sep) or S["work"] == S["repo"]:
        print(f"The work folder {S['work']} is inside the site folder; pick another with --work (the site is never written to).", file=sys.stderr)
        return 2
    if args.plan:
        return plan(S, args, outbox)
    if S["kind"] == "git" and not S["working_tree"] and git(S["repo"], "rev-parse", "--verify", "--quiet", S["ref"] + "^{commit}", check=False).returncode != 0:
        print(f"git does not know \"{S['ref']}\" in {S['repo']}", file=sys.stderr)
        return 2
    S["pics"].mkdir(parents=True, exist_ok=True)
    report_path = S["work"] / "report.json"
    old = {}
    if report_path.is_file():
        try:
            old = json.loads(report_path.read_text(encoding="utf-8")).get("results", {})
        except ValueError:
            old = {}
    items = [(v["key"], v) for v in S["versions"]] + ([("now", S["before"])] if S["before"] else [])
    todo = [(k, it) for k, it in items if not args.only or k.upper() in args.only]
    for k, _ in todo:   # make again: old pictures of this version go away
        for f in S["pics"].glob(f"{k.lower()}-*.png"):
            f.unlink()
        old.pop(k, None)
    say(f"Making {len(todo)} of {len(items)} sets of pictures for {S['id']} ({args.jobs} at a time, ports from {S['port_base']}) ...")
    ports, results, failures = Ports(S["port_base"]), dict(old), {}
    def job(k, it):
        say(f"  {k}: started")
        for attempt in range(args.retries + 1):
            try:
                res = run_task(S, it, k, ports, args)
                break
            except SnapProblem as e:
                if attempt >= args.retries:
                    raise
                say(f"  {k}: the pictures did not work out ({str(e)[:140]}); trying once more ...")
        say(f"  {k}: {len(res['shots'])} picture(s) in {res['seconds']} s  ({res['change']})")
        for n in res["notes"]:
            say(f"       note: {n}")
        return res
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        futs = {ex.submit(job, k, it): k for k, it in todo}
        for f in concurrent.futures.as_completed(futs):
            k = futs[f]
            try:
                results[k] = f.result()
            except Problem as e:
                failures[k] = str(e)
                say(f"  {k}: FAILED  {e}")
            except Exception as e:   # a bug here must still end with a plain line
                failures[k] = f"{k}: unexpected problem ({e.__class__.__name__}: {e})"
                say(f"  {k}: FAILED  {failures[k]}")
    qt.write_json(report_path, {"id": S["id"], "results": results, "failed": failures})
    if failures:
        say("")
        say(f"{len(failures)} set(s) of pictures failed: {', '.join(sorted(failures))}. Nothing was written to the question file.")
        say("Fix the cause (the logs are in " + str(S["work"] / "logs") + ") and run again; add --only " + ",".join(sorted(failures)) + " to redo just those.")
        return 1
    missing = [k for k, _ in items if k not in results]
    if missing:
        say(f"Pictures for {', '.join(missing)} are missing (never made, or the last try failed). Run again with --only {','.join(missing)}, or without --only to make everything.")
        return 1
    over = optimise(S, results, args)
    sheet = contact_sheet(S, results, S["work"] / "contact.png")
    qt.write_json(report_path, {"id": S["id"], "results": results, "failed": {}})
    spec_file, q = write_question(S, results, outbox)
    say("")
    for k, _ in items:
        for s in results[k]["shots"]:
            say(f"  {Path(s['file']).name:<28} {s['w']}x{s['h']}   {s.get('kb', '?')} KB after the 350 KB check")
    if over:
        say(f"  note: {', '.join(over)} stay over 350 KB even when shrunk; they still work, but are slow to load.")
    if sheet:
        say(f"Contact sheet (look at it before posting): {sheet}")
    say(f"Question file: {spec_file}")
    rc = 0
    if not args.no_check:
        pq = TOOLS / "post_question.py"
        r = subprocess.run([sys.executable, "-I", str(pq), "check", str(spec_file), "--outbox", str(outbox)], capture_output=True, text=True)
        say(("post_question check: " + (r.stdout or r.stderr).strip()).strip())
        rc = 0 if r.returncode == 0 else 1
    say("")
    say(f"Next: python3 -I {pq if not args.no_check else TOOLS / 'post_question.py'} prepare {spec_file}   (then Artifact upload, then finish; see tools/README.md part (b))")
    return rc


if __name__ == "__main__":
    sys.exit(main())
