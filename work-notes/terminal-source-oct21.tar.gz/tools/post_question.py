#!/usr/bin/env python3
"""Get questions ready for the Question Terminal. Scripts only PREPARE files; Claude then calls
Artifact (upload pictures) and ArtifactData (write the questions). See README.md in this folder.

    python3 -I post_question.py check   SPEC.json | --many DIR        just look for mistakes
    python3 -I post_question.py prepare SPEC.json | --many DIR        shrink pictures -> outbox, write upload.json
    python3 -I post_question.py finish  SPEC.json | --many DIR [--urls urls.json]   write batch-1.json
    python3 -I post_question.py applied BATCHFILE [--results RESULTS.json]   after ArtifactData accepted it: keep versions.json up to date
    python3 -I post_question.py preview SPEC.json                      data for photographing the question in the real page

Options: --outbox DIR  --versions versions.json  --version PATH=N  --allow-words a,b  --skip-bad
         finish only: --status seen|working|... [--note TEXT]   (also sets the new question's status)

SPEC.json is one question (an object), or a list of documents (like the seed files, each may carry
"_collection": "questions" | "sections").  See README.md for the field list.
Question kinds: choice (4 choices), visual (2-4 versions with pictures), readonly, chooser (she picks pictures from a gallery:
SPEC3.md F4; gallery photos and preview.base may be "file" (uploaded by prepare) or a ready https "url"; --pics DIR adds a folder to look in).
Optional on any question: canRecheck (true/false) and safety {...} (checked with seed/check_safety.py), peopleNote (chooser).
"""
import argparse
import base64
import copy
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

import importlib.util as _iu  # noqa: E402

# Load the shared helpers by path (python3 -I does not put this folder on the import path).
_spec = _iu.spec_from_file_location("qtlib", Path(__file__).resolve().parent / "qtlib.py")
qt = _iu.module_from_spec(_spec)
sys.modules["qtlib"] = qt
_spec.loader.exec_module(qt)

KINDS = ("choice", "visual", "readonly", "chooser")
SLOTS_MAX, GALLERY_MAX, OVERLAYS_MAX = 4, 60, 8
FRAMES = ("none", "white", "yellow")
DATA_IMAGE = re.compile(r"^data:image/(?:png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$")   # the page accepts these too (SPEC3 F4)
MAX_DOC_BYTES = 900_000   # one question must fit into a batch (1 MiB)
EXTRA_ROOTS = []   # folders to look for picture files in (--pics)
WHO = ("owner", "kathy", "rob", "adviser", "unknown")
Q_KNOWN = {
    "id", "sectionId", "kind", "order", "createdAt", "title", "story", "why", "ownTip", "choices", "versions",
    "beforeImages", "required", "round", "parentId", "who", "needs", "previouslyNotSure", "topic", "oldId",
    "canRecheck", "safety", "chooser", "peopleNote", "_collection",
}
UPLOAD_MAX = 25  # files per Artifact upload call
T_TOOLS = Path(__file__).resolve().parent


# --------------------------------------------------------------------------- helpers
def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _find_file(f, base, roots=()):
    if not isinstance(f, str) or not f.strip():
        return None
    p = Path(f).expanduser()
    for cand in ([p] if p.is_absolute() else [Path(base) / p, Path.cwd() / p] + [Path(r) / p for r in roots]):
        try:
            if cand.is_file():
                return cand.resolve()
        except OSError:   # a name that is far too long to be a file
            return None
    return None


def _text(v, default=""):
    return v.strip() if isinstance(v, str) else default


MAX_TEXT = 10000   # characters in any one text field
MAX_WORD = 120     # characters in one "word" (no spaces): a longer run of letters can freeze the page layout


def text_limits(texts, E):
    """One clear line per field that is too long, or has a 'word' with no spaces that is too long."""
    for where, text in texts:
        if not isinstance(text, str):
            continue
        if len(text) > MAX_TEXT:
            E.append(f"{where} is {len(text):,} characters; the limit is {MAX_TEXT:,}")
        longest = max((len(w) for w in text.split()), default=0)
        if longest > MAX_WORD:
            E.append(f"{where} has one 'word' with no spaces that is {longest:,} characters long; the limit is {MAX_WORD} (it could freeze the page)")


# --------------------------------------------------------------------------- one question
def norm_question(spec, base, allow, order):
    """-> (doc, uploads, errors, warnings).  uploads = [{name, src, ref}] where ref is the image
    entry inside doc that gets its url (and size) later."""
    E, W, uploads, texts = [], [], [], []
    if not isinstance(spec, dict):
        return None, [], ["this entry is not an object like {...}"], []
    for k in spec:
        if k not in Q_KNOWN:
            W.append(f"unknown field '{k}' is ignored")

    qid = spec.get("id")
    if not isinstance(qid, str) or not qt.ID_RE.match(qid):
        E.append(f"id must be 1-60 characters: lowercase letters, digits, - and _ only (got {qid!r})")
        qid = "noid"
    sec = spec.get("sectionId")
    if not isinstance(sec, str) or not qt.ID_RE.match(sec):
        E.append(f"sectionId must use only lowercase letters, digits, - and _ (got {sec!r})")
    kind = spec.get("kind")
    if kind not in KINDS:
        E.append(f"kind must be one of {', '.join(KINDS)} (got {kind!r})")

    title = _text(spec.get("title"))
    if not title:
        E.append("title is missing")
    elif len(title) > 110:
        E.append(f"title is {len(title):,} characters; the limit is 110" + (" (and 300 at the very most)" if len(title) > 300 else ""))
    elif "\n" in title:
        E.append("title must be one line")
    texts.append(("title", title))

    story = spec.get("story")
    if isinstance(story, str):
        story = [story]
    if not isinstance(story, list) or not (1 <= len(story) <= 4) or not all(isinstance(s, str) and s.strip() for s in story):
        E.append("story must be 1 to 4 short paragraphs (a list of non-empty texts)")
        story = []
    story = [s.strip() for s in story]
    for i, s in enumerate(story, 1):
        texts.append((f"story paragraph {i}", s))
        if len(s) > 450:
            W.append(f"story paragraph {i} is long ({len(s)} characters); shorter reads better")

    why = _text(spec.get("why"))
    own_tip = _text(spec.get("ownTip"))
    needs = _text(spec.get("needs"))
    topic = _text(spec.get("topic"))
    for nm, v in (("why", why), ("ownTip", own_tip), ("needs", needs), ("topic", topic)):
        if nm in spec and not isinstance(spec[nm], (str, type(None))):
            E.append(f"{nm} must be text")
        texts.append((nm, v))
    if len(why) > 400:
        W.append("why is long; keep it to 1-2 sentences")

    # numbers / flags
    for nm in ("required", "previouslyNotSure"):
        if nm in spec and not isinstance(spec[nm], bool):
            E.append(f"{nm} must be true or false")
    rnd = spec.get("round", 1)
    if not isinstance(rnd, int) or isinstance(rnd, bool) or rnd < 1:
        E.append("round must be a whole number, 1 or more")
        rnd = 1
    parent = spec.get("parentId")
    if parent is not None and (not isinstance(parent, str) or not qt.ID_RE.match(parent)):
        E.append(f"parentId must be an id or null (got {parent!r})")
        parent = None
    who = spec.get("who", "owner")
    if who not in WHO:
        E.append(f"who must be one of {', '.join(WHO)} (got {who!r})")
    if "order" in spec and not _is_num(spec["order"]):
        E.append("order must be a number")
    old_id = spec.get("oldId")
    if old_id is not None and not isinstance(old_id, str):
        E.append("oldId must be text or null")
    created = spec.get("createdAt")
    if created is not None and qt.parse_iso(created) is None:
        E.append(f"createdAt is not a date like 2026-10-07T12:00:00Z (got {created!r})")
        created = None

    choices_in = spec.get("choices")
    versions_in = spec.get("versions")
    choices, versions, before = [], [], []
    chooser = None

    def parse_choices(items, exact):
        out = []
        for i, c in enumerate(items):
            if isinstance(c, str):
                c = {"label": c}
            if not isinstance(c, dict):
                E.append(f"choice {i + 1} is not text or an object with label/explain")
                continue
            key = c.get("key", qt.KEYS[i])
            lab, exp = _text(c.get("label")), _text(c.get("explain"))
            if key != qt.KEYS[i]:
                E.append(f"choice {i + 1} must have key {qt.KEYS[i]} (got {key!r})")
            if not lab:
                E.append(f"choice {qt.KEYS[i]} has no label")
            if not exp:
                W.append(f"choice {qt.KEYS[i]} has no 'explain' line (what happens if she picks it)")
            if len(lab) > 120:
                W.append(f"choice {qt.KEYS[i]} label is long ({len(lab)} characters)")
            texts.extend([(f"choice {qt.KEYS[i]} label", lab), (f"choice {qt.KEYS[i]} explain", exp)])
            out.append({"key": qt.KEYS[i], "label": lab, "explain": exp})
        labels = [c["label"].lower() for c in out if c["label"]]
        if len(set(labels)) != len(labels):
            W.append("two choices have the same label")
        return out

    if kind == "choice":
        if versions_in:
            E.append("a 'choice' question cannot have versions (use kind 'visual' for pictures)")
        if spec.get("beforeImages"):
            E.append("beforeImages belong to 'visual' questions")
        if not isinstance(choices_in, list) or len(choices_in) != 4:
            E.append(f"a 'choice' question needs exactly 4 choices (got {len(choices_in) if isinstance(choices_in, list) else 0})")
        else:
            choices = parse_choices(choices_in, True)

    elif kind == "visual":
        if choices_in:
            E.append("a 'visual' question has versions, not choices (the page adds the answer buttons)")
        if not isinstance(versions_in, list) or not (2 <= len(versions_in) <= 4):
            E.append(f"a 'visual' question needs 2 to 4 versions (got {len(versions_in) if isinstance(versions_in, list) else 0})")
            versions_in = []
        for i, v in enumerate(versions_in):
            if not isinstance(v, dict):
                E.append(f"version {i + 1} is not an object")
                continue
            key = v.get("key", qt.KEYS[i])
            if key != qt.KEYS[i]:
                E.append(f"version {i + 1} must have key {qt.KEYS[i]} (got {key!r})")
            key = qt.KEYS[i]
            lab, cap = _text(v.get("label")), _text(v.get("caption"))
            if not lab:
                E.append(f"version {key} has no label")
            texts += [(f"version {key} label", lab), (f"version {key} caption", cap)]
            ent = {"key": key, "label": lab, "caption": cap, "images": []}
            files = v.get("files", v.get("file"))
            if isinstance(files, str):
                files = [files]
            alts = v.get("alts", v.get("alt"))
            if isinstance(alts, str):
                alts = [alts]
            alts = alts if isinstance(alts, list) else []
            ready = v.get("images")
            if files and ready:
                E.append(f"version {key}: give either files (new pictures) or images (already uploaded), not both")
            elif files:
                if not isinstance(files, list) or not (1 <= len(files) <= 4):
                    E.append(f"version {key}: files must be a list of 1 to 4 picture files")
                else:
                    for n, f in enumerate(files, 1):
                        src = _find_file(f, base)
                        alt = _text(alts[n - 1]) if n - 1 < len(alts) else ""
                        if not src:
                            E.append(f"version {key}: picture file not found: {f}")
                        if not alt:
                            alt = f"{lab or 'Version ' + key}, picture {n}"
                            W.append(f"version {key} picture {n} has no alt text (a short description for screen readers); using '{alt}'")
                        texts.append((f"version {key} picture {n} alt", alt))
                        image = {"url": None, "alt": alt, "w": 0, "h": 0}
                        ent["images"].append(image)
                        uploads.append({"name": f"{qid}-{key.lower()}-{n}.webp", "src": src, "ref": image})
            elif isinstance(ready, list) and ready:
                for n, im in enumerate(ready, 1):
                    r = _check_ready_image(im, f"version {key} picture {n}", E, W)
                    texts.append((f"version {key} picture {n} alt", r["alt"]))
                    ent["images"].append(r)
            else:
                E.append(f"version {key} has no pictures (files: [...])")
            versions.append(ent)
        labels = [v["label"].lower() for v in versions if v["label"]]
        if len(set(labels)) != len(labels):
            W.append("two versions have the same label")
        # "how it looks today"
        b_in = spec.get("beforeImages") or []
        if not isinstance(b_in, list) or len(b_in) > 4:
            E.append("beforeImages must be a list of at most 4 pictures")
            b_in = []
        for n, b in enumerate(b_in, 1):
            if isinstance(b, str):
                b = {"file": b}
            if not isinstance(b, dict):
                E.append(f"beforeImages {n} is not an object like {{file, alt, caption}}")
                continue
            cap = _text(b.get("caption"))
            if b.get("url"):
                r = _check_ready_image(b, f"beforeImages {n}", E, W)
                r["caption"] = cap
                texts.append((f"beforeImages {n} alt", r["alt"]))
                before.append(r)
                texts.append((f"beforeImages {n} caption", cap))
                continue
            src = _find_file(b.get("file"), base)
            alt = _text(b.get("alt"))
            if not src:
                E.append(f"beforeImages {n}: picture file not found: {b.get('file')}")
            if not alt:
                alt = f"How it looks today, picture {n}"
                W.append(f"beforeImages {n} has no alt text; using '{alt}'")
            texts += [(f"beforeImages {n} alt", alt), (f"beforeImages {n} caption", cap)]
            image = {"url": None, "alt": alt, "w": 0, "h": 0, "caption": cap}
            before.append(image)
            uploads.append({"name": f"{qid}-before-{n}.webp", "src": src, "ref": image})

    elif kind == "readonly":
        if versions_in or spec.get("beforeImages"):
            E.append("a 'readonly' question has no versions or pictures")
        if choices_in:  # the kathy pile keeps the first questionnaire's options so she can read them
            if not isinstance(choices_in, list) or len(choices_in) > 4:
                E.append("a 'readonly' question may list at most 4 choices")
            else:
                choices = parse_choices(choices_in, False)
        if sec == "kathy" and who not in ("kathy", "rob", "adviser", "unknown"):
            W.append("in the 'kathy' section 'who' should say who answers (kathy, rob, adviser or unknown)")
        if sec == "kathy" and not needs:
            W.append("a 'kathy' question should say what we need (the 'needs' field)")

    elif kind == "chooser":
        if versions_in or spec.get("beforeImages"):
            E.append("a 'chooser' question has a gallery in `chooser`, not versions or beforeImages")
        if choices_in:
            E.append("a 'chooser' question draws its own answer controls: leave `choices` out")
        chooser = parse_chooser(spec.get("chooser"), qid, base, E, W, texts, uploads)

    if sec == "kathy" and kind in ("choice", "visual", "chooser"):
        E.append("the 'kathy' section is read-only: questions there must have kind 'readonly'")

    # ---- the words about people in pictures, and the safety check (SPEC3 F3, rules in seed/check_safety.py)
    people_note = _text(spec.get("peopleNote"))
    if "peopleNote" in spec and not isinstance(spec["peopleNote"], (str, type(None))):
        E.append("peopleNote must be text")
    if people_note:
        texts.append(("peopleNote", people_note))
        if kind != "chooser":
            W.append("peopleNote is only used by 'chooser' questions")
    safety_doc = None
    if "canRecheck" in spec or "safety" in spec:
        probe = {"id": qid, **{k: spec[k] for k in ("canRecheck", "safety") if k in spec}}
        rules = _safety_rules()
        if rules is None:
            E.append("the question has a safety check, but seed/check_safety.py (the rules for it) was not found, so it cannot be checked")
        else:
            drop = f"{qid}: "
            e, w = rules.check_question(probe)
            E += [m[len(drop):] if m.startswith(drop) else m for m in e]
            W += [m[len(drop):] if m.startswith(drop) else m for m in w]
        s = spec.get("safety")
        if isinstance(s, dict):
            safety_doc = copy.deepcopy(s)
            texts += [("safety summary", s.get("summary")), ("safety whatItDoes", s.get("whatItDoes"))]
            for i, c in enumerate(s.get("checks") if isinstance(s.get("checks"), list) else [], 1):
                if isinstance(c, dict):
                    texts += [(f"safety check {i} label", c.get("label")), (f"safety check {i} note", c.get("note"))]
            for i, x in enumerate(s.get("limits") if isinstance(s.get("limits"), list) else [], 1):
                texts.append((f"safety limit {i}", x))

    text_limits(texts, E)
    for where, word in qt.jargon_hits(texts, allow):
        E.append(f"the word '{word}' is in {where}; she should not read it. Say it in everyday words")

    doc = {
        "id": qid,
        "sectionId": sec,
        "kind": kind,
        "order": spec["order"] if _is_num(spec.get("order")) else order,
        "createdAt": created or qt.now_iso(),
        "title": title,
        "story": story,
        "why": why,
        "ownTip": own_tip,
        "choices": choices,
        "versions": versions,
        "beforeImages": before,
        "required": bool(spec.get("required", False)),
        "round": rnd,
        "parentId": parent,
        "who": who,
        "needs": needs,
        "previouslyNotSure": bool(spec.get("previouslyNotSure", False)),
        "oldId": old_id,
    }
    if topic:
        doc["topic"] = topic
    if kind == "chooser":
        doc["chooser"] = chooser
        size = len(json.dumps(doc, ensure_ascii=False).encode("utf-8"))
        if size > MAX_DOC_BYTES:
            E.append(f"the question is {size // 1024} KB; one question can be at most about {MAX_DOC_BYTES // 1024} KB. Upload the pictures and use their addresses instead of putting them inside")
    if people_note:
        doc["peopleNote"] = people_note
    if isinstance(spec.get("canRecheck"), bool):
        doc["canRecheck"] = spec["canRecheck"]
    if safety_doc is not None:
        doc["safety"] = safety_doc
    return doc, uploads, E, W


def _ok_pic_url(u):
    """https://... or an uploaded-asset address /_blob/<32 hex>"""
    import re
    return u.startswith("https://") or bool(re.fullmatch(r"/_blob/[0-9a-f]{32}", u))


def _check_ready_image(im, where, E, W):
    """A picture that already has an https address."""
    if not isinstance(im, dict) or not isinstance(im.get("url"), str) or not _ok_pic_url(im["url"]):
        E.append(f"{where}: the picture needs a url starting with https:// (or /_blob/<id> from an upload)")
        return {"url": "", "alt": "", "w": 0, "h": 0}
    alt = _text(im.get("alt"))
    if not alt:
        alt = "Picture"
        W.append(f"{where} has no alt text")
    w, h = im.get("w"), im.get("h")
    if not (isinstance(w, int) and isinstance(h, int) and w > 0 and h > 0):
        W.append(f"{where} has no w/h (width and height); the page cannot reserve space for it")
        w, h = 0, 0
    return {"url": im["url"], "alt": alt, "w": w, "h": h}


# --------------------------------------------------------------------------- the safety rules and the picture chooser
_SAFETY = []


def _safety_rules():
    """seed/check_safety.py loaded by its path (None when the file is missing)."""
    if not _SAFETY:
        path = T_TOOLS.parent / "seed" / "check_safety.py"
        mod = None
        if path.is_file():
            spec = _iu.spec_from_file_location("check_safety", path)
            mod = _iu.module_from_spec(spec)
            spec.loader.exec_module(mod)
        _SAFETY.append(mod)
    return _SAFETY[0]


def _chooser_picture(raw, where, name, base, E, W, texts, uploads, target, need_label=False):
    """One picture of a chooser (a gallery photo or preview.base): fills the dict `target` (url, alt, w, h) that goes into the document.
    `file` = a picture on this computer (prepare uploads it as `name`); `url` = already uploaded (https:// or /_blob/<id>).
    An older draft may hold a file name in `url`: that is accepted when the file exists (looked for beside the spec, in its parent folder, or in --pics)."""
    target.update({"url": "", "alt": "", "w": 0, "h": 0})
    if not isinstance(raw, dict):
        E.append(f"{where} must be an object like {{id, file, alt, label}}")
        return target
    roots = [Path(base).parent] + list(EXTRA_ROOTS)
    f, u = raw.get("file"), raw.get("url")
    if isinstance(u, str) and u and not _ok_pic_url(u) and not f and _find_file(u, base, roots):
        f, u = u, None
    label = _text(raw.get("label"))
    alt = _text(raw.get("alt"))
    if need_label:
        if not label:
            E.append(f"{where} has no label (the short name under the thumbnail)")
        texts.append((f"{where} label", label))
    if not alt:
        alt = label or "Picture"
        W.append(f"{where} has no alt text (a short description for screen readers); using '{alt}'")
    texts.append((f"{where} alt", alt))
    target["alt"] = alt
    if f and u:
        E.append(f"{where}: give either file (a new picture) or url (already uploaded), not both")
    elif f:
        src = _find_file(f, base, roots)
        if not src:
            E.append(f"{where}: picture file not found: {f}")
        else:
            target["url"] = None   # prepare / finish fill in the address and the size
            uploads.append({"name": name, "src": src, "ref": target, "copy_if_small": True})
    elif isinstance(u, str) and u:
        w, h = raw.get("w"), raw.get("h")
        if DATA_IMAGE.match(u):
            W.append(f"{where}: the picture is stored inside the question ({len(u) // 1024} KB). It works, but upload it and use its address when you can")
        elif not _ok_pic_url(u):
            E.append(f"{where}: the picture needs a url starting with https:// (or /_blob/<32 hex letters or digits> from an upload, or data:image/...), or a `file` to upload")
        if not (isinstance(w, int) and isinstance(h, int) and not isinstance(w, bool) and not isinstance(h, bool) and w > 0 and h > 0):
            E.append(f"{where}: w and h (width and height in pixels, whole numbers) are needed for a picture that is already uploaded")
            w = h = 0
        target.update({"url": u, "w": w, "h": h})
    else:
        E.append(f"{where} has no picture (file: \"...\" to upload, or url: \"https://...\")")
    return target


def parse_chooser(ch, qid, base, E, W, texts, uploads):
    """The `chooser` block of a 'chooser' question (SPEC3 F4) -> document block. Problems go into E (must fix) and W (notes)."""
    if not isinstance(ch, dict):
        E.append("a 'chooser' question needs a `chooser` block: {slots, gallery, preview, allowNone}")
        return {"slots": [], "gallery": []}
    for k in ch:
        if k not in ("slots", "gallery", "preview", "allowNone"):
            W.append(f"unknown field chooser.{k} is ignored")
    # places a picture goes
    slots_in = ch.get("slots")
    slots, slot_ids = [], set()
    if not isinstance(slots_in, list) or not (1 <= len(slots_in) <= SLOTS_MAX):
        E.append(f"chooser.slots needs 1 to {SLOTS_MAX} places (got {len(slots_in) if isinstance(slots_in, list) else 0})")
        slots_in = []
    for i, s in enumerate(slots_in, 1):
        if not isinstance(s, dict):
            E.append(f"chooser slot {i} must be an object like {{id, label, hint}}")
            continue
        sid, lab, hint = s.get("id"), _text(s.get("label")), _text(s.get("hint"))
        if not isinstance(sid, str) or not qt.ID_RE.match(sid):
            E.append(f"chooser slot {i}: id must use only lowercase letters, digits, - and _ (got {sid!r})")
            continue
        if sid in slot_ids:
            E.append(f"chooser slot id '{sid}' is used twice")
        slot_ids.add(sid)
        if not lab:
            E.append(f"chooser slot '{sid}' has no label (for example \"Left side\")")
        elif len(lab) > 30:
            W.append(f"chooser slot '{sid}': a short place name reads best (it is {len(lab)} characters; about 20 fit in the badge)")
        texts += [(f"chooser slot '{sid}' label", lab), (f"chooser slot '{sid}' hint", hint)]
        slots.append({"id": sid, "label": lab, "hint": hint})
    # the photos
    gal_in = ch.get("gallery")
    gallery, gids = [], set()
    if not isinstance(gal_in, list) or not (1 <= len(gal_in) <= GALLERY_MAX):
        E.append(f"chooser.gallery needs 1 to {GALLERY_MAX} photos (got {len(gal_in) if isinstance(gal_in, list) else 0})")
        gal_in = []
    elif len(gal_in) < len(slots):
        W.append(f"the gallery has fewer photos ({len(gal_in)}) than places ({len(slots)})")
    for i, g in enumerate(gal_in, 1):
        gid = g.get("id") if isinstance(g, dict) else None
        where = f"gallery photo {i}" + (f" '{gid}'" if isinstance(gid, str) else "")
        if not isinstance(gid, str) or not qt.ID_RE.match(gid):
            E.append(f"{where}: id must use only lowercase letters, digits, - and _ (got {gid!r})")
            gid = f"noid-{i}"
        elif gid in gids:
            E.append(f"gallery photo id '{gid}' is used twice")
        gids.add(gid)
        people = g.get("people", False) if isinstance(g, dict) else False
        if not isinstance(people, bool):
            E.append(f"{where}: people must be true or false (true = the photo shows people)")
            people = False
        entry = {"id": gid, "url": "", "alt": "", "w": 0, "h": 0, "label": _text(g.get("label")) if isinstance(g, dict) else "", "people": people}
        _chooser_picture(g, where, f"{qid}-g-{gid}.webp", base, E, W, texts, uploads, entry, need_label=True)
        gallery.append(entry)
    # the picture the choice is shown on
    preview = None
    pv = ch.get("preview")
    if pv is not None:
        if not isinstance(pv, dict):
            E.append("chooser.preview must be an object like {base, overlays}")
        else:
            for k in pv:
                if k not in ("base", "overlays"):
                    W.append(f"unknown field chooser.preview.{k} is ignored")
            base_img = {}
            if pv.get("base") is None:
                E.append("chooser.preview needs a `base` picture (the picture her choice is shown on)")
            else:
                base_img = _chooser_picture(pv.get("base"), "preview base picture", f"{qid}-base.webp", base, E, W, texts, uploads, {})
            overlays, seen_slots = [], set()
            ov_in = pv.get("overlays", [])
            if not isinstance(ov_in, list) or len(ov_in) > OVERLAYS_MAX:
                E.append(f"preview.overlays must be a list of at most {OVERLAYS_MAX} places")
                ov_in = []
            for i, o in enumerate(ov_in, 1):
                if not isinstance(o, dict):
                    E.append(f"preview overlay {i} must be an object like {{slot, x, y, w, h, rotate, frame}}")
                    continue
                where = f"preview overlay {i}"
                if o.get("slot") not in slot_ids:
                    E.append(f"{where}: slot {o.get('slot')!r} is not one of the places ({', '.join(sorted(slot_ids)) or 'none'})")
                nums = {}
                for k in ("x", "y", "w", "h"):
                    v = o.get(k)
                    if not _is_num(v):
                        E.append(f"{where}: {k} must be a number (percent of the base picture)")
                    else:
                        nums[k] = v
                rot = o.get("rotate", 0)
                if not _is_num(rot):
                    E.append(f"{where}: rotate must be a number (degrees)")
                    rot = 0
                elif abs(rot) > 45:
                    W.append(f"{where}: rotate {rot} is a lot (the page clamps it)")
                frame = o.get("frame", "none")
                if frame not in FRAMES:
                    E.append(f"{where}: frame must be one of {', '.join(FRAMES)} (got {frame!r})")
                    frame = "none"
                if len(nums) == 4:
                    if nums["w"] <= 0 or nums["h"] <= 0 or nums["x"] < 0 or nums["y"] < 0 or nums["x"] + nums["w"] > 100.5 or nums["y"] + nums["h"] > 100.5:
                        W.append(f"{where}: x, y, w, h are percent of the base picture, and this one sticks out of it (the page clamps it)")
                if o.get("slot") in seen_slots:
                    W.append(f"{where}: slot '{o.get('slot')}' already has a place on the picture")
                seen_slots.add(o.get("slot"))
                overlays.append({"slot": o.get("slot"), "x": nums.get("x", 0), "y": nums.get("y", 0), "w": nums.get("w", 0), "h": nums.get("h", 0), "rotate": rot, "frame": frame})
            for s in slots:
                if s["id"] not in seen_slots:
                    W.append(f"place '{s['id']}' has no overlay: she would not see her choice for it on the preview picture")
            preview = {"base": base_img, "overlays": overlays}
    else:
        W.append("no chooser.preview: she cannot see her choice on a picture before she commits")
    allow_none = ch.get("allowNone", False)
    if not isinstance(allow_none, bool):
        E.append("chooser.allowNone must be true or false")
        allow_none = False
    uploads.sort(key=lambda u: u["name"] != f"{qid}-base.webp")   # the base picture goes in the first upload list
    out = {"slots": slots, "gallery": gallery, "allowNone": allow_none}
    if preview is not None:
        out["preview"] = preview
    return out


# --------------------------------------------------------------------------- other documents
def norm_section(spec, allow):
    E, W = [], []
    sid = spec.get("id")
    if not isinstance(sid, str) or not qt.ID_RE.match(sid):
        E.append(f"section id must use only lowercase letters, digits, - and _ (got {sid!r})")
        sid = "noid"
    title = _text(spec.get("title"))
    if not title:
        E.append("section title is missing")
    kind = spec.get("kind", "builtin")
    if kind not in ("builtin", "custom"):
        E.append("section kind must be builtin or custom")
    size = spec.get("size", "small")
    if size not in ("small", "big"):
        E.append("section size must be small or big")
    if "order" in spec and not _is_num(spec["order"]):
        E.append("section order must be a number")
    for nm in ("hold", "readOnly", "archived"):
        if nm in spec and not isinstance(spec[nm], bool):
            E.append(f"section {nm} must be true or false")
    texts = [("section title", title), ("section blurb", _text(spec.get("blurb")))]
    text_limits(texts, E)
    for where, word in qt.jargon_hits(texts, allow):
        E.append(f"the word '{word}' is in {where}; she should not read it")
    doc = {
        "id": sid, "title": title, "kind": kind,
        "order": spec["order"] if _is_num(spec.get("order")) else 100,
        "size": size, "hold": bool(spec.get("hold", False)), "readOnly": bool(spec.get("readOnly", False)),
        "blurb": _text(spec.get("blurb")), "archived": bool(spec.get("archived", False)),
        "createdAt": spec.get("createdAt") if qt.parse_iso(spec.get("createdAt")) else qt.now_iso(),
        "createdBy": spec.get("createdBy", "claude"),
    }
    return doc, E, W


# --------------------------------------------------------------------------- loading the spec files
def _sources(path, many):
    """-> [(label, object, base_dir)]"""
    p = Path(path or many).expanduser()
    files = []
    if p.is_dir():
        files = sorted(x for x in p.glob("*.json") if not x.name.startswith(("urls", "versions", "upload", "batch")))
        if not files:
            qt.die(f"No .json files in {p}")
    elif p.is_file():
        files = [p]
    else:
        qt.die(f"Not found: {p}")
    out = []
    for f in files:
        try:
            obj = qt.read_json(f)
        except ValueError as e:
            qt.die(f"{f.name} is not valid JSON: {e}")
        if isinstance(obj, list):
            for i, o in enumerate(obj):
                out.append((f"{f.name}[{i}]", o, f.parent))
        else:
            out.append((f.name, obj, f.parent))
    return out, p


def build_items(path, many, allow):
    """-> (items, problems, warnings, source_path, is_many).  item = dict(coll, doc_id, doc, uploads, label)"""
    srcs, p = _sources(path, many)
    base_order = int(time.time())
    items, problems, warnings = [], [], []
    for idx, (label, obj, base) in enumerate(srcs):
        coll = "questions"
        if isinstance(obj, dict):
            coll = obj.get("_collection") or ("sections" if obj.get("kind") in ("builtin", "custom") else "questions")
        if coll == "questions":
            doc, uploads, E, W = norm_question(obj, base, allow, base_order + idx)
        elif coll == "sections" and isinstance(obj, dict):
            (doc, E, W), uploads = norm_section(obj, allow), []
        elif isinstance(obj, dict):
            doc = {k: v for k, v in obj.items() if k != "_collection"}
            did = doc.get("id") or doc.get("sectionId")
            uploads, E, W = [], [], []
            if not isinstance(did, str) or not qt.ID_RE.match(did):
                E.append(f"{coll} document needs an id of lowercase letters, digits, - and _")
        else:
            doc, uploads, E, W = None, [], ["this entry is not an object like {...}"], []
        did = (doc.get("id") or doc.get("sectionId")) if isinstance(doc, dict) else None
        name = f"{label} ({coll}/{did})" if did else label
        problems += [(name, m) for m in E]
        warnings += [(name, m) for m in W]
        if doc is not None and not E:
            items.append({"coll": coll, "doc_id": did, "doc": doc, "uploads": uploads, "label": name})
    seen = {}
    for it in items:
        k = (it["coll"], it["doc_id"])
        if k in seen:
            problems.append((it["label"], f"the id {k[1]} is used twice in {k[0]} (also in {seen[k]})"))
        seen[k] = it["label"]
    return items, problems, warnings, p, (p.is_dir() or len(srcs) > 1)


def report(problems, warnings, quiet_warnings=False):
    if warnings and not quiet_warnings:
        print("Notes:")
        for n, m in warnings[:60]:
            print(f"  - {n}: {m}")
        if len(warnings) > 60:
            print(f"  ... and {len(warnings) - 60} more")
    if problems:
        print("These need fixing (nothing was written):", file=sys.stderr)
        for n, m in problems[:80]:
            print(f"  - {n}: {m}", file=sys.stderr)
        if len(problems) > 80:
            print(f"  ... and {len(problems) - 80} more", file=sys.stderr)


def folder_for(outbox, items, source, many):
    if many:
        stem = "".join(c if c.isalnum() or c in "-_" else "-" for c in (source.stem if source.is_file() else source.name))
        return outbox / f"many-{stem}"
    return outbox / items[0]["doc_id"]


def chunks(seq, n):
    return [seq[i:i + n] for i in range(0, len(seq), n)]


# --------------------------------------------------------------------------- commands
def _small_copy(src, dst, max_w=1600, max_kb=350):
    """A WebP that is already small enough (a chooser photo made for the gallery) is copied as it is: no second round of
    lossy compression. Anything else returns None and goes through optimize_image."""
    src = Path(src)
    if src.suffix.lower() != ".webp" or src.stat().st_size > max_kb * 1024:
        return None
    from PIL import Image
    try:
        with Image.open(src) as im:
            w, h = im.size
            if w > max_w or getattr(im, "n_frames", 1) > 1:
                return None
    except Exception:
        return None
    dst = Path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    return {"file": str(dst.resolve()), "width": w, "height": h, "bytes": dst.stat().st_size, "format": "webp", "copied": True}


def cmd_prepare(a, items, many, source, outbox, quiet=False):
    opt = qt.load_sibling("optimize_image")
    all_files = []
    for it in items:
        if not it["uploads"]:
            continue
        d = outbox / it["doc_id"]
        d.mkdir(parents=True, exist_ok=True)
        for old in list(d.glob("upload*.json")):
            old.unlink()
        record, mine = [], []
        for u in it["uploads"]:
            try:
                r = _small_copy(u["src"], d / u["name"]) if u.get("copy_if_small") else None
                r = r or opt.optimize(u["src"], d / u["name"])
            except ValueError as e:
                qt.die(f"{it['label']}: {e}", 1)
            u["ref"]["w"], u["ref"]["h"] = r["width"], r["height"]
            mine.append(r["file"])
            record.append({"file": r["file"], "from": str(u["src"]), "w": r["width"], "h": r["height"], "bytes": r["bytes"],
                           **({"over_budget": True} if r.get("over_budget") else {})})
            flag = "  (over the 350 KB goal)" if r.get("over_budget") else ""
            if not quiet:
                print(f"  {r['file']}  {r['width']}x{r['height']}  {r['bytes'] // 1024} KB{flag}")
        qt.write_json(d / "images.json", record)
        parts = chunks(mine, UPLOAD_MAX)
        for i, part in enumerate(parts, 1):
            qt.write_json(d / ("upload.json" if i == 1 else f"upload-{i}.json"), {"file_paths": part})
        all_files += mine
        if not quiet:
            print(f"prepared {it['doc_id']}: {len(mine)} picture(s) -> {d / 'upload.json'}" + (f" (+{len(parts) - 1} more list(s), {UPLOAD_MAX} files each)" if len(parts) > 1 else ""))
            print(json.dumps({"file_paths": parts[0]}))
    if quiet:
        return
    if not all_files:
        print(f"Checked {len(items)} document(s): no pictures to upload. Next: finish.")
        return
    if many:
        mf = folder_for(outbox, items, source, True)
        parts = chunks(all_files, UPLOAD_MAX)
        for i, part in enumerate(parts, 1):
            p = qt.write_json(mf / f"upload-{i}.json", {"file_paths": part})
            print(f"upload list {i} of {len(parts)}: {p}")
    print("Next: Artifact (publish, asset: true, url = the Question Terminal page, file_paths = the list above).")
    print("      Then save each file's address as urls.json and run: post_question.py finish ... --urls urls.json")


def cmd_preview(a, items, many, source, outbox):
    """Pictures as inline data + a seed file for test/mock-claude.js, so the real page can be photographed before anything is published."""
    cmd_prepare(a, items, many, source, outbox, quiet=True)
    seed, have = {}, set()
    for it in items:
        if it["coll"] == "sections":
            have.add(it["doc_id"])
    for it in items:
        for u in it["uploads"]:
            f = outbox / it["doc_id"] / u["name"]
            u["ref"]["url"] = "data:image/webp;base64," + base64.b64encode(f.read_bytes()).decode("ascii")
        seed[f"{it['coll']}/{it['doc_id']}"] = copy.deepcopy(it["doc"])
    for it in items:
        sid = it["doc"].get("sectionId") if it["coll"] == "questions" else None
        if sid and sid not in have:
            have.add(sid)
            seed[f"sections/{sid}"] = {"id": sid, "title": sid.replace("-", " ").title(), "kind": "builtin", "order": 1, "size": "small", "hold": False,
                                       "readOnly": sid == "kathy", "blurb": "", "archived": False, "createdAt": qt.now_iso(), "createdBy": "claude"}
    folder = folder_for(outbox, items, source, many)
    folder.mkdir(parents=True, exist_ok=True)
    f = folder / "preview-seed.js"
    f.write_text("window.__MOCK_SEED__ = " + json.dumps(seed, ensure_ascii=False) + ";\n", encoding="utf-8")
    first = next((i for i in items if i["coll"] == "questions"), None)
    print(f"Preview data: {f}  ({f.stat().st_size // 1024} KB)")
    if first:
        print("Photograph it in the real page (700 x 800, the size beside the chat):")
        print(f"  NODE_PATH=/opt/node22/lib/node_modules node {T_TOOLS}/snap.mjs --url {T_TOOLS.parent}/dist/index.html --init {f} --init {T_TOOLS.parent}/test/mock-claude.js "
              f"--w 700 --h 800 --eval \"QT.ready.then(() => QT.route.go('question', {{id: '{first['doc_id']}'}}))\" --out {folder}/preview.png")


def _url_of(v):
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        for k in ("url", "asset_url", "href", "src"):
            if isinstance(v.get(k), str):
                return v[k]
    return None


def _name_of(x):
    for k in ("file", "name", "path", "filename", "basename", "file_path", "source", "local"):
        if isinstance(x.get(k), str):
            return x[k]
    return None


def parse_urls(raw, expected):
    """Accepts {basename: url}, {basename: {url, id}}, [{name|file|path, url}], or a plain list of urls in upload order."""
    found, positional = {}, []

    def add(name, url):
        found[os.path.basename(str(name).replace("\\", "/"))] = url

    def walk(x):
        if isinstance(x, list):
            for e in x:
                if isinstance(e, str):
                    positional.append(e)
                else:
                    walk(e)
        elif isinstance(x, dict):
            u, nm = _url_of(x), _name_of(x)
            if u and nm:
                add(nm, u)
                return
            for k, v in x.items():
                if isinstance(v, list):
                    walk(v)
                elif _url_of(v):
                    add(k, _url_of(v))
                elif isinstance(v, dict):
                    walk(v)

    walk(raw)
    if positional and not any(n in found for n in expected):
        if len(positional) != len(expected):
            qt.die(f"urls.json lists {len(positional)} addresses but {len(expected)} pictures were uploaded; "
                   "use {\"file-name.webp\": \"https://...\"} so each picture is matched by name.")
        found = dict(zip(expected, positional))
    return found


def cmd_finish(a, items, many, source, outbox):
    expected = [u["name"] for it in items for u in it["uploads"]]
    urls = {}
    if expected:
        if not a.urls:
            qt.die("These questions have pictures, so finish needs --urls urls.json (the addresses the upload gave back).\n"
                   "Pictures expected: " + ", ".join(expected))
        try:
            raw = qt.read_json(a.urls)
        except (OSError, ValueError) as e:
            qt.die(f"Could not read {a.urls}: {e}")
        urls = parse_urls(raw, expected)
        missing = [n for n in expected if n not in urls]
        if missing:
            qt.die("No address for these pictures in urls.json: " + ", ".join(missing))
        bad = [n for n in expected if not _ok_pic_url(urls[n])]
        if bad:
            qt.die("These addresses must start with https:// or look like /_blob/<id>: " + ", ".join(bad))
    for it in items:
        for u in it["uploads"]:
            f = outbox / it["doc_id"] / u["name"]
            if not f.is_file():
                qt.die(f"{f} is missing. Run prepare first.")
            from PIL import Image  # same library as optimize_image
            with Image.open(f) as im:
                u["ref"]["w"], u["ref"]["h"] = im.size
            u["ref"]["url"] = urls[u["name"]]
    versions = qt.load_versions(a.versions, a.version, outbox=outbox, auto=not a.no_versions)
    sections = [it for it in items if it["coll"] == "sections"]
    rest = [it for it in items if it["coll"] != "sections"]
    writes = []
    for it in sections + rest:
        writes.append(qt.make_write("set", it["coll"], it["doc_id"], it["doc"], versions))
        if a.status and it["coll"] == "questions":
            sd = qt.status_doc(it["doc_id"], a.status, note=a.note or "")
            writes.append(qt.make_write("set", "status", it["doc_id"], sd, versions))
    folder = folder_for(outbox, items, source, many)
    made = qt.write_batches(folder, writes, with_files=True)
    print(f"Ready: {len(writes)} write(s) for {len(items)} document(s) in {len(made)} batch file(s).")
    for inline, files, n in made:
        print(f"  {inline}   ({n} writes, documents inline)")
        print(f"  {files}   (same writes; each document is read from a file: best for long or many documents)")
    if any(w.get("if_version") for w in writes):
        print("Some writes carry if_version (documents that already exist).")
    print("Next: ArtifactData action=batch, url=<Question Terminal page>, writes=<the writes list of one batch file>.")
    print("      If it says a document already exists, refresh versions with read_answers.py and run finish again with --versions.")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Prepare questions for the Question Terminal.", add_help=True)
    ap.add_argument("command", choices=["check", "prepare", "finish", "preview", "applied"])
    ap.add_argument("spec", nargs="?", help="spec file (one question, or a list of documents), or a folder of them")
    ap.add_argument("--many", metavar="DIR", help="a folder of spec files (e.g. T/seed)")
    ap.add_argument("--urls", help="finish: JSON file with the address of each uploaded picture")
    ap.add_argument("--outbox", help="where to write (default: T/outbox)")
    ap.add_argument("--versions", help="versions.json from read_answers.py (adds if_version for documents that exist)")
    ap.add_argument("--no-versions", action="store_true", help="finish: do not use T/outbox/versions.json automatically")
    ap.add_argument("--version", action="append", default=[], metavar="PATH=N", help="one version by hand, e.g. questions/q1=3")
    ap.add_argument("--allow-words", help="comma list of words to let through the jargon check")
    ap.add_argument("--skip-bad", action="store_true", help="with --many: leave out documents with problems instead of stopping")
    ap.add_argument("--pics", action="append", default=[], metavar="DIR", help="chooser questions: another folder to look for picture files in (repeatable)")
    ap.add_argument("--status", choices=["seen", "working", "done", "followup", "held"], help="finish: also set the new question's status")
    ap.add_argument("--note", help="finish: note for --status")
    ap.add_argument("--results", help="applied: JSON map path -> version copied from the ArtifactData result")
    ap.add_argument("--again", action="store_true", help="applied: record a batch file that was recorded before")
    a = ap.parse_args(argv)
    if a.command == "applied":
        if not a.spec:
            ap.error("applied needs the batch file that ArtifactData just accepted")
        lines, vpath = qt.apply_batch(a.spec, a.results, a.outbox, a.again)
        print(f"Recorded {len(lines)} write(s) in {vpath}:")
        for l in lines[:40]:
            print("  " + l)
        if len(lines) > 40:
            print(f"  ... and {len(lines) - 40} more")
        return 0
    if not a.spec and not a.many:
        ap.error("give a spec file, or --many DIR")
    outbox = qt.outbox_dir(a.outbox)
    allow = qt.parse_allow(a.allow_words)
    EXTRA_ROOTS[:] = [Path(x).expanduser() for x in a.pics]
    items, problems, warnings, source, many = build_items(a.spec, a.many, allow)
    if a.many:
        many = True
    if problems and not (a.skip_bad and items):
        report(problems, warnings)
        return 2
    report(problems if a.skip_bad else [], warnings)
    if problems:
        print(f"Left out {len({n for n, _ in problems})} document(s) with problems (--skip-bad).")
    if not items:
        qt.die("Nothing to do.")
    if a.command == "check":
        pics = sum(len(i["uploads"]) for i in items)
        print(f"OK: {len(items)} document(s) look good; {pics} picture(s) to upload.")
        return 0
    if a.command == "prepare":
        cmd_prepare(a, items, many, source, outbox)
    elif a.command == "preview":
        cmd_preview(a, items, many, source, outbox)
    else:
        cmd_finish(a, items, many, source, outbox)
    return 0


if __name__ == "__main__":
    sys.exit(main())
