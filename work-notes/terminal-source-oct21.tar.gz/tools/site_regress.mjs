#!/usr/bin/env node
/* site_regress.mjs - the PHOTOGRAPHER of the website regression kit (run by site_regress.py; see T/notes/REGRESS.md).

   NODE_PATH=/opt/node22/lib/node_modules node site_regress.mjs --repo DIR --jobs jobs.json --out OUT [--port 9550] [--scale 0.5] [--motion reduce]

   --jobs is a list of GROUPS: { url, w, h, date: "YYYY-MM-DD" (the farm's day, Eastern Time), shots: [ { id, scheme: "light"|"dark", top?: N } ] }.
   A group is loaded once; each shot is one picture of it (the whole page, or the top N screens when "top" is given); a "dark" shot switches the page's
   colour scheme with emulateMedia (no new load), so the light shot always comes first in a group.
   It serves DIR on 127.0.0.1 and never writes into it. What makes two runs on the same files give the SAME pixels:
     - Playwright's fake clock (page.clock), PAUSED: the page starts at the chosen day; timers, requestAnimationFrame and performance.now only move when
       this script says so (it runs the clock 3 s after the load and 0.5 s after the pictures are in), so every animation sits in the same state
       however busy the computer is;
     - Math.random is replaced by a seeded generator (the hero's critters, the wandering bee and the greeting lines use it) and restarts for every page;
     - lazy pictures are made eager, waited for and decoded; fonts are waited for; CSS / Web Animations are fast-forwarded or stopped ("animations: disabled");
     - the "Site check" box that the page draws on localhost is removed (it lists dates and would differ from day to day);
     - one fresh browser context per picture: no stored language, no cookies, no cache from an earlier picture; Eastern Time; 1 device pixel per CSS pixel.
   Written pictures: OUT/<id>.png.  Exit code 0 = all pictures saved, 1 = at least one failed (named on stderr).   */
import fs from 'node:fs';
import path from 'node:path';
import { startServer, launch } from '../test/lib.mjs';

const arg = (name, dflt) => { const i = process.argv.indexOf('--' + name); return i > 0 && i + 1 < process.argv.length ? process.argv[i + 1] : dflt; };
const repo = path.resolve(arg('repo', '.'));
const jobsFile = arg('jobs');
const outDir = path.resolve(arg('out', 'out'));
const port = Number(arg('port', 9550));
const motion = arg('motion', 'reduce');   // 'reduce' = the page is told the visitor wants less movement (the site then keeps its scenes still: the same pixels every time); 'no-preference' = as most visitors see it
const scale = Number(arg('scale', 0.5));   // device pixels per CSS pixel: 0.5 = a quarter of the pixels (fast); 1 = every pixel
if (!jobsFile || !fs.existsSync(repo) || !fs.statSync(repo).isDirectory()) { console.error('usage: node site_regress.mjs --repo DIR --jobs jobs.json --out OUT [--port 9550] [--scale 0.5] [--motion reduce]'); process.exit(2); }
const groups = JSON.parse(fs.readFileSync(jobsFile, 'utf8'));
fs.mkdirSync(outDir, { recursive: true });

process.on('unhandledRejection', () => {});   // a page that was given up on may still fail later: that is no news
const SEED = `(() => {
  let s = 0x2f6e2b1;
  Math.random = () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
})();`;
const HIDE = `(() => { const css = document.createElement('style'); css.textContent = '#wa-problems{display:none!important}'; document.documentElement.appendChild(css); const b = document.getElementById('wa-problems'); if (b) b.remove(); })();`;

const site = await startServer({ root: repo, port });
let browser = await launch();
const failed = [];
let done = 0;
const t0 = Date.now();
const within = (p, ms, what) => { let t; return Promise.race([p, new Promise((_, rej) => { t = setTimeout(() => rej(new Error(what + ' took more than ' + Math.round(ms / 1000) + ' s')), ms); })]).finally(() => clearTimeout(t)); };
const savedIds = new Set();
async function takeGroup(g) {   // one page load with a watchdog: a hung page or browser must not stop the whole run
  try { await within(takeGroupInner(g), 300000, 'the page ' + g.url + ' ' + g.w + 'x' + g.h); }
  catch (e) {
    for (const sh of g.shots) if (!savedIds.has(sh.id) && !failed.some((f) => f.startsWith(sh.id + ':'))) { failed.push(sh.id + ': ' + e.message); console.error('FAILED ' + sh.id + ': ' + e.message); }
    const old = browser; browser = null;
    if (old) await within(old.close(), 10000, 'closing the browser').catch(() => {});
  }
}
async function takeGroupInner(g) {
  if (!browser || !browser.isConnected()) browser = await launch();   // a very tall page can take the browser down: start a new one and go on
  const ctx = await browser.newContext({ viewport: { width: g.w, height: g.h }, deviceScaleFactor: scale, colorScheme: 'light', locale: 'en-US', timezoneId: 'America/New_York', reducedMotion: motion, serviceWorkers: 'block' });
  try {
    const T = { t: Date.now() }; const lap = (k) => { T[k] = Date.now() - T.t; T.t = Date.now(); };
    const page = await ctx.newPage();
    page.setDefaultTimeout(30000);
    const [y, m, d] = String(g.date).split('-').map(Number);
    const day0 = Date.UTC(y, m - 1, d, 16, 0, 0);   // 11 or 12 o'clock in the morning on the farm's day
    await page.clock.install({ time: new Date(day0) });
    await page.clock.pauseAt(new Date(day0 + 1000));   // from here the page's time moves ONLY when this script runs the clock: nothing depends on how fast the computer is
    await page.addInitScript(SEED);
    await page.goto(site.url + String(g.url).replace(/^\/+/, ''), { waitUntil: 'load', timeout: 45000 });
    lap('load'); await page.clock.runFor(3000); lap('clock');
    await page.evaluate(async () => {
      document.querySelectorAll('img[loading="lazy"]').forEach((i) => { i.loading = 'eager'; });
      const cap = (p, t) => Promise.race([p, new Promise((r) => setTimeout(r, t))]);
      try { await cap(document.fonts.ready, 5000); } catch (e) { /* no fonts api */ }
      const pend = [...document.images].filter((i) => !i.complete);
      await cap(Promise.all(pend.map((i) => new Promise((r) => { i.addEventListener('load', r); i.addEventListener('error', r); }))), 10000);
      await cap(Promise.all([...document.images].map((i) => (i.decode ? i.decode().catch(() => {}) : null))), 10000);   // "complete" is not "decoded": a picture that is not drawn yet is a different picture
    });
    lap('images'); await page.clock.runFor(500);
    await page.evaluate(HIDE);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.clock.runFor(100);
    for (const sh of g.shots) {
      try {
        if (sh.scheme === 'dark') { await page.emulateMedia({ colorScheme: 'dark' }); await page.clock.runFor(300); }
        const shot = { path: path.join(outDir, sh.id + '.png'), fullPage: true, animations: 'disabled', caret: 'hide', scale: 'device' };
        if (sh.top) {   // a "top N screens" picture (cheap): where only a reaction of the whole site is looked for (the dark colour scheme)
          const H = await page.evaluate(() => document.documentElement.scrollHeight);
          shot.clip = { x: 0, y: 0, width: g.w, height: Math.min(H, sh.top * g.h) };
        }
        lap('prep'); await page.screenshot(shot); lap('shot');
        done++; savedIds.add(sh.id);
        console.log('saved ' + sh.id + '  (load ' + T.load + ' clock ' + T.clock + ' images ' + T.images + ' shot ' + T.shot + ' ms)');
      } catch (e) {
        failed.push(sh.id + ': ' + String(e.message).split('\n')[0]);
        console.error('FAILED ' + sh.id + ': ' + String(e.message).split('\n')[0]);
      }
    }
  } catch (e) {
    for (const sh of g.shots) { failed.push(sh.id + ': ' + String(e.message).split('\n')[0]); console.error('FAILED ' + sh.id + ': ' + String(e.message).split('\n')[0]); }
  }
  await ctx.close().catch(() => {});
}
for (const g of groups) {
  await takeGroup(g);
  // a picture that failed (a slow machine, a browser that fell over) is tried once more with a fresh browser page
  const again = g.shots.filter((sh) => failed.some((f) => f.startsWith(sh.id + ':')));
  if (again.length) {
    again.forEach((sh) => { const i = failed.findIndex((f) => f.startsWith(sh.id + ':')); failed.splice(i, 1); });
    console.log('trying again: ' + again.map((x) => x.id).join(', '));
    await takeGroup({ ...g, shots: again });
  }
}
await browser.close().catch(() => {});
await site.close();
console.log(`worker (port ${port}): ${done} of ${done + failed.length} pictures in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
process.exit(failed.length ? 1 : 0);
