"""Shared helpers for the Question Terminal tools (post_question.py, status.py, read_answers.py).

Not run by itself. Each tool loads this file by its path (works with `python3 -I`).
Everything here is plain standard-library Python.
"""
import datetime
import importlib.util
import json
import os
import re
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
T = TOOLS.parent

ID_RE = re.compile(r"^[a-z0-9_-]{1,60}$")
KEYS = ["A", "B", "C", "D"]

# Words the owner must never read (SPEC section 3). Whole words only; common endings are covered.
JARGON_WORDS = "database, JSON, API, deploy, commit, repo, token, sync"
JARGON_RE = re.compile(
    r"\b(databases?|json|apis?|deploy(?:s|ed|ing|ment|ments)?|commit(?:s|ted|ting)?|repos?|"
    r"repositor(?:y|ies)|tokens?|sync(?:s|ed|ing|hroni[sz]\w*)?)\b",
    re.I,
)


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def load_sibling(name):
    """Load T/tools/<name>.py by path (so it also works when Python runs with -I)."""
    path = TOOLS / (name + ".py")
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def now_iso():
    forced = os.environ.get("QT_NOW")  # for tests
    if forced:
        return forced
    d = datetime.datetime.now(datetime.timezone.utc)
    return d.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % (d.microsecond // 1000)


_TIME_JUNK = re.compile("[\x00-\x1f\x7f-\x9f\u2028\u2029\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")


def parse_iso(s):
    """ISO text -> aware datetime (UTC when no zone is given), or None."""
    if not isinstance(s, str) or not s.strip():
        return None
    if _TIME_JUNK.search(s):   # a line break or a control character is never part of a time (a hostile document could hide a forged line there)
        return None
    s = s.strip()
    try:
        d = datetime.datetime.fromisoformat(s[:-1] + "+00:00" if s.endswith("Z") else s)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=datetime.timezone.utc)


def stamp():
    d = datetime.datetime.now(datetime.timezone.utc)
    return d.strftime("%Y%m%d-%H%M%S")


def outbox_dir(arg=None):
    p = Path(arg or os.environ.get("QT_OUTBOX") or (T / "outbox")).expanduser()
    p.mkdir(parents=True, exist_ok=True)
    return p.resolve()


def read_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    return path.resolve()


def load_versions(file=None, pairs=(), outbox=None, auto=True):
    """versions.json (made by read_answers.py) plus optional 'path=N' overrides -> {path: int}.
    Without --versions, the newest <outbox>/versions.json is used when there is one (a stale number is
    harmless: ArtifactData then refuses the write and names the current version)."""
    out = {}
    if not file and auto and outbox is not None and (Path(outbox) / "versions.json").is_file():
        file = Path(outbox) / "versions.json"
        age = int((datetime.datetime.now().timestamp() - file.stat().st_mtime) // 60)
        print(f"Using document versions from {file} (made {age} min ago). --no-versions ignores it.")
    if file:
        try:
            raw = read_json(file)
        except (OSError, ValueError) as e:
            die(f"Could not read the versions file {file}: {e}")
        if isinstance(raw, dict) and isinstance(raw.get("versions"), dict):
            raw = raw["versions"]
        if not isinstance(raw, dict):
            die(f"The versions file {file} should be an object like {{\"status/q1\": 3}}.")
        for k, n in raw.items():
            if isinstance(n, int) and not isinstance(n, bool) and n >= 1:
                out[str(k)] = n
    for p in pairs or ():
        k, _, n = p.partition("=")
        if not k or not n.strip().isdigit() or int(n) < 1:
            die(f"--version needs the form path=NUMBER (for example meta/heartbeat=4), got: {p}")
        out[k.strip()] = int(n)
    return out


def jargon_hits(fields, allow=()):
    """fields = [(where, text)] -> [(where, word)] for every banned word found."""
    allowed = {a.strip().lower() for a in allow if a.strip()}
    hits = []
    for where, text in fields:
        if not isinstance(text, str):
            continue
        for m in JARGON_RE.finditer(text):
            if m.group(0).lower() not in allowed:
                hits.append((where, m.group(0)))
    return hits


def parse_allow(text):
    return [w for w in (text or "").replace(";", ",").split(",") if w.strip()]


def status_doc(qid, state, note="", done_note="", done_images=None, followup_id=None, now=None):
    now = now or now_iso()
    return {
        "id": qid,
        "state": state,
        "seenAt": now,
        "note": note or "",
        "doneNote": done_note or "",
        "doneImages": list(done_images or []),
        "followupId": followup_id or None,
        "at": now,
    }


def make_write(op, collection, doc_id, data, versions=None):
    w = {"op": op, "collection": collection, "doc_id": doc_id, "data": data}
    v = (versions or {}).get(f"{collection}/{doc_id}")
    if v:
        w["if_version"] = v
    return w


def chunk_writes(writes, max_n=50, max_bytes=800_000):
    """Split writes into batches of at most 50 entries (and well under the 1 MiB body limit)."""
    seen = set()
    for w in writes:
        k = (w["collection"], w["doc_id"])
        if k in seen:
            die(f"The same document is written twice: {k[0]}/{k[1]} (a batch may address a document only once).")
        seen.add(k)
    out, cur, size = [], [], 0
    for w in writes:
        n = len(json.dumps(w, ensure_ascii=False).encode("utf-8"))
        if cur and (len(cur) >= max_n or size + n > max_bytes):
            out.append(cur)
            cur, size = [], 0
        cur.append(w)
        size += n
    if cur:
        out.append(cur)
    return out


NOTE = ('Pass the "writes" list to ArtifactData: action "batch", url = the Question Terminal page. '
        "(This key, note, is not part of the call.)")


def write_batches(folder, writes, prefix="batch", with_files=True, clean=True, name_stamp=None):
    """Write <folder>/<prefix>-N.json (documents inline) and, when with_files, <prefix>-N.files.json
    (each entry points at a file in <folder>/docs/, so long documents need not be pasted).
    Returns [(inline_path, files_path_or_None, number_of_writes)]."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    if clean:
        for old in list(folder.glob(f"{prefix}-*.json")):
            old.unlink()
    docfile = {}
    if with_files:
        for w in writes:
            if w["op"] == "delete":
                continue
            fn = folder / "docs" / f"{w['collection'].replace('/', '-')}-{w['doc_id']}.json"
            write_json(fn, w["data"])
            docfile[(w["collection"], w["doc_id"])] = str(fn.resolve())
    out = []
    parts = chunk_writes(writes)
    base = prefix if not name_stamp else f"{prefix}-{name_stamp}"
    if name_stamp:  # never overwrite a file from the same second
        n = 1
        while (folder / f"{base}.json").exists() or (folder / f"{base}-1.json").exists():
            n += 1
            base = f"{prefix}-{name_stamp}-r{n}"
    for i, part in enumerate(parts, 1):
        label = f"{base}-{i}" if (len(parts) > 1 or not name_stamp) else base
        a = write_json(folder / f"{label}.json", {"writes": part, "note": NOTE})
        b = None
        if with_files:
            fparts = []
            for w in part:
                e = {k: v for k, v in w.items() if k != "data"}
                e["file_path"] = docfile[(w["collection"], w["doc_id"])]
                fparts.append(e)
            b = write_json(folder / f"{label}.files.json", {"writes": fparts, "note": NOTE})
        out.append((a, b, len(part)))
    return out


def _load_results(path):
    """RESULTS.json: {"status/q1": 3, ...} or {"versions": {...}} or [{"collection":..,"doc_id":..,"version":..}] -> {path: int}."""
    try:
        raw = read_json(path)
    except (OSError, ValueError) as e:
        die(f"Could not read the results file {path}: {e}")
    if isinstance(raw, dict) and isinstance(raw.get("versions"), dict):
        raw = raw["versions"]
    out = {}
    if isinstance(raw, list):
        for e in raw:
            if isinstance(e, dict) and e.get("collection") and e.get("doc_id") and isinstance(e.get("version"), int):
                out[f"{e['collection']}/{e['doc_id']}"] = e["version"]
    elif isinstance(raw, dict):
        for k, v in raw.items():
            if isinstance(v, int) and not isinstance(v, bool) and v >= 1:
                out[str(k)] = v
    if not out:
        die(f"The results file {path} holds no versions. Expected {{\"status/q1\": 3, ...}} (path -> version).")
    return out


def apply_batch(batch_file, results_file=None, outbox=None, again=False):
    """Call this AFTER ArtifactData has accepted a batch file: it moves <outbox>/versions.json on, so the next
    status or question write is pinned with the right if_version.  set/update: the version from RESULTS.json,
    else the known one + 1 (a new document: 1); delete: the entry goes.  The same batch file is refused a second time
    (it would count twice) unless again=True."""
    import hashlib
    try:
        raw = Path(batch_file).read_bytes()
        batch = json.loads(raw.decode("utf-8"))
    except (OSError, ValueError) as e:
        die(f"Could not read the batch file {batch_file}: {e}")
    writes = batch.get("writes") if isinstance(batch, dict) else None
    if not isinstance(writes, list) or not writes:
        die(f"{batch_file} has no \"writes\" list: give the batch-N.json or status-<time>.json file that was applied.")
    ob = outbox_dir(outbox)
    ledger_path, vpath = ob / "applied.json", ob / "versions.json"
    key = hashlib.sha1(raw).hexdigest()
    try:
        ledger = read_json(ledger_path) if ledger_path.is_file() else {}
    except ValueError:
        ledger = {}
    if key in ledger and not again:
        die(f"{batch_file} was already recorded on {ledger[key]}. Recording it twice would count its writes twice (use --again if you really changed the notebook again).", 1)
    results = _load_results(results_file) if results_file else {}
    versions = {}
    if vpath.is_file():
        try:
            old = read_json(vpath)
            versions = {k: v for k, v in (old.get("versions", old) if isinstance(old, dict) else {}).items() if isinstance(v, int)}
        except ValueError:
            versions = {}
    lines = []
    for w in writes:
        if not isinstance(w, dict) or "collection" not in w or "doc_id" not in w:
            die(f"{batch_file}: an entry has no collection/doc_id")
        path = f"{w['collection']}/{w['doc_id']}"
        if w.get("op") == "delete":
            versions.pop(path, None)
            lines.append(f"{path}: removed")
            continue
        if path in results:
            new = results[path]
        elif path in versions:
            new = versions[path] + 1
        elif isinstance(w.get("if_version"), int):
            new = w["if_version"] + 1
        else:
            new = 1
        versions[path] = new
        lines.append(f"{path} -> {new}")
    write_json(vpath, versions)
    ledger[key] = now_iso()
    write_json(ledger_path, ledger)
    return lines, vpath
