#!/usr/bin/env python3
"""merge_wave.py - put the patches of several helpers together on a FRESH copy of the website, one after the other, and report what happened.

Nothing in the real website folder is ever written: the real repo is only READ (git archive). Everything happens in a work folder; to undo, delete it
(`merge_wave.py --undo WORKDIR`, or just remove the folder).

  python3 T/tools/merge_wave.py --jobs small-fixes,label-variants,oldmac-photos,winter-hero --tests end
  python3 T/tools/merge_wave.py --jobs a,b,c --order c,a,b --dry-run
  python3 T/tools/merge_wave.py --list                      # what is in the outbox: patch files, summary, loose files, base commit
  python3 T/tools/merge_wave.py --undo T/outbox/_merge/20261007-210000

A JOB is a folder `T/outbox/<job>/` (or any folder or single patch file given as a path) with
  PATCH, PATCH*, *.patch, *.diff   text patches made with `git diff` against the base commit (several files are applied in name order)
  SUMMARY.md                       what the job changed, in words (used for the owner's change list; a section "In plain words" / "For the owner" is preferred)
  BASE.txt                         the commit the patch was made against (only compared and reported)
  files/                           loose files (photos, pictures) that a text patch cannot carry. Where they go:
                                     files/FILES.txt (or files.txt, LIST.txt, MANIFEST.txt, files.json): one line per file: `path/in/repo`, or `name.jpg => assets/photos/name.jpg`
                                       (a path alone means: the file is at files/<that path>, else files/<its file name>); .json may be a list of paths or {"from": "to"}
                                     without a list: every file under files/ goes to the same path inside the site (files/assets/photos/x.jpg -> assets/photos/x.jpg)
                                     files directly in files/ with no list have no known place: they are reported as skipped (or use --loose-dest JOB=assets/photos)
For each job, in order: `git apply --3way` in a throw-away git repo made from `git archive <rev>`; the loose files are copied; the generators run
(default: tools/pages.py, tools/i18n.py extract, tools/i18n.py build); the result is committed. A job that conflicts is rolled back (its conflict
files are saved in WORK/conflicts/<job>/) and the next job goes on, unless --stop-on-conflict (then the work tree is left AS IT IS, with the conflict markers).
If a patch conflicts only in files that the generators write (lang/*.js, built pages ...), the patch is applied again without those files and the
generators rebuild them (status "applied, generated files rebuilt"); --no-regen-fallback turns this off.

Output in WORK/out/: merged.patch (git diff --binary vs the base commit, checked with `git apply --check` on a second fresh copy), CHANGES.md (plain words for the owner),
report.json, report.txt, jobs/<job>.patch (what each job changed, generated files included).

Exit code: 0 everything applied (and no test failed), 1 something conflicted / was skipped / failed, 2 wrong options.
"""
import argparse
import datetime
import fnmatch
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
T = os.path.dirname(HERE)                       # .../terminal
DEFAULT_REPO = '/home/user/websites'
DEFAULT_OUTBOX = os.path.join(T, 'outbox')
MARKER = '.merge_wave_work'
DEFAULT_GEN = ['python3 tools/pages.py', 'python3 tools/i18n.py extract', 'python3 tools/i18n.py build']
DEFAULT_CHECKS = ['python3 tools/i18n.py missing es', 'python3 tools/i18n.py missing hi', 'python3 tools/i18n.py missing zh', 'python3 tools/i18n.py missing vi']
DEFAULT_TESTS = 'node tests/run-all.mjs --quick --retry'
DEFAULT_GENERATED = ['lang/es.js', 'lang/hi.js', 'lang/vi.js', 'lang/zh.js', 'lang/en.json', 'lang/js-strings.json', 'js/footer-art.js',
                     'first-visit.html', 'pumpkin-patch.html', 'strawberry-picking.html', 'school-field-trips.html', 'wise-pie.html', 'sitemap.xml', 'robots.txt']
MANIFESTS = ['FILES.txt', 'files.txt', 'LIST.txt', 'list.txt', 'MANIFEST.txt', 'manifest.txt', 'files.json', 'FILES.json', 'manifest.json']


class Stop(Exception):
    pass


def say(msg=''):
    print(msg, flush=True)


def run(cmd, cwd=None, env=None, timeout=600, check=False, input_text=None):
    """Runs a command (list, or a string split like a shell would). Returns (returncode, stdout, stderr). Never raises for a failing command."""
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout, input=input_text, errors='replace')
        rc, out, err = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        rc, out, err = 124, (e.stdout or '') if isinstance(e.stdout, str) else '', 'TIMEOUT after %s s' % timeout
    except FileNotFoundError as e:
        rc, out, err = 127, '', 'command not found: %s' % e
    if check and rc != 0:
        raise RuntimeError('command failed (%s): %s\n%s' % (rc, ' '.join(cmd), err.strip()[:600]))
    return rc, out, err


def git(site, *args, check=False, timeout=300):
    env = dict(os.environ, GIT_AUTHOR_NAME='merge-wave', GIT_AUTHOR_EMAIL='merge@wave.local', GIT_COMMITTER_NAME='merge-wave', GIT_COMMITTER_EMAIL='merge@wave.local',
               GIT_CONFIG_NOSYSTEM='1', GIT_TERMINAL_PROMPT='0')
    return run(['git', '-c', 'core.autocrlf=false', '-c', 'core.safecrlf=false', '-c', 'core.quotepath=false', '-C', site] + list(args), env=env, timeout=timeout, check=check)


def natural_key(s):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r'(\d+)', s)]


# ---------------------------------------------------------------------------------------------------- jobs
class Job:
    def __init__(self, name):
        self.name = name
        self.dir = None
        self.patches = []
        self.summary = None
        self.base = None
        self.files_dir = None
        self.loose = []           # [(source path, destination inside the site)]
        self.loose_unplaced = []  # files with no known destination
        self.problems = []
        self.touched = []

    def describe(self):
        return '%s: %d patch file(s), %d loose file(s)%s%s' % (self.name, len(self.patches), len(self.loose), ' (+%d without a place)' % len(self.loose_unplaced) if self.loose_unplaced else '',
                                                                  ', summary' if self.summary else ', NO summary')


def read_text(path):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()
    except OSError:
        return ''


def patch_files_in(folder):
    out = []
    try:
        names = os.listdir(folder)
    except OSError:
        return out
    for n in names:
        p = os.path.join(folder, n)
        if not os.path.isfile(p):
            continue
        low = n.lower()
        if low.startswith('patch') or low.endswith('.patch') or low.endswith('.diff'):
            out.append(p)
    return sorted(out, key=lambda p: natural_key(os.path.basename(p)))


def parse_manifest(path, files_dir):
    """Returns [(source, dest)], [problems]."""
    pairs, problems = [], []
    text = read_text(path)
    entries = []
    if path.lower().endswith('.json'):
        try:
            data = json.loads(text)
        except ValueError as e:
            return [], ['%s is not valid JSON: %s' % (os.path.basename(path), e)]
        if isinstance(data, dict):
            data = data.get('files', data)
        if isinstance(data, dict):
            entries = [(k, v) for k, v in data.items()]
        elif isinstance(data, list):
            for it in data:
                if isinstance(it, str):
                    entries.append((None, it))
                elif isinstance(it, dict):
                    entries.append((it.get('from') or it.get('src') or it.get('file'), it.get('to') or it.get('dest') or it.get('path')))
    else:
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            m = re.split(r'\s*(?:=>|->|\t)\s*', line, maxsplit=1)
            entries.append((m[0], m[1]) if len(m) == 2 else (None, m[0]))
    for src, dest in entries:
        dest = (dest or src or '').strip().lstrip('/')
        if not dest:
            continue
        cands = []
        if src:
            cands += [os.path.join(files_dir, src), os.path.join(files_dir, os.path.basename(src))]
        cands += [os.path.join(files_dir, dest), os.path.join(files_dir, os.path.basename(dest))]
        found = next((c for c in cands if os.path.isfile(c)), None)
        if not found:
            problems.append('listed but not found in files/: %s' % (src or dest))
            continue
        pairs.append((found, dest.replace('\\', '/')))
    return pairs, problems


def load_job(name, outbox, loose_dest):
    j = Job(name)
    cand = name if os.path.exists(name) else os.path.join(outbox, name)
    if os.path.isfile(cand):                              # a single patch file
        j.name = re.sub(r'\.(patch|diff)$', '', os.path.basename(cand))
        j.dir = os.path.dirname(os.path.abspath(cand))
        j.patches = [os.path.abspath(cand)]
        sib = os.path.splitext(os.path.abspath(cand))[0] + '.md'
        if os.path.isfile(sib):
            j.summary = sib
        return j
    if not os.path.isdir(cand):
        j.problems.append('no folder or patch file "%s" (looked in %s)' % (name, outbox))
        return j
    j.dir = os.path.abspath(cand)
    j.name = os.path.basename(j.dir.rstrip('/')) if os.path.exists(name) else name
    j.patches = [os.path.abspath(p) for p in patch_files_in(j.dir)]
    for n in os.listdir(j.dir):
        if n.lower() in ('summary.md', 'summary.txt', 'summary'):
            j.summary = os.path.join(j.dir, n)
        if n.lower() in ('base.txt', 'base'):
            j.base = read_text(os.path.join(j.dir, n)).strip().split()[0] if read_text(os.path.join(j.dir, n)).strip() else None
    fd = os.path.join(j.dir, 'files')
    if os.path.isdir(fd):
        j.files_dir = fd
        manifest = next((os.path.join(fd, m) for m in MANIFESTS if os.path.isfile(os.path.join(fd, m))), None)
        allfiles = []
        for root, _dirs, fs_ in os.walk(fd):
            for f in fs_:
                allfiles.append(os.path.join(root, f))
        if manifest:
            j.loose, probs = parse_manifest(manifest, fd)
            j.problems += probs
            listed = set(os.path.abspath(s) for s, _ in j.loose)
            j.loose_unplaced = [f for f in allfiles if os.path.abspath(f) not in listed and os.path.abspath(f) != os.path.abspath(manifest)]
        else:
            for f in allfiles:
                rel = os.path.relpath(f, fd).replace(os.sep, '/')
                if '/' in rel:
                    j.loose.append((f, rel))
                elif loose_dest.get(j.name) or loose_dest.get('*'):
                    j.loose.append((f, (loose_dest.get(j.name) or loose_dest.get('*')).strip('/') + '/' + rel))
                else:
                    j.loose_unplaced.append(f)
    if not j.patches and not j.loose and not j.loose_unplaced:
        j.problems.append('nothing to apply: no PATCH / *.patch / *.diff and no loose files')
    return j


def touched_by(patch_path):
    text = read_text(patch_path)
    files = []
    for m in re.finditer(r'^diff --git a/(.+?) b/(.+)$', text, re.M):
        files.append(m.group(2))
    if not files:
        for m in re.finditer(r'^\+\+\+ (?:b/)?(\S+)', text, re.M):
            if m.group(1) != '/dev/null':
                files.append(m.group(1))
    return sorted(set(files))


# ---------------------------------------------------------------------------------------------------- the work copy
def make_site(repo, rev, work):
    """git archive REV of the real repo into WORK/site, then a throw-away git repo around it. Returns (site, full commit id)."""
    rc, out, err = git(repo, 'rev-parse', '--verify', rev + '^{commit}')
    if rc != 0:
        raise Stop('the repo %s has no commit "%s": %s' % (repo, rev, err.strip()))
    commit = out.strip()
    site = os.path.join(work, 'site')
    os.makedirs(site)
    p1 = subprocess.Popen(['git', '-C', repo, 'archive', '--format=tar', commit], stdout=subprocess.PIPE)
    p2 = subprocess.run(['tar', '-x', '-C', site], stdin=p1.stdout, capture_output=True)
    p1.stdout.close()
    p1.wait()
    if p1.returncode != 0 or p2.returncode != 0:
        raise Stop('git archive failed: %s' % p2.stderr.decode('utf-8', 'replace')[:300])
    git(site, 'init', '-q', check=True)
    git(site, 'add', '-A', check=True)
    git(site, 'commit', '-q', '-m', 'base %s' % commit[:7], check=True)
    git(site, 'tag', 'wave-base', check=True)
    return site, commit


def reset_clean(site):
    git(site, 'reset', '-q', '--hard', 'HEAD')
    git(site, 'clean', '-fdq')


def commit_all(site, message):
    git(site, 'add', '-A')
    rc, out, _ = git(site, 'status', '--porcelain')
    if not out.strip():
        return False
    git(site, 'commit', '-q', '-m', message, check=True)
    return True


FAIL_RE = [re.compile(r'^error: patch failed: (.+?):(\d+)'), re.compile(r'^error: (.+?): patch does not apply'), re.compile(r'^error: (.+?): does not (?:exist in index|match index)'),
           re.compile(r'^error: (.+?): No such file'), re.compile(r'^error: (.+?): already exists in'),
           re.compile(r"^error: cannot apply binary patch to '(.+?)' without full index line")]


def conflict_blocks(path):
    """Line ranges of the conflict markers in a text file: [(first line, last line)]."""
    blocks, start = [], None
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            for i, line in enumerate(f, 1):
                if line.startswith('<<<<<<< '):
                    start = i
                elif line.startswith('>>>>>>> ') and start:
                    blocks.append((start, i))
                    start = None
    except OSError:
        pass
    return blocks


def git_apply(site, patch, excludes=(), strip=1):
    cmd = ['apply', '--3way', '--whitespace=nowarn', '-p%d' % strip] + ['--exclude=' + e for e in excludes] + [patch]
    rc, out, err = git(site, *cmd)
    text = (out or '') + (err or '')
    res = {'rc': rc, 'log': text.strip(), 'failed': [], 'conflicts': [], 'files_with_markers': []}
    for line in text.splitlines():
        for rx in FAIL_RE:
            m = rx.match(line)
            if m:
                res['failed'].append({'file': m.group(1), 'line': int(m.group(2)) if m.lastindex and m.lastindex >= 2 else None, 'why': line[7:]})
                break
    rc2, uu, _ = git(site, 'diff', '--name-only', '--diff-filter=U')
    unmerged = [x for x in uu.splitlines() if x]
    for m in re.finditer(r"Applied patch to '(.+?)' with conflicts", text):
        if m.group(1) not in unmerged:
            unmerged.append(m.group(1))
    for f in unmerged:
        blocks = conflict_blocks(os.path.join(site, f))
        res['conflicts'].append({'file': f, 'hunks': ['lines %d-%d' % b for b in blocks] or ['(binary or deleted)']})
    return res


def matches_any(path, patterns):
    return any(fnmatch.fnmatch(path, p) for p in patterns)


def hash_file(site, path):
    rc, out, _ = git(site, 'hash-object', path)
    return out.strip() if rc == 0 else None


def copy_loose(site, job):
    """Copies the job's loose files. Returns (copied list, problems list)."""
    copied, problems = [], []
    for src, dest in job.loose:
        if dest.startswith('..') or os.path.isabs(dest):
            problems.append('%s: destination "%s" is outside the site' % (os.path.basename(src), dest))
            continue
        target = os.path.join(site, dest)
        new_hash = hash_file(site, src)
        if os.path.exists(target):
            cur = hash_file(site, target)
            if cur == new_hash:
                copied.append((dest, 'already the same'))
                continue
            rc, base_blob, _ = git(site, 'rev-parse', 'wave-base:' + dest)
            if rc == 0 and base_blob.strip() != cur:
                problems.append('%s: an earlier job already changed this file, so it was not overwritten' % dest)
                continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        shutil.copyfile(src, target)
        copied.append((dest, 'copied'))
    return copied, problems


def run_steps(site, cmds, label, timeout, env):
    """Runs commands; returns list of {cmd, rc, tail}."""
    res = []
    for c in cmds:
        rc, out, err = run(c, cwd=site, env=env, timeout=timeout)
        txt = (out + '\n' + err).strip()
        res.append({'cmd': c, 'rc': rc, 'tail': '\n'.join(txt.splitlines()[-6:])})
    return res


def parse_tests(out):
    """Failures from `node tests/run-all.mjs` output: {name: [detail lines]}."""
    fails, cur = {}, None
    for line in out.splitlines():
        m = re.match(r'^FAIL\s+(\S+)', line)
        if m:
            cur = m.group(1)
            fails.setdefault(cur, [])
            continue
        if cur and line.startswith('      ') and len(fails[cur]) < 4:
            fails[cur].append(line.strip()[:200])
        elif cur and not line.startswith('      '):
            cur = None
    for m in re.finditer(r'^Failed: (.+)$', out, re.M):
        for n in [x.strip() for x in m.group(1).split(',')]:
            fails.setdefault(n, [])
    return fails


def run_tests(site, cmd, timeout, env):
    rc, out, err = run(cmd, cwd=site, env=env, timeout=timeout)
    text = out + '\n' + err
    fails = parse_tests(text)
    summary = next((l for l in reversed(text.splitlines()) if re.search(r'test files:', l)), '')
    return {'rc': rc, 'fails': fails, 'summary': summary.strip(), 'tail': '\n'.join(text.strip().splitlines()[-4:]), 'ran': rc != 127}


# ---------------------------------------------------------------------------------------------------- the summary text for the owner
def plain_summary(path, limit=18):
    """(title, lines) for the owner's list: a "plain words" paragraph or section when the file has one, else the first paragraph(s)."""
    text = read_text(path) if path else ''
    if not text.strip():
        return None, []
    lines = text.splitlines()
    title = next((re.sub(r'^#+\s*', '', l).strip() for l in lines if l.startswith('#')), None)
    head = re.compile(r'^#+\s*(in plain words|plain words|for the owner|what changed|what changes|changes for the owner|summary)\b', re.I)
    inline = re.compile(r'^[\W_]*(?:in )?plain words[\s*_]*(?:\([^)]*\))?[\s*_:.\-]*(.*)$', re.I)
    block = None
    for i, l in enumerate(lines):
        m = inline.match(l)
        if head.match(l):
            block = []
            for l2 in lines[i + 1:]:
                if l2.startswith('#'):
                    break
                block.append(l2)
            break
        if m and not l.startswith('#'):
            first = m.group(1).strip()
            block = [first[:1].upper() + first[1:]] if first else []
            for l2 in lines[i + 1:]:
                if not l2.strip() or l2.startswith('#'):
                    break
                block.append(l2)
            break
    if block is None:   # no plain-words part: the first two paragraphs after the title
        body, paras = [l for l in lines if not l.startswith('# ')], []
        cur = []
        for l in body + ['']:
            if l.strip() and not l.startswith('#'):
                cur.append(l)
            elif cur:
                paras.append(cur)
                cur = []
                if len(paras) == 2:
                    break
        block = [x for pr in paras for x in pr + ['']]
    block = [l.rstrip() for l in block]
    while block and not block[0].strip():
        block.pop(0)
    out, blank = [], 0
    for l in block:
        if not l.strip():
            blank += 1
            if blank > 1:
                continue
        else:
            blank = 0
        out.append(l)
        if len(out) >= limit:
            out.append("(more in the job's SUMMARY.md)")
            break
    return title, out


def write_changes(path, results, commit, order_note):
    L = ['# What changed on the website', '', 'Made on %s from the website as it was at commit `%s`. %s' % (datetime.date.today().isoformat(), commit[:7], order_note), '']
    ok_jobs = [r for r in results if r['status'].startswith('applied')]
    bad = [r for r in results if not r['status'].startswith('applied')]
    for i, r in enumerate(ok_jobs, 1):
        title, body = plain_summary(r.get('summary'))
        L.append('## %d. %s' % (i, title or r['name']))
        L.append('')
        L.append('*(job `%s`: %s%s)*' % (r['name'], r['status'], ', %d file(s) changed' % r['files_changed'] if r.get('files_changed') is not None else ''))
        for w in r.get('warnings', []):
            L.append('')
            L.append('> **Needs a look:** %s' % w)
        L.append('')
        L += body or ['(this job has no description of its own; see the technical list below)']
        L.append('')
    if bad:
        L += ['## Not in this merge', '']
        for r in bad:
            L.append('- **%s**: %s' % (r['name'], r['status']) + (' (%s)' % '; '.join(r['notes'][:2]) if r.get('notes') else ''))
        L.append('')
    L += ['## Technical list (for Claude)', '', '| job | result | files | lines added/removed |', '|---|---|---|---|']
    for r in results:
        L.append('| %s | %s | %s | %s |' % (r['name'], r['status'], r.get('files_changed', ''), '%s / %s' % (r.get('added', ''), r.get('removed', '')) if r.get('added') is not None else ''))
    L.append('')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(L))


# ---------------------------------------------------------------------------------------------------- main
def parse_args(argv):
    ap = argparse.ArgumentParser(description='Merge the patches of several jobs onto a fresh copy of the website (the real repo is only read).', formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog='See T/notes/MERGE.md')
    ap.add_argument('--jobs', help='comma separated job names (folders in the outbox) or paths of folders / patch files; applied in this order')
    ap.add_argument('--order', help='comma separated: the order to apply in (jobs not named here follow in --jobs order)')
    ap.add_argument('--outbox', default=DEFAULT_OUTBOX, help='where the job folders are (default: T/outbox)')
    ap.add_argument('--repo', default=DEFAULT_REPO, help='the real website repo (only read; default %s)' % DEFAULT_REPO)
    ap.add_argument('--rev', default='HEAD', help='the commit to start from (default HEAD)')
    ap.add_argument('--work', '--repo-base', dest='work', help='the work folder to make (default T/outbox/_merge/<time>); it must not exist unless --force')
    ap.add_argument('--force', action='store_true', help='replace the work folder if it exists (only if it was made by this tool)')
    ap.add_argument('--dry-run', action='store_true', help='apply the patches in a temporary folder only (no generators, no tests, no output files), show what would happen, delete it')
    ap.add_argument('--stop-on-conflict', action='store_true', help='stop at the first job that conflicts and leave its conflict markers in the work folder')
    ap.add_argument('--strip', type=int, default=1, help='path prefix to strip from patch file names (git apply -p, default 1)')
    ap.add_argument('--gen', action='append', metavar='CMD', help='a generator command run in the site folder (repeatable; replaces the default list: %s)' % '; '.join(DEFAULT_GEN))
    ap.add_argument('--no-gen', action='store_true', help='do not run the generators')
    ap.add_argument('--gen-when', choices=['each', 'end'], default='each', help='run the generators after every job (default) or once at the end')
    ap.add_argument('--no-check', action='store_true', help='skip the "is any translation missing" check after the generators (%s)' % '; '.join(DEFAULT_CHECKS))
    ap.add_argument('--generated', default=','.join(DEFAULT_GENERATED), help='files the generators write (comma separated globs); a conflict only in these is solved by rebuilding them')
    ap.add_argument('--no-regen-fallback', action='store_true', help='do not retry a conflicting patch without the generated files')
    ap.add_argument('--tests', choices=['none', 'each', 'end'], default='none', help='run the fast tests after every job, once at the end, or never (default none)')
    ap.add_argument('--test-cmd', default=DEFAULT_TESTS, help='the test command, run in the site folder (default: %s)' % DEFAULT_TESTS)
    ap.add_argument('--tests-baseline', action='store_true', help='run the tests once on the untouched copy first, so only NEW failures are blamed on the jobs')
    ap.add_argument('--gen-timeout', type=int, default=300)
    ap.add_argument('--test-timeout', type=int, default=3000)
    ap.add_argument('--loose-dest', action='append', default=[], metavar='JOB=DIR', help='where loose files that sit directly in a job\'s files/ go when there is no list (JOB may be *)')
    ap.add_argument('--no-verify', action='store_true', help='do not check merged.patch with git apply --check on a second fresh copy')
    ap.add_argument('--list', action='store_true', help='show the jobs found in the outbox and stop')
    ap.add_argument('--undo', metavar='WORKDIR', help='delete a work folder made by this tool (nothing else is touched)')
    return ap.parse_args(argv)


def list_jobs(outbox):
    if not os.path.isdir(outbox):
        say('no outbox folder %s' % outbox)
        return
    for n in sorted(os.listdir(outbox), key=natural_key):
        if n.startswith('_') or not os.path.isdir(os.path.join(outbox, n)):
            continue
        j = load_job(n, outbox, {})
        if not j.patches and not j.loose and not j.loose_unplaced:
            say('  %-22s (no patch yet)' % n)
            continue
        say('  %-22s %d patch file(s)  %d loose file(s)  base %s  %s' % (n, len(j.patches), len(j.loose) + len(j.loose_unplaced), (j.base or '?')[:7], 'summary' if j.summary else 'NO SUMMARY'))
        for p in j.patches:
            say('      %s  (%s files)' % (os.path.basename(p), len(touched_by(p))))


def main(argv=None):
    a = parse_args(argv)
    if a.undo:
        d = os.path.abspath(a.undo)
        if not os.path.isfile(os.path.join(d, MARKER)):
            say('Refused: %s was not made by merge_wave.py (no %s file inside).' % (d, MARKER))
            return 2
        shutil.rmtree(d)
        say('Deleted %s. The real website folder was never touched.' % d)
        return 0
    if a.list:
        list_jobs(a.outbox)
        return 0
    if not a.jobs and not a.order:
        say('Say which jobs to merge: --jobs a,b,c  (or --list to see what is in the outbox).')
        return 2
    names = [x.strip() for x in (a.jobs or '').split(',') if x.strip()]
    if a.order:
        order = [x.strip() for x in a.order.split(',') if x.strip()]
        names = order + [n for n in names if n not in order]
    seen = set()
    names = [n for n in names if not (n in seen or seen.add(n))]
    loose_dest = {}
    for item in a.loose_dest:
        if '=' not in item:
            say('--loose-dest wants JOB=DIR, got "%s"' % item)
            return 2
        k, v = item.split('=', 1)
        loose_dest[k] = v
    repo = os.path.abspath(a.repo)
    if not os.path.isdir(os.path.join(repo, '.git')) and not os.path.isfile(os.path.join(repo, '.git')):
        say('%s is not a git repo.' % repo)
        return 2

    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    if a.dry_run:
        work = tempfile.mkdtemp(prefix='merge_wave_dry_')
    else:
        work = os.path.abspath(a.work or os.path.join(DEFAULT_OUTBOX, '_merge', stamp))
        if os.path.exists(work):
            if a.force and os.path.isfile(os.path.join(work, MARKER)):
                shutil.rmtree(work)
            elif os.listdir(work):
                say('The work folder %s exists. Use another name, or --force (only for a folder this tool made), or --undo %s first.' % (work, work))
                return 2
        os.makedirs(work, exist_ok=True)
    real_work = os.path.realpath(work)
    if real_work == os.path.realpath(repo) or real_work.startswith(os.path.realpath(repo) + os.sep):
        say('The work folder must not be inside the real website folder.')
        return 2
    with open(os.path.join(work, MARKER), 'w') as f:
        f.write('made by merge_wave.py on %s\n' % stamp)

    env = dict(os.environ)
    env.pop('WA_URL', None)
    if not env.get('NODE_PATH') and os.path.isdir('/opt/node22/lib/node_modules'):
        env['NODE_PATH'] = '/opt/node22/lib/node_modules'
    gen_cmds = [] if a.no_gen or a.dry_run else (a.gen if a.gen else DEFAULT_GEN)
    generated = [g.strip() for g in a.generated.split(',') if g.strip()]
    results, exit_code, stopped = [], 0, False
    try:
        site, commit = make_site(repo, a.rev, work)
        say('Work folder: %s%s' % (work, '  (dry run: it is deleted at the end)' if a.dry_run else ''))
        say('Start: %s %s' % (a.rev, commit[:7]))
        jobs = [load_job(n, a.outbox, loose_dest) for n in names]
        # which files do several jobs touch?
        owners = {}
        for j in jobs:
            for p in j.patches:
                for f in touched_by(p):
                    owners.setdefault(f, []).append(j.name)
            j.touched = sorted(f for f, who in owners.items() if j.name in who)
        shared = {f: sorted(set(w)) for f, w in owners.items() if len(set(w)) > 1}
        if shared:
            say('Files touched by more than one job (where conflicts can come from):')
            for f, w in sorted(shared.items()):
                say('   %-44s %s%s' % (f, ', '.join(w), '   (generated file: rebuilt)' if matches_any(f, generated) else ''))
        base_fails = {}
        test_env = env
        if a.tests != 'none' and a.tests_baseline and not a.dry_run:
            say('\nTests on the untouched copy (so old failures are not blamed on the jobs) ...')
            tr = run_tests(site, a.test_cmd, a.test_timeout, test_env)
            base_fails = tr['fails']
            say('   %s' % (tr['summary'] or tr['tail'].replace('\n', ' | ')))
            if base_fails:
                say('   already failing before any job: %s' % ', '.join(sorted(base_fails)))
        for idx, job in enumerate(jobs, 1):
            r = {'name': job.name, 'summary': job.summary, 'status': '', 'notes': [], 'conflicts': [], 'failed': [], 'generators': [], 'checks': [], 'tests': None, 'files_changed': None, 'warnings': [],
                 'patch_files': [os.path.basename(p) for p in job.patches], 'loose': [], 'base': job.base}
            say('\n[%d/%d] %s' % (idx, len(jobs), job.describe()))
            if not job.patches and not job.loose:
                r['status'] = 'skipped'
                r['notes'] = list(job.problems)
                if job.loose_unplaced:
                    r['notes'] = ['%d loose file(s) in files/ have no place: add files/FILES.txt with lines "name => path/in/site", or use --loose-dest JOB=dir' % len(job.loose_unplaced)]
                say('   SKIPPED: %s' % '; '.join(r['notes']))
                results.append(r)
                exit_code = 1
                continue
            if job.base and not commit.startswith(job.base[:7]):
                r['notes'].append('made against %s, merged onto %s' % (job.base[:7], commit[:7]))
                say('   note: made against %s, merging onto %s (the 3-way merge copes with small differences)' % (job.base[:7], commit[:7]))
            head_before = git(site, 'rev-parse', 'HEAD')[1].strip()
            failed_apply = False
            regen = False
            for p in job.patches:
                res = git_apply(site, p, strip=a.strip)
                if res['rc'] != 0:
                    bad_files = [c['file'] for c in res['conflicts']] + [f['file'] for f in res['failed']]
                    if (not a.no_regen_fallback) and bad_files and all(matches_any(f, generated) for f in bad_files):
                        reset_clean(site)
                        res2 = git_apply(site, p, excludes=generated, strip=a.strip)
                        if res2['rc'] == 0:
                            regen = True
                            r['notes'].append('%s: conflicts only in generated files (%s): applied without them, the generators rebuild them' % (os.path.basename(p), ', '.join(sorted(set(bad_files)))))
                            say('   %s: conflicts only in generated files -> applied without them' % os.path.basename(p))
                            continue
                        res = res2
                    failed_apply = True
                    r['conflicts'] += [dict(c, patch=os.path.basename(p)) for c in res['conflicts']]
                    r['failed'] += [dict(f, patch=os.path.basename(p)) for f in res['failed']]
                    r['notes'].append('%s did not apply' % os.path.basename(p))
                    say('   CONFLICT in %s' % os.path.basename(p))
                    for c in res['conflicts']:
                        say('      %s: %s' % (c['file'], ', '.join(c['hunks'])))
                    for f in res['failed']:
                        say('      %s%s: %s' % (f['file'], ':%s' % f['line'] if f['line'] else '', f['why']))
                    if not res['conflicts'] and not res['failed']:
                        say('      ' + res['log'][:400].replace('\n', '\n      '))
                    break
            if failed_apply:
                keep = os.path.join(work, 'conflicts', re.sub(r'[^A-Za-z0-9_.-]', '_', job.name))
                os.makedirs(keep, exist_ok=True)
                for c in r['conflicts']:
                    src = os.path.join(site, c['file'])
                    if os.path.isfile(src):
                        dst = os.path.join(keep, c['file'])
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        shutil.copyfile(src, dst)
                with open(os.path.join(keep, 'conflicts.json'), 'w') as f:
                    json.dump({'conflicts': r['conflicts'], 'failed': r['failed']}, f, indent=1)
                if a.stop_on_conflict:
                    r['status'] = 'conflict (stopped here)'
                    results.append(r)
                    exit_code = 1
                    stopped = True
                    if not a.dry_run:
                        os.makedirs(os.path.join(work, 'out'), exist_ok=True)
                        with open(os.path.join(work, 'out', 'report.json'), 'w') as f:
                            json.dump({'base': commit, 'work': work, 'jobs': results, 'stopped': True}, f, indent=1, default=str)
                    say('\nSTOPPED (--stop-on-conflict). The work folder is left as it is: %s/site (conflict markers in the files above).' % work)
                    say('Resolve there, or run again without --stop-on-conflict to roll back and carry on.')
                    break
                reset_clean(site)
                r['status'] = 'conflict (rolled back)'
                say('   rolled back' + ('' if a.dry_run else '; conflict files saved in %s' % keep))
                results.append(r)
                exit_code = 1
                continue
            copied, lp = copy_loose(site, job) if job.loose else ([], [])
            r['loose'] = copied
            if job.loose:
                say('   loose files: %d copied/checked%s' % (len(copied), ('; PROBLEMS: ' + '; '.join(lp)) if lp else ''))
            if lp:
                r['notes'] += lp
                reset_clean(site)
                r['status'] = 'conflict (loose files, rolled back)'
                results.append(r)
                exit_code = 1
                continue
            if job.loose_unplaced:
                r['warnings'].append('%d loose file(s) have no known place and were NOT copied: %s (add files/FILES.txt with lines "name => path/in/site", or use --loose-dest)' % (len(job.loose_unplaced), ', '.join(os.path.basename(x) for x in job.loose_unplaced[:5])))
                say('   WARNING: %s' % r['warnings'][-1])
            commit_all(site, 'job %s' % job.name)
            do_gen = bool(gen_cmds) and (a.gen_when == 'each' or regen)
            if do_gen:
                say('   generators ...')
                r['generators'] = run_steps(site, gen_cmds, 'gen', a.gen_timeout, env)
                badg = [g for g in r['generators'] if g['rc'] != 0]
                for g in r['generators']:
                    say('      %s %s' % ('ok  ' if g['rc'] == 0 else 'FAIL', g['cmd']) + ('' if g['rc'] == 0 else '  -> ' + g['tail'].replace('\n', ' | ')[:240]))
                if badg:
                    r['warnings'].append('generator failed: %s' % badg[0]['cmd'])
                    exit_code = 1
                if not a.no_check and not badg:
                    for c in DEFAULT_CHECKS:
                        rc, out, err = run(c, cwd=site, env=env, timeout=a.gen_timeout)
                        line = (out + err).strip().splitlines()[-1] if (out + err).strip() else ''
                        r['checks'].append({'cmd': c, 'rc': rc, 'line': line})
                    missing = [(c['cmd'].split()[-1], c['line']) for c in r['checks'] if not re.search(r'\b0 missing\b', c['line'])]
                    if missing:
                        r['warnings'].append('translations still missing: ' + '; '.join('%s: %s' % m for m in missing))
                        say('      translations: ' + '; '.join('%s -> %s' % (m[0], m[1][:80]) for m in missing))
                    else:
                        say('      translations: 0 missing in es, hi, zh, vi')
                commit_all(site, 'job %s: generated files' % job.name)
            r['status'] = 'applied, generated files rebuilt' if regen else 'applied'
            rc, stat, _ = git(site, 'diff', '--numstat', head_before, 'HEAD')
            rows = [l.split('\t') for l in stat.splitlines() if l.strip()]
            r['files_changed'] = len(rows)
            r['added'] = sum(int(x[0]) for x in rows if x[0].isdigit())
            r['removed'] = sum(int(x[1]) for x in rows if x[1].isdigit())
            if not a.dry_run:
                os.makedirs(os.path.join(work, 'out', 'jobs'), exist_ok=True)
                with open(os.path.join(work, 'out', 'jobs', re.sub(r'[^A-Za-z0-9_.-]', '_', job.name) + '.patch'), 'w', encoding='utf-8', errors='surrogateescape') as f:
                    f.write(git(site, 'diff', '--binary', head_before, 'HEAD')[1])
            say('   %s: %d files, +%d -%d' % (r['status'].upper(), r['files_changed'], r['added'], r['removed']))
            if a.tests == 'each' and not a.dry_run:
                say('   tests ...')
                tr = run_tests(site, a.test_cmd, a.test_timeout, test_env)
                new = {k: v for k, v in tr['fails'].items() if k not in base_fails}
                r['tests'] = {'summary': tr['summary'], 'new_failures': new, 'old_failures': sorted(k for k in tr['fails'] if k in base_fails)}
                say('      ' + (tr['summary'] or tr['tail'].replace('\n', ' | ')))
                for k, v in new.items():
                    say('      FAIL %s' % k)
                    for d in v:
                        say('           %s' % d)
                if new:
                    exit_code = 1
                    r['warnings'].append('tests failing after this job: %s' % ', '.join(sorted(new)))
            results.append(r)

        if not stopped and not a.dry_run:
            if gen_cmds and a.gen_when == 'end':
                say('\nGenerators (once, at the end) ...')
                gr = run_steps(site, gen_cmds, 'gen', a.gen_timeout, env)
                for g in gr:
                    say('   %s %s' % ('ok  ' if g['rc'] == 0 else 'FAIL', g['cmd']) + ('' if g['rc'] == 0 else '  -> ' + g['tail'].replace('\n', ' | ')[:240]))
                if any(g['rc'] != 0 for g in gr):
                    exit_code = 1
                commit_all(site, 'generated files')
            if a.tests == 'end':
                say('\nTests on the merged result ...')
                tr = run_tests(site, a.test_cmd, a.test_timeout, test_env)
                new = {k: v for k, v in tr['fails'].items() if k not in base_fails}
                say('   ' + (tr['summary'] or tr['tail'].replace('\n', ' | ')))
                for k, v in new.items():
                    say('   FAIL %s' % k)
                    for d in v:
                        say('        %s' % d)
                if new:
                    exit_code = 1
                results.append({'name': '(tests on the merged result)', 'status': 'tests failed: ' + ', '.join(sorted(new)) if new else 'tests passed', 'notes': [], 'summary': None,
                                'tests': {'summary': tr['summary'], 'new_failures': new, 'old_failures': sorted(k for k in tr['fails'] if k in base_fails)}})
            # the combined patch
            out_dir = os.path.join(work, 'out')
            os.makedirs(out_dir, exist_ok=True)
            commit_all(site, 'rest')
            rc, merged, _ = git(site, 'diff', '--binary', 'wave-base', 'HEAD')
            with open(os.path.join(out_dir, 'merged.patch'), 'w', encoding='utf-8', errors='surrogateescape') as f:
                f.write(merged)
            rc, stat, _ = git(site, 'diff', '--stat', 'wave-base', 'HEAD')
            say('\nCombined patch: %s  (%d bytes)' % (os.path.join(out_dir, 'merged.patch'), len(merged.encode('utf-8', 'surrogateescape'))))
            say('\n'.join('   ' + l for l in stat.splitlines()[-1:]))
            if not a.no_verify and merged.strip():
                chk = tempfile.mkdtemp(prefix='merge_wave_verify_')
                try:
                    p1 = subprocess.Popen(['git', '-C', repo, 'archive', '--format=tar', commit], stdout=subprocess.PIPE)
                    subprocess.run(['tar', '-x', '-C', chk], stdin=p1.stdout, capture_output=True)
                    p1.stdout.close()
                    p1.wait()
                    rc, o, e = run(['git', 'apply', '--check', '--binary', os.path.join(out_dir, 'merged.patch')], cwd=chk)
                    ok = rc == 0
                    say('Check: merged.patch %s on a second fresh copy of %s.' % ('applies cleanly (git apply --check)' if ok else 'DOES NOT APPLY: ' + (o + e).strip()[:300], commit[:7]))
                    if not ok:
                        exit_code = 1
                finally:
                    shutil.rmtree(chk, ignore_errors=True)
            note = 'Jobs, in this order: %s.' % ', '.join(r['name'] for r in results if not r['name'].startswith('('))
            write_changes(os.path.join(out_dir, 'CHANGES.md'), [r for r in results if not r['name'].startswith('(')], commit, note)
            with open(os.path.join(out_dir, 'report.json'), 'w') as f:
                json.dump({'base': commit, 'work': work, 'jobs': results, 'shared_files': shared}, f, indent=1, default=str)
            with open(os.path.join(out_dir, 'report.txt'), 'w') as f:
                for r in results:
                    f.write('%-28s %s\n' % (r['name'], r['status']))
                    for n in r.get('notes', []):
                        f.write('      %s\n' % n)
                    for n in r.get('warnings', []):
                        f.write('      WARNING: %s\n' % n)
            say('Owner list: %s' % os.path.join(out_dir, 'CHANGES.md'))
    except Stop as e:
        say('Stopped: %s' % e)
        exit_code = 2
    finally:
        if a.dry_run:
            shutil.rmtree(work, ignore_errors=True)

    say('\n=== Result')
    for r in results:
        extra = r['notes'][:2] if not r['status'].startswith('applied') else []
        extra += ['WARNING: ' + w for w in r.get('warnings', [])]
        say('  %-26s %s%s' % (r['name'], r['status'], ('   [' + '; '.join(extra) + ']') if extra else ''))
    if a.dry_run:
        say('Dry run: nothing was kept. (Generators and tests are not run in a dry run.)')
    elif not stopped:
        say('Undo: delete %s   (or: python3 %s --undo %s)' % (work, os.path.relpath(__file__) if not os.path.isabs(__file__) else __file__, work))
    return exit_code


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say('\nInterrupted.')
        sys.exit(1)
