#!/usr/bin/env python3
"""Website regression kit: prove that a change touched only what it should (see T/notes/REGRESS.md).

  python3 site_regress.py snap --repo DIR --out OUT [--workers 2] [--port-base 9550] [--only REGEX] [--list]
      (--scale 0.5 = half-size pictures, 4x faster; --scale 1 = every pixel;  --motion reduce (default) = the page is told 'less movement', so scenes stay
       still and two runs give the same pixels; --motion no-preference = animated scenes, which cannot be compared pixel by pixel)
      photographs a standard set of pictures of the site in DIR (never changed by this tool):
        home page (index.html)   1366x768 and 700x800, light = whole page, dark = top 3 screens, on 4 days (2027-04-20 spring, 2027-06-25 summer, 2026-10-15 fall,
                                 2026-12-20 winter)                                                          16 pictures
        the other pages          first-visit, wise-pie, pumpkin-patch, strawberry-picking, school-field-trips, 404:
                                 1366x768 and 700x800, light and dark, on 2026-10-15                          24 pictures
        languages                home page ?lang=es hi zh vi, 1366x768 and 700x800, light, on 2026-10-15        8 pictures
      The pictures are made by tools/site_regress.mjs (fake clock, seeded random, animations stopped): the same files give the same pixels.
  python3 site_regress.py compare --before OUT1 --after OUT2 --report R.html [--tol 16] [--min-pixels 30]
      compares the two folders picture by picture (PIL), prints a table, writes R.html (+ R.html.files/ with heat-maps) and exits with 0
      when nothing changed, 1 when something did, 2 when a picture is missing on one side.

Needs: Python 3.8+, Pillow (PIL), node with Playwright (NODE_PATH=/opt/node22/lib/node_modules, set here when it is not set)."""
import argparse, concurrent.futures, html, json, os, re, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
MJS = os.path.join(HERE, 'site_regress.mjs')

SEASON_DAYS = [('spring', '2027-04-20'), ('summer', '2027-06-25'), ('fall', '2026-10-15'), ('winter', '2026-12-20')]
SIZES = [(1366, 768), (700, 800)]
SCHEMES = ['light', 'dark']
OTHER_PAGES = ['first-visit', 'wise-pie', 'pumpkin-patch', 'strawberry-picking', 'school-field-trips', '404']
LANGS = ['es', 'hi', 'zh', 'vi']
OTHER_DAY = '2026-10-15'


def build_groups():
    """A group = one page load (url, size, day); its shots are the pictures taken from that load: the whole page in the light scheme, then (where
    wanted) the top 3 screens in the dark scheme. The site is light-only on purpose; a reaction to the dark scheme shows at the top, and the whole page is slow."""
    groups = []

    def group(base, url, w, h, day, dark):
        shots = [{'id': '%s_%dx%d_light' % (base, w, h), 'scheme': 'light'}]
        if dark:
            shots.append({'id': '%s_%dx%d_dark' % (base, w, h), 'scheme': 'dark', 'top': 3})
        groups.append({'url': url, 'w': w, 'h': h, 'date': day, 'shots': shots})
    for season, day in SEASON_DAYS:
        for (w, h) in SIZES:
            group('home_' + season, 'index.html', w, h, day, True)
    for page in OTHER_PAGES:
        for (w, h) in SIZES:
            group('page-' + page, page + '.html', w, h, OTHER_DAY, True)
    for lang in LANGS:
        for (w, h) in SIZES:
            group('lang-' + lang, 'index.html?lang=' + lang, w, h, OTHER_DAY, False)
    return groups


def build_jobs():
    return [dict(sh, url=g['url'], w=g['w'], h=g['h'], date=g['date']) for g in build_groups() for sh in g['shots']]


def cmd_snap(a):
    repo = os.path.abspath(a.repo)
    if not os.path.isfile(os.path.join(repo, 'index.html')):
        print('%s has no index.html: is that the website folder?' % repo, file=sys.stderr); return 2
    groups = build_groups()
    if a.only:
        rx = re.compile(a.only)
        for g in groups:
            g['shots'] = [sh for sh in g['shots'] if rx.search(sh['id'])]
            if g['shots'] and g['shots'][0]['scheme'] != 'light':   # the light picture of a group is always taken first (the dark one is switched on afterwards)
                g['shots'][0]['_first_dark'] = True
        groups = [g for g in groups if g['shots']]
    jobs = [dict(sh, url=g['url'], w=g['w'], h=g['h'], date=g['date']) for g in groups for sh in g['shots']]
    if a.list:
        for j in jobs:
            print('%-52s %s  %dx%d %s %s' % (j['id'], j['url'], j['w'], j['h'], j['scheme'], j['date']))
        print(len(jobs), 'pictures'); return 0
    out = os.path.abspath(a.out)
    os.makedirs(out, exist_ok=True)
    if not a.only:   # a full run starts clean; --only adds to / replaces single pictures
        for f in os.listdir(out):
            if f.endswith('.png'):
                os.remove(os.path.join(out, f))
    # the groups are dealt out to the workers, longest first, so that both finish together (a page with a tall layout costs more than a short one)
    weight = lambda g: (3 if g['url'].startswith('index.html') else 1) * len(g['shots'])
    buckets = [[] for _ in range(a.workers)]
    loads = [0] * a.workers
    for g in sorted(groups, key=weight, reverse=True):
        k = loads.index(min(loads)); buckets[k].append(g); loads[k] += weight(g)
    job_files = []
    for k, bucket in enumerate(buckets):
        jf = os.path.join(out, '_jobs%d.json' % k)
        with open(jf, 'w') as f:
            json.dump(bucket, f, indent=1)
        job_files.append(jf)
    env = dict(os.environ)
    env.setdefault('NODE_PATH', '/opt/node22/lib/node_modules')
    env.setdefault('PLAYWRIGHT_BROWSERS_PATH', '/opt/pw-browsers')
    t0 = time.time()

    def run(i):
        p = subprocess.run(['node', MJS, '--repo', repo, '--jobs', job_files[i], '--out', out, '--port', str(a.port_base + i), '--scale', str(a.scale), '--motion', a.motion],
                           env=env, capture_output=True, text=True)
        return i, p.returncode, p.stdout, p.stderr
    bad = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as ex:
        for i, rc, so, se in ex.map(run, range(a.workers)):
            last = [l for l in so.strip().split('\n') if l.startswith('worker')]
            print(last[-1] if last else 'worker %d: no summary' % i)
            if rc:
                bad += 1
                print(se.strip()[-1500:], file=sys.stderr)
    missing = [j['id'] for j in jobs if not os.path.isfile(os.path.join(out, j['id'] + '.png'))]
    secs = time.time() - t0
    with open(os.path.join(out, 'manifest.json' if not a.only else 'manifest-only.json'), 'w') as f:
        json.dump({'repo': repo, 'seconds': round(secs, 1), 'workers': a.workers, 'jobs': jobs, 'missing': missing}, f, indent=1)
    print('%d of %d pictures in %s in %.0f s with %d workers' % (len(jobs) - len(missing), len(jobs), out, secs, a.workers))
    if missing:
        print('MISSING: ' + ', '.join(missing), file=sys.stderr); return 1
    return 1 if bad else 0


def load_pil():
    try:
        from PIL import Image, ImageChops, ImageEnhance, ImageFilter
    except ImportError:
        print('Pillow is needed for compare: python3 -m pip install pillow', file=sys.stderr); sys.exit(2)
    return Image, ImageChops, ImageEnhance, ImageFilter


def diff_pair(pa, pb, tol, heat_path, thumb_dir, name):
    """-> (changed_pixels, total_pixels, note). Writes the heat-map when something changed."""
    Image, ImageChops, ImageEnhance, ImageFilter = load_pil()
    A = Image.open(pa).convert('RGB')
    B = Image.open(pb).convert('RGB')
    note = ''
    W, H = max(A.width, B.width), max(A.height, B.height)
    if A.size != B.size:
        note = 'size %dx%d -> %dx%d' % (A.width, A.height, B.width, B.height)
        for nm in ('A', 'B'):
            im = A if nm == 'A' else B
            canvas = Image.new('RGB', (W, H), (255, 0, 255))   # magenta = no picture here on this side
            canvas.paste(im, (0, 0))
            if nm == 'A':
                A = canvas
            else:
                B = canvas
    d = ImageChops.difference(A, B)
    r, g, b = d.split()
    m = ImageChops.lighter(ImageChops.lighter(r, g), b)
    mask = m.point(lambda v: 255 if v > tol else 0)
    changed = mask.histogram()[255]
    if changed:
        # heat-map: the AFTER picture dimmed, the changed pixels red (grown by 2 px so single lines can be seen)
        base = ImageEnhance.Brightness(B).enhance(0.35)
        grown = mask.filter(ImageFilter.MaxFilter(5))
        red = Image.new('RGB', B.size, (255, 40, 40))
        heat = Image.composite(red, base, grown)
        heat.save(heat_path)
    return changed, W * H, note


def thumb(src, dst, width=360, max_h=900):
    Image, _, _, _ = load_pil()
    im = Image.open(src).convert('RGB')
    s = min(width / im.width, max_h / im.height, 1.0)
    im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS).save(dst, optimize=True)


def cmd_compare(a):
    before, after = os.path.abspath(a.before), os.path.abspath(a.after)
    names = lambda d: sorted(f[:-4] for f in os.listdir(d) if f.endswith('.png'))
    nb, na = names(before), names(after)
    only_b, only_a = sorted(set(nb) - set(na)), sorted(set(na) - set(nb))
    if a.common_only:
        only_b, only_a = [], []
    common = sorted(set(nb) & set(na))
    report = os.path.abspath(a.report)
    files_dir = report + '.files'
    os.makedirs(files_dir, exist_ok=True)
    rows = []
    t0 = time.time()
    for n in common:
        heat = os.path.join(files_dir, n + '.heat.png')
        ch, tot, note = diff_pair(os.path.join(before, n + '.png'), os.path.join(after, n + '.png'), a.tol, heat, files_dir, n)
        rows.append({'name': n, 'changed': ch, 'total': tot, 'pct': 100.0 * ch / tot if tot else 0.0, 'note': note, 'heat': os.path.exists(heat)})
    changed_rows = [r for r in rows if r['changed'] > a.min_pixels or r['note']]
    noise_rows = [r for r in rows if 0 < r['changed'] <= a.min_pixels and not r['note']]
    for r in rows:
        if r['changed'] and r not in changed_rows and os.path.exists(os.path.join(files_dir, r['name'] + '.heat.png')):
            os.remove(os.path.join(files_dir, r['name'] + '.heat.png')); r['heat'] = False
    for r in changed_rows:
        thumb(os.path.join(before, r['name'] + '.png'), os.path.join(files_dir, r['name'] + '.before.png'))
        thumb(os.path.join(after, r['name'] + '.png'), os.path.join(files_dir, r['name'] + '.after.png'))
        if r['heat']:
            thumb(os.path.join(files_dir, r['name'] + '.heat.png'), os.path.join(files_dir, r['name'] + '.heat.t.png'))
    e = html.escape
    out = ['<!doctype html><meta charset="utf-8"><title>Website regression report</title>',
           '<style>body{font:15px/1.4 system-ui,sans-serif;margin:20px;color:#222}h1{font-size:22px}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 8px;text-align:left}'
           '.ok{color:#176b2c}.bad{color:#b3202e;font-weight:700}.grid{display:flex;gap:10px;align-items:flex-start;margin:6px 0 24px}.grid figure{margin:0}.grid img{display:block;border:1px solid #999;max-width:360px}'
           '.grid figcaption{font-size:12px;color:#555}</style>',
           '<h1>Website regression report</h1>',
           '<p>before: %s<br>after: %s<br>tolerance: a pixel counts when a colour channel differs by more than %d (of 255); a picture counts as changed with more than %d such pixels.</p>' % (e(before), e(after), a.tol, a.min_pixels)]
    verdict = 'NOTHING CHANGED' if not changed_rows and not only_b and not only_a else '%d PICTURE(S) CHANGED' % len(changed_rows)
    out.append('<h2 class="%s">%s</h2><p>%d pictures compared, %d with tiny differences (noise, %d pixels or fewer)%s%s.</p>' % (
        'ok' if verdict == 'NOTHING CHANGED' else 'bad', verdict, len(rows), len(noise_rows), a.min_pixels,
        ('; only in before: ' + e(', '.join(only_b))) if only_b else '', ('; only in after: ' + e(', '.join(only_a))) if only_a else ''))
    out.append('<table><tr><th>picture</th><th>changed pixels</th><th>% of the picture</th><th>note</th></tr>')
    for r in sorted(rows, key=lambda x: -x['changed']):
        cls = 'bad' if r in changed_rows else ('' if not r['changed'] else 'ok')
        out.append('<tr><td>%s</td><td class="%s">%d</td><td>%.4f%%</td><td>%s</td></tr>' % (e(r['name']), cls, r['changed'], r['pct'], e(r['note'])))
    out.append('</table>')
    for r in sorted(changed_rows, key=lambda x: -x['changed']):
        n = r['name']
        out.append('<h3>%s &mdash; %.3f%% changed (%d pixels)%s</h3><div class="grid">' % (e(n), r['pct'], r['changed'], (' &mdash; ' + e(r['note'])) if r['note'] else ''))
        out.append('<figure><img src="%s.files/%s.before.png"><figcaption>before</figcaption></figure>' % (e(os.path.basename(report)), e(n)))
        out.append('<figure><img src="%s.files/%s.after.png"><figcaption>after</figcaption></figure>' % (e(os.path.basename(report)), e(n)))
        if r['heat']:
            out.append('<figure><img src="%s.files/%s.heat.t.png"><figcaption>what changed (red)</figcaption></figure>' % (e(os.path.basename(report)), e(n)))
        out.append('</div>')
    with open(report, 'w') as f:
        f.write('\n'.join(out))
    print('%-52s %12s %10s' % ('picture', 'changed px', '%'))
    for r in sorted(rows, key=lambda x: -x['changed']):
        if r['changed'] or r['note']:
            print('%-52s %12d %9.4f%%  %s%s' % (r['name'], r['changed'], r['pct'], r['note'], '' if r in changed_rows else '  (noise)'))
    print('%s: %d compared, %d changed, %d noise, %d only before, %d only after, in %.0f s -> %s' % (verdict, len(rows), len(changed_rows), len(noise_rows), len(only_b), len(only_a), time.time() - t0, report))
    if only_b or only_a:
        return 2
    return 1 if changed_rows else 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('snap'); s.add_argument('--repo', required=True); s.add_argument('--out', required=True)
    s.add_argument('--workers', type=int, default=2); s.add_argument('--port-base', type=int, default=9550)
    s.add_argument('--only', default=''); s.add_argument('--scale', type=float, default=0.5); s.add_argument('--motion', default='reduce', choices=['reduce', 'no-preference']); s.add_argument('--list', action='store_true')
    c = sub.add_parser('compare'); c.add_argument('--before', required=True); c.add_argument('--after', required=True); c.add_argument('--report', required=True)
    c.add_argument('--common-only', action='store_true', help='compare only the pictures both folders have (a partial run)'); c.add_argument('--tol', type=int, default=16); c.add_argument('--min-pixels', type=int, default=30)
    a = ap.parse_args()
    sys.exit(cmd_snap(a) if a.cmd == 'snap' else cmd_compare(a))


if __name__ == '__main__':
    main()
