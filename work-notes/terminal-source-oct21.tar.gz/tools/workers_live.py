#!/usr/bin/env python3
"""Keep the Workers part of the Terminal LIVE from the helpers' own work records (transcripts).

    python3 -I tools/workers_live.py [--dry-run] [--only ID[,ID]] [--skip ID[,ID]] [--since 30m|2h|ISO]
                                     [--out FILE | --in-place] [--tool-words] [--handed-back done|resting] [--show]
                                     [--keep-activity] [--write-map] [--no-discover] [--idle-minutes N]
    python3 -I tools/test_workers_live.py        (self-test, a few seconds, made-up transcripts only)

Every helper's activity is written, one JSON object per line, to  <session>/tasks/<agentId>.output  (large files with
private working text). This tool STREAMS each file once and keeps only a few facts: the first and last time, how many tool
calls, whether the helper handed its report back, whether it waits for a background command, and the SHORT human
descriptions that helpers write for their tool calls ("Run the status test alone"). No other text is kept, printed or
written; plain-word swaps are made first (test -> check, suite -> set of checks, a11y -> access checks, re-run -> run ... again,
code -> page files, docs -> notes, UK -> US spelling); a description that still holds a path, a link, a token-like
string, code, jargon (schema, state, expectations, ...) or does not start with a verb is thrown away.

It reads state/workers.json (never changed unless --in-place) and writes an updated copy (default
outbox/workers-live/workers.json). Then the lead runs  python3 -I tools/terminal_state.py sync  as usual.

What changes in a worker document (only these): state, now, updatedAt, startedAt, finishedAt, activity, and waitingFor
(set back to "none" when the worker is no longer waiting). Never: id, name, role, parentId, kind, icon, brain, taskIds,
progress, order, result. A worker without a transcript (Claude, the teams) is left exactly as it is.

How a helper is matched to its transcript (first match wins):
  1. state/worker-agents.json  {"w-core": "a0662bf910688676f", ...}   (keys starting with _ are ignored)
  2. the worker's startedAt is EXACTLY (to the millisecond) the first time in one transcript, and no other helper
     has it. --write-map saves what step 2 found into the map file. --no-discover turns step 2 off.

THE STATE RULES (conservative; "done" needs clear evidence):
  done     the last thing in the transcript is the answer to the hand-back call (SubagentHandback), nothing came after.
           finishedAt = that time. If a new message arrives later the helper is "working" again.
           (--handed-back resting shows these as "resting" = free for more work, with finishedAt empty.)
  waiting  the helper started a background command (Monitor, or a command run in the background), got the "started"
           answer, did nothing else since (at most a closing remark), the last event is at least 1 minute old, and the
           command's own time limit has not run out. waitingFor stays "none" (it waits for a command, not a person).
  working  anything else with a last event at most IDLE minutes old (default 8). While a long command is still running
           (a call without an answer yet) the limit is that command's own time limit plus 90 seconds.
  resting  anything else: no hand-back, and nothing happened for more than IDLE minutes.
  Never produced: "stopped" (a worker the lead set to stopped is left alone). A worker the lead set to "waiting" for the
  owner, Miss Cathy or Rob stays waiting unless the transcript shows it is busy again; a person's answer can't be seen.
  updatedAt = last user/assistant event time; startedAt = first. (sync cannot move updatedAt backwards: it then uses the
  sync time.)
`now`      the newest plain description among the last 12 tool calls, only for working/waiting, first verb turned into
           "-ing" ("Running the status check alone"), at most 140 characters. If none is usable: the worker's own role
           line when it says what the task IS ("Draws the farm map ..." -> "Drawing the farm map ..."; a past-tense role
           such as "Built the page" is not used), then (only with --tool-words) a fixed phrase for the tool in use
           ("Reading files"), else "".
`activity` up to 8 lines, newest first, same clean descriptions (first verb in past tense), plus plain milestones:
           "Got the task", "Got a new task", "Handed back its report". Repeats are dropped (the newest stays).
           If the transcript gives nothing, the lead's lines stay. --keep-activity never touches them.
`steps`    tool calls (without the hand-back call itself); printed in the table only, never written to a document.

Exit 0 = fine, 2 = a request that cannot be done. Plain standard library only.
"""
import argparse
import collections
import datetime
import importlib.util as _iu
import json
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
T = HERE.parent


def _load(name):
    spec = _iu.spec_from_file_location(name, HERE / (name + ".py"))
    mod = _iu.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


qt = _load("qtlib")

DEFAULT_TASKS_DIR = T.parent.parent / "tasks"      # <session>/tasks  (T is <session>/scratchpad/terminal)
DEFAULT_IN = T / "state" / "workers.json"
DEFAULT_OUT = T / "outbox" / "workers-live" / "workers.json"
IDLE_MIN = 8
MAX_NOW = 140
MAX_ACTIVITY = 8
RECENT_CALLS = 12                  # `now` comes from the newest clean description among this many latest tool calls
LIVE_KEYS = ("state", "now", "updatedAt", "startedAt", "finishedAt", "activity", "waitingFor")
HUMANS = ("owner", "cathy", "rob")
AGENT_ID = re.compile(r"^[a-z][a-z0-9]{5,39}$")
AGENT_FILE = re.compile(r"^a[0-9a-f]{12,24}$")
BG_SLACK_S = 60
SETTLE_S = 60                       # a waiting helper must have been quiet this long, else it may still be thinking


# ------------------------------------------------------------------------------------------------ words: scrub a description
# A description is used ONLY when it is plain everyday words (after a few plain-word swaps). Anything else is thrown away.
EXTRA_JARGON = re.compile(r"\b(agents?|sub-?agents?|models?)\b", re.I)        # same as terminal_state.py / SPEC2 section 1
TECH = re.compile(
    r"\b(git|github|gitlab|npm|npx|node|nodejs|python\d*|pip|bash|shell|curl|wget|grep|sed|awk|regex|regexp|stdout|stderr|stdin|"
    r"chromium|chrome|playwright|puppeteer|selenium|headless|localhost|https?|ssh|sudo|chmod|mkdir|json|yaml|toml|xml|html|css|"
    r"scss|js|javascript|typescript|dom|cli|cdn|dns|urls?|uris?|sql|sha\d*|md5|base64|utf-?8|ascii|diffs?|patch(?:es)?|"
    r"lint(?:er|ing)?|traceback|stack ?trace|exceptions?|undefined|null|boolean|array|async|await|callbacks?|endpoints?|"
    r"payloads?|webhooks?|cron|pid|daemon|binary|compil\w+|bundl\w+|minif\w+|dependenc\w+|install\w*|uninstall\w*|packages?|"
    r"paths?|scripts?|stubs?|mocks?|fixtures?|harness|selectors?|viewports?|console|devtools|runtime|threads?|servers?|proxy|sockets?|"
    r"cache[ds]?|hash\w*|branch(?:es)?|rebase|sandbox\w*|docker|container|kernel|env|environment variables?|stdio|tty|"
    r"password\w*|passcode|secret\w*|credentials?|login|cookies?|auth\w*|bearer|api[- ]?keys?|private keys?|ids?|uuids?|"
    r"regression suite|exit codes?|return codes?|status codes?|ports?)\b",
    re.I,
)
# More words an everyday reader would trip over. A line that still has one AFTER the swaps below is dropped.
JARGON2 = re.compile(
    r"\b(expectations?|schemas?|states?|child process(?:es)?|subprocess\w*|processes|assert\w*|mutat\w+|refactor\w*|regress\w*|"
    r"baselines?|breakpoints?|markup|config\w*|params?|parameters?|args?|variables?|functions?|modules?|imports?|syntax|"
    r"pars(?:e|es|ed|ing)|quer(?:y|ies)|enums?|tuples?|iterat\w+|timeouts?|latency|e2e|end-to-end|integration|unit|aria|axe|"
    r"lighthouse|wcag|hooks?|handlers?|listeners?|pipelines?|worktrees?|stash\w*|checkouts?|workflows?|artifacts?|manifests?|"
    r"tarballs?|blobs?|buffers?|metadata|stubbed|spawn\w*|src|dist|dirs?|readme|ui|ux|cwd|[A-Za-z]\d{1,3}|[A-Za-z]\d+[A-Za-z]+)\b",
    re.I,
)

# Plain-word swaps (US spelling). Applied in this order; the first letter keeps its capital.
_AGAIN = ("run|running|ran|check|checking|checked|read|reading|build|building|built|open|opening|opened|test|testing|tested|"
          "measure|measuring|measured|take|taking|took|render|rendering|rendered|load|loading|loaded|fetch|fetching|fetched|"
          "verify|verifying|verified|do|doing|did|try|trying|tried|compare|comparing|compared|send|sending|sent|post|posting|"
          "posted|save|saving|saved|apply|applying|applied|start|starting|started|draw|drawing|drew|write|writing|wrote|make|"
          "making|made|edit|editing|edited|snap|snapping|snapped")
RE_LEAD = re.compile(r"^re-?(" + _AGAIN + r")\b(.*)$", re.I)
RE_INLINE = re.compile(r"\bre-?(" + _AGAIN + r")\b(\s+(?:it|them|this|that|these|those)\b)?", re.I)
SWAPS = [
    (re.compile(r"\ba11y(?:\s+(?:tests?|checks?))?\b", re.I), "access checks"),
    (re.compile(r"\btest suites\b", re.I), "sets of checks"),
    (re.compile(r"\btest suite\b", re.I), "set of checks"),
    (re.compile(r"\bsuites\b", re.I), "sets of checks"),
    (re.compile(r"\bsuite\b", re.I), "set of checks"),
    (re.compile(r"\bhelpers\b", re.I), "workers"),
    (re.compile(r"\bhelper\b", re.I), "worker"),
    (re.compile(r"\bjobs\b", re.I), "tasks"),
    (re.compile(r"\bjob\b", re.I), "task"),
    (re.compile(r"\bgrey(s|ish)?\b", re.I), r"gray\1"),
    (re.compile(r"\bdocs\b", re.I), "notes"),
    (re.compile(r"\bdoc\b", re.I), "note"),
    (re.compile(r"\b(?:source code|codebase)\b", re.I), "page files"),
    (re.compile(r"\bcode\b", re.I), "page files"),
    (re.compile(r"\btesting\b", re.I), "checking"),
    (re.compile(r"\btested\b", re.I), "checked"),
    (re.compile(r"\btester\b", re.I), "checker"),
    (re.compile(r"\btests\b", re.I), "checks"),
    (re.compile(r"\btest\b", re.I), "check"),
    (re.compile(r"\b(colo)ur(s|ed|ing|ful|less)?\b", re.I), r"\1r\2"),
    (re.compile(r"\b(neighbo|favo|hono|behavio|labo|flavo|humo|rumo|harbo|armo)ur(s|ed|ing|able|ite|ites)?\b", re.I), r"\1r\2"),
    (re.compile(r"\b(cent|met|theat|fib)re(s|d)?\b", re.I), r"\1er\2"),
    (re.compile(r"\b(organi|recogni|summari|optimi|normali|minimi|initiali|customi|prioriti|reali|finali|categori|visuali|"
                r"standardi|personali|modernis?)s(e|ed|es|ing|ation|ations)\b", re.I), r"\1z\2"),
    (re.compile(r"\banalys(e|ed|es|ing)\b", re.I), r"analyz\1"),
    (re.compile(r"\b(catalog)ue(s|d)?\b", re.I), r"\1\2"),
    (re.compile(r"\blicence(s|d)?\b", re.I), r"license\1"),
    (re.compile(r"\b(cance|trave|labe|mode|fue|signa)l(led|ling)\b", re.I), lambda m: m.group(1) + "l" + {"led": "ed", "ling": "ing"}[m.group(2).lower()]),
    (re.compile(r"\b(programme|defence|judgement|ageing|whilst)\b", re.I),
     lambda m: {"programme": "program", "defence": "defense", "judgement": "judgment", "ageing": "aging", "whilst": "while"}[m.group(1).lower()]),
]


def _keep_case(m, new):
    return new[:1].upper() + new[1:] if m.group(0)[:1].isupper() and new else new


def swap(t):
    """Plain words and US spelling. The first letter keeps its capital; 're-run' becomes 'run ... again'."""
    m = RE_LEAD.match(t)
    if m:
        rest = m.group(2).rstrip()
        t = m.group(1)[:1].upper() + m.group(1)[1:].lower() + rest + ("" if rest.lower().endswith("again") else " again")
    t = RE_INLINE.sub(lambda m: m.group(1).lower() + (m.group(2) or "") + " again", t)
    for rx, new in SWAPS:
        if callable(new):
            t = rx.sub(lambda m, f=new: _keep_case(m, f(m)), t)
        else:
            t = rx.sub(lambda m, n=new: _keep_case(m, m.expand(n)), t)
    return t


SYMBOLS = re.compile(r"[/\\`<>{}|;$@~^*=#\[\]\"“”&]")
DOTTED = re.compile(r"\w\.\w")                                  # file names, web addresses, version numbers
FLAG = re.compile(r"(^|\s)-{1,2}[A-Za-z]")
NUMBERS = re.compile(r"\d{5,}|\d{3}[-. ]\d{3,4}")
WORD = re.compile(r"[A-Za-z0-9_'’-]+")
CAPS_OK = {"OK", "NC", "USA", "FAQ", "PDF", "PNG", "JPG", "JPEG", "GIF", "TV", "DVD", "PM", "AM", "OKAY"}

# --tool-words: what to say when a call has no description of its own (fixed phrases; nothing is taken from the file)
TOOL_WORDS = {
    "Read": "Reading files", "Write": "Writing a file", "Edit": "Editing a file", "MultiEdit": "Editing a file",
    "NotebookEdit": "Editing a file", "Grep": "Looking through the files", "Glob": "Looking through the files",
    "WebSearch": "Searching the web", "WebFetch": "Reading a web page", "Bash": "Working on its task",
    "Monitor": "Waiting for a long task to finish", "SendMessage": "Sending a message", "Agent": "Asking another worker",
    "Task": "Asking another worker", "Skill": "Looking up how to do the task",
}

# first word -> (gerund for `now`, past tense for activity)
VERBS = {
    "run": ("Running", "Ran"), "check": ("Checking", "Checked"), "read": ("Reading", "Read"), "write": ("Writing", "Wrote"),
    "build": ("Building", "Built"), "look": ("Looking", "Looked"), "find": ("Finding", "Found"),
    "list": ("Listing", "Listed"), "show": ("Showing", "Showed"), "open": ("Opening", "Opened"), "make": ("Making", "Made"),
    "fix": ("Fixing", "Fixed"), "edit": ("Editing", "Edited"), "update": ("Updating", "Updated"), "add": ("Adding", "Added"),
    "remove": ("Removing", "Removed"), "wait": ("Waiting", "Waited"), "watch": ("Watching", "Watched"),
    "compare": ("Comparing", "Compared"), "count": ("Counting", "Counted"), "try": ("Trying", "Tried"),
    "take": ("Taking", "Took"), "save": ("Saving", "Saved"), "start": ("Starting", "Started"), "stop": ("Stopping", "Stopped"),
    "view": ("Viewing", "Viewed"), "review": ("Reviewing", "Reviewed"), "create": ("Creating", "Created"),
    "draw": ("Drawing", "Drew"), "render": ("Rendering", "Rendered"), "measure": ("Measuring", "Measured"),
    "verify": ("Verifying", "Verified"), "confirm": ("Confirming", "Confirmed"), "validate": ("Validating", "Validated"),
    "inspect": ("Inspecting", "Inspected"), "scan": ("Scanning", "Scanned"), "search": ("Searching", "Searched"),
    "get": ("Getting", "Got"), "print": ("Printing", "Printed"), "record": ("Recording", "Recorded"),
    "copy": ("Copying", "Copied"), "move": ("Moving", "Moved"), "rename": ("Renaming", "Renamed"),
    "delete": ("Deleting", "Deleted"), "clean": ("Cleaning", "Cleaned"), "load": ("Loading", "Loaded"),
    "finish": ("Finishing", "Finished"), "prepare": ("Preparing", "Prepared"), "collect": ("Collecting", "Collected"),
    "send": ("Sending", "Sent"), "post": ("Posting", "Posted"), "set": ("Setting", "Set"), "use": ("Using", "Used"),
    "retry": ("Retrying", "Retried"), "rerun": ("Rerunning", "Reran"), "re-run": ("Re-running", "Re-ran"),
    "double-check": ("Double-checking", "Double-checked"), "grab": ("Grabbing", "Grabbed"), "pick": ("Picking", "Picked"),
    "fetch": ("Fetching", "Fetched"), "download": ("Downloading", "Downloaded"), "resize": ("Resizing", "Resized"),
    "shrink": ("Shrinking", "Shrank"), "photograph": ("Photographing", "Photographed"), "capture": ("Capturing", "Captured"),
    "translate": ("Translating", "Translated"), "merge": ("Merging", "Merged"), "apply": ("Applying", "Applied"),
    "polish": ("Polishing", "Polished"), "tidy": ("Tidying", "Tidied"), "summarize": ("Summarizing", "Summarized"),
    "explore": ("Exploring", "Explored"), "search": ("Searching", "Searched"), "ask": ("Asking", "Asked"),
    "see": ("Seeing", "Saw"), "poll": ("Waiting", "Waited"), "locate": ("Finding", "Found"), "probe": ("Looking into", "Looked into"),
    "peek": ("Looking", "Looked"), "compute": ("Working out", "Worked out"), "extract": ("Pulling out", "Pulled out"),
    "generate": ("Making", "Made"), "regenerate": ("Remaking", "Remade"), "replay": ("Playing back", "Played back"),
    "reproduce": ("Recreating", "Recreated"), "identify": ("Finding", "Found"), "correct": ("Fixing", "Fixed"),
    "audit": ("Checking", "Checked"), "analyze": ("Analyzing", "Analyzed"), "survey": ("Looking over", "Looked over"),
    "zoom": ("Zooming in on", "Zoomed in on"), "crop": ("Cropping", "Cropped"), "split": ("Splitting", "Split"),
    "repeat": ("Repeating", "Repeated"), "tighten": ("Tightening", "Tightened"), "pause": ("Pausing", "Paused"),
    "shorten": ("Shortening", "Shortened"), "trim": ("Trimming", "Trimmed"), "outline": ("Outlining", "Outlined"),
    "refine": ("Refining", "Refined"), "replace": ("Replacing", "Replaced"), "combine": ("Combining", "Combined"),
    "skim": ("Skimming", "Skimmed"),
}

LEMMA = {}
for _k, (_g, _p) in VERBS.items():
    for _w in (_k, _g.lower(), _p.lower()):
        LEMMA.setdefault(_w, _k)


def scrub(text):
    """-> (plain text or None, reason). Reason is a short code, never the text."""
    if not isinstance(text, str):
        return None, "none"
    t = " ".join(text.split())
    if not t:
        return None, "empty"
    if len(t) > 200:
        return None, "long"
    if SYMBOLS.search(t):
        return None, "symbols"
    if DOTTED.search(t):
        return None, "dotted"
    if FLAG.search(t):
        return None, "flag"
    if NUMBERS.search(t):
        return None, "numbers"
    words = WORD.findall(t)
    if len(words) > 30:
        return None, "long"
    for w in words:
        core = w.strip("'’-")
        if len(core) >= 24:
            return None, "codelike"
        if re.search(r"[A-Za-z]", core) and re.search(r"\d", core) and len(core) >= 7:
            return None, "codelike"
        if "_" in core or re.search(r"[a-z][A-Z]", core):
            return None, "codelike"
        if len(core) >= 3 and core.isalpha() and core.isupper() and core not in CAPS_OK:
            return None, "codelike"
    t = swap(t)
    if qt.JARGON_RE.search(t) or EXTRA_JARGON.search(t) or TECH.search(t) or JARGON2.search(t):
        return None, "jargon"
    t = re.sub(r"\bKathy\b", "Cathy", t)                       # she is "Miss Cathy"
    t = t.rstrip(" .!:;,-")
    if len(t) < 4 or not re.search(r"[A-Za-z]{3}", t) or len(t.split()) < 3:
        return None, "short"
    return t[0].upper() + t[1:], "ok"


def phrase(clean, form):
    """form 0 = the "-ing" form for `now`, 1 = past tense for activity. Only the first word changes; it may be given as
    "run", "running" or "ran". None when the line does not start with a verb we know (such a line is not used)."""
    head, _, rest = clean.partition(" ")
    lemma = LEMMA.get(head.lower().strip(",:;"))
    if lemma is None:
        return None
    out = VERBS[lemma][form] + (" " + rest if rest else "")
    # a second command joined by "and" follows the first: "Add the check and run it" -> "Adding the check and running it"
    def second(m):
        k = m.group(1).lower()
        return f" and {VERBS[k][form].lower()} " if k in VERBS else m.group(0)
    return re.sub(r" and (\w+) (?=(?:it|them|this|that|these|those|the|a|an|all|each|both|any|my|your|their|its|our|again|then)\b)", second, out, flags=re.I)


def cap(text, n=MAX_NOW):
    text = " ".join(text.split())
    if len(text) <= n:
        return text
    cut = text[: n - 1].rsplit(" ", 1)[0].rstrip(" ,;:-")
    return cut + "…"


# ------------------------------------------------------------------------------------------------ time
def parse_ts(ts):
    return qt.parse_iso(ts)


def as_dt(text):
    d = qt.parse_iso(text)
    return d


def sec_z(dt):
    return dt.astimezone(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def age_text(sec):
    if sec is None:
        return "?"
    sec = max(0, int(sec))
    if sec < 90:
        return f"{sec}s"
    m = (sec + 30) // 60
    if m < 120:
        return f"{m}m"
    h = m // 60
    if h < 48:
        return f"{h}h{m % 60:02d}m"
    return f"{h // 24}d{h % 24}h"


def parse_since(text, now):
    """'30m', '2h', '1d' (ago) or an ISO time -> aware datetime."""
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*([mhd])\s*", text or "")
    if m:
        unit = {"m": 60, "h": 3600, "d": 86400}[m.group(2)]
        return now - datetime.timedelta(seconds=float(m.group(1)) * unit)
    d = qt.parse_iso(text)
    if d is None:
        qt.die(f"--since needs a time like 30m, 2h, 1d or 2026-10-07T20:00:00Z (got {text!r}).")
    return d


# ------------------------------------------------------------------------------------------------ reading one transcript
class Summary:
    """The few facts kept from one transcript. Nothing else from the file is stored."""

    def __init__(self, agent_id):
        self.agent_id = agent_id
        self.lines = 0
        self.bad = 0
        self.first = None            # (text, datetime) of the first user/assistant record
        self.last = None             # same, of the last one
        self.steps = 0
        self.seen_calls = set()
        self.descs = collections.deque(maxlen=600)         # (datetime, past-tense text) for every tool call with a plain description
        self.recent = collections.deque(maxlen=RECENT_CALLS)   # (datetime, "-ing" text or None, tool name) for the latest tool calls
        self.milestones = []                               # (datetime, text)
        self.pending = {}                                  # tool_use_id -> (name, datetime, timeout seconds, background?)
        self.handback_ids = set()
        self.ended = None                                  # (text, datetime) when the tail is the answer to a hand-back
        self.bg_open = {}                                  # tool_use_id -> (datetime, timeout seconds): started, no answer yet
        self.bg_wait = None                                # (start datetime, timeout seconds) while the helper has nothing else going
        self.rejects = collections.Counter()
        self.accepted = 0
        self.max_pending_s = 0

    # -- one record
    def feed(self, o):
        if not isinstance(o, dict) or o.get("type") not in ("user", "assistant"):
            return
        ts = o.get("timestamp")
        dt = parse_ts(ts)
        if dt is None:
            return
        if self.first is None:
            self.first = (ts, dt)
            self.milestones.append((dt, "Got the task"))
        if self.last is None or dt >= self.last[1]:
            self.last = (ts, dt)
        was_ended, self.ended = self.ended, None
        m = o.get("message")
        content = m.get("content") if isinstance(m, dict) else None
        if o["type"] == "user":
            if isinstance(content, str):
                self.bg_wait = None
                if was_ended:
                    self.milestones.append((dt, "Got a new task"))
                return
            if isinstance(content, list):
                for it in content:
                    if isinstance(it, dict) and it.get("type") == "tool_result":
                        self._result(it.get("tool_use_id"), ts, dt)
            return
        if isinstance(content, list):
            for it in content:
                if isinstance(it, dict) and it.get("type") == "tool_use":
                    self._call(it, dt)

    def _call(self, it, dt):
        cid, name = it.get("id"), it.get("name")
        inp = it.get("input") if isinstance(it.get("input"), dict) else {}
        if cid in self.seen_calls:
            return
        self.seen_calls.add(cid)
        self.bg_wait = None
        if name == "SubagentHandback":
            self.handback_ids.add(cid)
            self.pending[cid] = (name, dt, 0, False)
            return
        self.steps += 1
        bg = name == "Monitor" or bool(inp.get("run_in_background"))
        tmo = inp.get("timeout_ms") if name == "Monitor" else inp.get("timeout")
        if not isinstance(tmo, (int, float)) or isinstance(tmo, bool) or tmo <= 0:
            tmo = 600000 if name == "Monitor" else (1800000 if bg else 120000)
        self.pending[cid] = (name, dt, tmo / 1000.0, bg)
        if bg:
            self.bg_open[cid] = (dt, tmo / 1000.0)
        desc = inp.get("description")
        ing = None
        if isinstance(desc, str) and desc.strip():
            clean, why = scrub(desc)
            if clean:
                ing, past = phrase(clean, 0), phrase(clean, 1)
                if ing is None:
                    self.rejects["noverb"] += 1        # does not start with a verb we can turn into "-ing" / past tense
                else:
                    self.accepted += 1
                    self.descs.append((dt, past))
            else:
                self.rejects[why] += 1
        self.recent.append((dt, ing, name))

    def _result(self, cid, ts, dt):
        info = self.pending.pop(cid, None)
        if cid in self.handback_ids:
            self.ended = (ts, dt)
            self.milestones.append((dt, "Handed back its report"))
            self.bg_wait = None
            return
        if cid in self.bg_open:
            self.bg_wait = (dt, self.bg_open.pop(cid)[1])      # started: the helper now has nothing else going
            return
        self.bg_wait = None

    # -- the verdict
    def verdict(self, now, idle_min=IDLE_MIN):
        """-> (state, why). state is working | waiting | resting | done, or None when the file has no usable record."""
        if self.last is None:
            return None, "no records"
        age = (now - self.last[1]).total_seconds()
        if self.ended is not None:
            return "done", "handed back its report"
        if self.bg_wait is not None:
            start, tmo = self.bg_wait
            if age >= SETTLE_S and (now - start).total_seconds() <= tmo + BG_SLACK_S:
                return "waiting", "waiting for a background command"
        limit = idle_min * 60
        running = [p[2] for p in self.pending.values() if p[0] != "SubagentHandback" and not p[3]]
        if running:
            limit = max(limit, max(running) + 90)
        if age <= limit:
            return "working", "busy"
        return "resting", f"quiet for {age_text(age)}"

    def now_line(self):
        """The newest plain description among the last tool calls that starts with a verb ("-ing" form), else None."""
        for dt, ing, name in reversed(self.recent):
            if ing:
                return cap(ing)
        return None

    def tool_phrase(self):
        """--tool-words: a fixed phrase for the kind of tool the newest call used (nothing is taken from the file)."""
        return TOOL_WORDS.get(self.recent[-1][2]) if self.recent else None

    def activity(self):
        items = [(dt, i, t) for i, (dt, t) in enumerate(self.descs)]
        base = len(items)
        items += [(dt, base + i, t) for i, (dt, t) in enumerate(self.milestones)]
        items.sort(key=lambda x: (x[0], x[1]), reverse=True)
        seen, out = set(), []
        for dt, _, text in items:
            text = cap(text)
            k = text.lower()
            if k in seen:
                continue
            seen.add(k)
            out.append({"at": sec_z(dt), "text": text})
            if len(out) >= MAX_ACTIVITY:
                break
        return out


SPLICE = b'{"parentUuid"'


def read_transcript(path, agent_id):
    s = Summary(agent_id)
    with open(path, "rb") as fh:
        for line in fh:
            s.lines += 1
            if b'"attachment":{' in line[:300]:      # notes the system adds; never part of what a helper did
                continue
            try:
                o = json.loads(line)
            except ValueError:
                # Two writers sometimes splice: a cut-off record, then a whole one on the same line. Keep the whole one.
                s.bad += 1
                o, at = None, line.find(SPLICE, 1)
                while at > 0 and o is None:
                    try:
                        o = json.loads(line[at:])
                    except ValueError:
                        at = line.find(SPLICE, at + 1)
                if o is None:
                    continue
            s.feed(o)
    return s


# ------------------------------------------------------------------------------------------------ mapping workers -> transcripts
def transcript_path(tasks_dir, agent_id):
    if not AGENT_ID.match(agent_id or ""):
        return None
    for name in (agent_id + ".output", "agent-" + agent_id + ".jsonl"):
        p = Path(tasks_dir) / name
        if p.exists():
            return p
    return None


def load_map(path):
    p = Path(path)
    if not p.is_file():
        return {}
    try:
        raw = qt.read_json(p)
    except (OSError, ValueError) as e:
        qt.die(f"Could not read the map {p}: {e}")
    if not isinstance(raw, dict):
        qt.die(f"The map {p} should look like {{\"w-core\": \"a0662bf910688676f\"}}.")
    return {k: v for k, v in raw.items() if isinstance(k, str) and not k.startswith("_") and isinstance(v, str)}


def first_time(path):
    """The first user/assistant time of a transcript (reads the first lines only)."""
    try:
        with open(path, "rb") as fh:
            for n, line in enumerate(fh):
                if n > 20:
                    break
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                if isinstance(o, dict) and o.get("type") in ("user", "assistant") and parse_ts(o.get("timestamp")):
                    return parse_ts(o["timestamp"])
    except OSError:
        pass
    return None


def discover(workers, mapping, tasks_dir):
    """Match unmapped helpers to transcripts by the exact first time. -> ({worker id: agent id}, [problems])"""
    tasks_dir = Path(tasks_dir)
    want = {}
    for d in workers:
        if d.get("kind") == "helper" and d["id"] not in mapping and parse_ts(d.get("startedAt")):
            want.setdefault(parse_ts(d["startedAt"]), []).append(d["id"])
    if not want or not tasks_dir.is_dir():
        return {}, []
    used = set(mapping.values())
    found = collections.defaultdict(list)
    for p in sorted(tasks_dir.glob("a*.output")):
        aid = p.name[:-7]
        if not AGENT_FILE.match(aid) or aid in used:
            continue
        ft = first_time(p)
        if ft in want:
            found[ft].append(aid)
    out, problems = {}, []
    for ft, wids in want.items():
        aids = found.get(ft, [])
        if len(wids) == 1 and len(aids) == 1:
            out[wids[0]] = aids[0]
        elif aids:
            problems.append(f"{', '.join(wids)}: the start time fits {len(aids)} transcript(s); not guessed")
    return out, problems


# ------------------------------------------------------------------------------------------------ updating the documents
ROLE_VERBS = {"change": "Changing", "keep": "Keeping", "help": "Helping", "handle": "Handling", "turn": "Turning", "put": "Putting",
              "give": "Giving", "bring": "Bringing", "sort": "Sorting", "plan": "Planning", "design": "Designing", "study": "Studying",
              "rehearse": "Rehearsing", "stack": "Stacking", "work": "Working", "look": "Looking", "talk": "Talking",
              "walk": "Walking", "report": "Reporting", "explain": "Explaining", "tell": "Telling", "pick": "Picking"}


def _stems(word):
    out = {word}
    if word.endswith("ies"):
        out.add(word[:-3] + "y")
    if word.endswith("es"):
        out.add(word[:-2])
    if word.endswith("s"):
        out.add(word[:-1])
    return out


def plain_role(role):
    """The worker's own role line as a last resort for `now`: only when it says what the task IS now ("Draws the farm map ..."
    becomes "Drawing the farm map ..."). A role in the past tense ("Built the page") says what was done, so it is not used.
    Same plain-word rules as every other line. "" if unusable."""
    clean, _ = scrub(role) if isinstance(role, str) else (None, "none")
    if not clean:
        return ""
    head, _, rest = clean.partition(" ")
    h = head.lower()
    for second in re.findall(r"\band\s+([a-z]+)\b", rest.lower()):       # "... and checks nothing got lost": two verbs, we can only turn one
        if _stems(second) & (set(VERBS) | set(ROLE_VERBS)):
            return ""
    stems = [h] + sorted(_stems(h) - {h})
    for st in stems:
        if st in VERBS:
            return cap(VERBS[st][0] + (" " + rest if rest else ""))
        if st in ROLE_VERBS:
            return cap(ROLE_VERBS[st] + (" " + rest if rest else ""))
    return ""


def plan_doc(doc, s, now, idle_min, keep_activity, tool_words=False, handed_back="done"):
    """-> (new doc, state shown, note)."""
    state, why = s.verdict(now, idle_min)
    if state == "done" and handed_back == "resting":
        state, why = "resting", "handed back its report (shown as resting)"
    new = dict(doc)
    if state is None:
        return new, doc.get("state"), "no usable records; kept as it was"
    old_state, old_wf = doc.get("state"), doc.get("waitingFor", "none")
    note = why
    pinned = None
    if old_state == "stopped":
        pinned = "stopped by Claude; kept"
    elif old_state == "waiting" and old_wf in HUMANS and state in ("done", "resting", "waiting"):
        pinned = f"kept: waiting for {old_wf}"
    if s.first:
        new["startedAt"] = s.first[0]
    if s.last:
        new["updatedAt"] = s.last[0]
    if not keep_activity:
        acts = s.activity()
        if acts:
            new["activity"] = acts
    if pinned:
        return new, old_state, pinned
    new["state"] = state
    new["finishedAt"] = s.ended[0] if state == "done" and s.ended else None
    if state in ("working", "waiting"):
        line, how = s.now_line(), ""
        if not line:
            line, how = plain_role(doc.get("role")), "its role line"
        if not line and tool_words:
            line, how = s.tool_phrase() or "", "a phrase for the tool in use"
        new["now"] = line or ""
        if how:
            note += "; no plain description for 'now', " + (f"used {how}" if line else "left empty")
    else:
        new["now"] = ""
    if state != "waiting" and old_wf not in ("none", None):
        new["waitingFor"] = "none"
    return new, state, note


def guard(old, new):
    """The promises of this tool: only the live fields may differ, and the texts must be plain."""
    for k in set(old) | set(new):
        if k not in LIVE_KEYS and old.get(k) != new.get(k):
            raise RuntimeError(f"internal error: would change '{k}' of {old.get('id')}")
    texts = [new.get("now", "")] + [e["text"] for e in new.get("activity", []) if isinstance(e, dict)]
    for t in texts:
        if t and (qt.JARGON_RE.search(t) or EXTRA_JARGON.search(t) or "\n" in t or len(t) > MAX_NOW):
            raise RuntimeError(f"internal error: an unsuitable line for {old.get('id')}")
    if len(new.get("activity", [])) > MAX_ACTIVITY:
        raise RuntimeError("internal error: more than 8 activity lines")


# ------------------------------------------------------------------------------------------------ main
def build_parser():
    p = argparse.ArgumentParser(
        prog="workers_live.py",
        description="Update the live fields of state/workers.json from the workers' transcripts. Writes a COPY (see --out).",
        epilog="Rules: top of this file or notes/WORKERS-LIVE.md. Prints only counts, times and plain-words lines.")
    p.add_argument("--in", dest="infile", metavar="FILE", help="workers file to read (default: state/workers.json)")
    p.add_argument("--out", metavar="FILE", help="where to write the updated copy (default: outbox/workers-live/workers.json)")
    p.add_argument("--in-place", action="store_true", help="write over the input file (a copy goes to outbox/backup-state/ first)")
    p.add_argument("--dry-run", action="store_true", help="write nothing; only print the table")
    p.add_argument("--only", action="append", metavar="ID", help="only this worker id (repeat, or a comma list)")
    p.add_argument("--skip", action="append", metavar="ID", help="leave this worker exactly as it is (repeat, or a comma list)")
    p.add_argument("--handed-back", choices=("done", "resting"), default="done",
                   help="what a worker that handed its report back is shown as (default done; resting = free for more work)")
    p.add_argument("--since", metavar="TIME", help="only workers whose transcript changed since this time (30m, 2h, 1d or an ISO time)")
    p.add_argument("--map", metavar="FILE", help="worker id -> agent id (default: worker-agents.json next to the input file)")
    p.add_argument("--write-map", action="store_true", help="save the transcripts found by start time into the map file (also in a dry run)")
    p.add_argument("--no-discover", action="store_true", help="use the map only; do not match by start time")
    p.add_argument("--tasks-dir", metavar="DIR", help="where <agentId>.output files are (default: <session>/tasks; env QT_TASKS_DIR)")
    p.add_argument("--idle-minutes", type=float, default=IDLE_MIN, metavar="N", help=f"quiet this long without a hand-back = resting (default {IDLE_MIN})")
    p.add_argument("--keep-activity", action="store_true", help="do not touch the activity lines")
    p.add_argument("--tool-words", action="store_true", help="last resort for `now` (after the role line): the kind of tool in use, a fixed phrase like 'Reading files'")
    p.add_argument("--show", action="store_true", help="also print each worker's 'now' line and newest activity line")
    p.add_argument("--now", metavar="ISO", help="pretend it is this time (tests); env QT_NOW does the same")
    p.add_argument("--outbox", metavar="DIR", help="outbox folder for backups (default: outbox/)")
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    infile = Path(a.infile).expanduser() if a.infile else DEFAULT_IN
    if not infile.is_file():
        qt.die(f"There is no workers file at {infile}.")
    try:
        workers = qt.read_json(infile)
    except (OSError, ValueError) as e:
        qt.die(f"Could not read {infile}: {e}")
    if not isinstance(workers, list) or not all(isinstance(d, dict) and isinstance(d.get("id"), str) for d in workers):
        qt.die(f"{infile} should be a list of worker documents (each with an id).")
    if a.in_place and a.out:
        qt.die("Use either --in-place or --out, not both.")
    out_path = infile if a.in_place else (Path(a.out).expanduser() if a.out else DEFAULT_OUT)
    if out_path.is_dir() or (a.out and str(a.out).endswith(os.sep)):
        out_path = out_path / "workers.json"
    if not a.in_place and out_path.resolve() == infile.resolve():
        qt.die("The output would overwrite the input. Give another --out, or say --in-place.")

    now = qt.parse_iso(a.now or os.environ.get("QT_NOW") or "") or datetime.datetime.now(datetime.timezone.utc)
    since = parse_since(a.since, now) if a.since else None
    tasks_dir = Path(a.tasks_dir or os.environ.get("QT_TASKS_DIR") or DEFAULT_TASKS_DIR).expanduser()
    if not tasks_dir.is_dir():
        qt.die(f"There is no folder with transcripts at {tasks_dir} (use --tasks-dir).")
    map_path = Path(a.map).expanduser() if a.map else infile.with_name("worker-agents.json")
    mapping = load_map(map_path)
    skip = {x.strip() for item in (a.skip or []) for x in item.split(",") if x.strip()}
    only = None
    if a.only:
        only = {x.strip() for item in a.only for x in item.split(",") if x.strip()}
        unknown = sorted(only - {d["id"] for d in workers})
        if unknown:
            qt.die("Not in the workers file: " + ", ".join(unknown))

    by_start = {}
    if not a.no_discover:
        by_start, problems = discover(workers, mapping, tasks_dir)
    else:
        problems = []

    rows, new_docs, counts = [], [], collections.Counter()
    unmapped, missing, skipped, changed = [], [], [], 0
    rejects, accepted = collections.Counter(), 0
    used_agents = set()

    def row(wid, state, age, steps, note, now_text="", newest=""):
        rows.append({"id": wid, "state": state, "age": age, "steps": steps, "note": note, "now": now_text, "newest": newest})

    for d in workers:
        wid = d["id"]
        agent, how = mapping.get(wid), "map"
        if not agent and wid in by_start:
            agent, how = by_start[wid], "start time"
        if agent:
            used_agents.add(agent)
        if only is not None and wid not in only:
            new_docs.append(d)
            continue
        if wid in skip:
            new_docs.append(d)
            row(wid, d.get("state", "?"), "-", "-", "skipped (--skip); kept as it was")
            continue
        if not agent:
            new_docs.append(d)
            if d.get("kind") == "helper":
                unmapped.append(wid)
                row(wid, d.get("state", "?"), "-", "-", "NOT MAPPED: no transcript known; kept as it was")
            else:
                skipped.append(wid)
                row(wid, d.get("state", "?"), "-", "-", f"{d.get('kind', '?')}: no work file of its own; kept as it was")
            continue
        path = transcript_path(tasks_dir, agent)
        if path is None:
            new_docs.append(d)
            missing.append(f"{wid} ({agent})")
            row(wid, d.get("state", "?"), "-", "-", "transcript file not found; kept as it was")
            continue
        if since is not None:
            try:
                mtime = datetime.datetime.fromtimestamp(os.stat(path).st_mtime, datetime.timezone.utc)
            except OSError:
                mtime = None
            if mtime is not None and mtime < since - datetime.timedelta(seconds=60):
                new_docs.append(d)
                row(wid, d.get("state", "?"), "-", "-", "not touched since --since; kept as it was")
                continue
        s = read_transcript(path, agent)
        rejects.update(s.rejects)
        accepted += s.accepted
        if since is not None and (s.last is None or s.last[1] < since):
            new_docs.append(d)
            row(wid, d.get("state", "?"), "-", "-", "not touched since --since; kept as it was")
            continue
        new, shown, note = plan_doc(d, s, now, a.idle_minutes, a.keep_activity, a.tool_words, a.handed_back)
        guard(d, new)
        new_docs.append(new)
        counts[new.get("state")] += 1
        if new != d:
            changed += 1
        age = (now - s.last[1]).total_seconds() if s.last else None
        was = d.get("state", "?")
        note = (f"found by start time; " if how != "map" else "") + note + (f"; {s.bad} damaged line(s) skipped" if s.bad else "")
        newest = new["activity"][0]["text"] if new.get("activity") and not a.keep_activity else ""
        row(wid, was if shown == was else f"{was} > {shown}", age_text(age), s.steps, note, new.get("now", ""), newest)

    # ---- the table
    print(f"Workers live  (as of {sec_z(now)}; idle limit {a.idle_minutes:g} min; transcripts in {tasks_dir})")
    cols = [("worker", "id"), ("state", "state"), ("last event", "age"), ("steps", "steps"), ("note", "note")]
    w = [max(len(h), *(len(str(r[k])) for r in rows)) if rows else len(h) for h, k in cols[:4]]
    print("  " + "  ".join(h.ljust(w[i]) for i, (h, k) in enumerate(cols[:4])) + "  note")
    print("  " + "  ".join("-" * w[i] for i in range(4)) + "  ----")
    for r in rows:
        print("  " + "  ".join(str(r[k]).ljust(w[i]) for i, (h, k) in enumerate(cols[:4])) + "  " + r["note"])
    if a.show:
        print("\nWhat the page would say (plain-words lines only):")
        for r in rows:
            if r["now"] or r["newest"]:
                print(f"  {r['id']}: now = {r['now']!r}; newest activity = {r['newest']!r}")

    # ---- summary
    nstate = ", ".join(f"{counts[k]} {k}" for k in ("working", "waiting", "resting", "done", "stopped") if counts[k]) or "none"
    print(f"\nRead {sum(counts.values())} transcript(s): {nstate}.  Documents that would change: {changed} of {len(workers)}.")
    if by_start:
        print("Matched by exact start time (not in the map): " + ", ".join(f"{k}={v}" for k, v in sorted(by_start.items())))
    for note in problems:
        print("  note: " + note)
    if unmapped:
        print("Helpers with NO transcript found: " + ", ".join(unmapped) + "  (add them to " + str(map_path) + ")")
    if missing:
        print("Mapped but the transcript file is missing: " + ", ".join(missing))
    if skipped:
        print("Left as they are (no work file of their own): " + ", ".join(skipped))
    free = sorted(p.name[:-7] for p in tasks_dir.glob("a*.output") if AGENT_FILE.match(p.name[:-7]) and p.name[:-7] not in used_agents)
    if free and only is None:
        print(f"Transcripts that belong to no worker in the file ({len(free)}): " + ", ".join(free[:14]) + (" ..." if len(free) > 14 else ""))
    tot = accepted + sum(rejects.values())
    if tot:
        print(f"Descriptions: {accepted} of {tot} were plain enough to use; thrown away: " +
              (", ".join(f"{n} {k}" for k, n in rejects.most_common()) or "none") + ".")

    # ---- write
    if a.write_map and by_start:
        merged = dict(mapping)
        merged.update(by_start)
        qt.write_json(map_path, merged)
        print(f"Map saved: {map_path} ({len(merged)} entries).")
    if a.dry_run:
        print("Dry run: no workers file written.")
        return 0
    if a.in_place:
        bk = qt.outbox_dir(a.outbox) / "backup-state"
        bk.mkdir(parents=True, exist_ok=True)
        (bk / f"workers-{qt.stamp()}.json").write_bytes(infile.read_bytes())
        for old in sorted(bk.glob("workers-*.json"))[:-20]:
            old.unlink()
    qt.write_json(out_path, new_docs)
    print(f"Wrote {out_path}" + ("  (the state file itself)" if a.in_place else "") + ".")
    if not a.in_place:
        print("Next: look at it, then copy it over state/workers.json (or rerun with --in-place), then  python3 -I tools/terminal_state.py check  and  sync.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
