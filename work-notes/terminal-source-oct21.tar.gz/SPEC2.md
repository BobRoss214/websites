# The Terminal, part 2: Workers and Tasks (blueprint; read SPEC.md and COMMON.md first, they still apply)

T = /tmp/claude-0/-home-user-websites/0370289f-5c48-5314-b3f5-bb8be7afd39d/scratchpad/terminal. Same rules as COMMON.md (never touch /home/user/websites, no publishing, no ArtifactData, own ports, short report <= 25 lines, quality over speed, about 40 minutes).

## 0. What the owner asked for (her words, Oct 7)
"Now we just call it the terminal. It is more than questions. Sections within sections. The main parts are: the question terminal; a WORKERS terminal that shows me all the workers and everything I want to know about them, live, what they are doing, and I can ask each worker questions, with main workers and so on; and a TASK terminal where I see the current tasks and the finished tasks, like files that break into two and those break into more: a main idea drops down into tasks, and those into smaller tasks. I want to see all the tasks happening. It must be explained on the page in a very casual, simple way so anyone can understand, and be fun, cool looking and interactive. I can add tasks, edit tasks, and ask questions about what you are working on."
Plan she was told (do not contradict it): one page, three parts at the top (Questions, Workers, Tasks); Questions stays exactly as it is; the page shows what Claude writes into it; her questions go to Claude, who passes them on and writes the answer back; nothing on the real website changes.

## 1. Words and look
- Same words rules as SPEC.md section 3: short, friendly, everyday English, no jargon (no "database, JSON, agent, sub-agent, model, token, API, sync, deploy, commit"). Say "worker" for a helper. Say "Claude" for the boss.
- Casual explanations, a little humor is welcome (farm talk is fine: "crew", "rows", "harvest") but never silly about money, safety or facts.
- Fun, cool, interactive: smooth small animations (always off with `prefers-reduced-motion`), a friendly little picture/badge for each worker, colored states, tap to open/close, counters that tick, hover/focus highlights. Keep it tidy: it must still fit the fit-rule (SPEC.md section 2): 700 x 800 side panel is the main size, 1366 x 768 and 1920 x 1080 must look great too, nothing breaks at 400 px (no sideways page scroll; wide drawings scroll inside their own box).
- Use the base tokens and classes (notes/layout-classes.md). New colors only as new tokens defined in YOUR css file with light and dark values, never literals. Text >= 13 px, targets >= 40 px, visible focus, keyboard works for everything, `aria` names on every control, state is never shown by color alone (also a word or icon).
- All document text is untrusted: textContent only, never innerHTML with data. Wrap localStorage in try/catch. Page must render with a friendly message when the db is missing.

## 2. Navigation (the "parts")
- The page title becomes "Terminal". The top bar stays (live dot, last looked, sound, check). Under it a sticky strip of three tabs (segmented control): **Questions** | **Workers** | **Tasks**. Each tab can show a small count badge (Questions: waiting for her; Workers: how many are working; Tasks: how many wait for her).
- Part ids: `questions` (all existing views: home, section, question, done, newsection), `workers`, `tasks`. New views: `QT.views.workers(el, params)`, `QT.views.tasks(el, params)`; routes `QT.route.go('workers', {focus: workerId})` and `QT.route.go('tasks', {focus: taskId})`.
- In the Workers and Tasks parts the left menu is hidden and the main area uses the full width (the Questions part is unchanged, left menu and all). On narrow screens the hamburger is hidden in those two parts.
- Remember the last part in localStorage (try/catch), like the last view already is. Keyboard: tabs are a proper tab list (arrows move, Enter/Space opens).
- Cross links: a worker card links to its tasks; a task links to its workers and to related questions (`QT.route.go('question', {id})`); a "waiting for you" task links straight to the question she must answer.

## 3. Data (new collections in the same notebook). Who writes what
Claude writes: `workers`, `tasks`, `replies`. The page writes: `taskAdds`, `taskEdits`, `asks`. Nobody edits the other side's documents. Ids: lowercase letters, digits, `-`, `_`.
```
workers/<id>  { id, name:String,                       // "Map drawer A" (plain, short)
                parentId:String|null,                  // the main worker or team it belongs to; null for the top (Claude)
                kind:"lead"|"team"|"helper",           // lead = Claude, team = a group of helpers, helper = one worker
                icon:String,                           // ONE emoji picked by Claude; the page falls back to the initials
                role:String,                           // what the job is, plain words, <= 90 chars
                state:"working"|"waiting"|"resting"|"done"|"stopped",
                                                       // working = busy now, waiting = needs an answer or something from someone, resting = free and ready for more, done = finished its job, stopped = stopped early
                now:String,                            // what they are doing right now, <= 140 chars, "" when not working
                waitingFor:"owner"|"cathy"|"rob"|"claude"|"none",
                startedAt:ISO|null, updatedAt:ISO, finishedAt:ISO|null,
                activity:[{at:ISO, text:String}],      // newest first, at most 8, plain words
                result:String,                         // when done: what they handed back, <= 300 chars
                taskIds:[String],                      // tasks they work on
                brain:"Claude"|"Sonnet"|"Opus"|"",     // optional label, shown small as "Skill level: ..." NO: show as "Strength: standard | extra strong" (Sonnet/Claude = standard, Opus = extra strong)
                progress:Number|null,                  // 0-100 ONLY when Claude really knows; never invent; null hides the bar
                order:Number }
tasks/<id>    { id, parentId:String|null,              // null = a main idea
                title:String,                          // <= 80 chars
                plain:String,                          // one or two plain sentences: what this is and why it matters
                state:"todo"|"working"|"waiting"|"done"|"paused",
                waitingFor:"owner"|"cathy"|"rob"|"none",
                workerIds:[String], questionIds:[String],
                note:String,                           // short live note, "" when none
                order:Number, createdAt:ISO, updatedAt:ISO, doneAt:ISO|null,
                createdBy:"claude"|"owner",
                seenAt:ISO|null }                      // when Claude last looked at HER changes to this task (adds, edits, asks)
replies/<askId> { id (= the ask id), targetKind:"worker"|"task", targetId:String,
                state:"seen"|"working"|"answered",
                text:String,                           // the answer, plain words, <= 1200 chars
                from:String,                           // "Claude" or the worker's name
                at:ISO }
taskAdds/<id>   { id, parentId:String|null, title, plain, createdAt:ISO }            // a task SHE adds. Claude "adopts" it by writing tasks/<same id> with createdBy "owner" and seenAt
taskEdits/<taskId> { id (= taskId), title?:String, plain?:String, paused?:Boolean, removed?:Boolean, updatedAt:ISO }   // her changes to ANY task (merge); removed = "please take this task off the list"
asks/<id>       { id, targetKind:"worker"|"task", targetId:String, text:String (<= 600), createdAt:ISO }
```
Effective task = `tasks/<id>` if it exists, else `taskAdds/<id>` shown with `state:"todo"`, `createdBy:"owner"`, `pending:true`; then her `taskEdits` laid on top (title, plain; `paused:true` shows state "paused" with the word "You paused this"; `removed:true` shows it crossed out with "You asked to remove this"). The page never writes `tasks`, `workers` or `replies`.
"Claude has seen it" for her changes: a task add/edit is seen when `tasks/<id>.seenAt >= the add/edit time`; an ask is seen when `replies/<askId>` exists (state seen/working/answered). Until then show the gray chip "You added this · waiting for Claude to see it" (same look and words style as the question chips in 40-status.css). After: "Claude saw it ✓". Answered asks show the answer in a speech bubble.

## 4. Page code API additions (global `QT`)
```
QT.collections gets: 'workers','tasks','replies','taskAdds','taskEdits','asks'     (core)
QT.write.taskAdd({parentId,title,plain}) -> Promise<id>        // id = 'u-' + base36 time + 3 random chars; sets createdAt; ping "Added a task: <title 60 chars>"
QT.write.taskEdit(taskId, patch) -> Promise                    // merge into taskEdits/<taskId>, sets id + updatedAt; ping "Changed a task: <title>"
QT.write.ask({targetKind,targetId,text}) -> Promise<id>        // ping "Question for <worker/task name>: <text 80 chars>"
   (all three follow the existing rules: refuse when QT.offline, retry like QT.retry, ping only if the test succeeded this session and at most one per 20 s)
QT.parts = {                                                    // module 50-parts.js (owner: question)
  current() -> 'questions'|'workers'|'tasks',   go(part, params),
  workers() -> [worker...] sorted,  workerKids(id) -> [worker], workerRoots() -> [worker],
  tasks() -> [effective task...] (see section 3),  taskKids(id) -> [task], taskRoots() -> [task],
  progress(taskId) -> {done, total}   // counts LEAF tasks below it (a task with no children counts itself)
  seen(doc) -> true|false    // for taskAdds/taskEdits/asks: has Claude seen it (rules in section 3)
  counts() -> {questionsWaiting, workersWorking, tasksWaitingForYou, tasksWorking, tasksDone}
}
QT.views.workers, QT.views.tasks        // 51-workers.js (owner: visual), 52-tasks.js (owner: sections)
```
Events: reuse `store` ({collection, ids, initial}); views subscribe themselves and return a cleanup, exactly like the existing views.

## 5. The Workers part (what she sees)
- Top: one friendly line + a "how to read this" fold-out (one short card, remembered closed after she closes it): "Claude is the boss of a farm crew. This page shows who is on the crew, what each one is doing right now, and what they finished. You can ask any worker a question. Your question goes to Claude first, and Claude passes it on."
- Summary strip with live counters: "4 working · 1 waiting · 6 resting · 12 finished". Tap a counter to filter. A "Show finished" toggle (finished are folded into a tidy list at the bottom by default when there are many).
- Cards in a tree: the top card is Claude (kind lead). Under it the teams (kind team), under each team its helpers. Teams and the lead can fold/unfold (keyboard ok). Fold state is remembered.
- A worker card: round badge (icon or initials, colored by state, gentle pulse while working), name, role, the state chip ("Working…" with dots, "Waiting for you", "Resting", "Finished ✓", "Stopped"), the line "Right now: ..." (only when working or waiting), "Started 25 min ago · last update 2 min ago", optional progress bar (only when `progress` is a number), strength label, task chips (tap = go to that task), the last activity lines (fold-out: "What they did"), the result when finished.
- "Ask this worker": a button opens a small text box (max 600 chars) + Send. After sending show her message as a bubble with the chip "Sent · waiting for Claude to see it"; then "Claude saw it ✓"; then the answer bubble ("Answer from <name>"), newest answer opens by itself once. She can see all her old questions and answers on the card (fold-out "Your questions (3)").
- A worker that is finished can still be asked a question: the placeholder says "This worker has finished. Claude will answer from their notes."
- Empty states: friendly text when there are no workers yet ("No crew yet. When Claude has helpers they will show up here.").

## 6. The Tasks part (what she sees)
- Top: a "How to read this" card that is open the first time and remembered closed after. Casual, 5-6 short lines, with a tiny live example drawing of three levels. Must say: a big idea at the top; it breaks into jobs; jobs break into smaller jobs; when the small ones are done the big one is done; the colors (to do, working, waiting for you / Miss Cathy / Rob, done, paused); tap a job to open it; you can add, change and ask.
- Summary strip: "Working now 6 · Waiting for you 3 · Done 24" (tap = filter). A search box (title/plain), filters: All / Working / Waiting / Done / Paused, buttons "Open all" / "Close all".
- **Tree view (must be great):** big ideas as rows at the top level; children indented with elbow connector lines drawn in CSS; each node is a pill card: colored state dot (+ word), title, one-line plain text, "3 of 5 done" mini progress bar for parents, little worker badges, a "Waiting for you" flag that links to the question. Open/close with a caret; opening animates (reduced motion: instant). The whole tree is keyboard friendly (tree pattern: arrows, Enter, Home/End) with `role="tree"`. Finished branches look calm (green, faded a little) and fold themselves unless she opens them.
- **Map view (second step, after the tree is solid):** the same data drawn left to right (levels as columns, curved lines between parent and child) inside its own scroll box; tap a node = same detail panel. A toggle "List | Map". If it cannot be made good in time, ship the tree alone and say so in the report.
- **Detail panel** for the tapped task (under the node on narrow screens; on the right from 1100 px): title, plain text, state chip, who works on it (worker badges), related questions (links), note, dates ("added", "done 2 h ago"), then the buttons: **Add a smaller task**, **Change this task**, **Pause / Resume**, **Ask about this task**, and for her own tasks **Remove**.
- **Add a task:** a small form (title required, "What does it mean? (optional)", where it goes: pick a parent from a list or "a new big idea"). Saves `taskAdds`; the new node appears at once with the pending chip. **Change:** title/plain text. **Ask:** text box like the worker one, shows the answer bubble in the panel.
- Honesty rule: a pending add/edit/pause/remove is shown as pending until Claude saw it; the page never claims work started.
- Empty state: friendly ("No tasks yet. Add the first one with the + button").

## 7. Module ownership (one helper per row; do not edit another helper's file; ask the lead in your report)
| file(s) | owner | what |
|---|---|---|
| `src/js/00-core.js`, `test/mock-claude.js`, `build.py` if needed | **core** | new collections, `QT.write.taskAdd/taskEdit/ask`, mock support for the 6 collections, tests for them in `test/core.test.mjs` |
| `src/js/50-parts.js`, `src/css/50-parts.css` | **question** | the tab strip, hiding the menu in Workers/Tasks, remembering the part, count badges, `QT.parts` (all selectors above), the shared small helpers for "pending/seen" chips and the speech-bubble look, plus short unit tests in `test/parts.test.mjs` |
| `src/js/51-workers.js`, `src/css/51-workers.css` | **visual** | the Workers part |
| `src/js/52-tasks.js`, `src/css/52-tasks.css` | **sections** | the Tasks part (tree first, map second) |
| `tools/terminal_state.py`, `tools/read_answers.py` (add the new lists only), `notes/STATE-FILES.md` | **later** | the live-state tool (section 8) |
| `seed/workers.json`, `seed/tasks.json`, `state/*.json` | **kathy** | the first real crew and task tree (section 9) |
| `test/parts.e2e.test.mjs`, `test/workers.test.mjs`, `test/tasks.test.mjs`, `test/run-all.mjs` | **tester** | browser tests: fit at 3 sizes, keyboard, a11y (axe), live updates, writes, offline, old tests still pass |
Order of work: core first (its API is already written above, others code against the spec at once with the mock); question next (selectors); then visual and sections; later and kathy in parallel; tester writes tests as the parts appear.
Build to your own folder: `python3 build.py --out dist-<yourname>/index.html` (never overwrite `dist/index.html`; the lead does the final build).

## 8. Keeping it live (the lead's tool, owner: later)
The lead keeps two plain files up to date, `T/state/workers.json` and `T/state/tasks.json` (arrays of the documents in section 3, without `_collection`). `python3 -I tools/terminal_state.py sync` reads them, reads the live copy from `outbox/export/<collection>/` (exported by ArtifactData with out_dir) and writes ready-to-send batch files (`set` for new documents, `update`/`set` with `if_version` for changed ones, nothing for unchanged ones, at most 50 per batch, same output style as post_question.py: `outbox/state-<time>/batch-N.json` + `.files.json`, with `--outbox`), plus `terminal_state.py applied BATCH --results ...` like the other tools. Extra commands: `worker ID --state working --now "..." [--activity "..."]`, `task ID --state done`, `adopt TASKADD_ID` (turns her added task into a real one with seenAt), `reply ASKID --state answered --text "..."` and `check` (validates ids, parents exist, no cycles, state words, text length, no jargon words, `now` empty unless working/waiting). Then `read_answers.py` also lists NEW task adds, edits and asks that need a reply. Update `tools/README.md`-style help inside `notes/STATE-FILES.md`.

## 9. The first real content (owner: kathy)
Write `seed/workers.json` and `seed/tasks.json` (arrays, each document with `_collection`) and copies in `state/`. Facts only from files in T/notes (roster.md, STATE.md at scratchpad/STATE.md, prompts/INDEX.md and the briefs). Workers: Claude (lead); teams: "Terminal builders", "Map drawers", "Photos, words and winter crew", "Questions for Miss Cathy and Rob crew", "Site checkers"; helpers under them using the real roster (the 28 spawned helpers; names in plain words like "Map drawer A: Storybook Hills"). State and `now` must match what is true now: finished helpers are `done`, running ones `working` with what the brief says they do; do NOT invent progress numbers. Tasks: main ideas such as "Redraw the farm map", "Winter tree game", "Holiday photos on the home page", "Share pictures", "The 'See the farm in' words", "Small fixes (news, strollers, frog hat, sunflowers, QR signs)", "Old Mac photo copies", "The Terminal itself", "Questions for Miss Cathy and Rob", "Website translations check", "GitHub files private"; each with 2-5 smaller tasks and sub-tasks, states matching her answers so far (see scratchpad/STATE.md Oct 7 section and the owner decisions in notes). Link `questionIds` to real ids in seed/*.json. Plain words for the owner.
