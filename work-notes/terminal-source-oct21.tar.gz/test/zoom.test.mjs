/* Zoom and big-text test (owner: layout).   NODE_PATH=/opt/node22/lib/node_modules node T/test/zoom.test.mjs     Ports 9250-9299.
 * The whole built page (python3 T/build.py) with the mock and the tester's fixtures, at
 *   browser zoom 200% / 300% of a 1366x768 window  = a 683x384 / 455x256 window with 2 / 3 device pixels per CSS pixel
 *   "bigger text": the root font-size forced to 24 px and 32 px at 700x800 and at 1366x768          (light and dark)
 * in 7 views: home, section "other", big custom section, choice question, picture question, Cathy (read-only) question, Done.
 * Checks per view: no sideways scroll; nothing wider than the window / clipped / overlapping / cut off (the tester's measure());
 * the sticky bars (top bar + question bar) cover at most 35% of the window height; every button >= 40 px; every control is reached
 * by Tab and is not hidden under a sticky bar when it has focus; the menu (drop-down or side menu) is usable; text follows the size
 * setting (bigger-text runs); the picture viewer opens, fits, closes with Esc and gives the focus back (picture question).
 * Screenshots: T/shots/zoom-<config>-<view>[-dark].png (a few only).       */
import * as H from './harness.mjs';
import { ok, info, measure } from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';

const CONFIGS = [
  { name: 'zoom200', w: 683, h: 384, dpr: 2 },
  { name: 'zoom300', w: 455, h: 256, dpr: 3 },
  { name: 'font24-700', w: 700, h: 800, fs: 24 },
  { name: 'font32-700', w: 700, h: 800, fs: 32 },
  { name: 'font24-1366', w: 1366, h: 768, fs: 24 },
  { name: 'font32-1366', w: 1366, h: 768, fs: 32 },
];
const VIEWS = [
  { name: 'home', view: 'home', params: {} },
  { name: 'section-other', view: 'section', params: { id: IDS.sections.other } },
  { name: 'section-big', view: 'section', params: { id: IDS.sections.big } },
  { name: 'q-choice', view: 'question', params: { id: IDS.choiceNormal }, q: true },
  { name: 'q-visual', view: 'question', params: { id: IDS.visual }, q: true, pics: true },
  { name: 'q-cathy', view: 'question', params: { id: IDS.readonly }, q: true },
  { name: 'done', view: 'done', params: {} },
];
const ONLY = process.env.ZOOM_ONLY ? new RegExp(process.env.ZOOM_ONLY) : null;   // e.g. ZOOM_ONLY=zoom200 for a quick run
const SHOT = new Set(['home', 'q-visual', 'q-choice']);

const h = await H.start(9250);
const DOCS = seed();
const offenders = new Map();   // text that ignores the size setting: selector -> {px, where[]}

/* ---- things measured inside the page ---- */
const stickyState = () => {
  const vh = innerHeight, tb = document.querySelector('.topbar');
  const qb = document.querySelector('#qt-view .qbar');
  const max = Math.max(0, document.documentElement.scrollHeight - vh);
  window.scrollTo(0, Math.min(max, 400));
  const t = tb ? tb.getBoundingClientRect().bottom : 0;
  let q = 0, qSticky = false;
  if (qb) { const cs = getComputedStyle(qb); qSticky = cs.position === 'sticky'; if (qSticky) q = qb.getBoundingClientRect().bottom; }
  window.scrollTo(0, 0);
  return { vh, topbar: Math.round(t), qbar: Math.round(q), qSticky, cover: Math.max(t, q) / vh, free: qb ? qb.classList.contains('qbar-free') : null };
};
const smallButtons = () => {
  const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && !e.closest('.sr, [hidden]'); };
  const sel = (e) => e.tagName.toLowerCase() + (e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\s+/).slice(0, 3).join('.') : '');
  const out = [];
  document.querySelectorAll('button, a.btn, [role="button"], input[type="checkbox"], input[type="radio"], summary').forEach((e) => {
    if (!vis(e) || e.disabled) return;
    if (e.tagName === 'INPUT' && e.closest('.switch')) { e.closest('.switch'); return; }   // the switch label is the 40 px target
    const r = e.getBoundingClientRect();
    if (r.height < 39.5 || (r.width < 39.5)) out.push(`${sel(e)} "${(e.innerText || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim().slice(0, 24)}" ${Math.round(r.width)}x${Math.round(r.height)}`);
  });
  return out;
};
const textScale = () => {
  const root = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  const bad = new Map();
  const walker = document.createTreeWalker(document.getElementById('app'), NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) {
    if (!n.textContent.trim()) continue;
    const e = n.parentElement;
    if (!e || e.closest('.sr, [hidden], script, style, svg') || !e.getClientRects().length) continue;
    const px = parseFloat(getComputedStyle(e).fontSize);
    if (px / root < 0.7) { const k = e.tagName.toLowerCase() + '.' + String(e.className).trim().split(/\s+/).slice(0, 2).join('.'); if (!bad.has(k)) bad.set(k, px); }
  }
  return { root, bad: [...bad.entries()] };
};
const prep = () => {   // number every visible focusable thing
  const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && !e.closest('[hidden], [inert]'); };
  // Tab stops only: a roving-tabindex group (tabindex=-1, moved with the arrow keys) and what sits in a closed <details> are not Tab stops
  const list = [...document.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), textarea:not([disabled]), select:not([disabled]), summary, [tabindex]:not([tabindex="-1"])')].filter((e) => vis(e) && e.getAttribute('tabindex') !== '-1' && !(e.closest('details:not([open])') && e.tagName !== 'SUMMARY'));
  list.forEach((e, i) => e.setAttribute('data-zt', String(i)));
  return list.length;
};
const focusInfo = () => {
  const e = document.activeElement;
  if (!e || e === document.body || !e.hasAttribute('data-zt')) return { id: -1, tag: e ? e.tagName : '' };
  const r = e.getBoundingClientRect();
  const px = Math.min(Math.max(r.left + r.width / 2, 1), innerWidth - 1), py = Math.min(Math.max(r.top + Math.min(r.height / 2, 12), 1), innerHeight - 1);
  const top = document.elementFromPoint(px, py);
  const inView = r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
  const covered = !!top && !(e === top || e.contains(top) || top.contains(e) || (e.closest('label') && e.closest('label').contains(top)));
  return { id: +e.getAttribute('data-zt'), inView, covered, by: covered && top ? top.tagName.toLowerCase() + '.' + String(top.className).slice(0, 30) : '', name: (e.innerText || e.getAttribute('aria-label') || e.tagName).replace(/\s+/g, ' ').trim().slice(0, 24), tall: r.height > innerHeight };
};
const menuInfo = () => {
  const btn = document.querySelector('.menu-btn'), menu = document.getElementById('qt-menu');
  const narrow = !!btn && getComputedStyle(btn).display !== 'none';
  const r = menu.getBoundingClientRect();
  const main = document.getElementById('qt-main').getBoundingClientRect();
  return { narrow, menuW: Math.round(r.width), mainW: Math.round(main.width), vw: innerWidth };
};

async function tabCheck(page, name, tag) {
  await page.evaluate(() => { window.scrollTo(0, 0); if (document.activeElement) document.activeElement.blur(); });
  const total = await page.evaluate(prep);
  const cap = Math.min(total + 3, 160);
  const seen = new Set(), problems = [];
  for (let i = 0; i < cap; i++) {
    await page.keyboard.press('Tab');
    const f = await page.evaluate(focusInfo);
    if (f.id >= 0) {
      seen.add(f.id);
      if (!f.tall && (!f.inView || f.covered)) problems.push(`#${f.id} "${f.name}" ${!f.inView ? 'is not on screen' : 'is under ' + f.by}`);
    }
    if (seen.size === total) break;
  }
  const miss = seen.size === total ? [] : await page.evaluate((got) => [...document.querySelectorAll('[data-zt]')].filter((e) => !got.includes(+e.getAttribute('data-zt'))).map((e) => `${e.tagName.toLowerCase()}${e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : ''}${e.type ? '[' + e.type + ']' : ''} "${(e.innerText || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim().slice(0, 18)}"`), [...seen]);
  ok(`${tag} ${name}: every control is reached by Tab (${seen.size} of ${total})`, seen.size === total, 'missing: ' + miss.slice(0, 4).join(' | '));
  ok(`${tag} ${name}: a control with the focus is on screen and not under a sticky bar`, problems.length === 0, problems.slice(0, 3).join(' | '));
}

async function viewerCheck(page, tag) {
  const card = page.locator('#qt-view .qtv-card').first();
  if (!(await card.count())) { ok(`${tag} picture viewer: there is a picture to open`, false, 'no .qtv-card'); return; }
  await card.scrollIntoViewIfNeeded();
  await card.click();
  const open = await H.until(page, () => !!document.querySelector('.qtl'), null, 4000);
  ok(`${tag} picture viewer opens`, !!open);
  if (!open) return;
  await H.settle(page, 400);
  const v = await page.evaluate(() => {
    const q = document.querySelector('.qtl'), r = q.getBoundingClientRect(), cl = q.querySelector('.qtl-close'), cr = cl ? cl.getBoundingClientRect() : null;
    const img = q.querySelector('img'), ir = img ? img.getBoundingClientRect() : null;
    const btns = [...q.querySelectorAll('button')].filter((b) => b.getClientRects().length).map((b) => { const x = b.getBoundingClientRect(); return `${b.className.slice(0, 20)} ${Math.round(x.width)}x${Math.round(x.height)}${x.left < -0.5 || x.top < -0.5 || x.right > innerWidth + 0.5 || x.bottom > innerHeight + 0.5 ? ' OUTSIDE' : ''}`; });
    return { inside: r.left >= -1 && r.top >= -1 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1, close: cr ? [Math.round(cr.width), Math.round(cr.height), cr.top >= -0.5 && cr.right <= innerWidth + 0.5 && cr.bottom <= innerHeight + 0.5] : null, img: ir ? [Math.round(ir.width), Math.round(ir.height)] : null, btns, active: document.activeElement && document.activeElement.className, hscroll: document.documentElement.scrollWidth > innerWidth + 1 };
  });
  ok(`${tag} picture viewer fills the window and nothing sticks out`, v.inside && !v.hscroll && !v.btns.some((b) => /OUTSIDE/.test(b)), JSON.stringify(v));
  ok(`${tag} picture viewer: Close is on screen and >= 40 px`, !!v.close && v.close[0] >= 39.5 && v.close[1] >= 39.5 && v.close[2], JSON.stringify(v.close));
  ok(`${tag} picture viewer: the big picture is drawn`, !!v.img && v.img[0] > 20 && v.img[1] > 20, JSON.stringify(v.img));
  // the focus stays inside while tabbing
  let outside = 0;
  for (let i = 0; i < 12; i++) { await page.keyboard.press('Tab'); if (!(await page.evaluate(() => !!document.activeElement && !!document.activeElement.closest('.qtl')))) outside++; }
  ok(`${tag} picture viewer: Tab stays inside the viewer`, outside === 0, outside + ' of 12 presses left it');
  await page.keyboard.press('Escape');
  const closed = await H.until(page, () => !document.querySelector('.qtl'), null, 3000);
  ok(`${tag} picture viewer: Esc closes it`, !!closed);
  const back = await page.evaluate(() => !!document.activeElement && document.activeElement.classList.contains('qtv-card'));
  ok(`${tag} picture viewer: the focus goes back to the picture`, back);
}

for (const scheme of ['light', 'dark']) {
  for (const c of CONFIGS) {
    if (ONLY && !ONLY.test(c.name)) continue;
    const tag = `[${c.name}${scheme === 'dark' ? ' dark' : ''}]`;
    const page = await H.open(h, { docs: DOCS, w: c.w, h: c.h, dpr: c.dpr || 1, scheme, label: tag + ' ' });
    if (c.fs) { await page.addStyleTag({ content: `html{font-size:${c.fs}px!important}` }); await H.settle(page, 250); }   // bigger text: the root font size is forced (rem and em follow it)
    ok(`${tag} app draws`, await H.ready(page));
    const rootFs = await page.evaluate(() => parseFloat(getComputedStyle(document.documentElement).fontSize));
    ok(`${tag} root font size is ${c.fs || 16}px`, Math.abs(rootFs - (c.fs || 16)) < 0.5, String(rootFs));
    for (const v of VIEWS) {
      await H.go(page, v.view, v.params);
      await page.evaluate(() => window.scrollTo(0, 0));
      await H.settle(page, 120);
      const name = v.name;
      const m = await page.evaluate(measure);
      ok(`${tag} ${name}: no sideways scroll`, m.docW <= m.vw + 1 && m.bodyW <= m.vw + 1, `doc ${m.docW} body ${m.bodyW} window ${m.vw}`);
      ok(`${tag} ${name}: nothing wider than the window`, m.wide.length === 0, m.wide.slice(0, 3).join(' | '));
      ok(`${tag} ${name}: no clipped text in buttons / chips`, m.clipped.length === 0, m.clipped.slice(0, 3).join(' | '));
      ok(`${tag} ${name}: nothing drawn on top of anything else`, m.overlap.length === 0, m.overlap.slice(0, 3).join(' | '));
      ok(`${tag} ${name}: no text cut off inside cards, tiles or rows`, m.cut.length === 0, m.cut.slice(0, 3).join(' | '));
      if (v.q && m.story) ok(`${tag} ${name}: the story text is there and not covered`, m.story.shown && m.story.covered === 0 && m.story.left >= -1 && m.story.right <= m.story.vw + 1, JSON.stringify(m.story));
      const st = await page.evaluate(stickyState);
      ok(`${tag} ${name}: sticky bars cover at most 35% of the window (${Math.round(st.cover * 100)}%: top bar ${st.topbar}px${v.q ? ', question bar ' + (st.qSticky ? 'sticky to ' + st.qbar + 'px' : 'not sticky') : ''})`, st.cover <= 0.35 + 0.005, JSON.stringify(st));
      const small = await page.evaluate(smallButtons);
      ok(`${tag} ${name}: every button is at least 40 px`, small.length === 0, small.slice(0, 4).join(' | '));
      if (c.fs) {
        const ts = await page.evaluate(textScale);
        for (const [k, px] of ts.bad) { const o = offenders.get(k) || { px, where: new Set() }; o.where.add(c.name); offenders.set(k, o); }
        ok(`${tag} ${name}: all text follows the bigger text size (no px-sized text under 0.7 x ${ts.root}px)`, ts.bad.length === 0, ts.bad.slice(0, 5).map(([k, px]) => `${k} ${px}px`).join(' | '));
      }
      if (SHOT.has(name) && scheme === 'light') await H.shot(page, `zoom-${c.name}-${name}`);
      await tabCheck(page, name, tag);
      const mi = await page.evaluate(menuInfo);
      if (name === 'home') {
        if (mi.narrow) {
          await page.click('.menu-btn'); await H.settle(page, 120);
          const o = await page.evaluate(() => { const m = document.getElementById('qt-menu'), r = m.getBoundingClientRect(); const items = [...m.querySelectorAll('.mi')]; const last = items[items.length - 1]; last.scrollIntoView({ block: 'nearest' }); const lr = last.getBoundingClientRect(), mr = m.getBoundingClientRect(); return { open: m.classList.contains('open') && r.width > 0, inside: r.left >= -1 && r.top >= -1 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1, lastReachable: lr.top >= mr.top - 1 && lr.bottom <= mr.bottom + 1, scrolls: m.scrollHeight > m.clientHeight + 1, items: items.length, h: Math.round(r.height), vh: innerHeight }; });
          ok(`${tag} menu: the drop-down opens, fits in the window and its last item can be reached`, o.open && o.inside && o.lastReachable, JSON.stringify(o));
          await page.keyboard.press('Escape');
          ok(`${tag} menu: Esc closes the drop-down`, !(await page.evaluate(() => document.getElementById('qt-menu').classList.contains('open'))));
        } else {
          const o = await page.evaluate(() => { const m = document.getElementById('qt-menu'), items = [...m.querySelectorAll('.mi')]; const last = items[items.length - 1]; last.scrollIntoView({ block: 'nearest' }); const lr = last.getBoundingClientRect(), mr = m.getBoundingClientRect(); return { visible: m.getClientRects().length > 0, w: Math.round(mr.width), lastReachable: lr.top >= mr.top - 1 && lr.bottom <= mr.bottom + 1, clippedText: items.filter((i) => i.scrollWidth > i.clientWidth + 1).length }; });
          ok(`${tag} menu: the side menu is there, its last item can be reached, no text sticks out`, o.visible && o.lastReachable && o.clippedText === 0, JSON.stringify(o));
          ok(`${tag} menu: the page keeps room beside the side menu (main ${mi.mainW}px of ${mi.vw}px)`, mi.mainW >= Math.min(320, mi.vw * 0.5), JSON.stringify(mi));
        }
        // the top bar: nothing sticks out, nothing is cut
        const tb = await page.evaluate(() => { const bar = document.querySelector('.topbar'), W = document.documentElement.clientWidth; const bad = []; if (bar.scrollWidth > bar.clientWidth + 1) bad.push('bar scrolls ' + bar.scrollWidth + '>' + bar.clientWidth); for (const e of bar.querySelectorAll('.btn, .brand-t, .hb, .live')) { const b = e.getBoundingClientRect(); if (!b.width) continue; if (b.right > W + 0.5 || b.left < -0.5) bad.push(e.className + ' outside'); if (b.top < -0.5 || b.bottom > bar.getBoundingClientRect().bottom + 0.5) bad.push(e.className + ' vertically outside'); if (e.classList.contains('btn') && e.scrollWidth > e.clientWidth + 1) bad.push(e.className + ' text cut'); } return { h: Math.round(bar.getBoundingClientRect().height), bad }; });
        ok(`${tag} top bar: nothing cut or outside the bar (${tb.h}px high)`, tb.bad.length === 0, JSON.stringify(tb));
      }
      if (v.pics) await viewerCheck(page, `${tag} ${name}:`);
    }
    await page.context().close();
  }
}
if (offenders.size) {
  info('TEXT THAT IGNORES THE BIGGER-TEXT SIZE (px-sized, under 0.7 x root):');
  [...offenders.entries()].slice(0, 40).forEach(([k, o]) => info(`   ${k}  ${o.px}px  in ${[...o.where].join(',')}`));
}
await H.stop(h);
