import * as H from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';
const h = await H.start(9798, { src: true });
try {
  const page = await H.open(h, { docs: seed(), w: 1366, h: 900, label: 'probe: ' });
  await H.ready(page);
  for (const [view, params] of [['question', { id: IDS.visual || 'v-map-1' }], ['question', { id: IDS.visualAnswered }], ['question', { id: 'c-done' }]]) {
    await H.go(page, view, params); await H.settle(page, 800);
    const r = await page.evaluate(() => [...document.querySelectorAll('#qt-view img')].map((i) => ({ src: (i.getAttribute('src') || '').slice(0, 40), nw: i.naturalWidth, complete: i.complete })));
    console.log(view, JSON.stringify(params), JSON.stringify(r));
  }
  console.log('ids', JSON.stringify(Object.keys(IDS)));
} finally { await H.stop(h); }
