/* Tests for the Tasks part (src/js/52-tasks.js, src/css/52-tasks.css): the tree, the detail panel, the add / change / pause / remove / ask forms.
 *
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/tasks-view.test.mjs        (AXE_PATH=.../axe.min.js adds the accessibility checks)
 *
 * Builds the whole page into dist-sections2/index.html (every file in src), loads the task collections into the mock notebook (test/mock-claude.js), opens the Tasks part
 * and drives it with Playwright. What the page writes is read back from window.__mock.writes. Ports 9500-9599. Screenshots: T/shots/tasks/. */
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { startServer, launch, ok, info, finish, okSoon, axeSource } from './lib.mjs';
import { injectMock } from './mockfix.mjs';
import { seed } from './fixtures.mjs';
import { tasksDocs, byCollection } from './tasks.fixture.mjs';

const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = path.join(T, 'shots', 'tasks');
fs.mkdirSync(SHOTS, { recursive: true });
try {
  execFileSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, 'dist-sections2', 'index.html')], { cwd: T, stdio: 'pipe' });
} catch (e) { console.log('FAIL the page builds  ' + String(e.stderr || e.message).split('\n').slice(0, 3).join(' | ')); process.exit(1); }
let site = null;
for (let port = 9500; port <= 9599 && !site; port++) { try { site = await startServer({ root: T, port }); } catch (e) { /* in use */ } }
if (!site) { console.log('FAIL no free port between 9500 and 9599'); process.exit(1); }
const browser = await launch();
const errs = [];
const NOISE = /fonts\.g|net::ERR|Failed to load resource|favicon/;
const AXE = axeSource();

async function open(o = {}) {
  const ctx = await browser.newContext({ viewport: { width: o.w || 700, height: o.h || 800 }, colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference', locale: 'en-US', timezoneId: 'America/New_York' });
  const page = await ctx.newPage();
  page.setDefaultTimeout(10000);
  page.on('pageerror', (e) => errs.push((o.label || '') + 'pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !NOISE.test(m.text()) && !(o.allowConsole && o.allowConsole.test(m.text()))) errs.push((o.label || '') + 'console: ' + m.text()); });
  const docs = o.docs || tasksDocs();
  await page.addInitScript(([how, view, mode]) => { try { if (how) localStorage.setItem('qt.tasks.howto', 'closed'); if (mode) localStorage.setItem('qt.tasks.mode', mode); localStorage.setItem('qt.route', JSON.stringify({ view: 'tasks', params: {} })); } catch (e) { /* none */ } }, [o.how !== false, 'tasks', o.mode || '']);
  await injectMock(page, { ...(o.seed || seed()), ...docs }, o.mock || {});
  await page.goto(site.url + 'dist-sections2/index.html' + (o.q || ''), { waitUntil: 'load' });
  try { await page.waitForSelector(o.empty ? '.tk-empty' : (o.mode === 'map' ? '.tk-mtree' : '.tk-tree'), { state: o.mode === 'map' && !o.empty ? 'attached' : 'visible', timeout: 15000 }); } catch (e) { console.log('OPEN FAILED', o.label, errs.slice(-3).join(' | '), (await page.evaluate(() => (document.getElementById('app') ? document.getElementById('app').innerText : 'no app').slice(0, 300)))); throw e; }
  await settle(page, 200);
  return page;
}
const settle = (page, n = 150) => page.evaluate((t) => new Promise((r) => requestAnimationFrame(() => setTimeout(r, t))), n).catch(() => {});
const shot = async (page, name) => { try { await page.screenshot({ path: path.join(SHOTS, name + '.png') }); } catch (e) { /* closed */ } };
const node = (page, id) => page.locator(`li.tk-node[data-id="${id}"]`);
const card = (page, id) => page.locator(`li.tk-node[data-id="${id}"] > .tk-card`);
const expanded = (page, id) => node(page, id).getAttribute('aria-expanded');
/* what the page wrote, as [kind, ...]: ['taskAdd', doc] ['taskEdit', taskId, patch] ['ask', doc] */
const writes = (page) => page.evaluate(() => window.__mock.writes.filter((w) => /^(taskAdds|taskEdits|asks)\//.test(w.path)).map((w) => {
  if (w.path.startsWith('taskAdds/')) return ['taskAdd', w.data];
  if (w.path.startsWith('asks/')) return ['ask', w.data];
  const { id, updatedAt, ...patch } = w.data; return ['taskEdit', w.path.slice(10), patch];
}));
const put = (page, c, id, d) => page.evaluate(([a, b, x]) => window.__mock.db.put(a + '/' + b, x), [c, id, d]);
const noScrollX = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
const text = (page) => page.evaluate(() => document.getElementById('qt-view').innerText.replace(/\s+/g, ' ').trim());
const iso = (ago = 0) => new Date(Date.now() - ago).toISOString();
const D = () => byCollection(tasksDocs());   // for the live puts: { tasks: { id: doc } }
const docsOf = () => tasksDocs();
const ids = (page) => page.locator('li.tk-node').evaluateAll((els) => els.map((e) => e.getAttribute('data-id')));

/* ================================================================== 1. what is drawn */
{
  const docs = docsOf();
  const page = await open({ label: 'tree ', how: false });
  const total = Object.keys(docs).filter((k) => k.startsWith('tasks/')).length + Object.keys(docs).filter((k) => k.startsWith('taskAdds/') && !docs['tasks/' + k.slice(9)]).length;
  ok('tree: role=tree with one treeitem per task (adds she made included)', (await page.locator('[role=tree]').count()) === 1 && (await page.locator('li[role=treeitem]').count()) === total, `${await page.locator('li[role=treeitem]').count()} vs ${total}`);
  ok('tree: levels 1 to 4 are in aria-level', await page.locator('li[aria-level="4"]').count() > 0 && (await page.locator('li[aria-level="5"]').count()) === 0);
  ok('tree: 8 big ideas at the top (her gift shop page too)', (await page.locator('li[aria-level="1"]').count()) === 8);
  ok('tree: every treeitem has a name from its title', await page.locator('li[role=treeitem]').evaluateAll((els) => els.every((e) => { const n = document.getElementById(e.getAttribute('aria-labelledby')); return n && n.textContent.trim().length > 0; })));
  ok('tree: exactly one treeitem is in the tab order (roving)', (await page.locator('li[role=treeitem][tabindex="0"]').count()) === 1);
  ok('how to read: open the first time, with the words about big ideas, jobs and smaller jobs', (await (async () => { const p = await open({ label: 'how ', how: false }); const t = await text(p); await p.context().close(); return t.includes('How to read this') && t.includes('A big idea sits at the top') && t.includes('Tasks break into smaller tasks') && t.includes('Nothing here changes your real website'); })()));
  /* counters */
  const n = { working: 0, waiting: 0, done: 0, paused: 0 };
  const removed = new Set(Object.keys(docs).filter((k) => k.startsWith('taskEdits/') && docs[k].removed).map((k) => k.slice(10)));
  Object.entries(docs).forEach(([k, v]) => { if (!k.startsWith('tasks/') || removed.has(v.id)) return; const e = docs['taskEdits/' + v.id]; const st = e && e.paused ? 'paused' : v.state; if (st === 'working') n.working++; if (st === 'waiting' && v.waitingFor === 'owner') n.waiting++; if (st === 'done') n.done++; if (st === 'paused') n.paused++; });
  const num = (key) => page.locator(`.tk-count.c-${key} .tk-num`).innerText();
  ok('strip: the counters say how many work, wait for her and are done', (await num('working')) === String(n.working) && (await num('waitingYou')) === String(n.waiting) && (await num('done')) === String(n.done), `${await num('working')}/${await num('waitingYou')}/${await num('done')} vs ${JSON.stringify(n)}`);
  ok('states: every one has a word, not only a colour (To do, Working, Waiting for you, Done, Paused)', await (async () => { const t = await text(page); return ['To do', 'Working', 'Waiting for you', 'Waiting for Miss Cathy', 'Done', 'Paused'].every((w) => t.includes(w)); })());
  ok('states: the dot comes with its word on each card', await page.locator('.tk-card .tk-state').evaluateAll((els) => els.every((e) => e.textContent.trim().length > 2)));
  /* progress */
  const mapBar = page.locator('li[data-id="map"] > .tk-card [role=progressbar]');
  ok('progress: "3 of 7 done" counts the small jobs at the bottom, with a progress bar', (await card(page, 'map').innerText()).includes('3 of 7 done') && (await mapBar.getAttribute('aria-valuenow')) === '3' && (await mapBar.getAttribute('aria-valuemax')) === '7');
  ok('progress: a job without smaller jobs shows no bar', (await card(page, 'map-spring').locator('[role=progressbar]').count()) === 0);
  /* folding */
  ok('fold: a branch that is all finished starts folded and calm', (await expanded(page, 'oldmac')) === 'false' && (await node(page, 'oldmac').getAttribute('class')).includes('finished'));
  ok('fold: a branch with work going on starts open', (await expanded(page, 'map')) === 'true' && (await expanded(page, 'terminal')) === 'true');
  ok('fold: a branch with nothing going on starts closed', (await expanded(page, 'map-phone')) === 'false');
  ok('fold: folded children are hidden from the tab order and from screen readers', await node(page, 'oldmac').locator('> .tk-wrap').evaluate((w) => getComputedStyle(w.firstElementChild).visibility === 'hidden'));
  ok('worker badges: the job shows who works on it', (await card(page, 'map-fall-pump').locator('.tk-wk').count()) === 1 && (await card(page, 'terminal').locator('.tk-wk').count()) === 2);
  ok('waiting for you: the card has a flag that goes to the question', (await card(page, 'map-words').getByRole('button', { name: /Answer the question/ }).count()) === 1 && (await card(page, 'map-words-pond').getByRole('button').count()) === 0);
  await card(page, 'map-words').getByRole('button', { name: /Answer the question/ }).click();
  await settle(page, 200);
  ok('waiting for you: the flag opens that question', (await page.evaluate(() => window.QT.route.current())).view === 'question' && (await page.evaluate(() => window.QT.route.current())).params.id === 'v-map-1');
  await page.context().close();
}

/* ================================================================== 2. open and close, keyboard */
{
  const page = await open({ label: 'keys ', how: false });
  await node(page, 'oldmac').locator('> .tk-card > .tk-caret').click();
  await settle(page, 100);
  ok('open/close: the caret opens a folded branch (and animates: data-open)', (await expanded(page, 'oldmac')) === 'true' && (await node(page, 'oldmac').locator('> .tk-wrap').getAttribute('data-open')) === 'true');
  await node(page, 'oldmac').locator('> .tk-card > .tk-caret').click();
  ok('open/close: ... and closes it again', (await expanded(page, 'oldmac')) === 'false');
  await node(page, 'oldmac').locator('> .tk-card > .tk-caret').click();
  await page.reload({ waitUntil: 'load' }); await page.waitForSelector('.tk-tree'); await settle(page, 200);
  ok('open/close: what she opened is remembered', (await expanded(page, 'oldmac')) === 'true');
  /* keyboard */
  await node(page, 'map').focus();
  await page.keyboard.press('ArrowDown'); await settle(page, 60);
  ok('keyboard: arrow down moves to the next visible job (the first smaller job)', (await page.evaluate(() => document.activeElement.getAttribute('data-id'))) === 'map-seasons');
  await page.keyboard.press('ArrowLeft'); await settle(page, 60);
  ok('keyboard: arrow left closes an open job', (await expanded(page, 'map-seasons')) === 'false');
  await page.keyboard.press('ArrowLeft'); await settle(page, 60);
  ok('keyboard: arrow left on a closed job goes to its parent', (await page.evaluate(() => document.activeElement.getAttribute('data-id'))) === 'map');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowRight'); await settle(page, 60);
  ok('keyboard: arrow right opens a closed job', (await expanded(page, 'map-seasons')) === 'true');
  await page.keyboard.press('ArrowRight'); await settle(page, 60);
  ok('keyboard: arrow right on an open job goes to its first smaller job', (await page.evaluate(() => document.activeElement.getAttribute('data-id'))) === 'map-spring');
  await page.keyboard.press('End'); await settle(page, 60);
  const last = await page.evaluate(() => document.activeElement.getAttribute('data-id'));
  ok('keyboard: End goes to the last visible job', last === 'u-gift', last);
  await page.keyboard.press('Home'); await settle(page, 60);
  ok('keyboard: Home goes to the first one', (await page.evaluate(() => document.activeElement.getAttribute('data-id'))) === 'map');
  ok('keyboard: still exactly one item in the tab order', (await page.locator('li[role=treeitem][tabindex="0"]').count()) === 1);
  await page.keyboard.press('Enter'); await settle(page, 150);
  ok('keyboard: Enter opens the details, and the focus stays on the job', (await page.locator('.tk-detail').count()) === 1 && (await page.evaluate(() => document.activeElement.getAttribute('data-id'))) === 'map' && (await node(page, 'map').getAttribute('aria-selected')) === 'true');
  await page.keyboard.press('Enter'); await settle(page, 150);
  ok('keyboard: Enter again closes them', (await page.locator('.tk-detail').count()) === 0);
  await page.getByRole('button', { name: 'Close all' }).click();
  await settle(page, 100);
  ok('open all / close all: Close all folds every branch', (await page.locator('li.tk-node[aria-expanded="true"]').count()) === 0);
  await page.getByRole('button', { name: 'Open all' }).click();
  ok('open all / close all: Open all opens every branch', (await page.locator('li.tk-node[aria-expanded="false"]').count()) === 0);
  await page.context().close();
}

/* ================================================================== 3. filters and search */
{
  const page = await open({ label: 'filter ', how: false });
  await page.getByRole('button', { name: /^Working \d/ }).click();
  await settle(page, 100);
  const w = await ids(page);
  ok('filter: "Working" shows the working jobs and the big ideas above them, nothing else', w.includes('map-fall-pump') && w.includes('map') && !w.includes('map-spring') && !w.includes('oldmac') && !w.includes('photos'), JSON.stringify(w.slice(0, 12)));
  ok('filter: a filtered tree is opened up so nothing is hidden', (await page.locator('li.tk-node[aria-expanded="false"]').count()) === 0);
  await page.getByRole('button', { name: /^Done \d/ }).click();
  await settle(page, 100);
  const dn = await ids(page);
  ok('filter: "Done" shows the finished jobs', dn.includes('oldmac') && dn.includes('map-spring') && !dn.includes('map-fall-pump'));
  await page.getByRole('button', { name: /^Paused \d/ }).click(); await settle(page, 100);
  const pz = await ids(page);
  ok('filter: "Paused" shows what is paused (Claude\'s and hers)', pz.includes('trans') && pz.includes('tasks-map-view'));
  await page.getByRole('button', { name: /^Waiting \(anyone\) \d/ }).click(); await settle(page, 100);
  ok('filter: "Waiting" shows jobs that wait for her, Miss Cathy or Rob', (await ids(page)).includes('map-words-pond') && (await ids(page)).includes('win-six'));
  await page.locator('.tk-count.c-waitingYou').click(); await settle(page, 100);
  ok('filter: the "Waiting for you" counter narrows it to what waits for HER (not Miss Cathy or Rob)', (await page.locator('.tk-count.c-waitingYou').getAttribute('aria-pressed')) === 'true' && (await ids(page)).includes('win-six') && !(await ids(page)).includes('map-words-pond'));
  await page.locator('.tk-count.c-waitingYou').click(); await settle(page, 100);
  ok('filter: tapping the counter again takes the filter off', (await page.locator('.tk-count.c-waitingYou').getAttribute('aria-pressed')) === 'false' && (await page.getByRole('button', { name: /^All \d/ }).getAttribute('aria-pressed')) === 'true');
  await page.getByLabel('Search the tasks').fill('pond');
  await settle(page, 150);
  const s = await ids(page);
  ok('search: finds words in the title and the plain text, with the path to them', JSON.stringify(s) === JSON.stringify(['map', 'map-words', 'map-words-pond']) || (s.includes('map-words-pond') && s.includes('map') && !s.includes('winter')), JSON.stringify(s));
  await page.getByLabel('Search the tasks').fill('zzzz nothing');
  await settle(page, 150);
  ok('search: nothing found says so and offers a way back', (await text(page)).includes('Nothing matches that.') && (await page.getByRole('button', { name: 'Show everything' }).count()) === 1);
  await page.getByRole('button', { name: 'Show everything' }).click(); await settle(page, 150);
  ok('search: "Show everything" clears it', (await page.getByLabel('Search the tasks').inputValue()) === '' && (await page.locator('li.tk-node').count()) > 40);
  await page.context().close();
}

/* ================================================================== 4. the detail panel */
{
  const page = await open({ label: 'detail ', how: false });
  await card(page, 'map').click();
  await settle(page, 200);
  const dp = page.locator('.tk-detail');
  const t = (await dp.innerText()).replace(/\s+/g, ' ');
  ok('detail: title, plain words, state and progress', t.includes('Redraw the farm map') && t.includes('Make the map on the home page look like the farm') && t.includes('Working') && t.includes('3 of 7 smaller tasks done'));
  ok('detail: who works on it (a button to that worker), dates, and the note', t.includes('Who works on it') && t.includes('Claude') && t.includes('Added 5 days ago') && t.includes('Spring and summer are done'));
  ok('detail: all five kinds of buttons for a Claude task (no Remove)', ['Add a smaller task', 'Change this task', 'Pause', 'Ask about this task'].every((b) => t.includes(b)) && !t.includes('Remove'));
  ok('detail: her questions with their answers', t.includes('Your questions (3)') && t.includes('How many seasons are done?') && t.includes('Answer from Claude') && t.includes('Two of four: spring and summer'));
  ok('detail: an ask Claude saw says so, one it has not seen is "waiting"', t.includes('Claude saw it ✓') && t.includes('Sent · waiting for Claude to see it'));
  await card(page, 'map-words').click(); await settle(page, 200);
  const q = (await page.locator('.tk-detail').innerText()).replace(/\s+/g, ' ');
  ok('detail: related questions are links with their state', q.includes('Questions about it') && q.includes('Waiting for you') && (await page.locator('.tk-detail .tk-qbtn').count()) === 1);
  await page.locator('.tk-detail .tk-qbtn').click(); await settle(page, 150);
  ok('detail: a related question opens', (await page.evaluate(() => window.QT.route.current())).view === 'question');
  await page.evaluate(() => window.QT.route.go('tasks'));
  await page.waitForSelector('.tk-tree'); await settle(page, 200);
  await card(page, 'u-gift').click(); await settle(page, 200);
  const g = (await page.locator('.tk-detail').innerText()).replace(/\s+/g, ' ');
  ok('detail: her own task has Remove, and says it was added by her and Claude has not seen it', g.includes('Remove') && g.includes('You added this · waiting for Claude to see it') && g.includes('by you'));
  await card(page, 'u-seen').click(); await settle(page, 200);
  ok('detail: after Claude has seen her task it says "Claude saw it ✓"', (await page.locator('.tk-detail').innerText()).includes('Claude saw it ✓'));
  await page.locator('.tk-detail').getByRole('button', { name: 'Close the details' }).click(); await settle(page, 100);
  ok('detail: Close closes the panel', (await page.locator('.tk-detail').count()) === 0);
  await page.context().close();
}

/* ================================================================== 5. add, change, pause, remove, ask */
{
  const page = await open({ label: 'forms ', how: false });
  await page.getByRole('button', { name: '+ Add a task' }).click();
  await settle(page, 150);
  ok('add: a form with a name, "What does it mean? (optional)" and where it goes', (await page.getByLabel('Name of the task').count()) === 1 && (await page.getByLabel('What does it mean? (optional)').count()) === 1 && (await page.getByLabel('Where does it go?').count()) === 1);
  await page.getByRole('button', { name: 'Add task' }).click();
  await settle(page, 100);
  ok('add: no name -> nothing is saved, she is asked for a name', (await writes(page)).length === 0 && (await text(page)).includes('Please give the task a name.'));
  await page.getByLabel('Name of the task').fill('Pick a pony name');
  await page.getByLabel('What does it mean? (optional)').fill('For the new pony on the farm.');
  await page.getByLabel('Where does it go?').selectOption('winter');
  await page.getByRole('button', { name: 'Add task' }).click();
  await okSoon('add: saves taskAdd with the parent, title and words', () => writes(page), (w) => w.length === 1 && w[0][0] === 'taskAdd' && w[0][1].parentId === 'winter' && w[0][1].title === 'Pick a pony name' && w[0][1].plain === 'For the new pony on the farm.' && w[0][1].id.startsWith('u-'), 6000);
  const newId = (await writes(page))[0][1].id;
  await okSoon('add: the new job shows at once under its parent, with the pending chip, selected', () => card(page, newId).innerText(), (x) => x.includes('Pick a pony name') && x.includes('You added this · waiting for Claude to see it'), 6000);
  ok('add: it is a child of the Winter tree game and its panel is open', (await node(page, 'winter').locator(`li[data-id="${newId}"]`).count()) === 1 && (await page.locator('.tk-detail').innerText()).includes('Pick a pony name'));
  ok('add: the form is gone and the page says it will be seen', (await page.getByLabel('Name of the task').count()) === 0 && (await text(page)).includes('Claude will see it soon'));
  /* a smaller task from the panel */
  await card(page, 'map').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Add a smaller task' }).click(); await settle(page, 150);
  ok('add from the panel: the place is already "Redraw the farm map"', (await page.getByLabel('Where does it go?').inputValue()) === 'map');
  await page.getByLabel('Name of the task').fill('Draw the barn red');
  await page.getByRole('button', { name: 'Add task' }).click();
  await okSoon('add from the panel: saved under the map', async () => (await writes(page)).filter((w) => w[0] === 'taskAdd').length, (n) => n === 2, 6000);
  ok('add: a new big idea has no parent', await (async () => { await page.getByRole('button', { name: '+ Add a task' }).click(); await settle(page, 100); await page.getByLabel('Where does it go?').selectOption(''); await page.getByLabel('Name of the task').fill('A brand new idea'); await page.getByRole('button', { name: 'Add task' }).click(); await okSoon('x', async () => (await writes(page)).length, (n) => n === 3, 6000); const w = (await writes(page))[2]; return w[1].parentId === null && (await page.locator('li[aria-level="1"]').count()) === 9; })());
  /* change */
  await card(page, 'u-gift').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Change this task' }).click(); await settle(page, 100);
  ok('change: the form starts with what is there now', (await page.locator('.tk-form').getByLabel('Name of the task').inputValue()) === 'Add a gift shop page');
  await page.getByRole('button', { name: 'Save change' }).click(); await settle(page, 150);
  ok('change: nothing changed -> nothing written', (await writes(page)).filter((w) => w[0] === 'taskEdit').length === 0);
  await page.getByRole('button', { name: 'Change this task' }).click(); await settle(page, 100);
  await page.locator('.tk-form').getByLabel('Name of the task').fill('Add a farm shop page');
  await page.getByRole('button', { name: 'Save change' }).click();
  await okSoon('change: writes only the changed title', async () => (await writes(page)).filter((w) => w[0] === 'taskEdit'), (l) => l.length === 1 && l[0][1] === 'u-gift' && JSON.stringify(l[0][2]) === JSON.stringify({ title: 'Add a farm shop page' }), 6000);
  await okSoon('change: the job shows the new name with "Your change · waiting for Claude to see it"', () => card(page, 'u-gift').innerText(), (x) => x.includes('Add a farm shop page'), 6000);
  /* pause / resume */
  await card(page, 'map-fall').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Pause', exact: true }).click();
  await okSoon('pause: writes paused:true', async () => (await writes(page)).filter((w) => w[0] === 'taskEdit' && w[1] === 'map-fall'), (l) => l.length === 1 && l[0][2].paused === true, 6000);
  await okSoon('pause: the job says "You paused this" with the pending chip', () => card(page, 'map-fall').innerText(), (x) => x.includes('You paused this') && x.includes('Your change · waiting for Claude to see it'), 6000);
  ok('pause: the button becomes "Keep going"', (await page.getByRole('button', { name: 'Keep going' }).count()) === 1);
  await page.getByRole('button', { name: 'Keep going' }).click();
  await okSoon('resume: writes paused:false', async () => (await writes(page)).filter((w) => w[0] === 'taskEdit' && w[1] === 'map-fall'), (l) => l.length === 2 && l[1][2].paused === false, 6000);
  /* remove */
  await card(page, 'u-gift').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Remove', exact: true }).click(); await settle(page, 100);
  ok('remove: asks first', (await text(page)).includes('Take this task off the list? Claude will remove it.'));
  await page.getByRole('button', { name: 'Keep it', exact: true }).click(); await settle(page, 100);
  ok('remove: "Keep it" changes nothing', (await writes(page)).filter((w) => w[2] && w[2].removed).length === 0);
  await page.getByRole('button', { name: 'Remove', exact: true }).click();
  await page.getByRole('button', { name: 'Remove it' }).click();
  await okSoon('remove: writes removed:true', async () => (await writes(page)).filter((w) => w[2] && w[2].removed === true), (l) => l.length === 1 && l[0][1] === 'u-gift', 6000);
  await okSoon('remove: the job is crossed out and says "You asked to remove this"', () => card(page, 'u-gift').innerText(), (x) => x.includes('You asked to remove this'), 6000);
  ok('remove: the counters do not count it any more and it has an undo', (await node(page, 'u-gift').getAttribute('class')).includes('removed') && (await page.getByRole('button', { name: 'Keep it after all' }).count()) === 1);
  ok('remove: a Claude task never has Remove', await (async () => { await card(page, 'map-spring').click(); await settle(page, 150); return (await page.getByRole('button', { name: 'Remove', exact: true }).count()) === 0; })());
  /* ask */
  await card(page, 'winter').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Ask about this task' }).click(); await settle(page, 100);
  await page.getByRole('button', { name: 'Send', exact: true }).click(); await settle(page, 100);
  ok('ask: an empty question is not sent', (await writes(page)).filter((w) => w[0] === 'ask').length === 0 && (await text(page)).includes('Please type your question first.'));
  await page.getByLabel('Your question about this task').fill('When will the trees be done?');
  await page.getByRole('button', { name: 'Send', exact: true }).click();
  await okSoon('ask: writes the question for this task', async () => (await writes(page)).filter((w) => w[0] === 'ask'), (l) => l.length === 1 && l[0][1].targetKind === 'task' && l[0][1].targetId === 'winter' && l[0][1].text === 'When will the trees be done?', 6000);
  const askId = (await writes(page)).find((w) => w[0] === 'ask')[1].id;
  await okSoon('ask: her message shows as a bubble with "Sent · waiting for Claude to see it"', () => page.locator('.tk-detail').innerText(), (x) => x.includes('You asked') && x.includes('When will the trees be done?') && x.includes('Your questions (1)') && x.includes('Sent · waiting for Claude to see it'), 6000);
  await put(page, 'replies', askId, { id: askId, targetKind: 'task', targetId: 'winter', state: 'seen', text: '', from: 'Claude', at: iso() });
  await okSoon('ask: "Claude saw it ✓" when Claude has looked', () => page.locator('.tk-detail').innerText(), (x) => x.includes('Claude saw it ✓') && !x.includes('Sent · waiting'), 6000);
  await put(page, 'replies', askId, { id: askId, targetKind: 'task', targetId: 'winter', state: 'answered', text: 'Soon: the last words are being written.', from: 'Claude', at: iso() });
  await okSoon('ask: the answer shows in a bubble', () => page.locator('.tk-detail').innerText(), (x) => x.includes('Answer from Claude') && x.includes('Soon: the last words are being written.'), 6000);
  await shot(page, 'z-forms-700');
  await page.context().close();
  /* failures */
  const pf = await open({ label: 'fail ', how: false, allowConsole: /./ });
  await pf.evaluate(() => { window.__mock.failWrites = true; window.__mock.failCode = 'invalid_argument'; });
  await pf.getByRole('button', { name: '+ Add a task' }).click(); await settle(pf, 80);
  await pf.getByLabel('Name of the task').fill('Will not save');
  await pf.getByRole('button', { name: 'Add task' }).click();
  await okSoon('failure: saving fails -> a plain message and her words stay', () => text(pf), (x) => x.includes('Not saved. Your words are still here. Please try again.'), 6000);
  ok('failure: ... the words are still in the box', (await pf.getByLabel('Name of the task').inputValue()) === 'Will not save');
  await pf.context().close();
}

/* ================================================================== 6. live updates, text kept */
{
  const page = await open({ label: 'live ', how: false });
  const before = await page.locator('.tk-count.c-working .tk-num').innerText();
  const d = D();
  await put(page, 'tasks', 'map-fall-corn', { ...d.tasks['map-fall-corn'], state: 'working', updatedAt: iso() });
  await okSoon('live: a task that starts working moves the counter', () => page.locator('.tk-count.c-working .tk-num').innerText(), (x) => Number(x) === Number(before) + 1, 6000);
  await okSoon('live: ... and its card says Working', () => card(page, 'map-fall-corn').innerText(), (x) => x.includes('Working'), 6000);
  await put(page, 'tasks', 'new-live', { ...d.tasks['map-phone'], id: 'new-live', parentId: 'map', title: 'A job Claude just added', order: 99, state: 'todo' });
  await okSoon('live: a task Claude adds appears under its parent', () => node(page, 'map').locator('li[data-id="new-live"]').count(), (n) => n === 1, 6000);
  await page.getByRole('button', { name: '+ Add a task' }).click(); await settle(page, 120);
  const title = page.getByLabel('Name of the task');
  await title.click(); await title.fill('Half a task name');
  await page.evaluate(() => { const t = document.querySelector('.tk-form input[type=text]'); t.setSelectionRange(5, 9); });
  await put(page, 'tasks', 'map-spring', { ...d.tasks['map-spring'], note: 'changed by Claude', updatedAt: iso() });
  await put(page, 'workers', 'w-map-a', { ...d.workers['w-map-a'], now: 'Something new', updatedAt: iso() });
  await settle(page, 700);
  const st = await page.evaluate(() => { const t = document.querySelector('.tk-form input[type=text]'); return { v: t.value, f: document.activeElement === t, s: t.selectionStart, e: t.selectionEnd }; });
  ok('live: text typed in the add form stays, with focus and selection, when Claude changes things', st.v === 'Half a task name' && st.f && st.s === 5 && st.e === 9, JSON.stringify(st));
  await page.getByRole('button', { name: 'Cancel' }).click();
  /* search box keeps focus */
  const sb = page.getByLabel('Search the tasks');
  await sb.click(); await sb.fill('map');
  await put(page, 'tasks', 'map-summer', { ...d.tasks['map-summer'], note: 'x', updatedAt: iso() });
  await settle(page, 700);
  ok('live: the search box keeps its words and focus', (await sb.inputValue()) === 'map' && (await page.evaluate(() => document.activeElement && document.activeElement.id === 'tk-search')));
  await page.context().close();
}

/* ================================================================== 7. her pending changes (honest chips) */
{
  const page = await open({ label: 'pending ', how: false });
  ok('pending: a task she added shows "You added this · waiting for Claude to see it"', (await card(page, 'u-gift').innerText()).includes('You added this · waiting for Claude to see it') && (await card(page, 'u-prices').innerText()).includes('You added this · waiting for Claude to see it'));
  ok('pending: a change of a title shows "Your change · waiting for Claude to see it" with her new words', (await card(page, 'win-msg').innerText()).includes('final words') && (await card(page, 'win-msg').innerText()).includes('Your change · waiting for Claude to see it'));
  ok('pending: a pause she asked for says "You paused this" and is not claimed as paused by Claude', (await card(page, 'tasks-map-view').innerText()).includes('You paused this') && (await card(page, 'tasks-map-view').innerText()).includes('waiting for Claude to see it'));
  ok('pending: a removal she asked for is crossed out and says so', (await node(page, 'u-old').getAttribute('class')).includes('removed') && (await card(page, 'u-old').textContent()).includes('You asked to remove this'));
  ok('pending: a task Claude has taken over and seen has no waiting chip', !(await card(page, 'u-seen').innerText()).includes('waiting for Claude'));
  await put(page, 'tasks', 'win-msg', { ...D().tasks['win-msg'], seenAt: iso(), updatedAt: iso() });
  await okSoon('pending: once Claude has seen her change the waiting chip goes away', () => card(page, 'win-msg').innerText(), (x) => !x.includes('waiting for Claude'), 6000);
  await page.context().close();
}

/* ================================================================== 8. safe text, right-to-left */
{
  const XSS = '<img src=x onerror="window.__xss=1">';
  const AR = 'هل تريد أن نضيف صفحة جديدة؟';
  const docs = docsOf();
  docs['tasks/map'] = { ...docs['tasks/map'], title: XSS, plain: XSS, note: XSS };
  docs['tasks/map-spring'] = { ...docs['tasks/map-spring'], title: AR };
  docs['workers/w-claude'] = { ...docs['workers/w-claude'], name: XSS, icon: XSS };
  docs['asks/ask-1'] = { ...docs['asks/ask-1'], text: XSS };
  const page = await open({ label: 'xss ', docs, how: false });
  await card(page, 'map').click(); await settle(page, 150);
  ok('safe: HTML in titles, plain words, notes, worker names and questions is plain text', (await page.locator('#qt-view img').count()) === 0 && (await page.evaluate(() => window.__xss === undefined)) && (await card(page, 'map').innerText()).includes('<img src=x'));
  ok('safe: Arabic words line up from the right (dir=auto)', (await page.locator('li[data-id="map-spring"] .tk-title').evaluate((e) => ({ a: e.getAttribute('dir'), d: getComputedStyle(e).direction }))).d === 'rtl');
  await page.context().close();
}

/* ================================================================== 9. empty, offline, focus link */
{
  const e = await open({ label: 'empty ', docs: {}, empty: true, how: false });
  ok('empty: a friendly line and the + button', (await text(e)).includes('No tasks yet.') && (await text(e)).includes('Add the first one with the + button') && (await e.getByRole('button', { name: '+ Add a task' }).count()) === 1);
  await e.getByRole('button', { name: '+ Add a task' }).click(); await settle(e, 100);
  await e.getByLabel('Name of the task').fill('My first task');
  await e.getByRole('button', { name: 'Add task' }).click();
  await okSoon('empty: the first task appears', () => e.locator('li.tk-node').count(), (n) => n === 1, 6000);
  await e.context().close();
  const o = await open({ label: 'offline ', how: false });
  await card(o, 'map').click(); await settle(o, 150);
  await o.evaluate(() => { window.QT.offline = true; window.QT.emit('offline', {}); });
  await settle(o, 200);
  const t = await text(o);
  ok('offline: she can still read, but no button that cannot work (add, change, ask)', t.includes('Redraw the farm map') && t.includes('Not connected yet.') && (await o.getByRole('button', { name: '+ Add a task' }).count()) === 0 && (await o.getByRole('button', { name: 'Ask about this task' }).count()) === 0);
  await o.evaluate(() => { window.QT.offline = false; window.QT.emit('online', {}); });
  await settle(o, 200);
  ok('offline: when the connection is back the buttons come back', (await o.getByRole('button', { name: '+ Add a task' }).count()) === 1 && (await o.getByRole('button', { name: 'Ask about this task' }).count()) === 1);
  await o.context().close();
  const n = await open({ label: 'no db ', how: false, mock: { db: null }, empty: true, allowConsole: /./ });
  ok('no connection and no tasks: a calm line, no + button', (await text(n)).includes('No tasks yet.') && (await text(n)).includes('They will show up here when Claude is connected.') && (await n.getByRole('button', { name: '+ Add a task' }).count()) === 0);
  await n.context().close();
  const f = await open({ label: 'focus ', how: false });
  await f.evaluate(() => window.QT.route.go('tasks', { focus: 'win-hi' }));
  await f.waitForSelector('.tk-tree');
  await okSoon('focus link: route tasks {focus: id} opens the branch above it and selects the task', async () => ({ sel: await node(f, 'win-hi').getAttribute('aria-selected'), open: await expanded(f, 'win-trans'), d: await f.locator('.tk-detail').count() }), (v) => v.sel === 'true' && v.open === 'true' && v.d === 1, 6000);
  await f.context().close();
}

/* ================================================================== 9b. follow-ups: the "for you" counter, one form at a time, the how-to card on a narrow screen */
{
  const page = await open({ label: 'followups ', how: false, w: 700 });
  const shown = () => page.evaluate(() => [...document.querySelectorAll('li.tk-node')].filter((l) => { for (let p = l.parentElement; p; p = p.parentElement) if (p.classList && p.classList.contains('tk-wrap') && p.getAttribute('data-open') === 'false') return false; return true; }).map((l) => l.dataset.id));
  await page.locator('.tk-count.c-waitingYou').click(); await settle(page, 200);
  const you = await shown();
  ok('counter "Waiting for you": only what waits for HER (not Miss Cathy or Rob)', ['map-words', 'win-six', 'ph-pick'].every((i) => you.includes(i)) && !you.includes('map-words-pond') && !you.includes('cathy'), you.join());
  ok('... it says it is pressed, and none of the "Show" buttons is (so it is not mistaken for "Waiting")', (await page.locator('.tk-count.c-waitingYou').getAttribute('aria-pressed')) === 'true' && (await page.locator('.tk-seg button[aria-pressed="true"]').count()) === 0);
  await page.locator('.tk-count.c-waitingYou').click(); await settle(page, 150);
  await page.locator('[data-key="f:waiting"]').click(); await settle(page, 200);
  ok('the "Waiting" button still means anyone (Miss Cathy\'s questions are in it)', (await shown()).includes('map-words-pond') && (await shown()).includes('cathy'));
  await page.locator('[data-key="f:all"]').click(); await settle(page, 150);

  /* only one form open at a time */
  await page.getByRole('button', { name: '+ Add a task' }).click(); await settle(page, 150);
  ok('forms: "+ Add a task" opens the form at the top', (await page.locator('.tk-formcard').count()) === 1);
  await card(page, 'map').click(); await settle(page, 150);
  await page.getByRole('button', { name: 'Change this task' }).click(); await settle(page, 150);
  ok('forms: "Change this task" closes the form at the top (one form at a time)', (await page.locator('.tk-formcard').count()) === 0 && (await page.locator('.tk-detail form').count()) === 1);
  await page.getByRole('button', { name: '+ Add a task' }).click(); await settle(page, 150);
  ok('forms: "+ Add a task" closes the change form', (await page.locator('.tk-formcard').count()) === 1 && (await page.locator('.tk-detail form').count()) === 0);
  await page.getByRole('button', { name: 'Ask about this task' }).click(); await settle(page, 150);
  ok('forms: "Ask about this task" closes the form at the top', (await page.locator('.tk-formcard').count()) === 0 && (await page.locator('.tk-detail form').count()) === 1 && (await page.getByLabel('Your question about this task').count()) === 1);
  await page.getByRole('button', { name: 'Add a smaller task' }).click(); await settle(page, 150);
  ok('forms: "Add a smaller task" closes the ask form', (await page.getByLabel('Your question about this task').count()) === 0 && (await page.locator('.tk-detail form').count()) === 1);
  await page.context().close();

  /* "How to read this": open the first time, but not on a narrow screen where it would push the tasks off the first screen */
  const n = await open({ label: 'how400 ', how: false, w: 400, h: 800 });
  ok('how to read (400 px, first visit): the card starts folded and its button says "Show"', (await n.locator('.tk-how-body').isHidden()) && (await n.locator('.tk-howbtn').innerText()) === 'Show');
  ok('... so the first task is on the first screen', await n.evaluate(() => { const l = document.querySelector('li.tk-node'); return l.getBoundingClientRect().top < window.innerHeight - 40; }));
  await n.locator('.tk-howbtn').click(); await settle(n, 150);
  ok('... "Show" opens it, and it stays open after a reload (she asked for it)', (await n.locator('.tk-how-body').isVisible()) && await (async () => { await n.reload({ waitUntil: 'load' }); await n.waitForSelector('.tk-tree'); await settle(n, 200); return n.locator('.tk-how-body').isVisible(); })());
  await n.context().close();
  const w7 = await open({ label: 'how700 ', how: false, w: 700 });
  ok('how to read (700 px, first visit): open', (await w7.locator('.tk-how-body').isVisible()) && (await w7.locator('.tk-howbtn').innerText()) === 'Hide');
  await w7.context().close();
}

/* ================================================================== 9c. the map */
{
  const mn = (page, id) => page.locator(`li.tk-mn[data-id="${id}"]`);
  const mcard = (page, id) => page.locator(`li.tk-mn[data-id="${id}"] > .tk-mcard`);
  const mids = (page) => page.locator('li.tk-mn').evaluateAll((els) => els.map((e) => e.getAttribute('data-id')));
  const focusedId = (page) => page.evaluate(() => { const a = document.activeElement; return a && a.matches && a.matches('li.tk-mn') ? a.dataset.id : (a ? a.tagName : null); });
  const expandedM = (page, id) => mn(page, id).getAttribute('aria-expanded');

  /* ---- the toggle ---- */
  const page = await open({ label: 'map ', how: false, w: 700 });
  const modes = await page.locator('.tk-modes button').evaluateAll((els) => els.map((b) => b.innerText.trim() + '|' + b.getAttribute('aria-pressed')));
  ok('map: a "List | Map" toggle, List is pressed at first', JSON.stringify(modes) === JSON.stringify(['List|true', 'Map|false']), JSON.stringify(modes));
  ok('map: the toggle is its own group (the filter buttons are still All / Working / Waiting / Done / Paused)', (await page.locator('.tk-seg button').count()) === 5);
  const listVisible = await page.evaluate(() => [...document.querySelectorAll('li.tk-node')].filter((l) => { for (let p = l.parentElement; p; p = p.parentElement) if (p.classList && p.classList.contains('tk-wrap') && p.getAttribute('data-open') === 'false') return false; return true; }).map((l) => l.dataset.id).sort());
  await page.locator('.tk-modes button', { hasText: 'Map' }).click(); await settle(page, 250);
  ok('map: "Map" shows the map instead of the tree', (await page.locator('.tk-mapbox').count()) === 1 && (await page.locator('.tk-tree').count()) === 0 && (await page.locator('.tk-modes button[aria-pressed="true"]').innerText()) === 'Map');
  ok('map: it is remembered (qt.tasks.mode)', (await page.evaluate(() => localStorage.getItem('qt.tasks.mode'))) === 'map');
  const mapIds = (await mids(page)).slice().sort();
  ok('map: the same tasks as the list shows (what is open in the list is open in the map)', JSON.stringify(mapIds) === JSON.stringify(listVisible), `${mapIds.length} vs ${listVisible.length}`);
  ok('map: a region with a name, and a tree inside it (levels, open / closed)', (await page.locator('[role=region][aria-label="Map of the tasks"] [role=tree] li[role=treeitem]').count()) === mapIds.length && (await page.locator('li.tk-mn[aria-level="3"]').count()) > 0);
  ok('map: every task has its name and its state words for screen readers (aria-labelledby, aria-describedby)', await page.locator('li.tk-mn').evaluateAll((els) => els.every((e) => { const a = document.getElementById(e.getAttribute('aria-labelledby')), b = document.getElementById(e.getAttribute('aria-describedby')); return a && a.textContent.trim() && b && b.textContent.trim(); })));
  ok('map: a column heading for each level', JSON.stringify(await page.locator('.tk-mhead').allInnerTexts()) === JSON.stringify(['Big ideas', 'Tasks', 'Smaller tasks', 'Even smaller tasks']), JSON.stringify(await page.locator('.tk-mhead').allInnerTexts()));
  ok('map: the how-to words and counters are still there (strip, search, filters)', (await page.locator('.tk-strip').count()) === 1 && (await page.locator('#tk-search').count()) === 1 && (await page.locator('.tk-seg button').count()) === 5);

  /* ---- the picture: columns, curves ---- */
  const bad = await page.evaluate(() => {
    const lis = [...document.querySelectorAll('li.tk-mn')], R = (e) => e.getBoundingClientRect(), out = [];
    lis.forEach((li) => { const par = li.parentElement.closest('li.tk-mn'); if (par && !(R(li).left >= R(par).right + 20)) out.push('not right of its parent: ' + li.dataset.id); });
    for (let i = 0; i < lis.length; i++) for (let j = i + 1; j < lis.length; j++) { const a = R(lis[i]), b = R(lis[j]); if (a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1) out.push('overlap: ' + lis[i].dataset.id + ' / ' + lis[j].dataset.id); }
    lis.forEach((li) => { const kids = [...li.querySelectorAll(':scope > ul > li.tk-mn')]; if (kids.length) { const f = R(kids[0]), l = R(kids[kids.length - 1]), p = R(li); if (Math.abs((f.top + l.top) / 2 - p.top) > 2) out.push('not centred on its children: ' + li.dataset.id); } });
    const cols = {}; lis.forEach((li) => { const l = li.getAttribute('aria-level'); (cols[l] = cols[l] || new Set()).add(Math.round(R(li).left)); });
    Object.keys(cols).forEach((l) => { if (cols[l].size !== 1) out.push('level ' + l + ' is not one column: ' + [...cols[l]].join(',')); });
    return out;
  });
  ok('map: each level is one column, children are to the right of their parent, nothing overlaps, a parent is centred on its children', bad.length === 0, bad.slice(0, 4).join(' | '));
  const edges = await page.evaluate(() => ({ paths: document.querySelectorAll('svg.tk-mlinks path').length, kids: [...document.querySelectorAll('li.tk-mn')].filter((l) => l.parentElement.closest('li.tk-mn')).length, hidden: document.querySelector('svg.tk-mlinks').getAttribute('aria-hidden') }));
  ok('map: one curved line for every parent-child pair (a picture only, hidden from screen readers)', edges.paths === edges.kids && edges.paths > 5 && edges.hidden === 'true', JSON.stringify(edges));
  ok('map: the lines are curves that end at the cards', await page.evaluate(() => { const p = document.querySelector('svg.tk-mlinks path'); return /^M[\d. ]+C/.test(p.getAttribute('d')); }));
  const box = await page.evaluate(() => { const b = document.querySelector('.tk-mapbox'), cs = getComputedStyle(b); return { ox: cs.overflowX, oy: cs.overflowY, sw: b.scrollWidth, cw: b.clientWidth, sh: b.scrollHeight, ch: b.clientHeight, vh: innerHeight }; });
  ok('map: it scrolls inside its own box (sideways and up and down), not the page', /auto|scroll/.test(box.ox) && /auto|scroll/.test(box.oy) && box.sw > box.cw && box.ch <= box.vh * 0.76 && await noScrollX(page), JSON.stringify(box));
  ok('map: the level headings stay at the top while the map scrolls up and down', await page.evaluate(async () => { const b = document.querySelector('.tk-mapbox'), h = document.querySelector('.tk-mheads'); b.scrollTop = 150; await new Promise((r) => setTimeout(r, 80)); return Math.abs(h.getBoundingClientRect().top - b.getBoundingClientRect().top) < 3 && getComputedStyle(h).position === 'sticky'; }));
  await page.evaluate(() => { document.querySelector('.tk-mapbox').scrollTop = 0; });
  await shot(page, 'map-700x800');

  /* ---- tapping a task ---- */
  await mcard(page, 'map-fall').click(); await settle(page, 250);
  ok('map: tapping a task selects it and opens the same details panel (below the map at 700 px)', (await mn(page, 'map-fall').getAttribute('aria-selected')) === 'true' && (await page.locator('.tk-detail').count()) === 1 && (await page.locator('.tk-detail .tk-dtitle').innerText()) === 'Fall map' && await page.evaluate(() => document.querySelector('.tk-detail').getBoundingClientRect().top >= document.querySelector('.tk-mapbox').getBoundingClientRect().bottom - 1));
  ok('map: the panel has the same buttons as in the list', JSON.stringify(await page.locator('.tk-detail [data-key^="a-"]').evaluateAll((els) => els.map((b) => b.dataset.key))) === JSON.stringify(['a-add', 'a-edit', 'a-pause', 'a-ask']));
  ok('map: the path from the big idea to the task and its smaller tasks is drawn stronger', (await page.locator('svg.tk-mlinks path.hl').count()) === 4, String(await page.locator('svg.tk-mlinks path.hl').count()));
  ok('map: the selected card has a clear outline', parseFloat(await mcard(page, 'map-fall').evaluate((e) => getComputedStyle(e).outlineWidth)) >= 2);
  await page.getByRole('button', { name: 'Ask about this task' }).click(); await settle(page, 150);
  await page.getByLabel('Your question about this task').fill('Is the corn done?');
  await put(page, 'tasks', 'map-phone', { ...D().tasks['map-phone'], note: 'x', updatedAt: iso() });
  await settle(page, 700);
  ok('map: a redraw does not lose what she typed in the panel', (await page.getByLabel('Your question about this task').inputValue()) === 'Is the corn done?');
  await page.getByRole('button', { name: 'Cancel' }).click(); await settle(page, 100);
  await mcard(page, 'map-fall').click(); await settle(page, 200);
  ok('map: tapping it again closes the panel', (await page.locator('.tk-detail').count()) === 0 && (await mn(page, 'map-fall').getAttribute('aria-selected')) === 'false');

  /* ---- fold, shared with the list ---- */
  const kids0 = (await mids(page)).length;
  ok('map: a finished branch is folded and says how many are inside ("+2")', (await expandedM(page, 'oldmac')) === 'false' && (await mn(page, 'oldmac').locator(':scope > .tk-mtog').innerText()) === '+2' && !(await mids(page)).includes('om-1'));
  await mn(page, 'oldmac').locator(':scope > .tk-mtog').click(); await settle(page, 250);
  ok('map: the small round button opens it: its tasks appear in the next column', (await expandedM(page, 'oldmac')) === 'true' && (await mids(page)).includes('om-1') && (await mids(page)).includes('om-2') && (await mids(page)).length === kids0 + 2 && (await mn(page, 'oldmac').locator(':scope > .tk-mtog').innerText()) === '−');
  await page.locator('.tk-modes button', { hasText: 'List' }).click(); await settle(page, 250);
  ok('map: the List shows the same fold state (Old Mac is open there too)', (await node(page, 'oldmac').getAttribute('aria-expanded')) === 'true' && (await page.locator('.tk-tree').count()) === 1 && (await page.locator('.tk-mapbox').count()) === 0);
  await page.locator('.tk-modes button', { hasText: 'Map' }).click(); await settle(page, 250);
  await mn(page, 'oldmac').locator(':scope > .tk-mtog').click(); await settle(page, 250);
  ok('map: ... and the button closes it again', (await expandedM(page, 'oldmac')) === 'false' && (await mids(page)).length === kids0);
  await page.locator('[data-key="openall"]').click(); await settle(page, 300);
  const allCount = (await mids(page)).length;
  ok('map: "Open all" opens every branch', allCount > kids0 && await page.locator('li.tk-mn[aria-expanded]').evaluateAll((els) => els.every((e) => e.getAttribute('aria-expanded') === 'true')), `${kids0} -> ${allCount}`);
  await page.locator('[data-key="closeall"]').click(); await settle(page, 300);
  ok('map: "Close all" leaves only the big ideas', (await mids(page)).length === 8 && (await page.locator('li.tk-mn[aria-level="2"]').count()) === 0);
  await page.locator('[data-key="openall"]').click(); await settle(page, 300);
  await shot(page, 'map-open-all-700');

  /* ---- keyboard ---- */
  await page.locator('[data-key="closeall"]').click(); await settle(page, 200);
  await mn(page, 'map').focus();
  await page.keyboard.press('ArrowRight'); await settle(page, 200);
  ok('map keys: Right on a closed task opens it (and keeps the focus)', (await expandedM(page, 'map')) === 'true' && (await focusedId(page)) === 'map', await focusedId(page));
  await page.keyboard.press('ArrowRight'); await settle(page, 120);
  ok('map keys: Right on an open task goes to its first smaller task', (await focusedId(page)) === 'map-seasons', await focusedId(page));
  await page.keyboard.press('ArrowDown'); await settle(page, 100);
  ok('map keys: Down goes to the next task in the same column', (await focusedId(page)) === 'map-words', await focusedId(page));
  await page.keyboard.press('ArrowUp'); await settle(page, 100);
  ok('map keys: Up goes back', (await focusedId(page)) === 'map-seasons', await focusedId(page));
  await page.keyboard.press('ArrowRight'); await settle(page, 150);
  ok('map keys: Right on a closed one opens it; now its tasks are in the column to the right', (await expandedM(page, 'map-seasons')) === 'true' && (await mids(page)).includes('map-fall'));
  await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowDown'); await settle(page, 150);
  ok('map keys: Right then Down walk the next column (map-spring -> map-summer)', (await focusedId(page)) === 'map-summer', await focusedId(page));
  await page.keyboard.press('Home'); await settle(page, 100);
  ok('map keys: Home is the top of the column', (await focusedId(page)) === 'map-spring', await focusedId(page));
  await page.keyboard.press('End'); await settle(page, 100);
  ok('map keys: End is the bottom of the column', (await focusedId(page)) !== 'map-spring' && (await page.evaluate(() => document.activeElement.getAttribute('aria-level'))) === '3');
  await page.keyboard.press('ArrowLeft'); await settle(page, 100);
  ok('map keys: Left goes back to the bigger task', (await focusedId(page)) === 'map-seasons', await focusedId(page));
  await page.keyboard.press('ArrowLeft'); await settle(page, 150);
  ok('map keys: Left on an open task closes it', (await expandedM(page, 'map-seasons')) === 'false' && (await focusedId(page)) === 'map-seasons');
  await page.keyboard.press('Enter'); await settle(page, 200);
  ok('map keys: Enter opens the details (and the task stays in focus)', (await mn(page, 'map-seasons').getAttribute('aria-selected')) === 'true' && (await page.locator('.tk-detail .tk-dtitle').innerText()) === 'Draw the four seasons' && (await focusedId(page)) === 'map-seasons', await focusedId(page));
  ok('map keys: the focus ring is easy to see', parseFloat(await mcard(page, 'map-seasons').evaluate((e) => getComputedStyle(e).outlineWidth)) >= 2);
  await page.locator('[data-key="closeall"]').focus();
  let inTree = 0;
  for (let i = 0; i < 12; i++) { await page.keyboard.press('Tab'); if (await page.evaluate(() => !!(document.activeElement && document.activeElement.closest && document.activeElement.closest('.tk-mtree')))) inTree++; }
  ok('map keys: Tab stops ONCE in the map (the other cards are reached with the arrows)', inTree === 1, String(inTree));

  /* ---- filters and search work on the map too ---- */
  await page.locator('[data-key="f:waiting"]').click(); await settle(page, 250);
  let ids = await mids(page);
  ok('map filter "Waiting": the waiting tasks and the bigger tasks above them; done ones are gone; no fold buttons while filtering', ['map-words-pond', 'win-six', 'ph-pick', 'map', 'map-words'].every((i) => ids.includes(i)) && !ids.includes('oldmac') && !ids.includes('map-spring') && (await page.locator('.tk-mtog').count()) === 0, ids.join());
  await page.locator('.tk-count.c-waitingYou').click(); await settle(page, 250);
  ids = await mids(page);
  ok('map: the "Waiting for you" counter shows only what waits for her', ids.includes('win-six') && !ids.includes('map-words-pond') && !ids.includes('cathy'), ids.join());
  await page.locator('.tk-count.c-waitingYou').click(); await page.locator('[data-key="f:all"]').click(); await settle(page, 200);
  await page.fill('#tk-search', 'pond'); await settle(page, 300);
  ids = await mids(page);
  ok('map search "pond": her new task and the tasks above it', ids.includes('u-pend-1') || ids.includes('map-words-pond'), ids.join());
  await page.fill('#tk-search', 'no such thing'); await settle(page, 300);
  ok('map: nothing found says so and the map is gone', (await text(page)).includes('Nothing matches that.') && (await page.locator('.tk-mapbox').count()) === 0);
  await page.locator('[data-key="clearf"]').click(); await settle(page, 300);
  ok('map: "Show everything" brings it back', (await page.locator('.tk-mapbox').count()) === 1 && (await page.inputValue('#tk-search')) === '');

  /* ---- honest chips on the cards ---- */
  await page.locator('[data-key="openall"]').click(); await settle(page, 300);
  const pend = await mcard(page, 'u-gift').innerText();
  ok('map: a task she just added says "Not seen yet", with a dashed card (and the full words for screen readers)', pend.includes('Not seen yet') && (await mn(page, 'u-gift').evaluate((e) => e.classList.contains('pending'))) && (await mcard(page, 'u-gift').locator('.sr').first().textContent()).includes('Waiting for Claude to see it'), pend);
  ok('map: ... also a task she changed', (await mcard(page, 'win-msg').innerText()).includes('Not seen yet') && (await mn(page, 'win-msg').locator('.tk-mtitle').innerText()).includes('final words'));
  ok('map: "3 of 7" and a little bar on a big task', (await mcard(page, 'map').innerText()).includes('3 of 7') && (await mcard(page, 'map').locator('.tk-mbar i').evaluate((e) => e.style.width)) === '43%');
  ok('map: a task that waits for her, Miss Cathy or Rob says who', (await mcard(page, 'map-words').innerText()).includes('Waiting for you') && (await mcard(page, 'map-words-pond').innerText()).includes('Waiting for Miss Cathy'));
  ok('map: a removed task is crossed out and says so', (await mn(page, 'u-old').locator('.tk-mtitle').evaluate((e) => getComputedStyle(e).textDecorationLine)) === 'line-through' && (await mcard(page, 'u-old').innerText()).includes('You asked to remove this'));

  /* ---- live: new task, scroll position stays ---- */
  await page.evaluate(() => { const b = document.querySelector('.tk-mapbox'); b.scrollLeft = 140; b.scrollTop = 220; });
  await settle(page, 150);
  const before = await page.evaluate(() => ({ x: document.querySelector('.tk-mapbox').scrollLeft, y: document.querySelector('.tk-mapbox').scrollTop }));
  await put(page, 'tasks', 'map-fall-new', { ...D().tasks['map-fall-corn'], id: 'map-fall-new', title: 'A brand new smaller task', parentId: 'map-fall', order: 99 });
  await okSoon('map live: a new task shows up in its column', () => mids(page), (l) => l.includes('map-fall-new'), 6000);
  const after = await page.evaluate(() => ({ x: document.querySelector('.tk-mapbox').scrollLeft, y: document.querySelector('.tk-mapbox').scrollTop }));
  ok('map live: ... and the map does not jump (it stays where she scrolled it)', Math.abs(after.x - before.x) <= 2 && Math.abs(after.y - before.y) <= 2, JSON.stringify([before, after]));
  await put(page, 'tasks', 'map-fall-new', { ...D().tasks['map-fall-corn'], id: 'map-fall-new', title: 'A brand new smaller task', parentId: 'map-fall', order: 99, state: 'working' });
  await okSoon('map live: a state change shows at once', () => mcard(page, 'map-fall-new').innerText(), (x) => x.includes('Working'), 6000);
  await page.context().close();

  /* ---- the focus link, the new-task form, offline ---- */
  const f = await open({ label: 'map focus ', how: false, mode: 'map' });
  await f.evaluate(() => window.QT.route.go('tasks', { focus: 'win-hi' }));
  await okSoon('map focus link: route tasks {focus} opens the branch above, selects the task and scrolls it into the box', () => f.evaluate(() => { const li = document.querySelector('li.tk-mn[data-id="win-hi"]'); if (!li) return null; const r = li.getBoundingClientRect(), b = document.querySelector('.tk-mapbox').getBoundingClientRect(); return { sel: li.getAttribute('aria-selected'), inBox: r.left >= b.left - 1 && r.right <= b.right + 1 && r.top >= b.top - 1 && r.bottom <= b.bottom + 1, panel: !!document.querySelector('.tk-detail') }; }), (v) => v && v.sel === 'true' && v.inBox && v.panel, 8000);
  await f.getByRole('button', { name: '+ Add a task' }).first().click(); await settle(f, 150);
  await f.getByLabel('Name of the task').fill('Pick a pony name');
  await f.getByRole('button', { name: 'Add task' }).click();
  await okSoon('map: a task she adds shows at once on the map, selected, with the "not seen yet" mark', () => f.locator('li.tk-mn > .tk-mcard', { hasText: 'Pick a pony name' }).first().innerText().catch(() => ''), (x) => x.includes('Not seen yet'), 6000);
  await f.evaluate(() => { window.QT.offline = true; window.QT.emit('offline', {}); });
  await settle(f, 250);
  ok('map offline: she can still read the map; the panel says "Not connected yet." and has no buttons that cannot work', (await f.locator('.tk-mapbox').count()) === 1 && (await f.getByRole('button', { name: '+ Add a task' }).count()) === 0 && (await text(f)).includes('Not connected yet.'));
  await f.context().close();

  /* ---- safe text, right to left ---- */
  const XSS = '<img src=x onerror=alert(1)>';
  const docs = docsOf();
  docs['tasks/map'] = { ...docs['tasks/map'], title: XSS };
  docs['tasks/map-spring'] = { ...docs['tasks/map-spring'], title: 'هل تريد أن نضيف صفحة جديدة؟' };
  const x = await open({ label: 'map xss ', docs, how: false, mode: 'map' });
  ok('map safe: HTML in a title is plain text on the card', (await x.locator('#qt-view img').count()) === 0 && (await mcard(x, 'map').innerText()).includes('<img src=x') && (await x.evaluate(() => window.__xss === undefined)));
  ok('map safe: Arabic words line up from the right (dir=auto)', (await mn(x, 'map-spring').locator('.tk-mtitle').evaluate((e) => ({ a: e.getAttribute('dir'), d: getComputedStyle(e).direction }))).d === 'rtl');
  await x.context().close();

  /* ---- sizes, text size, motion ---- */
  for (const [w, h] of [[400, 800], [700, 800], [1366, 768], [1920, 1080]]) {
    const p = await open({ w, h, label: 'map size' + w + ' ', how: false, mode: 'map' });
    await mcard(p, 'map-fall').click(); await settle(p, 250);
    ok(`map size ${w}x${h}: no sideways scroll of the page, even with a panel open`, await noScrollX(p));
    const small = await p.evaluate(() => [...document.querySelectorAll('li.tk-mn, .tk-mtog')].filter((e) => { const r = e.getBoundingClientRect(); return r.width && (r.height < 39.5 || r.width < 39.5); }).map((e) => (e.dataset.id || e.className) + ' ' + Math.round(e.getBoundingClientRect().width) + 'x' + Math.round(e.getBoundingClientRect().height)));
    ok(`map size ${w}x${h}: every card and fold button is at least 40 px`, small.length === 0, small.slice(0, 3).join(' | '));
    const cut = await p.evaluate(() => [...document.querySelectorAll('.tk-mcard')].filter((c) => { const t = c.querySelector('.tk-mtitle'), m = c.querySelector('.tk-mmeta'); return t && m && (t.getBoundingClientRect().bottom > c.getBoundingClientRect().bottom || m.getBoundingClientRect().bottom > c.getBoundingClientRect().bottom + 0.5); }).length);
    ok(`map size ${w}x${h}: the title and the words under it fit inside every card`, cut === 0, String(cut));
    if (w === 1366) ok('map size 1366: the details sit on the right, beside the map', await p.evaluate(() => { const a = document.querySelector('.tk-aside'), t = document.querySelector('.tk-treecol'); return !!a && a.querySelector('.tk-detail') && a.getBoundingClientRect().left > t.getBoundingClientRect().right - 2; }));
    if (w === 400) ok('map size 400: the panel opens below the map', await p.evaluate(() => !document.querySelector('.tk-aside') && document.querySelector('.tk-detail').getBoundingClientRect().top >= document.querySelector('.tk-mapbox').getBoundingClientRect().bottom - 1));
    if (w === 700 || w === 1366 || w === 1920 || w === 400) await shot(p, `map-${w}x${h}`);
    await p.context().close();
  }
  const z = await open({ label: 'map zoom ', how: false, mode: 'map' });
  const w1 = await mn(z, 'map').evaluate((e) => e.getBoundingClientRect().width);
  await z.evaluate(() => { document.documentElement.style.fontSize = '24px'; }); await settle(z, 200);
  const w2 = await mn(z, 'map').evaluate((e) => e.getBoundingClientRect().width);
  ok('map zoom: with bigger text the cards and the whole map grow with it (rem), nothing is cut', Math.abs(w2 / w1 - 1.5) < 0.05 && (await z.evaluate(() => [...document.querySelectorAll('.tk-mcard')].every((c) => c.querySelector('.tk-mtitle').getBoundingClientRect().bottom <= c.getBoundingClientRect().bottom + 0.5))), `${w1} -> ${w2}`);
  await z.context().close();
  const rm = await open({ label: 'map reduced ', reduced: true, how: false, mode: 'map' });
  ok('map reduced motion: no transitions on the cards, no pulsing dots', (await rm.evaluate(() => getComputedStyle(document.querySelector('.tk-mcard')).transitionDuration)) === '0s' && (await rm.evaluate(() => getComputedStyle(document.querySelector('.tk-mn .tk-dot.st-working')).animationName)) === 'none');
  await rm.context().close();
  const em = await open({ label: 'map empty ', docs: {}, empty: true, how: false, mode: 'map' });
  ok('map empty: a friendly line, no empty map', (await text(em)).includes('No tasks yet.') && (await em.locator('.tk-mapbox').count()) === 0);
  await em.context().close();
  if (AXE) for (const scheme of ['light', 'dark']) {
    const p = await open({ label: 'map axe ' + scheme + ' ', scheme, how: false, w: 700, mode: 'map' });
    const run = async (name) => { await p.addScriptTag({ content: AXE }).catch(() => {}); const v = await p.evaluate(async () => { const r = await window.axe.run(document.getElementById('qt-view'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa', 'best-practice'] } }); return r.violations.map((q) => q.id + ' (' + q.nodes.length + 'x) ' + q.nodes.slice(0, 2).map((n) => n.target.join(' ')).join(' ## ')); }); ok(`[${scheme}] map ${name}: axe finds no problems`, v.length === 0, v.join(' || ').slice(0, 500)); };
    await run('the map');
    await mcard(p, 'map-words').click(); await settle(p, 250);
    await run('the map with the details');
    await p.locator('[data-key="openall"]').click(); await settle(p, 300);
    await run('the whole map open');
    await p.context().close();
  }
}

/* ================================================================== 10. sizes, targets, motion, accessibility */
{
  for (const [w, h] of [[400, 800], [700, 800], [1366, 768], [1920, 1080]]) {
    const page = await open({ w, h, label: 'size' + w + ' ', how: false });
    await card(page, 'map').click(); await settle(page, 150);
    ok(`size ${w}x${h}: no sideways scroll, even with a panel open`, await noScrollX(page));
    const small = await page.evaluate(() => [...document.querySelectorAll('#qt-view button, #qt-view input:not([type=hidden]), #qt-view select, #qt-view textarea')].filter((e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width && r.height && cs.visibility !== 'hidden' && !e.closest('.sr') && (r.height < 39.5 || r.width < 39.5); }).map((e) => (e.className || e.tagName) + ' ' + Math.round(e.getBoundingClientRect().height)));
    ok(`size ${w}x${h}: every button and field is at least 40 px`, small.length === 0, small.slice(0, 4).join(' | '));
    if (w === 700 || w === 1366 || w === 1920) await shot(page, `t-${w}x${h}`);
    if (w === 1366) ok('size 1366: the details sit on the right, beside the tree', await page.evaluate(() => { const a = document.querySelector('.tk-aside'), t = document.querySelector('.tk-treecol'); return !!a && a.getBoundingClientRect().left > t.getBoundingClientRect().right - 2; }));
    if (w === 700) ok('size 700: the details open under the job, inside the tree', await page.evaluate(() => !!document.querySelector('li.tk-node > .tk-detail') && !document.querySelector('.tk-aside')));
    await page.context().close();
  }
  const rm = await open({ label: 'reduced ', reduced: true, how: false });
  const m = await rm.evaluate(() => ({ wrap: getComputedStyle(document.querySelector('.tk-wrap')).transitionDuration, dot: getComputedStyle(document.querySelector('.tk-dot.st-working')).animationName }));
  ok('reduced motion: no transitions, no pulsing dots', m.wrap === '0s' && m.dot === 'none', JSON.stringify(m));
  await rm.context().close();
  if (!AXE) info('axe-core is not installed: the accessibility checks were skipped');
  else for (const scheme of ['light', 'dark']) {
    const page = await open({ label: 'axe ' + scheme + ' ', scheme, how: false, w: 700 });
    const run = async (name) => { await page.addScriptTag({ content: AXE }).catch(() => {}); const v = await page.evaluate(async () => { const r = await window.axe.run(document.getElementById('qt-view'), { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'best-practice'] } }); return r.violations.map((x) => x.id + ' (' + x.impact + ') ' + x.nodes.length + ' e.g. ' + x.nodes[0].html.slice(0, 100)); }); ok(`[${scheme}] axe: ${name} has no problems`, v.length === 0, v.join(' || ').slice(0, 600)); };
    await run('the tree');
    await card(page, 'map-words').click(); await settle(page, 200);
    await run('the tree with the details');
    await page.getByRole('button', { name: 'Ask about this task' }).click(); await settle(page, 150);
    await run('the ask form');
    await page.getByRole('button', { name: '+ Add a task' }).click(); await settle(page, 150);
    await run('the add form');
    await page.context().close();
  }
}

info('screenshots: T/shots/tasks/*.png');
await finish({ browser, site, errs });
