/* Seed test: the REAL starter content (T/seed/*.json) shown in the REAL page at 700x800.   Port range 9780-9789.
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/seed.test.mjs
 * For every question: opens without error, no sideways scroll, no cut-off or clipped text, the bar shows the title (at most 2 lines), the answer buttons
 * are there (4 choices, or none for read-only), nothing is left unstyled. Also: the lists (every section), counts in the menu, and a short content check
 * (title length, 4 choices, jargon words) so a typo in a seed file is caught here too.  Prints the tallest questions.
 */
import fs from 'node:fs';
import path from 'node:path';
import * as H from './harness.mjs';
import { ok, info, measure } from './harness.mjs';
import { seedFromFiles } from './mockfix.mjs';

const SEEDDIR = path.join(H.T, 'seed');
const files = fs.readdirSync(SEEDDIR).filter((f) => f.endsWith('.json')).sort((a, b) => (a === 'sections.json' ? -1 : b === 'sections.json' ? 1 : a.localeCompare(b))).map((f) => path.join(SEEDDIR, f));
if (!files.length) { ok('seed files exist (T/seed/*.json)', false, 'none found'); process.exit(1); }
// ids that two files (or one file twice) both use: the second would silently replace the first
const idSeen = {}, repeated = [];
for (const f of files) { let list = []; try { list = JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { ok(`seed: ${path.basename(f)} is valid JSON`, false, e.message); continue; } for (const d of list) { const k = d._collection + '/' + d.id; if (idSeen[k]) repeated.push(`${k} (${idSeen[k]} and ${path.basename(f)})`); else idSeen[k] = path.basename(f); } }
ok('seed: no document id is used twice across all the seed files', repeated.length === 0, repeated.slice(0, 5).join(' | '));
const docs = seedFromFiles(...files);
const seedSecIds = new Set(Object.keys(docs).filter((p) => p.startsWith('sections/')).map((p) => p.slice('sections/'.length)));
// Her own sections: she made them on the page, so they are in her notebook but not in the seed files, and the seed may put questions there.
// The ids come from her live notebook (not from us; the spelling of the first one is hers). Any other section id in the seed is a typo.
const HER_SECTIONS = { 'website-control-pannle': 'Website control panel' };
for (const [id, title] of Object.entries(HER_SECTIONS)) {
  if (!Object.values(docs).some((d) => d && d.sectionId === id) || docs['sections/' + id]) continue;
  const tpl = docs['sections/look'] || Object.values(docs).find((d) => d && d.kind === 'builtin') || {};
  docs['sections/' + id] = { ...tpl, id, title, kind: 'custom', order: 30 + Object.keys(HER_SECTIONS).indexOf(id), size: 'big', hold: false, readOnly: false, archived: false, createdBy: 'owner' };
}
const byColl = {};
for (const p of Object.keys(docs)) { const c = p.split('/')[0]; (byColl[c] = byColl[c] || []).push(docs[p]); }
const Q = byColl.questions || [];
info(`seed: ${files.map((f) => path.basename(f)).join(', ')} -> ${Object.entries(byColl).map(([c, l]) => l.length + ' ' + c).join(', ')}`);

/* ---------- content checks (in Node) ---------- */
const JARGON = /\b(json|api|database|token|deploy|commit|sync(?:hronize)?|asset|screenshots?|backend|frontend|endpoint|repo(?:sitory)?|webhook|cache|server|localstorage)\b/i;
{
  const ids = new Set(); const dups = [];
  for (const q of Q) { if (ids.has(q.id)) dups.push(q.id); ids.add(q.id); }
  ok('seed: every question id is unique', dups.length === 0, dups.join(','));
  ok('seed: ids use only lowercase letters, digits, - and _', Q.every((q) => /^[a-z0-9_-]+$/.test(q.id)), Q.filter((q) => !/^[a-z0-9_-]+$/.test(q.id)).map((q) => q.id).slice(0, 5).join(','));
  const secIds = new Set([...seedSecIds, ...Object.keys(HER_SECTIONS)]);
  ok('seed: every question belongs to a section of the seed (look, other, later, kathy, downloads) or to one of her own sections', Q.every((q) => secIds.has(q.sectionId)), Q.filter((q) => !secIds.has(q.sectionId)).map((q) => q.id + '->' + q.sectionId).slice(0, 5).join(','));
  ok('seed: the four built-in sections are in the seed files', ['look', 'other', 'later', 'kathy'].every((id) => seedSecIds.has(id)), [...seedSecIds].join(','));
  ok('seed: kind is choice, visual or readonly', Q.every((q) => ['choice', 'visual', 'readonly'].includes(q.kind)), Q.filter((q) => !['choice', 'visual', 'readonly'].includes(q.kind)).map((q) => q.id).slice(0, 5).join(','));
  const long = Q.filter((q) => String(q.title || '').length > 110);
  ok('seed: every title is 110 characters or less', long.length === 0, long.map((q) => q.id + ' ' + q.title.length).slice(0, 5).join(','));
  const noTitle = Q.filter((q) => !String(q.title || '').trim());
  ok('seed: every question has a title', noTitle.length === 0, noTitle.map((q) => q.id).join(','));
  const badChoices = Q.filter((q) => q.kind === 'choice' && !(Array.isArray(q.choices) && q.choices.length === 4 && q.choices.every((c, i) => c.key === 'ABCD'[i] && String(c.label || '').trim() && String(c.explain || '').trim())));
  ok('seed: every choice question has exactly 4 choices A-D with label and explanation', badChoices.length === 0, badChoices.map((q) => q.id).slice(0, 8).join(','));
  const badStory = Q.filter((q) => q.kind !== 'visual' && !(Array.isArray(q.story) && q.story.length >= 1 && q.story.length <= 4));
  ok('seed: story is 1 to 4 paragraphs', badStory.length === 0, badStory.map((q) => q.id + ':' + (q.story || []).length).slice(0, 8).join(','));
  const ro = Q.filter((q) => q.sectionId === 'kathy');
  ok(`seed: the ${ro.length} Miss Kathy questions are read-only and say who should answer and what is needed`, ro.length > 0 && ro.every((q) => q.kind === 'readonly' && ['kathy', 'rob', 'adviser', 'owner', 'unknown'].includes(q.who) && String(q.needs || '').trim()), ro.filter((q) => !(q.kind === 'readonly' && q.who && String(q.needs || '').trim())).map((q) => q.id).slice(0, 8).join(','));
  const jarg = [];
  for (const q of Q) { const t = [q.title, ...(q.story || []), q.why, q.ownTip, q.needs, ...(q.choices || []).flatMap((c) => [c.label, c.explain])].join(' \n '); const m = JARGON.exec(t); if (m) jarg.push(q.id + ':' + m[0]); }
  ok('seed: no tech words in the texts she reads', jarg.length === 0, jarg.slice(0, 10).join(', '));
  const emo = Q.filter((q) => /[\u{1F300}-\u{1FAFF}]/u.test(q.title));
  ok('seed: no emoji in titles (they turn into empty boxes on some computers)', emo.length === 0, emo.map((q) => q.id).join(','));
  const placeholders = Q.filter((q) => /\b(lorem|TODO|TBD|xxx|\?\?\?)\b/i.test(JSON.stringify(q)));
  ok('seed: no placeholder text left (lorem, TODO, TBD)', placeholders.length === 0, placeholders.map((q) => q.id).slice(0, 8).join(','));
  const orders = {};
  for (const q of Q) { const k = q.sectionId + ':' + q.order; (orders[k] = orders[k] || []).push(q.id); }
  const dupOrd = Object.entries(orders).filter(([, v]) => v.length > 1);
  if (dupOrd.length) info(`NOTE: ${dupOrd.length} places where two questions in a section have the same order number (e.g. ${dupOrd.slice(0, 3).map(([k, v]) => k + ' = ' + v.join('+')).join('; ')})`);
}

/* ---------- the real page ---------- */
const h = await H.start(9781);
await H.block('every question at 700x800', async () => {
  const page = await H.open(h, { docs, w: 700, h: 800, label: 'seed: ' });
  ok('seed: the app draws', await H.ready(page));
  const rows = [];
  const bad = { wide: [], clipped: [], contrast: [], bar: [], choices: [], err: [] };
  let n = 0;
  for (const q of Q) {
    await H.go(page, 'question', { id: q.id });
    const before = page.__errs.length;
    const m = await page.evaluate(measure);
    const extra = await page.evaluate(() => ({ choices: document.querySelectorAll('#qt-view .qa-choice').length, extras: document.querySelectorAll('#qt-view [data-fid^="x-"]').length, title: (document.querySelector('#qt-view .qbar-title') || {}).innerText || '', barH: (document.querySelector('#qt-view .qbar') || { getBoundingClientRect: () => ({ height: 0 }) }).getBoundingClientRect().height, h1s: document.querySelectorAll('#qt-view h1').length }));
    n++;
    if (m.docW > m.vw + 1 || m.wide.length) bad.wide.push(q.id + ' ' + m.wide.slice(0, 1).join(''));
    if (m.clipped.length) bad.clipped.push(q.id + ' ' + m.clipped[0]);
    if (m.contrast.length) bad.contrast.push(q.id + ' ' + m.contrast[0].ratio + ' ' + m.contrast[0].text);
    if (!extra.title.trim() || extra.barH > 90 || extra.h1s !== 1) bad.bar.push(`${q.id} bar ${Math.round(extra.barH)} px, ${extra.h1s} h1`);
    const want = q.kind === 'choice' ? 4 : q.kind === 'visual' ? (q.versions || []).length : 0;
    if (extra.choices !== want) bad.choices.push(`${q.id} ${q.kind}: ${extra.choices} buttons, expected ${want}`);
    if (q.kind === 'readonly' && extra.extras) bad.choices.push(`${q.id} read-only shows ${extra.extras} answer helpers`);
    if (page.__errs.length > before) bad.err.push(q.id + ' ' + page.__errs.slice(before).join(' | ').slice(0, 120));
    rows.push({ id: q.id, kind: q.kind, section: q.sectionId, docH: m.docH, title: q.title });
  }
  ok(`seed: all ${n} questions open and draw`, bad.err.length === 0, bad.err.slice(0, 4).join(' || '));
  ok('seed: no question needs sideways scrolling or has anything wider than the window', bad.wide.length === 0, bad.wide.slice(0, 5).join(' | '));
  ok('seed: no clipped text in buttons or chips', bad.clipped.length === 0, bad.clipped.slice(0, 4).join(' | '));
  ok('seed: text colours are readable everywhere', bad.contrast.length === 0, bad.contrast.slice(0, 4).join(' | '));
  ok('seed: the question bar shows the title in at most 2 lines (<= 90 px) and each page has one h1', bad.bar.length === 0, bad.bar.slice(0, 5).join(' | '));
  ok('seed: every question shows the right answer buttons (4 choices / one per picture / none when read-only)', bad.choices.length === 0, bad.choices.slice(0, 5).join(' | '));
  const tall = rows.filter((r) => r.kind !== 'readonly').sort((a, b) => b.docH - a.docH);
  const noScroll = rows.filter((r) => r.kind !== 'readonly' && r.docH <= 801).length;
  info(`seed: at 700x800, ${noScroll} of ${rows.filter((r) => r.kind !== 'readonly').length} answerable questions need NO scrolling; the tallest: ` + tall.slice(0, 5).map((r) => `${r.id} ${r.docH}px`).join(', '));
  const med = tall.map((r) => r.docH).sort((a, b) => a - b)[Math.floor(tall.length / 2)];
  info(`seed: median page height for answerable questions: ${med} px (window 800 px)`);
  await page.context().close();
});

await H.block('every section list', async () => {
  for (const [w, hh] of [[700, 800], [1366, 768]]) {
    const page = await H.open(h, { docs, w, h: hh, label: `seed-lists ${w}: ` });
    await H.ready(page);
    for (const s of (byColl.sections || [])) {
      await H.go(page, 'section', { id: s.id });
      const m = await page.evaluate(measure);
      const name = `seed [${w}x${hh}] section ${s.id}`;
      ok(`${name}: no sideways scroll, nothing wider than the window`, m.docW <= m.vw + 1 && m.wide.length === 0, m.wide.slice(0, 2).join(' | '));
      ok(`${name}: no clipped text, readable colours`, m.clipped.length === 0 && m.contrast.length === 0, [...m.clipped, ...m.contrast.map((c) => c.ratio + ' ' + c.text)].slice(0, 3).join(' | '));
      const nQ = Q.filter((q) => q.sectionId === s.id).length;
      const txt = await H.viewText(page);
      ok(`${name}: shows its ${nQ} questions (the list or a clear count)`, nQ === 0 || txt.includes(String(nQ)) || (await page.evaluate(() => document.querySelectorAll('#qt-view button.sx-qmain, #qt-view .item').length)) >= Math.min(nQ, 3), `view text ${txt.length} chars`);
      await H.shot(page, `seed-section-${s.id}-${w}x${hh}`);
    }
    await H.go(page, 'home');
    const home = await page.evaluate(measure);
    ok(`seed [${w}x${hh}] home: no sideways scroll, readable`, home.docW <= home.vw + 1 && home.wide.length === 0 && home.contrast.length === 0, home.wide.slice(0, 2).join(' | ') + (home.contrast[0] ? ' ' + home.contrast[0].text : ''));
    const counts = await page.evaluate(() => ({ title: document.title, kathy: (document.querySelector('.mi[data-key="s:kathy"] .count') || {}).innerText }));
    const waiting = Q.filter((q) => q.kind !== 'readonly').length;
    ok(`seed [${w}x${hh}]: tab title counts every question she can answer (${waiting})`, new RegExp('^\\(' + waiting + '\\) ').test(counts.title), counts.title);
    ok(`seed [${w}x${hh}]: the Miss Kathy number in the menu is ${Q.filter((q) => q.kind === 'readonly').length}`, Number(counts.kathy) === Q.filter((q) => q.kind === 'readonly').length, String(counts.kathy));
    ok(`seed [${w}x${hh}]: no page errors`, page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
    await page.context().close();
  }
});

await H.stop(h);
