/* Stale heartbeat in the top bar: the words "(Claude may be busy)" are visible, bar is 44px, nothing clipped, at 700 and 400 (and in between).  Port 9206. */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const { ok, info } = H;
const h = await H.start(9206);
const p = await H.open(h, { docs: seed({ stale: true }), w: 700, h: 800 });
for (const w of [360, 400, 440, 520, 640, 660, 679, 680, 700, 740, 760, 780, 800, 819, 840, 900, 1000, 1100, 1200, 1366]) {
  await p.setViewportSize({ width: w, height: 800 }); await H.settle(p, 100);
  const r = await p.evaluate(() => {
    const bar = document.querySelector('.topbar'), hb = bar.querySelector('.hb'), W = document.documentElement.clientWidth, bad = [];
    for (const e of bar.querySelectorAll('.btn, .live, .hb, .brand-t, .tb-main')) {
      const b = e.getBoundingClientRect(); if (!b.width) continue;
      if (b.right > W + 0.5 || b.left < -0.5) bad.push(e.className + ' outside');
      if (b.top < -0.5 || b.bottom > 44.5) bad.push(e.className + ' vertical ' + Math.round(b.top) + '..' + Math.round(b.bottom));
    }
    // is the hint really painted inside its box (not cut off)?
    const ex = hb.querySelector('.hb-extra'); let cut = false;
    if (ex) { const rg = document.createRange(); rg.selectNodeContents(ex); const rs = [...rg.getClientRects()]; const hr = hb.getBoundingClientRect();
      const cs = getComputedStyle(hb); cut = hb.scrollWidth > hb.clientWidth + 1 || hb.scrollHeight > hb.clientHeight + 1 || rs.some((q) => q.right > hr.right + 1 || q.bottom > hr.bottom + 1); }
    const wh = hb.querySelector('.hb-when'), wr = wh && wh.getBoundingClientRect(), hr2 = hb.getBoundingClientRect();
    const timeOk = !!wh && getComputedStyle(wh).display !== 'none' && wr.width > 0 && wr.left >= hr2.left - 1 && wr.right <= hr2.right + 1 && wr.bottom <= hr2.bottom + 1 && hb.scrollWidth <= hb.clientWidth + 1;
    if (!timeOk) bad.push('the time is cut or hidden');
    return { barH: bar.getBoundingClientRect().height, bad, cut, stage: hb.getAttribute('data-stage'), aside: bar.querySelector('.tb-main').classList.contains('aside'), text: hb.innerText.replace(/\s+/g, ' '), visible: ex ? getComputedStyle(ex).display !== 'none' : false, title: getComputedStyle(bar.querySelector('.brand-t')).display, lines: Math.round(hb.getBoundingClientRect().height / 15) };
  });
  ok(`[${w}px] stale hint visible, bar 44px, nothing outside/clipped`, r.barH === 44 && r.visible && !r.cut && r.bad.length === 0 && /may be busy/i.test(r.text), JSON.stringify(r));
  info(`[${w}px] "${r.text}" title=${r.title} hbLines~${r.lines}`);
  if ([400, 700, 820].includes(w)) await H.shot(p, `layout-stale-${w}`);
}
await H.stop(h);
