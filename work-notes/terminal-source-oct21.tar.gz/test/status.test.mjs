/* Test for the status helper (src/js/40-status.js + src/css/40-status.css).
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/status.test.mjs
 * Runs the module alone in test/status-harness.html (a small fake of the core: test/status-stub.js), with a fake Web Audio and a fake
 * `window.claude.use("comments")`.  Port 9600 (status helper range 9600-9699).
 * Pass ONLY=integration to skip the single-module tests, SKIP_INTEGRATION=1 to skip the check against the full page (T/dist/index.html).
 */
import path from 'node:path';
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { startServer, launch, ok, info, finish, ms, until } from './lib.mjs';
import { injectMock, sampleSeed, waitReady } from './mockfix.mjs';

const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = path.join(T, 'shots');
const PORT = Number(process.env.STATUS_PORT) || 9600;
const T0 = Date.parse('2026-10-07T12:00:00Z');
const iso = (msAgo) => new Date(T0 - msAgo).toISOString();
const MIN = 60 * 1000;

if (!process.env.QT_NOBUILD) {
  // the module with the real core but without the other helpers (own folder, nobody else uses it), and the full page if it is not there yet
  try { execFileSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, 'dist-status', 'index.html'), '--only', '40-status.js'], { cwd: T, stdio: 'pipe' }); } catch (e) { info('could not build dist-status: ' + String(e.stderr || e.message).split('\n')[0]); }
  { try { execFileSync('python3', [path.join(T, 'build.py')], { cwd: T, stdio: 'pipe' }); } catch (e) { info('could not build dist'); } }
}
const site = await startServer({ root: T, port: PORT });
const browser = await launch();
const errs = [];

/* ---------- what runs in the page before anything else ---------- */
const INIT = `(() => {
  const A = (window.__audio = { created: 0, starts: 0, stops: 0 });
  function Ctx() {
    if (window.__audioThrows) throw new Error('no audio here');
    A.created++; this.currentTime = 0; this.state = window.__audioState || 'running'; this.destination = {};
    this.resume = () => Promise.resolve();
  }
  const node = () => { const n = { connect(x) { return x || n; }, disconnect() {}, start() { A.starts++; }, stop() { A.stops++; }, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} };
    n.frequency = n.gain = n; n.type = ''; n.value = 0; return n; };
  Ctx.prototype.createOscillator = node; Ctx.prototype.createGain = node;
  window.AudioContext = Ctx; window.webkitAudioContext = Ctx;

  const cm = (window.__cm = { present: true, can: 'available', canThrows: false, failQueue: [], calls: [], n: 0 });
  const take = () => (cm.failQueue.length ? cm.failQueue.shift() : null);
  const comments = {
    canSendToClaude: async () => { cm.calls.push({ fn: 'can' }); if (cm.canThrows) throw { code: 'capability_removed', message: 'old' }; return cm.can; },
    anchorFor: async (el) => { cm.calls.push({ fn: 'anchor', tag: el && el.tagName }); return { path: 'body', x: 1, y: 2 }; },
    sendToClaude: async (t) => {
      cm.calls.push({ fn: 'send', t: JSON.parse(JSON.stringify(t)), at: Date.now() });
      const f = take();
      if (f) throw { code: f, message: 'x ' + f };
      return { threadId: t.threadId || 'thr-' + ++cm.n, commentId: 'c' + cm.calls.length };
    },
  };
  window.claude = { use: async (n) => (n === 'comments' && cm.present ? comments : null) };
  window.__act = true;
  Object.defineProperty(navigator, 'userActivation', { get: () => ({ isActive: window.__act !== false, hasBeenActive: true }), configurable: true });
})();`;

async function newPage(o = {}) {
  const ctx = await browser.newContext({ viewport: { width: o.w || 700, height: o.h || 800 }, colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference', locale: 'en-US', timezoneId: 'America/New_York' });
  const page = await ctx.newPage();
  page.setDefaultTimeout(ms(15000));
  page.on('pageerror', (e) => errs.push((o.label || '') + 'pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|Failed to load resource/.test(m.text())) errs.push((o.label || '') + 'console: ' + m.text()); });
  await page.addInitScript(INIT);
  if (o.init) await page.addInitScript(o.init);
  await page.clock.install({ time: new Date(T0) });
  await page.goto(site.url + (o.url || 'test/status-harness.html'), { waitUntil: 'load' });
  return page;
}
const load = async (page, docs) => { await page.evaluate((d) => window.__load(d), docs); await page.evaluate(async () => { await QT.ready; await Promise.resolve(); await Promise.resolve(); }); };
const put = (page, c, id, doc) => page.evaluate(([a, b, d]) => window.__put(a, b, d), [c, id, doc]);
const calls = (page) => page.evaluate(() => window.__cm.calls.filter((c) => c.fn === 'send'));
const starts = (page) => page.evaluate(() => window.__audio.starts);
const chimeCount = async (page) => Math.round((await starts(page)) / 3);
const enableSound = (page) => page.evaluate(() => QT.sound.set(true));
const flush = (page) => page.evaluate(async () => { for (let i = 0; i < 8; i++) await Promise.resolve(); });
const section = (id, extra = {}) => Object.assign({ id, title: id, kind: 'custom', order: 1, size: 'small', hold: false, readOnly: false, archived: false }, extra);
const question = (id, sectionId, extra = {}) => Object.assign({ id, sectionId, kind: 'choice', order: 1, title: 'Title of ' + id, createdAt: iso(10 * MIN) }, extra);

const only = process.env.ONLY || '';

/* =========================================================================================== 1. state machine */
if (only !== 'integration') {
  const page = await newPage({ label: 'state ' });
  await load(page, { sections: { look: section('look') } });
  const T1 = '2026-10-07T10:00:00.000Z', T2 = '2026-10-07T10:05:00.000Z', T3 = '2026-10-07T10:10:00.000Z', T5 = '2026-10-07T10:20:00.000Z';
  const ans = (at) => ({ id: 'q1', status: 'answered', key: 'A', label: 'Yes', answeredAt: at });
  const st = (state, o = {}) => Object.assign({ id: 'q1', state }, o);
  const CASES = [
    ['no answer, no status', null, null, 'waiting'],
    ['no answer, status "seen"', null, st('seen', { seenAt: T1 }), 'waiting'],
    ['answer, no status doc', ans(T1), null, 'answeredUnseen'],
    ['answer newer than seenAt', ans(T2), st('seen', { seenAt: T1 }), 'answeredUnseen'],
    ['seenAt newer than answer', ans(T1), st('seen', { seenAt: T2 }), 'seen'],
    ['seenAt equal to answer time', ans(T1), st('seen', { seenAt: T1 }), 'seen'],
    ['answer + working (seen after)', ans(T1), st('working', { seenAt: T2, note: 'x' }), 'working'],
    ['answer + done (seen after)', ans(T1), st('done', { seenAt: T2, doneNote: 'ok' }), 'done'],
    ['answer + followup', ans(T1), st('followup', { seenAt: T2, followupId: 'q2' }), 'followup'],
    ['answer + held', ans(T1), st('held', { seenAt: T2 }), 'held'],
    ['answer changed AFTER Claude marked it done', ans(T3), st('done', { seenAt: T1, at: T5 }), 'answeredUnseen'],
    ['answer + working, answer newer than seenAt', ans(T3), st('working', { seenAt: T2 }), 'answeredUnseen'],
    ['status without seenAt, "at" is newer than the answer', ans(T1), st('working', { at: T2 }), 'working'],
    ['status without seenAt and "at" older than the answer', ans(T3), st('working', { at: T1 }), 'answeredUnseen'],
    ['no answer, working', null, st('working', { note: 'doing it' }), 'working'],
    ['no answer, done', null, st('done', { doneNote: 'n' }), 'done'],
    ['no answer, held', null, st('held'), 'held'],
    ['no answer, followup', null, st('followup'), 'followup'],
    ['unknown state word with a seen answer', ans(T1), st('weird', { seenAt: T2 }), 'seen'],
    ['answer with a broken time stamp, status seen', { id: 'q1', status: 'answered', key: 'A', answeredAt: 'nonsense' }, st('seen', { seenAt: T2 }), 'seen'],
    ['skipped answer ("not sure") counts as answered', { id: 'q1', status: 'skipped', key: 'unsure', answeredAt: T1 }, null, 'answeredUnseen'],
  ];
  const got = await page.evaluate((cases) => cases.map(([name, a, s]) => {
    delete QT.store.answers.q1; delete QT.store.status.q1;
    if (a) QT.store.answers.q1 = a;
    if (s) QT.store.status.q1 = s;
    return [name, QT.status.state('q1')];
  }), CASES);
  CASES.forEach((c, i) => ok('state: ' + c[0] + ' -> ' + c[3], got[i][1] === c[3], got[i][1] === c[3] ? '' : 'got ' + got[i][1]));
  await page.context().close();
}

/* =========================================================================================== 2. chip words, look, live update */
if (only !== 'integration') {
  const page = await newPage({ label: 'chip ' });
  await load(page, { sections: { look: section('look'), kathy: section('kathy', { readOnly: true, kind: 'builtin' }) }, questions: { q1: question('q1', 'look'), q2: question('q2', 'look', { title: 'Follow-up' }), k1: question('k1', 'kathy', { kind: 'readonly' }) } });
  const T1 = '2026-10-07T10:00:00.000Z', T2 = '2026-10-07T10:05:00.000Z';
  const WORDS = {
    waiting: 'Waiting for you',
    answeredUnseen: 'You answered · waiting for Claude to see it',
    seen: 'Claude saw it ✓',
    working: 'Claude is working on it',
    done: 'Done ✓',
    followup: 'Claude has a follow-up question',
    held: 'Paused \u2013 you asked Claude to wait',
  };
  const setDocs = (a, s) => page.evaluate(([a, s]) => { delete QT.store.answers.q1; delete QT.store.status.q1; if (a) QT.store.answers.q1 = a; if (s) QT.store.status.q1 = s; }, [a, s]);
  const A1 = { id: 'q1', status: 'answered', key: 'A', label: 'Yes', answeredAt: T1 };
  const LONGNOTE = 'I made the map picture bigger and moved the words to the left. Then I checked it on a small phone screen and on a big computer screen.';
  const SC = {
    waiting: [null, null],
    answeredUnseen: [A1, null],
    seen: [A1, { id: 'q1', state: 'seen', seenAt: T2 }],
    working: [A1, { id: 'q1', state: 'working', seenAt: T2, note: 'Making version B bigger' }],
    done: [A1, { id: 'q1', state: 'done', seenAt: T2, doneNote: LONGNOTE }],
    followup: [A1, { id: 'q1', state: 'followup', seenAt: T2, followupId: 'q2' }],
    held: [A1, { id: 'q1', state: 'held', seenAt: T2 }],
  };
  for (const [state, [a, s]] of Object.entries(SC)) {
    await setDocs(a, s);
    const r = await page.evaluate(() => {
      const app = document.getElementById('app'); app.textContent = '';
      const c = QT.status.chip('q1'); app.appendChild(c);
      const pill = c.querySelector('.qt-pill');
      return { state: c.getAttribute('data-state'), text: c.textContent.replace(/\s+/g, ' ').trim(), pill: pill ? pill.querySelector('.qt-pill-text').textContent : null, cls: pill ? pill.className : '',
        title: c.title, dots: c.querySelectorAll('.dots i').length, dotsHidden: c.querySelector('.dots') ? c.querySelector('.dots').getAttribute('aria-hidden') : null,
        icons: [...c.querySelectorAll('svg')].map((v) => v.getAttribute('aria-hidden')), note: c.querySelector('.qt-note') ? c.querySelector('.qt-note').textContent : null, link: !!c.querySelector('.qt-link'), hidden: c.hidden };
    });
    ok('chip ' + state + ': words are "' + WORDS[state] + '"', r.pill === WORDS[state] && r.state === state, JSON.stringify(r.pill));
    ok('chip ' + state + ': has an accessible tooltip', r.title.length > 5, r.title);
    // colours: red (accent) ONLY for "Waiting for you"; "working" is calm blue (info)
    ok('chip ' + state + ': ' + (state === 'waiting' ? 'red (accent) = needs her' : 'not red'), (/\baccent\b/.test(r.cls)) === (state === 'waiting'), r.cls);
    if (state === 'working') ok('chip working: calm blue (info), not red', /\binfo\b/.test(r.cls) && !/\baccent\b/.test(r.cls), r.cls);
    ok('chip ' + state + ': icons are hidden from screen readers', r.icons.every((v) => v === 'true'));
    if (state === 'working') {
      ok('chip working: three animated dots, hidden from screen readers', r.dots === 3 && r.dotsHidden === 'true');
      ok('chip working: shows the note line', r.note === 'Making version B bigger', r.note);
    } else ok('chip ' + state + ': no dots', r.dots === 0);
    if (state === 'seen') ok('chip seen: says how long ago ("· 1 hour ago"), never a clock time', /✓\s*·\s*(\d+ min ago|\d+ hours? ago|\d+ days? ago|just now)$/.test(r.text) && !/\d:\d\d/.test(r.text), r.text);
    if (state === 'done') {
      ok('chip done: doneNote is shortened on the page', r.note && r.note.length <= 91 && r.note.endsWith('…'), r.note);
      ok('chip done: full doneNote is in the tooltip', r.title === LONGNOTE, r.title);
    }
    if (state === 'followup') ok('chip followup: has a link to the child question', r.link);
  }

  // short doneNote is not cut; images only when asked
  await setDocs(A1, { id: 'q1', state: 'done', seenAt: T2, doneNote: 'Done and dusted.', doneImages: [{ url: 'https://example.com/a.png', alt: 'Result A', w: 10, h: 10 }, { url: 'javascript:alert(1)', alt: 'bad' }, { url: 'https://example.com/b.png', alt: 'Result B' }] });
  const d1 = await page.evaluate(() => {
    const app = document.getElementById('app'); app.textContent = '';
    const a = QT.status.chip('q1'); const b = QT.status.chip('q1', { images: true }); app.appendChild(a); app.appendChild(b);
    return { note: a.querySelector('.qt-note').textContent, plainThumbs: a.querySelectorAll('.qt-thumb').length, imgThumbs: b.querySelectorAll('.qt-thumb').length, label: b.querySelector('.qt-thumbs-label') && b.querySelector('.qt-thumbs-label').textContent,
      links: [...b.querySelectorAll('.qt-thumb')].map((x) => x.getAttribute('href')), rel: b.querySelector('.qt-thumb').rel, alts: [...b.querySelectorAll('img')].map((x) => x.alt) };
  });
  ok('chip done: a short doneNote is shown whole', d1.note === 'Done and dusted.', d1.note);
  ok('chip done: no pictures unless images:true', d1.plainThumbs === 0);
  ok('chip done: "See the result" row with only safe https pictures', d1.imgThumbs === 2 && d1.label === 'See the result' && d1.links.every((u) => u.startsWith('https://')), JSON.stringify(d1));
  ok('chip done: picture links open safely', /noopener/.test(d1.rel) && d1.alts.join() === 'Result A,Result B', d1.rel + ' ' + d1.alts);

  // follow-up link goes to the child question, and does not trigger a click on a parent row
  await setDocs(A1, SC.followup[1]);
  const fl = await page.evaluate(() => {
    const app = document.getElementById('app'); app.textContent = '';
    const row = document.createElement('div'); let rowClicks = 0; row.addEventListener('click', () => rowClicks++);
    row.appendChild(QT.status.chip('q1')); app.appendChild(row);
    const routes = []; QT.on('route', (e) => routes.push(e));
    row.querySelector('.qt-link').click();
    return { routes, rowClicks };
  });
  ok('followup link: opens the child question', fl.routes.length === 1 && fl.routes[0].view === 'question' && fl.routes[0].params.id === 'q2', JSON.stringify(fl.routes));
  ok('followup link: does not also click the list row', fl.rowClicks === 0);
  // child missing -> no link, only words
  await setDocs(A1, { id: 'q1', state: 'followup', seenAt: T2, followupId: 'nope' });
  const nl = await page.evaluate(() => { const app = document.getElementById('app'); app.textContent = ''; const c = QT.status.chip('q1'); app.appendChild(c); return !!c.querySelector('.qt-link'); });
  ok('followup chip: no link when the child question does not exist', nl === false);

  // read-only (Cathy) question: no "Waiting for you"
  const ro = await page.evaluate(() => { const app = document.getElementById('app'); app.textContent = ''; const c = QT.status.chip('k1'); app.appendChild(c); return { hidden: c.hidden, vis: c.getBoundingClientRect().width, text: c.textContent }; });
  ok('chip for a read-only question is not shown while it has no status', ro.hidden && ro.vis === 0 && ro.text === '', JSON.stringify(ro));

  // live updating
  await setDocs(null, null);
  await page.evaluate(() => { const app = document.getElementById('app'); app.textContent = ''; window.__chip = QT.status.chip('q1'); app.appendChild(window.__chip); });
  const ct = () => page.evaluate(() => window.__chip.querySelector('.qt-pill-text') ? window.__chip.querySelector('.qt-pill-text').textContent : '(none)');
  ok('live chip starts as "Waiting for you"', (await ct()) === WORDS.waiting);
  await put(page, 'answers', 'q1', A1);
  ok('live chip: answer arrives -> "You answered ..."', (await ct()) === WORDS.answeredUnseen, await ct());
  await put(page, 'status', 'q1', { id: 'q1', state: 'seen', seenAt: T2 });
  ok('live chip: Claude saw it', (await ct()) === WORDS.seen, await ct());
  await put(page, 'status', 'q1', { id: 'q1', state: 'working', seenAt: T2, note: 'Step one' });
  ok('live chip: working', (await ct()) === WORDS.working);
  await put(page, 'status', 'q1', { id: 'q1', state: 'working', seenAt: T2, note: 'Step two' });
  ok('live chip: note changes in place', (await page.evaluate(() => window.__chip.querySelector('.qt-note').textContent)) === 'Step two');
  await put(page, 'status', 'q1', { id: 'q1', state: 'done', seenAt: T2, doneNote: 'All finished' });
  ok('live chip: done', (await ct()) === WORDS.done);
  await put(page, 'answers', 'q1', Object.assign({}, A1, { answeredAt: '2026-10-07T11:00:00.000Z', key: 'B' }));
  ok('live chip: she changes her answer after Claude was done -> back to "You answered ..."', (await ct()) === WORDS.answeredUnseen);
  await page.evaluate(() => window.__del('answers', 'q1'));
  await page.evaluate(() => window.__del('status', 'q1'));
  ok('live chip: answer undone -> "Waiting for you"', (await ct()) === WORDS.waiting);
  // an unrelated document does not rebuild the chip (dots must not restart)
  await put(page, 'status', 'q1', { id: 'q1', state: 'working', note: 'N', at: '2026-10-07T10:30:00.000Z' });
  const same = await page.evaluate(() => { const before = window.__chip.querySelector('.qt-pill'); window.__put('status', 'other-q', { id: 'other-q', state: 'working' }); window.__put('answers', 'other-q', { id: 'other-q', answeredAt: 'x' }); return before === window.__chip.querySelector('.qt-pill'); });
  ok('live chip: an update for another question does not rebuild it', same);

  // untrusted text
  await put(page, 'status', 'q1', { id: 'q1', state: 'working', note: '<img src=x onerror="window.__xss=1"> <b>bold</b>', at: T2 });
  await flush(page);
  const xs = await page.evaluate(() => ({ imgs: document.querySelectorAll('#app img').length, bolds: document.querySelectorAll('#app b').length, xss: window.__xss || 0, note: window.__chip.querySelector('.qt-note').textContent }));
  ok('chip: tags in the note are shown as plain text', xs.imgs === 0 && xs.bolds === 0 && xs.xss === 0 && xs.note.includes('<img'), JSON.stringify(xs));

  // listeners: attached chips listen, detached chips do not
  const leak = await page.evaluate(() => {
    const app = document.getElementById('app'); app.textContent = '';
    const base = QT.status._liveCount();
    const never = []; for (let i = 0; i < 300; i++) never.push(QT.status.chip('q' + i));
    const afterCreate = QT.status._liveCount();
    const box = document.createElement('div'); app.appendChild(box);
    for (let i = 0; i < 300; i++) box.appendChild(QT.status.chip('q' + i));
    for (let i = 0; i < 50; i++) box.appendChild(QT.status.newBadge('q' + i));
    const attached = QT.status._liveCount();
    window.__put('status', 'q5', { id: 'q5', state: 'working' });         // events while attached
    box.remove();
    const afterRemove = QT.status._liveCount();
    window.__put('status', 'q6', { id: 'q6', state: 'working' });         // events after: nothing to update, no errors
    app.appendChild(box);
    const back = QT.status._liveCount();
    box.textContent = '';
    return { base, afterCreate, attached, afterRemove, back, final: QT.status._liveCount(), storeListeners: QT.listenerCount('store') };
  });
  ok('chips that were never attached do not listen', leak.afterCreate === leak.base, JSON.stringify(leak));
  ok('attached chips and badges listen', leak.attached === leak.base + 350, JSON.stringify(leak));
  ok('detached chips stop listening', leak.afterRemove === leak.base && leak.final === leak.base, JSON.stringify(leak));
  ok('a chip that is put back listens again', leak.back === leak.base + 350);
  ok('the module keeps one store listener in total (not one per chip)', leak.storeListeners <= 2, String(leak.storeListeners));
  await page.context().close();
}

/* =========================================================================================== 3. heartbeat, counts, tab title */
if (only !== 'integration') {
  const page = await newPage({ label: 'hb ' });
  const hb = (mins) => page.evaluate((a) => { QT.store.meta.heartbeat = a === null ? undefined : { id: 'heartbeat', at: new Date(Date.now() - a).toISOString(), note: 'x' }; if (a === null) delete QT.store.meta.heartbeat; return QT.status.heartbeatLabel(); }, mins === null ? null : mins * MIN);
  await load(page, { sections: { look: section('look') } });
  let r = await hb(null);
  ok('heartbeat: none yet -> "Claude has not checked for your answers yet"', r.text === 'Claude has not checked for your answers yet' && r.stale === false, JSON.stringify(r));
  r = await hb(2);
  ok('heartbeat: 2 min ago', r.text === 'Claude last checked for your answers 2 min ago' && r.stale === false, JSON.stringify(r));
  r = await hb(0.2);
  ok('heartbeat: seconds ago -> "just now"', r.text === 'Claude last checked for your answers just now' && !r.stale, JSON.stringify(r));
  r = await hb(19);
  ok('heartbeat: 19 min is not stale', r.stale === false && r.text === 'Claude last checked for your answers 19 min ago', JSON.stringify(r));
  r = await hb(21);
  ok('heartbeat: 21 min is stale, with the friendly hint', r.stale === true && r.text === 'Claude last checked for your answers 21 min ago (Claude may be busy. Your answers are safe.)' && r.base === 'Claude last checked for your answers 21 min ago', JSON.stringify(r));
  r = await hb(3 * 60);
  ok('heartbeat: 3 hours', r.stale && /3 hours ago/.test(r.text), r.text);
  r = await page.evaluate(() => { QT.store.meta.heartbeat = { id: 'heartbeat', at: new Date(Date.now() + 5 * 60000).toISOString() }; return QT.status.heartbeatLabel(); });
  ok('heartbeat: a clock that is ahead does not show a negative time', r.text === 'Claude last checked for your answers just now' && !r.stale, JSON.stringify(r));
  r = await page.evaluate(() => { QT.store.meta.heartbeat = { id: 'heartbeat', at: 'garbage' }; return QT.status.heartbeatLabel(); });
  ok('heartbeat: a broken time stamp counts as "not checked for your answers yet"', r.text === 'Claude has not checked for your answers yet' && !r.stale, JSON.stringify(r));

  // self-updating heartbeat element
  await page.evaluate(() => { QT.store.meta.heartbeat = { id: 'heartbeat', at: new Date(Date.now() - 2 * 60000).toISOString() }; const app = document.getElementById('app'); app.textContent = ''; window.__hb = QT.status.heartbeatEl(); app.appendChild(window.__hb); });
  ok('heartbeat element shows the label', (await page.evaluate(() => window.__hb.textContent)) === 'Claude last checked for your answers 2 min ago');
  await page.clock.runFor(31 * 1000 + 10 * MIN);
  const t2 = await page.evaluate(() => ({ t: window.__hb.textContent, s: window.__hb.getAttribute('data-stale') }));
  ok('heartbeat element ticks on its own (time passes -> "12 min ago")', /^Claude last checked for your answers 12 min ago$/.test(t2.t) && t2.s === 'false', JSON.stringify(t2));
  await page.clock.runFor(10 * MIN);
  const t3 = await page.evaluate(() => ({ t: window.__hb.textContent, s: window.__hb.getAttribute('data-stale') }));
  ok('heartbeat element turns "stale" after 20 min', t3.s === 'true' && /\(Claude may be busy\. Your answers are safe\.\)/.test(t3.t), JSON.stringify(t3));
  await put(page, 'meta', 'heartbeat', { id: 'heartbeat', at: new Date(Date.parse(await page.evaluate(() => new Date().toISOString())) - 30 * 1000).toISOString() });
  ok('heartbeat element reacts to a new heartbeat', (await page.evaluate(() => window.__hb.getAttribute('data-stale'))) === 'false');
  await page.context().close();
}

if (only !== 'integration') {
  const page = await newPage({ label: 'count ' });
  const docs = {
    sections: { look: section('look', { kind: 'builtin' }), other: section('other', { kind: 'builtin' }), later: section('later', { kind: 'builtin' }), kathy: section('kathy', { kind: 'builtin', readOnly: true }), old: section('old', { archived: true }), mine: section('mine') },
    questions: {
      l1: question('l1', 'look', { kind: 'visual' }), l2: question('l2', 'look'), l3: question('l3', 'look'),           // l2 answered, l3 done
      o1: question('o1', 'other'), o2: question('o2', 'other'),
      k1: question('k1', 'kathy', { kind: 'readonly' }), k2: question('k2', 'kathy', { kind: 'readonly' }),
      a1: question('a1', 'old'),                                                                                        // archived section
      r1: question('r1', 'other', { kind: 'readonly' }),                                                                // read-only kind in a normal section
      m1: question('m1', 'mine'),
      x1: question('x1', 'nowhere'),                                                                                    // section does not exist
    },
    answers: { l2: { id: 'l2', status: 'answered', key: 'A', answeredAt: iso(MIN) } },
    status: { l3: { id: 'l3', state: 'done', doneNote: 'x' } },
  };
  await load(page, docs);
  const bc = (id) => page.evaluate((s) => QT.status.badgeCount(s), id);
  ok('badgeCount look = 1 (answered and done ones do not count)', (await bc('look')) === 1, String(await bc('look')));
  ok('badgeCount other = 2 (read-only question does not count)', (await bc('other')) === 2, String(await bc('other')));
  ok('badgeCount kathy = 0', (await bc('kathy')) === 0);
  ok('badgeCount archived section = 0', (await bc('old')) === 0);
  ok('badgeCount custom section = 1', (await bc('mine')) === 1);
  ok('badgeCount later (no questions) = 0', (await bc('later')) === 0);
  ok('badgeCount unknown section = 0', (await bc('zzz')) === 0);
  const total = await page.evaluate(() => QT.status.totalUnanswered());
  ok('total unanswered = 4', total === 4, String(total));
  ok('tab title shows the count: "(4) Terminal"', (await page.title()) === '(4) Terminal', await page.title());
  await put(page, 'answers', 'o1', { id: 'o1', status: 'answered', key: 'B', answeredAt: iso(0) });
  ok('tab title goes down when she answers: "(3) ..."', (await page.title()) === '(3) Terminal', await page.title());
  await put(page, 'questions', 'o3', question('o3', 'other'));
  ok('tab title goes up when Claude adds a question: "(4) ..."', (await page.title()) === '(4) Terminal', await page.title());
  await put(page, 'questions', 'k9', question('k9', 'kathy', { kind: 'readonly' }));
  ok('a new Cathy question does not change the count', (await page.title()) === '(4) Terminal');
  await put(page, 'sections', 'mine', section('mine', { archived: true }));
  ok('archiving a section lowers the count', (await page.title()) === '(3) Terminal', await page.title());
  for (const id of ['l1', 'o2', 'o3']) await put(page, 'answers', id, { id, status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('everything answered -> plain "Terminal"', (await page.title()) === 'Terminal', await page.title());
  await page.context().close();
}

/* =========================================================================================== 4. sound */
if (only !== 'integration') {
  // 4a: default off, remembered, first load never chimes, new things chime
  let page = await newPage({ label: 'sound ' });
  ok('sound starts OFF', (await page.evaluate(() => QT.sound.enabled())) === false);
  const base = { sections: { look: section('look'), kathy: section('kathy', { readOnly: true }) }, questions: { q1: question('q1', 'look') }, status: { q1: { id: 'q1', state: 'working' } }, plans: { look: { sectionId: 'look', version: 1, summary: 's', steps: ['a'], at: iso(MIN) } } };
  await enableSound(page);
  ok('sound: turning it on remembers it (qt.sound = 1)', (await page.evaluate(() => localStorage.getItem('qt.sound'))) === '1' && (await page.evaluate(() => QT.sound.enabled())) === true);
  ok('sound: turning it on does not chime by itself (layout does that)', (await starts(page)) === 0);
  await load(page, base);
  ok('sound ON: loading the page (existing question, status, plan) makes NO chime', (await starts(page)) === 0, 'starts=' + (await starts(page)));
  await put(page, 'questions', 'q2', question('q2', 'look'));
  ok('sound: a NEW question chimes once (3 notes)', (await starts(page)) === 3, 'starts=' + (await starts(page)));
  ok('sound: one Web Audio context was made, lazily', (await page.evaluate(() => window.__audio.created)) === 1);
  await put(page, 'questions', 'q2', question('q2', 'look', { title: 'Edited title' }));
  await put(page, 'questions', 'q3', question('q3', 'look'));
  ok('sound: a second new question within 4 s does not chime again (debounce)', (await chimeCount(page)) === 1, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'questions', 'q2', question('q2', 'look', { title: 'Edited again' }));
  ok('sound: editing an existing question never chimes', (await chimeCount(page)) === 1);
  await put(page, 'questions', 'q4', question('q4', 'look'));
  ok('sound: after 4 s the next new question chimes', (await chimeCount(page)) === 2, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'questions', 'k5', question('k5', 'kathy', { kind: 'readonly' }));
  ok('sound: a new question for Miss Cathy and Rob does not chime', (await chimeCount(page)) === 2);
  await put(page, 'questions', 'q4', question('q4', 'look'));
  await page.evaluate(() => window.__del('questions', 'q4'));
  await put(page, 'questions', 'q4', question('q4', 'look'));
  ok('sound: a question id that came back (same id) does not chime', (await chimeCount(page)) === 2);
  await put(page, 'status', 'q1', { id: 'q1', state: 'seen' });
  ok('sound: status changes that are not "done" do not chime', (await chimeCount(page)) === 2);
  await put(page, 'status', 'q1', { id: 'q1', state: 'done', doneNote: 'ok' });
  ok('sound: a status turning "done" chimes', (await chimeCount(page)) === 3, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'status', 'q1', { id: 'q1', state: 'done', doneNote: 'ok, edited' });
  ok('sound: an edit of an already done status does not chime', (await chimeCount(page)) === 3);
  await put(page, 'plans', 'look', { sectionId: 'look', version: 1, summary: 's', steps: ['a'], at: iso(MIN) });
  ok('sound: the same plan again does not chime', (await chimeCount(page)) === 3);
  await put(page, 'plans', 'look', { sectionId: 'look', version: 2, summary: 's2', steps: ['a', 'b'], at: iso(0) });
  ok('sound: a new plan version chimes', (await chimeCount(page)) === 4, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'plans', 'other', { sectionId: 'other', version: 1, summary: 's', steps: ['a'], at: iso(0) });
  ok('sound: a plan for another section chimes', (await chimeCount(page)) === 5);
  await page.clock.runFor(4100);
  await put(page, 'sections', 'look', section('look', { title: 'Renamed' }));
  await put(page, 'answers', 'q1', { id: 'q1', status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('sound: a sections change or a saved answer never plays the new-question chime (the answer gets its own small ding)', (await page.evaluate(() => QT.sound.playedBy.question)) === 5 && (await page.evaluate(() => QT.sound.playedBy.answered)) === 1);
  // reload: the setting is remembered, and loading still does not chime
  await page.reload({ waitUntil: 'load' });
  ok('sound: remembered after a reload', (await page.evaluate(() => QT.sound.enabled())) === true);
  await load(page, base);
  await put(page, 'questions', 'q9', question('q9', 'look'));
  ok('sound: after a reload the first load is silent and a new question still chimes once', (await chimeCount(page)) === 1, 'chimes=' + (await chimeCount(page)));
  // switch off
  await page.evaluate(() => QT.sound.set(false));
  ok('sound: off is remembered (qt.sound = 0)', (await page.evaluate(() => localStorage.getItem('qt.sound'))) === '0');
  await page.clock.runFor(4100);
  await put(page, 'questions', 'q10', question('q10', 'look'));
  await put(page, 'status', 'q10', { id: 'q10', state: 'done' });
  ok('sound OFF: nothing chimes', (await chimeCount(page)) === 1);
  ok('sound: chime() returns false when off', (await page.evaluate(() => QT.sound.chime())) === false);
  await page.evaluate(() => QT.sound.set(true));
  const played = await page.evaluate(() => QT.sound.chime());
  ok('sound: chime() after turning it on plays (the layout does this right after set(true))', played === true && (await chimeCount(page)) === 2);
  ok('sound: chime() twice in a row plays once', (await page.evaluate(() => QT.sound.chime())) === false && (await chimeCount(page)) === 2);
  await page.context().close();

  // 4b: the first load never chimes even if questions arrive "late" as part of the first snapshot; sound saved ON before load
  page = await newPage({ label: 'sound2 ', init: "localStorage.setItem('qt.sound','1')" });
  await page.evaluate(() => { window.__put = window.__put; });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look'), b: question('b', 'look'), c: question('c', 'look') } });
  ok('sound saved ON: opening the page with 3 questions already there does not chime', (await starts(page)) === 0 && (await page.evaluate(() => window.__audio.created)) === 0, 'starts=' + (await starts(page)));
  await put(page, 'questions', 'd', question('d', 'look'));
  ok('sound saved ON: a question that arrives later chimes', (await chimeCount(page)) === 1);
  await page.context().close();

  // 4b3: news from the Workers and Tasks parts plays the same happy chime ("whenever anything new arrives"): a new reply to her ask, a new / ready idea note,
  //      a new worker, a new task Claude made, a task of hers that Claude has just seen. Never on the first load, never for her own adds, edits and asks.
  page = await newPage({ label: 'sound-news ', init: "localStorage.setItem('qt.sound','1')" });
  const task = (id, extra = {}) => Object.assign({ id, parentId: null, title: 'Task ' + id, plain: '', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 1, createdAt: iso(60 * MIN), updatedAt: iso(50 * MIN), doneAt: null, createdBy: 'claude', seenAt: null }, extra);
  const worker = (id, extra = {}) => Object.assign({ id, name: 'Worker ' + id, parentId: null, kind: 'helper', icon: '', role: 'Does a job', state: 'working', now: '', waitingFor: 'none', order: 1, updatedAt: iso(2 * MIN) }, extra);
  await load(page, {
    sections: { look: section('look') }, questions: { q1: question('q1', 'look') },
    workers: { w1: worker('w1') }, tasks: { t1: task('t1'), t2: task('t2') },
    replies: { r1: { id: 'r1', targetKind: 'worker', targetId: 'w1', state: 'answered', text: 'Done', from: 'Claude', at: iso(30 * MIN) } },
    ideaStatus: { i1: { id: 'i1', state: 'read' } },
    taskAdds: { u1: { id: 'u1', parentId: null, title: 'Her idea', plain: '', createdAt: iso(20 * MIN) } },
    taskEdits: { t2: { id: 't2', title: 'New name', updatedAt: iso(10 * MIN) } },
    asks: { a0: { id: 'a0', targetKind: 'task', targetId: 't1', text: 'When?', createdAt: iso(15 * MIN) } },
  });
  ok('sound news: loading a page full of workers, tasks, replies, ideas and her own adds/edits/asks makes NO chime', (await starts(page)) === 0 && (await page.evaluate(() => window.__audio.created)) === 0, 'starts=' + (await starts(page)));
  await put(page, 'replies', 'r2', { id: 'r2', targetKind: 'worker', targetId: 'w1', state: 'seen', text: '', from: 'Claude', at: iso(0) });
  ok('sound news: a new reply document (Claude answers her ask) chimes once', (await chimeCount(page)) === 1, 'chimes=' + (await chimeCount(page)));
  await put(page, 'replies', 'r3', { id: 'r3', targetKind: 'task', targetId: 't1', state: 'answered', text: 'Soon', from: 'Claude', at: iso(0) });
  ok('sound news: a second one within 4 s stays quiet (the 4 s gap)', (await chimeCount(page)) === 1);
  await page.clock.runFor(4100);
  await put(page, 'replies', 'r2', { id: 'r2', targetKind: 'worker', targetId: 'w1', state: 'answered', text: 'Here is the answer', from: 'Claude', at: iso(0) });
  ok('sound news: a "seen" reply that becomes the answer chimes', (await chimeCount(page)) === 2, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'replies', 'r2', { id: 'r2', targetKind: 'worker', targetId: 'w1', state: 'answered', text: 'Here is the answer, said another way', from: 'Claude', at: iso(0) });
  ok('sound news: editing an answer that is already there does not chime', (await chimeCount(page)) === 2);
  await put(page, 'ideaStatus', 'i2', { id: 'i2', state: 'read' });
  ok('sound news: a new ideaStatus document chimes', (await chimeCount(page)) === 3, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'ideaStatus', 'i2', { id: 'i2', state: 'questionsReady' });
  ok('sound news: an idea note turning "questionsReady" chimes', (await chimeCount(page)) === 4, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'ideaStatus', 'i1', { id: 'i1', state: 'read', note: 'again' });
  ok('sound news: an idea note changing in another way does not chime', (await chimeCount(page)) === 4);
  await put(page, 'workers', 'w2', worker('w2'));
  ok('sound news: a new worker (Claude wrote it after the first load) chimes', (await chimeCount(page)) === 5, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'workers', 'w2', worker('w2', { state: 'done', now: '' }));
  await put(page, 'workers', 'w1', worker('w1', { now: 'busy' }));
  ok('sound news: a worker changing state does not chime', (await chimeCount(page)) === 5);
  await put(page, 'tasks', 't3', task('t3'));
  ok('sound news: a new task Claude made chimes', (await chimeCount(page)) === 6, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'tasks', 't3', task('t3', { state: 'working' }));
  ok('sound news: a task changing state does not chime', (await chimeCount(page)) === 6);
  // her own writes: nothing
  await put(page, 'taskAdds', 'u2', { id: 'u2', parentId: 't1', title: 'Her second idea', plain: '', createdAt: iso(0) });
  await put(page, 'taskEdits', 't1', { id: 't1', plain: 'Her words', updatedAt: iso(0) });
  await put(page, 'asks', 'a1', { id: 'a1', targetKind: 'worker', targetId: 'w1', text: 'Question?', createdAt: iso(0) });
  ok('sound news: her own task add, task edit and ask never chime', (await chimeCount(page)) === 6, 'chimes=' + (await chimeCount(page)));
  // Claude adopts her add (tasks/<same id>, createdBy owner, seenAt after her add): one chime for "Claude saw it", not two
  await page.clock.runFor(4100);
  await put(page, 'tasks', 'u1', task('u1', { createdBy: 'owner', seenAt: iso(0), createdAt: iso(20 * MIN) }));
  ok('sound news: Claude adopting her task (it has now seen it) chimes exactly once', (await chimeCount(page)) === 7, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'tasks', 'u1', task('u1', { createdBy: 'owner', seenAt: iso(0), state: 'working', createdAt: iso(20 * MIN) }));
  ok('sound news: a later change of that task does not chime again', (await chimeCount(page)) === 7);
  // her edit seen: tasks/t2.seenAt moves past her edit time (10 min ago)
  await put(page, 'tasks', 't2', task('t2', { seenAt: iso(1 * MIN) }));
  ok('sound news: a task whose seenAt moves past her edit time chimes', (await chimeCount(page)) === 8, 'chimes=' + (await chimeCount(page)));
  await page.clock.runFor(4100);
  await put(page, 'tasks', 't2', task('t2', { seenAt: iso(0) }));
  ok('sound news: seenAt moving again with nothing new of hers does not chime', (await chimeCount(page)) === 8);
  // sound off: nothing
  await page.evaluate(() => QT.sound.set(false));
  await page.clock.runFor(4100);
  await put(page, 'replies', 'r9', { id: 'r9', targetKind: 'task', targetId: 't1', state: 'answered', text: 'x', from: 'Claude', at: iso(0) });
  await put(page, 'workers', 'w9', worker('w9'));
  ok('sound news: with sound OFF nothing chimes', (await chimeCount(page)) === 8);
  await page.context().close();
  // a reload with sound saved ON: the same documents are there from the start and stay silent
  page = await newPage({ label: 'sound-news2 ', init: "localStorage.setItem('qt.sound','1')" });
  await load(page, { sections: { look: section('look') }, questions: { q1: question('q1', 'look') }, workers: { w1: worker('w1'), w2: worker('w2') }, tasks: { t1: task('t1'), u1: task('u1', { createdBy: 'owner', seenAt: iso(0), createdAt: iso(20 * MIN) }) },
    replies: { r1: { id: 'r1', targetKind: 'worker', targetId: 'w1', state: 'answered', text: 'x', from: 'Claude', at: iso(1) } }, ideaStatus: { i1: { id: 'i1', state: 'questionsReady' } }, taskAdds: { u1: { id: 'u1', parentId: null, title: 'x', plain: '', createdAt: iso(20 * MIN) } } });
  ok('sound news: after a reload the first load of all those is silent', (await starts(page)) === 0, 'starts=' + (await starts(page)));
  await page.context().close();

  // 4b2: three different sounds: new question / answer saved / the last waiting question answered
  page = await newPage({ label: 'sound-kinds ', init: "localStorage.setItem('qt.sound','1')" });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look'), b: question('b', 'look'), c: question('c', 'look'), k1: question('k1', 'kathy', { kind: 'readonly' }) },
    answers: { z: { id: 'z', status: 'answered', key: 'A', answeredAt: iso(MIN) } } });
  const by = (k) => page.evaluate((kk) => QT.sound.playedBy[kk], k);
  ok('sound kinds: opening the page with answers already there is silent', (await starts(page)) === 0);
  await put(page, 'answers', 'a', { id: 'a', status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('sound kinds: saving an answer plays the small ding (not the new-question chime)', (await by('answered')) === 1 && (await by('question')) === 0 && (await by('party')) === 0, JSON.stringify(await page.evaluate(() => QT.sound.playedBy)));
  ok('sound kinds: the ding is two short notes', (await starts(page)) === 2, 'starts=' + (await starts(page)));
  await put(page, 'answers', 'a', { id: 'a', status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('sound kinds: the same answer again is silent', (await by('answered')) === 1);
  await page.clock.runFor(500);
  await put(page, 'answers', 'b', { id: 'b', status: 'answered', key: 'B', answeredAt: iso(0) });
  ok('sound kinds: the next answer dings again, still no party (one question is still waiting)', (await by('answered')) === 2 && (await by('party')) === 0);
  await page.clock.runFor(500);
  await put(page, 'answers', 'c', { id: 'c', status: 'answered', key: 'unsure', answeredAt: iso(0) });
  ok('sound kinds: answering the LAST waiting question plays the celebration (and no extra ding)', (await by('party')) === 1 && (await by('answered')) === 2, JSON.stringify(await page.evaluate(() => QT.sound.playedBy)));
  ok('sound kinds: the celebration is longer than the ding', (await starts(page)) > 2 + 2 + 6, 'starts=' + (await starts(page)));
  await page.clock.runFor(500);
  await put(page, 'answers', 'c', { id: 'c', status: 'answered', key: 'A', answeredAt: iso(0) + 'x' });
  await page.clock.runFor(4100);
  await put(page, 'questions', 'd', question('d', 'look'));
  ok('sound kinds: a new question after that still plays the normal chime', (await by('question')) === 1);
  await page.evaluate(() => QT.sound.set(false));
  await put(page, 'answers', 'd', { id: 'd', status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('sound kinds: with the sound off, answers are silent', (await by('answered')) === 3 && (await by('party')) === 1);
  await page.context().close();

  // 4c: sound saved ON, but the browser has not been clicked yet: nothing is queued up to burst out later
  page = await newPage({ label: 'sound3 ', init: "localStorage.setItem('qt.sound','1'); window.__audioState='suspended'; Object.defineProperty(navigator,'userActivation',{get:()=>({isActive:false,hasBeenActive:false}),configurable:true});" });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look') } });
  await put(page, 'questions', 'b', question('b', 'look'));
  ok('sound: before any click the browser keeps audio asleep -> no chime is queued', (await starts(page)) === 0);
  await page.context().close();

  // 4d: Web Audio missing or throwing
  page = await newPage({ label: 'sound4 ', init: 'window.__audioThrows = true;' });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look') } });
  await enableSound(page);
  await put(page, 'questions', 'b', question('b', 'look'));
  const nc = await page.evaluate(() => QT.sound.chime());
  ok('sound: a browser that cannot make sound does not crash the page', nc === false);
  await page.context().close();
  page = await newPage({ label: 'sound5 ', init: 'delete window.AudioContext; delete window.webkitAudioContext;' });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look') } });
  await enableSound(page);
  await put(page, 'questions', 'b', question('b', 'look'));
  ok('sound: no Web Audio at all does not crash the page', (await page.evaluate(() => QT.sound.chime())) === false);
  await page.context().close();

  // 4e: localStorage blocked
  page = await newPage({ label: 'sound6 ', init: "Storage.prototype.getItem = function () { throw new Error('blocked'); }; Storage.prototype.setItem = function () { throw new Error('blocked'); };" });
  await load(page, { sections: { look: section('look') }, questions: { a: question('a', 'look') } });
  ok('storage blocked: sound is off and the page works', (await page.evaluate(() => QT.sound.enabled())) === false);
  await enableSound(page);
  ok('storage blocked: turning sound on still works for this visit', (await page.evaluate(() => QT.sound.enabled())) === true);
  await put(page, 'questions', 'b', question('b', 'look'));
  ok('storage blocked: a new question still chimes', (await chimeCount(page)) === 1);
  const nb = await page.evaluate(() => ({ a: QT.status.isNew('b'), s: QT.status.markSeen('b'), c: QT.status.isNew('b') }));
  ok('storage blocked: NEW badges still work in memory', nb.a === true && nb.c === false, JSON.stringify(nb));
  await page.context().close();
}

/* =========================================================================================== 5. NEW badges */
if (only !== 'integration') {
  let page = await newPage({ label: 'new ' });
  const docs = { sections: { look: section('look'), kathy: section('kathy', { readOnly: true }) }, questions: {} };
  for (let i = 0; i < 100; i++) docs.questions['k' + i] = question('k' + i, 'kathy', { kind: 'readonly' });
  for (let i = 0; i < 5; i++) docs.questions['q' + i] = question('q' + i, 'look');
  ok('NEW: before the first load nothing is new', (await page.evaluate(() => QT.status.isNew('q1'))) === false);
  await load(page, docs);
  const cnt = await page.evaluate(() => Object.keys(QT.store.questions).filter((id) => QT.status.isNew(id)).length);
  ok('NEW: the very first visit shows no NEW badge at all (105 questions)', cnt === 0, String(cnt));
  ok('NEW: the baseline is remembered (qt.seenq)', (await page.evaluate(() => JSON.parse(localStorage.getItem('qt.seenq')).ids.length)) === 105);
  await put(page, 'questions', 'n1', question('n1', 'look'));
  await put(page, 'questions', 'n2', question('n2', 'kathy', { kind: 'readonly' }));
  ok('NEW: a question that arrives later is new', (await page.evaluate(() => QT.status.isNew('n1'))) === true);
  ok('NEW: so is a later Cathy question', (await page.evaluate(() => QT.status.isNew('n2'))) === true);
  ok('NEW: newCount per section', (await page.evaluate(() => [QT.status.newCount('look'), QT.status.newCount('kathy'), QT.status.newCount()].join())) === '1,1,2');
  ok('NEW: an unknown id is never new', (await page.evaluate(() => QT.status.isNew('does-not-exist'))) === false);
  // live NEW element
  await page.evaluate(() => { const app = document.getElementById('app'); app.textContent = ''; window.__nb = QT.status.newBadge('n1'); app.appendChild(window.__nb); });
  const nbv = () => page.evaluate(() => ({ hidden: window.__nb.hidden, text: window.__nb.textContent }));
  let v = await nbv();
  ok('NEW badge element shows "New"', !v.hidden && v.text === 'New', JSON.stringify(v));
  // opening the question (route event) clears it, without anyone calling markSeen
  await page.evaluate(() => QT.route.go('question', { id: 'n1' }));
  ok('NEW: opening the question clears its badge (route event)', (await page.evaluate(() => QT.status.isNew('n1'))) === false);
  v = await nbv();
  ok('NEW badge element hides itself once the question was opened', v.hidden === true && v.text === '', JSON.stringify(v));
  await put(page, 'answers', 'n2', { id: 'n2', status: 'answered', key: 'A', answeredAt: iso(0) });
  ok('NEW: an answered question is not new', (await page.evaluate(() => QT.status.isNew('n2'))) === false);
  // reload: remembered
  await put(page, 'questions', 'n3', question('n3', 'look'));
  await page.reload({ waitUntil: 'load' });
  await load(page, Object.assign({}, docs, { questions: Object.assign({}, docs.questions, { n1: question('n1', 'look'), n2: question('n2', 'kathy', { kind: 'readonly' }), n3: question('n3', 'look'), n4: question('n4', 'look') }) }));
  const after = await page.evaluate(() => ['n1', 'n2', 'n3', 'n4'].map((id) => QT.status.isNew(id)).join());
  ok('NEW: after a reload, opened ones stay seen and ones nobody opened are still new', after === 'false,true,true,true', after);
  // markSeen with an array, twice
  const ms2 = await page.evaluate(() => [QT.status.markSeen(['n3', 'n4']), QT.status.markSeen('n3'), QT.status.isNew('n3'), QT.status.isNew('n4')].join());
  ok('NEW: markSeen accepts a list; repeating it changes nothing', ms2 === 'true,false,false,false', ms2);
  await page.context().close();

  // a slow notebook: "ready" comes before the questions -> the baseline is made when they arrive, never from an empty list
  page = await newPage({ label: 'new3 ' });
  await page.evaluate(() => window.__readyOnly());
  await flush(page);
  ok('NEW (slow notebook): nothing is saved while the questions have not arrived', (await page.evaluate(() => localStorage.getItem('qt.seenq'))) === null);
  await page.evaluate((q) => window.__initial('questions', q), docs.questions);
  const late = await page.evaluate(() => ({ n: Object.keys(QT.store.questions).filter((id) => QT.status.isNew(id)).length, saved: JSON.parse(localStorage.getItem('qt.seenq')).ids.length }));
  ok('NEW (slow notebook): when the questions arrive they all count as seen (first visit)', late.n === 0 && late.saved === 105, JSON.stringify(late));
  await page.context().close();

  // damaged storage -> treated like the first visit
  page = await newPage({ label: 'new2 ', init: "localStorage.setItem('qt.seenq','{not json')" });
  await load(page, docs);
  ok('NEW: damaged saved data -> treated like a first visit (nothing is new)', (await page.evaluate(() => Object.keys(QT.store.questions).filter((id) => QT.status.isNew(id)).length)) === 0);
  await page.context().close();
}

/* =========================================================================================== 6. Test connection + ping */
if (only !== 'integration') {
  const docs = { sections: { look: section('look') }, questions: { q1: question('q1', 'look', { title: 'Which picture do you like best?' }), q2: question('q2', 'look', { title: 'Q2' }) } };
  const sends = async (page) => (await calls(page)).map((c) => c.t);
  const result = (page) => page.evaluate(() => window.__r);
  const startTest = (page) => page.evaluate(() => { window.__r = undefined; QT.status.testConnection().then((r) => { window.__r = r; }); });
  const waitFor = (page, fn, arg) => until(page, fn, arg, 8000);
  const toastText = (page) => page.evaluate(() => { const e = document.querySelector('.qt-conn-text'); return e ? e.textContent : null; });
  const OKMSG = 'Claude heard you ✓';
  const FAILMSG = 'Claude did not hear this one. That is OK. Claude still finds your answers every few minutes.';

  // 6a: the happy path
  let page = await newPage({ label: 'ping ' });
  await load(page, docs);
  let p = await page.evaluate(() => QT.status.ping('Answered: x'));
  ok('ping before any test: nothing is sent', p.ok === false && p.reason === 'not_tested' && (await sends(page)).length === 0, JSON.stringify(p));
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  let r = await result(page);
  ok('test: result is ok with the plain words "Claude heard you ✓"', r.ok === true && r.message === OKMSG, JSON.stringify(r));
  let s = await sends(page);
  ok('test: exactly one message was sent, with the test text, in a NEW thread (anchor)', s.length === 1 && s[0].text === 'Question Terminal test ping' && s[0].anchor && !s[0].threadId, JSON.stringify(s));
  ok('test: anchored once (anchorFor was used)', (await page.evaluate(() => window.__cm.calls.filter((c) => c.fn === 'anchor').length)) === 1);
  ok('test: canSendToClaude was asked before sending', (await page.evaluate(() => window.__cm.calls.map((c) => c.fn).join())) === 'can,anchor,send');
  ok('test: the thread id is saved in meta/ping', (await page.evaluate(() => JSON.stringify(window.__metaWrites))) === '[["ping",{"threadId":"thr-1"}]]', await page.evaluate(() => JSON.stringify(window.__metaWrites)));
  ok('test: the result is shown in a message box', (await toastText(page)) === OKMSG, await toastText(page));
  ok('test: the message box is a polite live region', (await page.evaluate(() => document.querySelector('.qt-conn-wrap').getAttribute('role'))) === 'status');
  ok('test: connection() says the test worked', (await page.evaluate(() => QT.status.connection().ok)) === true);

  // throttle + queue + merge (test counted as the last send)
  await page.evaluate(() => { window.__out = []; for (const t of ['Answered: A → one', 'Answered: B → two', 'Answered: C → three']) QT.status.ping(t).then((x) => window.__out.push(x)); });
  await flush(page);
  ok('ping right after the test is held back (20 s rule), not sent', (await sends(page)).length === 1);
  await page.clock.runFor(10 * 1000);
  ok('ping: still held at 10 s', (await sends(page)).length === 1);
  await page.clock.runFor(10 * 1000 + 100);
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 2);
  s = await sends(page);
  ok('ping: after 20 s the 3 held pings go out as ONE message "Answered 3 questions"', s.length === 2 && s[1].text === 'Answered 3 questions', JSON.stringify(s[1]));
  ok('ping: it is a reply in the same thread', s[1] && s[1].threadId === 'thr-1' && !s[1].anchor, JSON.stringify(s[1]));
  await waitFor(page, () => window.__out.length === 3);
  ok('ping: every caller got {ok:true}', (await page.evaluate(() => window.__out.every((x) => x.ok === true))) === true);
  // a single ping sent right now is held for 20 s again
  await page.evaluate(() => { window.__out = []; QT.status.ping('Answered: D → four').then((x) => window.__out.push(x)); });
  await flush(page);
  ok('ping: at most one message per 20 s', (await sends(page)).length === 2);
  await page.clock.runFor(20 * 1000 + 100);
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 3);
  s = await sends(page);
  ok('ping: a single held ping keeps its own words', s[2] && s[2].text === 'Answered: D → four' && s[2].threadId === 'thr-1', JSON.stringify(s[2]));
  // two answers + an idea: mixed text
  await page.evaluate(() => { for (const t of ['Answered: A → one', 'Sent an idea in Gift shop', 'Answered: B → two']) QT.status.ping(t); });
  await page.clock.runFor(20 * 1000 + 100);
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 4);
  s = await sends(page);
  ok('ping: answers are merged, other kinds of text stay as lines', s[3] && s[3].text === 'Answered 2 questions\nSent an idea in Gift shop', JSON.stringify(s[3]));
  // long and dirty text
  await page.clock.runFor(20 * 1000 + 100);
  await page.evaluate(() => { QT.status.ping('Answered: ' + 'very long title '.repeat(30) + ' → ' + 'x'.repeat(200) + '\u0000\u0007\u001b[31m red'); });
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 5);
  s = await sends(page);
  ok('ping: a line is cut to 120 characters with no control characters', s[4] && s[4].text.length <= 120 && !/[\u0000-\u0008\u000b-\u001f]/.test(s[4].text) && s[4].text.endsWith('…'), JSON.stringify(s[4] && [s[4].text.length, s[4].text.slice(-20)]));
  // empty text
  p = await page.evaluate(() => QT.status.ping('   \u0000  '));
  ok('ping: empty text is ignored', p.ok === false && p.reason === 'empty');
  // test again: reuses the thread (no new anchor)
  await page.clock.runFor(20 * 1000 + 100);
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  s = await sends(page);
  ok('second test: replies in the same thread, no new thread', s.length === 6 && s[5].threadId === 'thr-1' && s[5].text === 'Question Terminal test ping' && (await page.evaluate(() => window.__cm.calls.filter((c) => c.fn === 'anchor').length)) === 1, JSON.stringify(s[5]));
  await page.context().close();

  // 6b: the answer text never carries her own typed words
  page = await newPage({ label: 'ping2 ' });
  await load(page, Object.assign({}, docs, { answers: { q1: { id: 'q1', status: 'answered', key: 'own', ownText: 'My secret phone number is 555', label: 'My secret phone number is 555', answeredAt: iso(0) }, q2: { id: 'q2', status: 'answered', key: 'B', label: 'The blue one', answeredAt: iso(0) } } }));
  const texts = await page.evaluate(() => [QT.status.answerText('q1'), QT.status.answerText('q2'), QT.status.answerText('q2', { key: 'unsure' }), QT.status.answerText('q2', { key: 'change', changeText: 'private words' })]);
  ok('answerText: own typed answer is never included', !/secret|555/.test(texts[0]) && /Which picture/.test(texts[0]), texts[0]);
  ok('answerText: choice label is included', texts[1] === 'Answered: Q2 → The blue one', texts[1]);
  ok('answerText: "not sure" and "change" use plain words', /not sure yet/.test(texts[2]) && /wants a change/.test(texts[3]) && !/private/.test(texts[3]), texts.join(' | '));
  ok('answerText: at most 120 characters', texts.every((x) => x.length <= 120));
  await page.context().close();

  // 6c: the ping({qid}) form
  page = await newPage({ label: 'ping3 ' });
  await load(page, Object.assign({}, docs, { answers: { q1: { id: 'q1', status: 'answered', key: 'own', ownText: 'secret words', label: 'secret words', answeredAt: iso(0) } } }));
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  await page.clock.runFor(21 * 1000);
  await page.evaluate(() => { QT.status.ping({ qid: 'q1' }); });
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 2);
  s = await sends(page);
  ok('ping({qid}) builds the safe text itself', s[1] && /Which picture/.test(s[1].text) && !/secret/.test(s[1].text), JSON.stringify(s[1]));
  await page.context().close();

  // 6d: not an editor
  page = await newPage({ label: 'ping4 ' });
  await load(page, docs);
  await page.evaluate(() => { window.__cm.can = 'writers_only'; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  r = await result(page);
  ok('writers_only: friendly "Claude did not hear this one" words, nothing sent', r.ok === false && r.message === FAILMSG && r.reason === 'writers_only' && (await sends(page)).length === 0, JSON.stringify(r));
  ok('writers_only: the message box shows the plain words', (await toastText(page)) === FAILMSG, await toastText(page));
  p = await page.evaluate(() => QT.status.ping('Answered: x'));
  ok('writers_only: later pings are quietly dropped', p.ok === false && p.reason === 'not_tested' && (await sends(page)).length === 0);
  for (const can of ['no_session', 'off', 'something-new']) {
    await page.evaluate((c) => { window.__cm.can = c; }, can);
    await startTest(page);
    await waitFor(page, () => window.__r !== undefined);
    r = await result(page);
    ok('canSend = ' + can + ': friendly words, nothing sent', r.ok === false && r.message === FAILMSG && (await sends(page)).length === 0, JSON.stringify(r));
  }
  await page.evaluate(() => { window.__cm.canThrows = true; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  r = await result(page);
  ok('canSend rejects (old platform): friendly words', r.ok === false && r.message === FAILMSG);
  await page.context().close();

  // 6e: comments not available at all
  page = await newPage({ label: 'ping5 ' });
  await load(page, docs);
  await page.evaluate(() => { window.__cm.present = false; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  r = await result(page);
  ok('no comments feature: friendly words', r.ok === false && r.message === FAILMSG && r.reason === 'no_comments', JSON.stringify(r));
  await page.context().close();
  page = await newPage({ label: 'ping5b ', init: 'delete window.claude;' });
  await load(page, docs);
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  r = await result(page);
  ok('no window.claude at all: friendly words, no crash', r.ok === false && r.message === FAILMSG);
  await page.context().close();

  // 6f: every error code on the test
  for (const [code, want] of [['consent_required', FAILMSG], ['forbidden', FAILMSG], ['claude_unavailable', FAILMSG], ['unavailable', FAILMSG], ['upstream_error', FAILMSG], ['invalid', FAILMSG], ['not_granted', FAILMSG], ['capability_removed', FAILMSG], ['mystery_code', FAILMSG], ['rate_limited', 'Please wait a moment and try again.']]) {
    page = await newPage({ label: 'code-' + code + ' ' });
    await load(page, docs);
    await page.evaluate((c) => { window.__cm.failQueue = [c]; }, code);
    await startTest(page);
    await waitFor(page, () => window.__r !== undefined);
    r = await result(page);
    ok('test with error "' + code + '": plain words, no crash', r.ok === false && r.message === want && (await toastText(page)) === want, JSON.stringify(r));
    ok('test with error "' + code + '": it was tried once only (no retry loop)', (await sends(page)).length === 1);
    p = await page.evaluate(() => QT.status.ping('Answered: x'));
    ok('test with error "' + code + '": later pings do nothing', p.ok === false && (await sends(page)).length === 1);
    await page.context().close();
  }

  // 6f2: a "no" is not remembered: when the comments feature shows up later, the next test works
  page = await newPage({ label: 'ping-late ' });
  await load(page, docs);
  await page.evaluate(() => { window.__cm.present = false; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  ok('comments missing first: friendly words', (await result(page)).ok === false);
  await page.evaluate(() => { window.__cm.present = true; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  ok('comments there now: the second test works', (await result(page)).ok === true);
  await page.context().close();

  // 6f3: optional "try without a test" switch (off unless the lead turns it on)
  page = await newPage({ label: 'ping-auto ' });
  await load(page, docs);
  p = await page.evaluate(() => QT.status.ping('Answered: x \u2192 y'));
  ok('auto ping is off by default', p.reason === 'not_tested');
  await page.evaluate(() => QT.status.setAutoPing(true));
  await page.evaluate(() => { window.__out = []; QT.status.ping('Answered: x \u2192 y').then((v) => window.__out.push(v)); });
  await waitFor(page, () => window.__out.length === 1);
  s = await sends(page);
  ok('auto ping on: the first ping goes out without a test (new thread)', s.length === 1 && s[0].anchor && (await page.evaluate(() => window.__out[0].ok)) === true, JSON.stringify(s));
  await page.context().close();
  page = await newPage({ label: 'ping-auto2 ' });
  await load(page, docs);
  await page.evaluate(() => { QT.status.setAutoPing(true); window.__cm.failQueue = ['consent_required', 'consent_required']; window.__out = []; QT.status.ping('Answered: x \u2192 y').then((v) => window.__out.push(v)); });
  await waitFor(page, () => window.__out.length === 1);
  p = await page.evaluate(() => QT.status.ping('Answered: again'));
  ok('auto ping on, but refused: it stops for the visit and never loops', (await page.evaluate(() => window.__out[0].ok)) === false && p.ok === false && (await sends(page)).length === 1, JSON.stringify(p));
  await page.context().close();

  // 6g: stored thread that does not exist any more -> a new thread is made
  page = await newPage({ label: 'ping6 ' });
  await load(page, Object.assign({}, docs, { meta: { ping: { id: 'ping', threadId: 'old-thread' } } }));
  await page.evaluate(() => { window.__cm.failQueue = ['not_found']; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  r = await result(page);
  s = await sends(page);
  ok('old thread is gone (not_found): a new thread is started and the test works', r.ok === true && s.length === 2 && s[0].threadId === 'old-thread' && s[1].anchor && !s[1].threadId, JSON.stringify(s));
  ok('old thread is gone: the new thread id replaces it in meta/ping', (await page.evaluate(() => JSON.stringify(window.__metaWrites.slice(-1)))) === '[["ping",{"threadId":"thr-1"}]]', await page.evaluate(() => JSON.stringify(window.__metaWrites)));
  await page.context().close();

  // 6h: a stored thread from an earlier visit is reused
  page = await newPage({ label: 'ping7 ' });
  await load(page, Object.assign({}, docs, { meta: { ping: { id: 'ping', threadId: 'kept-thread' } } }));
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  s = await sends(page);
  ok('thread from meta/ping is reused (reply, no new thread)', s.length === 1 && s[0].threadId === 'kept-thread' && (await page.evaluate(() => window.__cm.calls.filter((c) => c.fn === 'anchor').length)) === 0, JSON.stringify(s));
  ok('thread unchanged -> meta/ping is not written again', (await page.evaluate(() => window.__metaWrites.length)) === 0);
  await page.context().close();

  // 6i: click gesture rules for the automatic ping
  page = await newPage({ label: 'ping8 ' });
  await load(page, docs);
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  await page.evaluate(() => { window.__act = false; window.__out = []; QT.status.ping('Answered: late → one').then((x) => window.__out.push(x)); });
  await page.clock.runFor(21 * 1000);
  await flush(page);
  ok('ping without a recent click waits instead of failing (nothing sent yet)', (await sends(page)).length === 1);
  await page.mouse.click(300, 400);
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 2);
  s = await sends(page);
  ok('ping: sent with her next click', s.length === 2 && s[1].text === 'Answered: late → one' && s[1].threadId === 'thr-1', JSON.stringify(s));
  await waitFor(page, () => window.__out.length === 1);
  ok('ping: the caller still gets {ok:true}', (await page.evaluate(() => window.__out[0].ok)) === true);
  await page.context().close();

  // 6j: "claude_unavailable" on an automatic ping: one more try on her next click, then stop quietly
  page = await newPage({ label: 'ping9 ' });
  await load(page, docs);
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  await page.clock.runFor(21 * 1000);
  await page.evaluate(() => { window.__cm.failQueue = ['claude_unavailable', 'claude_unavailable']; window.__out = []; QT.status.ping('Answered: z → one').then((x) => window.__out.push(x)); });
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 2);
  await flush(page);
  ok('claude_unavailable once: the words are kept, caller not answered yet', (await page.evaluate(() => window.__out.length)) === 0);
  await page.mouse.click(300, 400);
  await page.clock.runFor(21 * 1000);
  await waitFor(page, () => window.__out.length === 1);
  const o1 = await page.evaluate(() => window.__out[0]);
  ok('claude_unavailable twice: gives up quietly with the reason', o1.ok === false && o1.reason === 'claude_unavailable', JSON.stringify(o1));
  s = await sends(page);
  ok('claude_unavailable twice: three tries in total at most (test + 2)', s.length === 3, String(s.length));
  p = await page.evaluate(() => QT.status.ping('Answered: more'));
  ok('after giving up, no more automatic pings this visit', p.ok === false && p.reason !== undefined && (await sends(page)).length === 3, JSON.stringify(p));
  await page.context().close();

  // 6k: rate_limited on an automatic ping: waits a long time and tries again
  page = await newPage({ label: 'ping10 ' });
  await load(page, docs);
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  await page.clock.runFor(21 * 1000);
  await page.evaluate(() => { window.__cm.failQueue = ['rate_limited']; window.__out = []; QT.status.ping('Answered: r → one').then((x) => window.__out.push(x)); });
  await waitFor(page, () => window.__cm.calls.filter((c) => c.fn === 'send').length >= 2);
  await page.clock.runFor(20 * 1000);
  await flush(page);
  ok('rate_limited: it does not hammer Claude (still only 2 tries after 20 s)', (await sends(page)).length === 2);
  await page.clock.runFor(41 * 1000);
  await waitFor(page, () => window.__out.length === 1);
  s = await sends(page);
  ok('rate_limited: later it tries again and succeeds', s.length === 3 && (await page.evaluate(() => window.__out[0].ok)) === true, String(s.length));
  await page.context().close();

  // 6l: the layout's toast is used when there is one
  page = await newPage({ label: 'ping11 ' });
  await load(page, docs);
  await page.evaluate(() => { window.__toasts = []; QT.layout = { toast(t, o) { const el = { _text: t }; el._close = () => { window.__toasts.push('closed:' + t); }; window.__toasts.push(t); return el; } }; });
  await startTest(page);
  await waitFor(page, () => window.__r !== undefined);
  const tt = await page.evaluate(() => window.__toasts);
  ok('with the layout toast: "Checking..." first, then it is closed and the result shows', tt.length === 3 && /^Checking/.test(tt[0]) && tt[1].startsWith('closed:Checking') && tt[2] === OKMSG, JSON.stringify(tt));
  ok('with the layout toast: no second message box of our own', (await page.evaluate(() => document.querySelectorAll('.qt-conn').length)) === 0);
  await page.context().close();

  // 6m: pressing the button twice quickly does one test
  page = await newPage({ label: 'ping12 ' });
  await load(page, docs);
  await page.evaluate(() => { window.__p1 = QT.status.testConnection(); window.__p2 = QT.status.testConnection(); window.__same = window.__p1 === window.__p2; });
  await waitFor(page, () => window.__r === undefined && window.__cm.calls.filter((c) => c.fn === 'send').length === 1);
  await flush(page);
  ok('two quick clicks on "Test connection" send one message', (await page.evaluate(() => window.__same)) === true && (await sends(page)).length === 1);
  // the button handler form: testConnection(event)
  await page.evaluate(() => { const b = document.createElement('button'); b.id = 'tb'; b.textContent = 'Test connection'; document.getElementById('app').appendChild(b); b.addEventListener('click', QT.status.testConnection); });
  await page.clock.runFor(1000);
  ok('testConnection can be used directly as a click handler (busy flag is cleared again)', await (async () => { await page.click('#tb'); await waitFor(page, () => !document.getElementById('tb').hasAttribute('aria-busy')); return !(await page.evaluate(() => document.getElementById('tb').hasAttribute('aria-busy'))); })());
  await page.context().close();
  page = await newPage({ label: 'ping13 ' });
  await load(page, docs);
  await page.evaluate(() => { const b = document.createElement('button'); b.id = 'tb'; b.textContent = 'Test connection'; document.getElementById('app').appendChild(b); b.addEventListener('click', QT.status.testConnection); });
  await page.click('#tb');
  await waitFor(page, () => window.__cm.calls.some((c) => c.fn === 'send'));
  ok('the new thread is anchored at the button that was clicked', (await page.evaluate(() => window.__cm.calls.filter((c) => c.fn === 'anchor').map((c) => c.tag).join())) === 'BUTTON');
  await page.context().close();
}

/* =========================================================================================== 7. pictures: chips in light and dark */
if (only !== 'integration') {
  fs.mkdirSync(SHOTS, { recursive: true });
  const T1 = '2026-10-07T10:00:00.000Z', T2 = '2026-10-07T10:05:00.000Z';
  const A1 = { id: 'q', status: 'answered', key: 'A', label: 'Yes', answeredAt: T1 };
  const rows = [
    ['waiting', null, null],
    ['answeredUnseen', A1, null],
    ['seen', A1, { state: 'seen', seenAt: T2 }],
    ['working', A1, { state: 'working', seenAt: T2, note: 'Making version B bigger and moving the words to the left' }],
    ['done', A1, { state: 'done', seenAt: T2, doneNote: 'I made the map picture bigger, moved the words to the left and checked it on a phone.', doneImages: [{ url: 'data:image/svg+xml,x', alt: 'nope' }] }],
    ['followup', A1, { state: 'followup', seenAt: T2, followupId: 'q2' }],
    ['held', A1, { state: 'held', seenAt: T2 }],
  ];
  for (const scheme of ['light', 'dark']) {
    for (const w of [700, 400]) {
      const page = await newPage({ scheme, w, h: 900, label: 'shot-' + scheme + ' ' });
      await load(page, { sections: { look: section('look') }, questions: { q2: question('q2', 'look'), q3: question('q3', 'look') } });
      const res = await page.evaluate(([rows, svgImg]) => {
        const app = document.getElementById('app'); app.textContent = '';
        const h = document.createElement('h2'); h.textContent = 'Status chips'; app.appendChild(h);
        rows.forEach(([name, a, s], i) => {
          const id = 'r' + i;
          if (a) QT.store.answers[id] = Object.assign({}, a, { id }); if (s) QT.store.status[id] = Object.assign({ id }, s);
          if (s && s.followupId) QT.store.questions.q2 = QT.store.questions.q2 || { id: 'q2' };
          const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-bottom:1px solid var(--line)';
          const lab = document.createElement('code'); lab.textContent = name; lab.style.cssText = 'width:110px;flex:none;font-size:12px;color:var(--soft)';
          row.appendChild(lab); row.appendChild(QT.status.chip(id, { images: true })); app.appendChild(row);
        });
        // a chip inside a sticky-bar-like box next to a long title
        const bar = document.createElement('div'); bar.className = 'qbar'; bar.style.cssText = 'position:static;display:flex;gap:10px;align-items:flex-start;padding:10px;border:1px solid var(--line);border-radius:10px;margin-top:14px';
        const t = document.createElement('div'); t.style.cssText = 'flex:1 1 0;min-width:0;font-weight:700'; t.textContent = 'Which version of the home picture do you like best for the top of the page?';
        QT.store.answers.rw = { id: 'rw', status: 'answered', key: 'B', answeredAt: '2026-10-07T10:00:00.000Z' }; QT.store.status.rw = { id: 'rw', state: 'working', seenAt: '2026-10-07T10:05:00.000Z', note: 'Making version B bigger' };
        bar.appendChild(t); bar.appendChild(QT.status.chip('rw')); app.appendChild(bar);
        // NEW badge + heartbeat for a quick look
        const extra = document.createElement('div'); extra.style.cssText = 'margin-top:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap';
        QT.store.questions.nq = { id: 'nq', sectionId: 'look' };
        QT.store.meta.heartbeat = { id: 'heartbeat', at: new Date(Date.now() - 2 * 60000).toISOString() };
        extra.appendChild(QT.status.heartbeatEl());
        const stale = QT.status.heartbeatEl(); stale.textContent = 'Claude last checked for your answers 25 min ago (Claude may be busy. Your answers are safe.)'; stale._refresh = null; stale.setAttribute('data-stale', 'true'); extra.appendChild(stale);
        app.appendChild(extra);
        // contrast of every piece of chip text against its own background (WCAG)
        const lum = (c) => { const m = c.match(/[\d.]+/g).map(Number); const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(m[0]) + 0.7152 * f(m[1]) + 0.0722 * f(m[2]); };
        const toRgb = (c) => { const cv = document.createElement('canvas').getContext('2d'); cv.fillStyle = '#000'; cv.fillStyle = c; const s = cv.fillStyle; if (s[0] === '#') { const n = parseInt(s.slice(1), 16); return 'rgb(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ')'; } return s; };
        const out = [];
        const bgOf = (el) => { let e = el; while (e) { const b = getComputedStyle(e).backgroundColor; if (b && !/rgba\(.*,\s*0\)|transparent/.test(b)) return toRgb(b); e = e.parentElement; } return toRgb(getComputedStyle(document.body).backgroundColor || '#fff'); };
        app.querySelectorAll('.qt-pill, .qt-note, .qt-link, .qt-thumbs-label').forEach((el) => {
          const fg = toRgb(getComputedStyle(el).color), bg = bgOf(el);
          const l1 = lum(fg), l2 = lum(bg); const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
          out.push([el.className + ':' + el.textContent.slice(0, 20), Math.round(ratio * 10) / 10]);
        });
        const rgbOf = (sel) => { const e = app.querySelector(sel); return e ? getComputedStyle(e).backgroundColor.match(/[\d.]+/g).slice(0, 3).map(Number) : null; };
        const dotsCol = (() => { const e = app.querySelector('qt-chip[data-state="working"] .dots i'); return e ? getComputedStyle(e).backgroundColor.match(/[\d.]+/g).slice(0, 3).map(Number) : null; })();
        const hues = { working: rgbOf('qt-chip[data-state="working"] .qt-pill'), waiting: rgbOf('qt-chip[data-state="waiting"] .qt-pill'), done: rgbOf('qt-chip[data-state="done"] .qt-pill'), dots: dotsCol };
        return { hues, contrast: out, dotsAnim: getComputedStyle(app.querySelector('.dots i')).animationName, scrollW: document.documentElement.scrollWidth, clientW: document.documentElement.clientWidth };
      }, [rows, '']);
      const bad = res.contrast.filter(([, r]) => r < 4.5);
      ok('chips in ' + scheme + ' at ' + w + ' px: all text has contrast >= 4.5', bad.length === 0, JSON.stringify(bad) + ' (min ' + Math.min(...res.contrast.map((x) => x[1])) + ')');
      ok('chips at ' + w + ' px: no sideways scroll', res.scrollW <= res.clientW, res.scrollW + ' > ' + res.clientW);
      ok('chips: the dots are animated normally', res.dotsAnim !== 'none', res.dotsAnim);
      ok('chips in ' + scheme + ': "working" is blue (blue > red channel), "waiting" is red (red > blue), dots are blue too', res.hues.working[2] > res.hues.working[0] && res.hues.waiting[0] > res.hues.waiting[2] && res.hues.dots[2] > res.hues.dots[0], JSON.stringify(res.hues));
      await page.screenshot({ path: path.join(SHOTS, 'status-chips-' + scheme + (w === 700 ? '' : '-' + w) + '.png'), fullPage: true });
      await page.context().close();
    }
  }
  // "See the result" pictures (served by the test, no network)
  for (const scheme of ['light', 'dark']) {
    const tp = await newPage({ scheme, label: 'thumbs ' });
    await tp.route('https://img.test/**', (route) => route.fulfill({ contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80"><rect width="120" height="80" fill="#c9a66b"/><circle cx="60" cy="40" r="22" fill="#7a3b1d"/></svg>' }));
    await load(tp, { sections: { look: section('look') } });
    const thumbs = await tp.evaluate(async () => {
      QT.store.answers.d = { id: 'd', status: 'answered', key: 'A', answeredAt: '2026-10-07T10:00:00.000Z' };
      QT.store.status.d = { id: 'd', state: 'done', seenAt: '2026-10-07T10:05:00.000Z', doneNote: 'I made the map bigger.', doneImages: [1, 2, 3, 4, 5].map((i) => ({ url: 'https://img.test/p' + i + '.svg', alt: 'Result ' + i })) };
      const c = QT.status.chip('d', { images: true }); document.getElementById('app').appendChild(c);
      for (let i = 0; i < 40 && ![...c.querySelectorAll('img')].every((im) => im.complete && im.naturalWidth > 0); i++) await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 50)));
      const r = [...c.querySelectorAll('.qt-thumb')].map((a) => a.getBoundingClientRect());
      return { n: r.length, h: r.map((x) => Math.round(x.height)), loaded: [...c.querySelectorAll('img')].every((im) => im.naturalWidth > 0) };
    });
    ok('done pictures (' + scheme + '): at most 4 thumbnails, each at least 40 px tall, loaded', thumbs.n === 4 && thumbs.h.every((x) => x >= 40) && thumbs.loaded, JSON.stringify(thumbs));
    await tp.screenshot({ path: path.join(SHOTS, 'status-done-pictures-' + scheme + '.png'), clip: { x: 0, y: 0, width: 700, height: 160 } });
    await tp.context().close();
  }
  // reduced motion
  const rp = await newPage({ reduced: true, label: 'reduced ' });
  await load(rp, { sections: { look: section('look') } });
  const rm = await rp.evaluate(() => { QT.store.answers.r = { id: 'r', answeredAt: '2026-10-07T10:00:00.000Z' }; QT.store.status.r = { id: 'r', state: 'working', seenAt: '2026-10-07T10:05:00.000Z', note: 'n' }; const c = QT.status.chip('r'); document.getElementById('app').appendChild(c); return [...c.querySelectorAll('.dots i')].map((i) => getComputedStyle(i).animationName); });
  ok('reduced motion: the dots do not animate', rm.length === 3 && rm.every((a) => a === 'none'), JSON.stringify(rm));
  await rp.context().close();
}

/* =========================================================================================== 8. with the real core, and with the full page */
const AUDIO_ONLY = INIT.slice(0, INIT.indexOf('const cm = ')) + '})();';   // just the fake Web Audio part (the mock brings its own window.claude)
const fq = (id, sectionId, order, extra = {}) => Object.assign({
  id, sectionId, kind: 'choice', order, createdAt: iso(3600e3), title: 'Test question ' + id, story: ['A made-up story for ' + id + '.'], why: 'Because this is a test.',
  choices: ['A', 'B', 'C', 'D'].map((k) => ({ key: k, label: 'Choice ' + k, explain: 'If you pick ' + k + ' something happens.' })),
  required: false, round: 1, parentId: null, who: 'owner', previouslyNotSure: false, oldId: null,
}, extra);
function bigSeed() {
  const seed = sampleSeed(T0);
  seed['questions/q4'] = fq('q4', 'look', 1);
  seed['questions/k1'] = fq('k1', 'kathy', 1, { kind: 'readonly', choices: [], who: 'kathy', needs: 'The opening hours.' });
  seed['status/q2'] = Object.assign({}, seed['status/q2'], { seenAt: iso(300e3), at: iso(300e3) });
  return seed;
}
async function realPage(o = {}) {
  const ctx = await browser.newContext({ viewport: { width: o.w || 700, height: o.h || 800 }, colorScheme: o.scheme || 'light', locale: 'en-US', timezoneId: 'America/New_York' });
  const page = await ctx.newPage();
  page.setDefaultTimeout(ms(15000));
  page.on('pageerror', (e) => errs.push((o.label || '') + 'pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|Failed to load resource|net::ERR/.test(m.text())) errs.push((o.label || '') + 'console: ' + m.text()); });
  await page.addInitScript(AUDIO_ONLY);
  if (o.init) await page.addInitScript(o.init);
  await injectMock(page, o.seed || bigSeed(), o.mock || {});
  await page.clock.install({ time: new Date(T0) });
  await page.goto(site.url + (o.url || 'dist/index.html'), { waitUntil: 'load' });
  await waitReady(page);
  await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 150))));
  return page;
}
const mockPings = (page) => page.evaluate(() => window.__mock.pings.map((p) => p.target));

if (process.env.ONLY !== 'unit' && fs.existsSync(path.join(T, 'test', 'mockfix.mjs'))) {
  // ---- 8a: the real core + only this module (python3 build.py --out dist-status/index.html --only 40-status.js)
  const iso1 = path.join(T, 'dist-status', 'index.html');
  if (fs.existsSync(iso1)) {
    const page = await realPage({ url: 'dist-status/index.html', label: 'core ' });
    ok('real core: QT.status and QT.sound exist', await page.evaluate(() => typeof QT.status.chip === 'function' && typeof QT.sound.chime === 'function' && typeof QT.status.ping === 'function'));
    ok('real core: tab title counts waiting questions (3)', (await page.title()) === '(3) Terminal', await page.title());
    ok('real core: first visit shows no NEW', (await page.evaluate(() => Object.keys(QT.store.questions).filter((id) => QT.status.isNew(id)).length)) === 0);
    await page.evaluate(() => { window.__tr = undefined; QT.status.testConnection().then((r) => { window.__tr = r; }); });
    await until(page, () => window.__tr !== undefined, null, 8000);
    ok('real core: test connection works against the mock', (await page.evaluate(() => window.__tr.ok)) === true);
    ok('real core: meta/ping was written by QT.write.meta', (await page.evaluate(() => window.__mock.writes.some((w) => w.path === 'meta/ping' && w.data && w.data.threadId === 't1'))) === true);
    // the core pings after an answer; status.ping holds it back for 20 s
    await page.evaluate(() => QT.write.answer('q1', { key: 'A', label: 'Choice A' }));
    await flush(page);
    ok('real core: an answer right after the test is held back', (await mockPings(page)).length === 1);
    await page.clock.runFor(21 * 1000);
    await until(page, () => window.__mock.pings.length >= 2, null, 8000);
    const pp = await mockPings(page);
    ok('real core: 20 s later "Answered: <title> -> <choice>" goes into the same thread', pp.length === 2 && pp[1].threadId === 't1' && pp[1].text === 'Answered: Test question q1 → Choice A', JSON.stringify(pp[1]));
    ok('real core: the ping carries only the title and the choice label', !/story|because/i.test(pp[1].text));
    ok('real core: the answered question is now "answeredUnseen" and the title count dropped', (await page.evaluate(() => QT.status.state('q1'))) === 'answeredUnseen' && (await page.title()) === '(2) Terminal', await page.title());
    // her own typed answer never reaches Claude
    await page.evaluate(() => QT.write.answer('q4', { key: 'own', ownText: 'MY PRIVATE WORDS', label: 'MY PRIVATE WORDS' }));
    await page.clock.runFor(21 * 1000);
    await until(page, () => window.__mock.pings.length >= 3, null, 8000);
    const p3 = await mockPings(page);
    ok('real core: her own typed words are never sent', p3.length === 3 && !/PRIVATE/.test(JSON.stringify(p3)) && /own answer/.test(p3[2].text), JSON.stringify(p3[2]));
    // Claude writes status -> chips follow, done -> chime
    await page.evaluate(() => QT.sound.set(true));
    await page.evaluate(() => window.__mock.db.put('status/q1', { id: 'q1', state: 'working', seenAt: new Date().toISOString(), note: 'Making it bigger', at: new Date().toISOString() }));
    await page.evaluate(() => { const c = QT.status.chip('q1'); document.getElementById('app').appendChild(c); window.__c = c; });
    ok('real core: chip follows what Claude wrote', /working on it/i.test(await page.evaluate(() => window.__c.textContent)) && /Making it bigger/.test(await page.evaluate(() => window.__c.textContent)));
    await page.evaluate(() => window.__mock.db.put('status/q1', { id: 'q1', state: 'done', seenAt: new Date().toISOString(), doneNote: 'Finished', at: new Date().toISOString() }));
    await until(page, () => window.__audio.starts >= 3, null, 5000);
    ok('real core: Claude marking it done makes one chime', (await chimeCount(page)) === 1, 'chimes=' + (await chimeCount(page)));
    ok('real core: ... and the chip says Done', /Done/.test(await page.evaluate(() => window.__c.textContent)));
    await page.context().close();
  } else info('isolated build dist-status/index.html not found: run  python3 build.py --out dist-status/index.html --only 40-status.js');

  // ---- 8b: the full page
  {
    let page = await realPage({ label: 'full ' });
    const hbText = () => page.evaluate(() => { const e = document.querySelector('.hb'); return e ? e.textContent.replace(/\s+/g, ' ').trim() : null; });
    ok('full page: top bar shows "Claude last checked for your answers 2 min ago"', /Claude last checked for your answers 2 min ago/.test(await hbText()) || /2 min ago/.test(await hbText()), await hbText());
    ok('full page: tab title "(3) Terminal"', (await page.title()) === '(3) Terminal', await page.title());
    const menuCounts = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll('.mi')].map((b) => [b.getAttribute('data-key'), (b.querySelector('.count') || {}).textContent || ''])));
    ok('full page: menu numbers are the numbers of waiting questions', menuCounts['s:look'] === '1' && menuCounts['s:other'] === '1' && menuCounts['s:my-topic'] === '1', JSON.stringify(menuCounts));
    ok('full page: no NEW badges on a first visit', (await page.evaluate(() => document.querySelectorAll('.badge-new').length)) === 0);
    // test connection
    ok('full page: sound toggle starts off', (await page.getAttribute('.sound-btn', 'aria-pressed')) === 'false');
    await page.click('.test-btn');
    await until(page, () => [...document.querySelectorAll('.toast')].some((t) => /Claude heard you/.test(t.textContent)), null, 8000);
    const toasts = await page.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent.replace(/[×]/g, '').trim()));
    ok('full page: "Test connection" shows "Claude heard you ✓" once', toasts.filter((t) => t === 'Claude heard you ✓').length === 1 && !toasts.some((t) => /^Checking/.test(t)), JSON.stringify(toasts));
    const pings = await mockPings(page);
    ok('full page: one test message with the test words', pings.length === 1 && pings[0].text === 'Question Terminal test ping', JSON.stringify(pings));
    ok('full page: the button is usable again', (await page.evaluate(() => !document.querySelector('.test-btn').disabled)) === true);
    // sound toggle
    await page.click('.sound-btn');
    ok('full page: sound toggle is on and remembered', (await page.getAttribute('.sound-btn', 'aria-pressed')) === 'true' && (await page.evaluate(() => localStorage.getItem('qt.sound'))) === '1');
    ok('full page: turning sound on plays one chime (the layout asks for it)', (await chimeCount(page)) === 1, 'chimes=' + (await chimeCount(page)));
    // a new question arrives
    await page.clock.runFor(4100);
    await page.evaluate((q) => window.__mock.db.put('questions/q5', q), fq('q5', 'other', 5, { createdAt: new Date(T0).toISOString() }));
    await until(page, () => window.__audio.starts >= 6, null, 5000);
    ok('full page: a new question chimes', (await chimeCount(page)) === 2, 'chimes=' + (await chimeCount(page)));
    ok('full page: tab title goes up: "(4) Terminal"', (await page.title()) === '(4) Terminal', await page.title());
    // she opens the section: NEW badge on the new one only
    await page.evaluate(() => QT.route.go('section', { id: 'other' }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 200))));
    const newRows = await page.evaluate(() => [...document.querySelectorAll('#qt-view .badge-new')].map((b) => (b.closest('.item') || b.parentElement).textContent.replace(/\s+/g, ' ').trim()));
    ok('full page: only the new question has a NEW badge', newRows.length === 1 && /Test question q5/.test(newRows[0]), JSON.stringify(newRows));
    ok('full page: unanswered rows sit under the "Waiting for you" heading and carry no chip; the answered row has its chip',
      JSON.stringify(await page.evaluate(() => { const g = [...document.querySelectorAll('#qt-view .sx-qgroup')].map((x) => ({ h: x.querySelector('h3').textContent.replace(/\s+/g, ' ').trim(), rows: [...x.querySelectorAll('.item')].map((r) => ({ t: r.querySelector('.sx-qtitle').textContent.trim(), chip: r.querySelector('qt-chip') ? r.querySelector('qt-chip').getAttribute('data-state') : null })) })); return g; }))
        === JSON.stringify([{ h: 'Waiting for you 2', rows: [{ t: 'Test question q1', chip: null }, { t: 'Test question q5', chip: null }] }, { h: 'You answered 1', rows: [{ t: 'Test question q2', chip: 'seen' }] }]),
      JSON.stringify(await page.evaluate(() => [...document.querySelectorAll('#qt-view .sx-qgroup')].map((x) => x.querySelector('h3').textContent.trim() + ': ' + [...x.querySelectorAll('.item')].map((r) => (r.querySelector('.sx-qtitle') || {}).textContent + '/' + (r.querySelector('qt-chip') ? r.querySelector('qt-chip').getAttribute('data-state') : '-')).join(', ')))));
    ok('full page: no list row says "Waiting for you" in a chip', (await page.evaluate(() => [...document.querySelectorAll('#qt-view qt-chip')].filter((c) => c.getAttribute('data-state') === 'waiting').length)) === 0);
    // open the new question: the badge goes away
    await page.evaluate(() => QT.route.go('question', { id: 'q5' }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 200))));
    ok('full page: opening a question clears its NEW badge', (await page.evaluate(() => QT.status.isNew('q5'))) === false);
    const barChip = await page.evaluate(() => { const c = document.querySelector('#qt-view .qbar qt-chip'); return c ? { text: c.textContent.replace(/\s+/g, ' ').trim(), state: c.getAttribute('data-state') } : null; });
    ok('full page: the sticky question bar has the chip ("Waiting for you")', barChip && barChip.state === 'waiting' && /Waiting for you/.test(barChip.text), JSON.stringify(barChip));
    // she answers by clicking a choice: chip changes in the bar
    await page.evaluate(() => document.querySelector('.qa-choice') && document.querySelector('.qa-choice').scrollIntoView({ block: 'center' }));
    const choice = await page.$('#qt-view .qa-choice');
    if (choice) { await choice.click(); await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 250)))); }
    const afterAns = await page.evaluate(() => { const c = document.querySelector('#qt-view .qbar qt-chip'); return c ? c.getAttribute('data-state') : null; });
    ok('full page: after she answers, the bar chip says "You answered ..."', afterAns === 'answeredUnseen', String(afterAns));
    ok('full page: the tab title went down again', (await page.title()) === '(3) Terminal', await page.title());
    await page.clock.runFor(21 * 1000);
    await until(page, () => window.__mock.pings.length >= 2, null, 8000);
    const pings2 = await mockPings(page);
    ok('full page: her answer was passed on after 20 s: "Answered: <title> -> <choice>"', pings2.length === 2 && /^Answered: Test question q5 → Choice [A-D]$/.test(pings2[1].text) && pings2[1].threadId === 't1', JSON.stringify(pings2[1]));
    // Claude starts working: the note shows in the bar on one line
    await page.evaluate(() => window.__mock.db.put('status/q5', { id: 'q5', state: 'working', seenAt: new Date(Date.now() + 1000).toISOString(), note: 'Making version B bigger', at: new Date(Date.now() + 1000).toISOString() }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 250))));
    const bar2 = await page.evaluate(() => { const c = document.querySelector('#qt-view .qbar qt-chip'); const n = c && c.querySelector('.qt-note'); return { state: c && c.getAttribute('data-state'), note: n && n.textContent, oneLine: n && getComputedStyle(n).whiteSpace, h: document.querySelector('#qt-view .qbar').getBoundingClientRect().height }; });
    ok('full page: bar chip follows Claude: "Claude is working on it" + note on one line', bar2.state === 'working' && bar2.note === 'Making version B bigger' && bar2.oneLine === 'nowrap', JSON.stringify(bar2));
    ok('full page: the sticky bar stays small (<= 100 px)', bar2.h <= 100, String(bar2.h));
    await page.screenshot({ path: path.join(SHOTS, 'status-bar-working-light.png') });
    // stale heartbeat: amber with the friendly hint
    await page.evaluate(() => window.__mock.db.put('meta/heartbeat', { at: new Date(Date.now() - 45 * 60000).toISOString(), note: 'x' }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 250))));
    const stale = await page.evaluate(() => { const e = document.querySelector('.hb'); return { cls: e.className, text: e.textContent.replace(/\s+/g, ' ').trim(), color: getComputedStyle(e).color }; });
    ok('full page: an old heartbeat turns amber with "(Claude may be busy. Your answers are safe.)"', /stale/.test(stale.cls) && /45 min ago/.test(stale.text) && /may be busy/.test(stale.text), JSON.stringify(stale));
    await page.screenshot({ path: path.join(SHOTS, 'status-bar-stale-light.png') });
    await page.context().close();

    // dark, and the list with every chip
    page = await realPage({ label: 'full-dark ', scheme: 'dark', seed: (() => { const sd = bigSeed(); const t = (m) => new Date(T0 - m * 60000).toISOString(); sd['questions/q4'].sectionId = 'other';
      sd['answers/q1'] = { id: 'q1', status: 'answered', key: 'A', label: 'Choice A', answeredAt: t(5), round: 1 };
      sd['answers/q4'] = { id: 'q4', status: 'answered', key: 'B', label: 'Choice B', answeredAt: t(20), round: 1 }; sd['status/q4'] = { id: 'q4', state: 'working', seenAt: t(10), note: 'Making version B bigger', at: t(2) };
      sd['questions/q6'] = fq('q6', 'other', 6); sd['answers/q6'] = { id: 'q6', status: 'answered', key: 'C', label: 'Choice C', answeredAt: t(60), round: 1 }; sd['status/q6'] = { id: 'q6', state: 'done', seenAt: t(50), doneNote: 'I made the picture bigger and moved the words to the left, then checked it.', at: t(30) };
      sd['questions/q7'] = fq('q7', 'other', 7); sd['answers/q7'] = { id: 'q7', status: 'answered', key: 'D', label: 'Choice D', answeredAt: t(90), round: 1 }; sd['status/q7'] = { id: 'q7', state: 'followup', seenAt: t(80), followupId: 'q1', at: t(70) };
      sd['questions/q8'] = fq('q8', 'other', 8); sd['answers/q8'] = { id: 'q8', status: 'answered', key: 'unsure', label: '', answeredAt: t(120), round: 1 }; sd['status/q8'] = { id: 'q8', state: 'held', seenAt: t(100), at: t(100) };
      return sd; })() });
    await page.evaluate(() => QT.route.go('section', { id: 'other' }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 300))));
    const st = await page.evaluate(() => [...document.querySelectorAll('#qt-view qt-chip')].map((c) => c.getAttribute('data-state')));
    ok('full page (dark): the list shows all kinds of chips', ['working', 'answeredUnseen', 'seen', 'done', 'followup', 'held'].every((x) => st.includes(x)), JSON.stringify(st));
    await page.screenshot({ path: path.join(SHOTS, 'status-list-dark.png'), fullPage: true });
    await page.context().close();
    page = await realPage({ label: 'full-light2 ', seed: await (async () => { const sd = bigSeed(); return sd; })() });
    await page.evaluate(() => QT.route.go('section', { id: 'other' }));
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 300))));
    await page.screenshot({ path: path.join(SHOTS, 'status-list-light.png'), fullPage: true });
    await page.context().close();

    // writers only: friendly message, answers do not ping
    page = await realPage({ label: 'full-wo ', mock: { comments: 'writers_only' } });
    await page.click('.test-btn');
    await until(page, () => [...document.querySelectorAll('.toast')].some((t) => /Claude did not hear this one/.test(t.textContent)), null, 8000);
    const wt = await page.evaluate(() => [...document.querySelectorAll('.toast')].map((t) => t.textContent.replace(/[×]/g, '').trim()));
    ok('full page (writers only): plain "Claude did not hear this one. That is OK ..." message', wt.some((t) => t === 'Claude did not hear this one. That is OK. Claude still finds your answers every few minutes.') && wt.filter((t) => /Claude did not hear this one/.test(t)).length === 1, JSON.stringify(wt));
    await page.evaluate(() => QT.write.answer('q1', { key: 'A', label: 'Choice A' }));
    await page.clock.runFor(25 * 1000);
    await flush(page);
    ok('full page (writers only): nothing is sent to Claude, the answer is still saved', (await mockPings(page)).length === 0 && (await page.evaluate(() => !!QT.store.answers.q1)));
    await page.context().close();

    // no comments feature at all
    page = await realPage({ label: 'full-nc ', mock: { comments: null } });
    await page.click('.test-btn');
    await until(page, () => [...document.querySelectorAll('.toast')].some((t) => /Claude did not hear this one/.test(t.textContent)), null, 8000);
    ok('full page (no comments feature): friendly message', true);
    await page.context().close();

    // no notebook at all: the status API still answers
    page = await realPage({ label: 'full-off ', mock: { db: null } });
    const off = await page.evaluate(() => ({ title: document.title, hb: QT.status.heartbeatLabel().text, bc: QT.status.badgeCount('look'), st: QT.status.state('x'), chip: QT.status.chip('x').textContent }));
    ok('full page (no notebook): plain title, "not checked for your answers yet", no crash', off.title === 'Terminal' && off.hb === 'Claude has not checked for your answers yet' && off.bc === 0 && off.st === 'waiting', JSON.stringify(off));
    await page.context().close();
  }
}

await finish({ browser, site, errs });
