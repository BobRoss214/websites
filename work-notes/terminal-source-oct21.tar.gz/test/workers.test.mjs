/* Workers part test (SPEC2 section 5).   NODE_PATH=/opt/node22/lib/node_modules node T/test/workers.test.mjs      Ports 9736+.
 * The crew tree and its cards, the summary strip and filters, folding, "What they did", progress, strength, task links, "Ask this worker" (the write,
 * the bubbles, seen / working / answered), empty and offline states, unsafe text.  It builds the page from T/src into its own snapshot.
 */
import { H, ok, info, seed, IDS, IDS2, sleep, partsDocs, openParts, tabsInfo, currentPart, textOf, unsafeReport } from './parts-lib.mjs';
import { okSoon } from './harness.mjs';
import { XSS, LONGWORD } from './fixtures.mjs';

const h = await H.start(9736, { src: true });
const DOCS = partsDocs();
const V = '#qt-view ';
const card = (id) => `article.wk-card[data-wid="${id}"]`;
const cardText = (page, id) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.innerText.replace(/\s+/g, ' ').trim() : null; }, card(id));

const fid = (name) => `[data-fid="${name}"]`;
const writesTo = async (page, prefix) => (await H.writes(page)).filter((w) => w.path.startsWith(prefix));
const goWorkers = async (page, params = {}) => { await H.go(page, 'workers', params); await H.settle(page, 350); };
const showFinished = async (page) => { const on = await page.evaluate(() => { const i = document.querySelector('[data-fid="showfin"]'); return !!i && i.checked; }); if (!on) { await page.click('label.wk-showfin'); await H.settle(page, 300); } };
/* really on screen: not folded away (a folded box is 0 high with hidden overflow, or inert / hidden) */
const SHOWN = `(e) => { if (!e || !e.getClientRects().length) return false; for (let p = e; p && p !== document.body; p = p.parentElement) { const cs = getComputedStyle(p); if (cs.display === 'none' || cs.visibility === 'hidden' || p.hidden || p.inert || p.getAttribute('aria-hidden') === 'true') return false; if (p !== e && p.getBoundingClientRect().height < 2 && /(hidden|clip)/.test(cs.overflow + cs.overflowY)) return false; } const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }`;
const visibleIds = (page) => page.evaluate((src) => { const shown = eval(src); return [...document.querySelectorAll('article.wk-card')].filter(shown).map((a) => a.dataset.wid); }, SHOWN);
const STATEWORD = { working: /Working/, waiting: /Waiting for you/, resting: /Resting/, done: /Finished ✓/, stopped: /Stopped/ };

/* ---------- 1. the crew tree ---------- */
await H.block('1 crew tree', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'tree: ' });
  await goWorkers(page);
  const t = await textOf(page);
  ok('a friendly title and one line under it', /The crew/.test(t) && /Everyone who works on your website/.test(t), t.slice(0, 120));
  ok('the top card is Claude (the lead); teams come under it, their helpers under them', await page.evaluate(() => { const ids = [...document.querySelectorAll('article.wk-card')].filter((a) => a.getClientRects().length).map((a) => a.dataset.wid); return ids[0] === 'claude' && ids.indexOf('team-maps') > 0 && ids.indexOf('map-a') > ids.indexOf('team-maps') && ids.indexOf('team-build') > ids.indexOf('map-b') && ids.indexOf('b-question') > ids.indexOf('team-build'); }), (await visibleIds(page)).join());
  const vis = await visibleIds(page);
  ok('finished workers are folded away by default (Finished list), the others are on show', !['map-c', 'b-core', 'q-other', 'site-1'].some((i) => vis.includes(i)) && ['claude', 'map-a', 'map-b', 'map-d', 'b-question', 'b-sections', 'q-cathy', 'w-xss'].every((i) => vis.includes(i)), vis.join());
  ok('a "Finished (4)" fold-out says how many are tucked away', /Finished \(4\)/.test(t), t.slice(0, 80));
  await showFinished(page);
  const vis2 = await visibleIds(page);
  ok('"Show finished" brings the 4 finished workers on screen', ['map-c', 'b-core', 'q-other', 'site-1'].every((i) => vis2.includes(i)), vis2.join());
  ok('card kinds are marked (lead, team, helper) with the right nesting depth', await page.evaluate(() => { const k = (id) => (document.querySelector(`article.wk-card[data-wid="${id}"]`) || {}).className || ''; return /is-lead/.test(k('claude')) && /is-team/.test(k('team-maps')) && /is-helper/.test(k('map-a')); }));
  // each card says its name, its role and the right state word
  const bad = [];
  for (const w of Object.values(DOCS).filter((d) => d && d.kind && d.role && d.state)) {
    if (/xss/.test(w.id)) continue;
    const ct = await cardText(page, w.id);
    if (!ct) { bad.push(w.id + ': no card'); continue; }
    if (!ct.includes(w.name)) bad.push(w.id + ': name');
    if (!ct.includes(w.role)) bad.push(w.id + ': role');
    if (!STATEWORD[w.state].test(ct)) bad.push(w.id + ': state word ' + w.state);
    const hasRight = /Right now:/.test(ct);
    if ((w.state === 'working' || w.state === 'waiting') && !hasRight) bad.push(w.id + ': no "Right now"');
    if (!(w.state === 'working' || w.state === 'waiting') && hasRight) bad.push(w.id + ': "Right now" when ' + w.state);
    if ((w.state === 'working' || w.state === 'waiting') && !ct.includes(w.now)) bad.push(w.id + ': now text');
    if (w.state === 'done' && !ct.includes(w.result)) bad.push(w.id + ': result');
    if (w.state === 'stopped' && !/Stopped/.test(ct)) bad.push(w.id + ': stopped');
  }
  ok('every worker card shows name, role, the right state word, "Right now:" only when working or waiting, and the result when finished', bad.length === 0, bad.slice(0, 5).join(' | '));
  const st = await cardText(page, 'map-a');
  ok('"Started 25 min ago · last update 2 min ago" style line is there (map-a)', /Started 25 min ago/.test(st) && /last update 2 min ago/.test(st), st);
  ok('a resting worker that never started has no "Started" line (map-d), only the last update', !/Started/.test(await cardText(page, 'map-d')) && /last update/.test(await cardText(page, 'map-d')), await cardText(page, 'map-d'));
  ok('Strength labels: Opus is "extra strong", Sonnet is "standard" (and no jargon names)', /extra strong/.test(await cardText(page, 'claude')) && /extra strong/.test(await cardText(page, 'map-b')) && /Strength: standard/.test(await cardText(page, 'map-a')) && !/Sonnet|Opus|brain/i.test(await textOf(page)), (await cardText(page, 'map-b')).slice(0, 200));
  ok('a team (brain "") shows no strength label', !/Strength/.test(await cardText(page, 'team-maps')), (await cardText(page, 'team-maps')).slice(0, 200));
  ok('the lead says how big its crew is ("Boss of 3 teams and 11 workers" style)', /Boss of 3 teams/.test(await cardText(page, 'claude')), (await cardText(page, 'claude')).slice(0, 220));
  const bars = await page.evaluate(() => [...document.querySelectorAll('article.wk-card')].map((a) => ({ id: a.dataset.wid, bar: (a.querySelector('[role=progressbar]') || {}).getAttribute ? { now: a.querySelector('[role=progressbar]').getAttribute('aria-valuenow'), max: a.querySelector('[role=progressbar]').getAttribute('aria-valuemax'), label: a.querySelector('[role=progressbar]').getAttribute('aria-label') } : null })).filter((x) => x.bar));
  ok('a progress bar only on the worker that has a real number (map-a, 40 of 100, with a name)', bars.length === 1 && bars[0].id === 'map-a' && bars[0].bar.now === '40' && bars[0].bar.max === '100' && /map drawer a/i.test(bars[0].bar.label), JSON.stringify(bars));
  await H.shot(page, 'workers-tree-1366');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 1b. look: the Claude card colour, the round faces, the task chips, the counters, chip contrast ---------- */
await H.block('1b look', async () => {
  const LUM = `const lum = (c) => { const m = c.match(/[\\d.]+/g).map(Number); const [r, g, b] = m.slice(0, 3).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; }; const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }; const backOf = (e) => { for (let n = e; n; n = n.parentElement) { const c = getComputedStyle(n).backgroundColor; if (!/rgba?\\(0, 0, 0, 0\\)|transparent/.test(c)) return c; } return 'rgb(255, 255, 255)'; };`;
  for (const scheme of ['light', 'dark']) {
    const page = await openParts(h, { w: 1366, h: 900, scheme, label: `look (${scheme}): ` });
    await goWorkers(page);
    await showFinished(page);
    const lead = await page.evaluate(() => { const c = document.querySelector('article.wk-card.is-lead'); return { state: c.dataset.state, bg: getComputedStyle(c).backgroundImage, chip: c.querySelector('.wk-chip').textContent.trim() }; });
    const tok = (name) => page.evaluate((n) => { const d = document.createElement('i'); d.style.color = `var(${n})`; document.body.appendChild(d); const c = getComputedStyle(d).color; d.remove(); return c; }, name);
    ok(`(${scheme}) the Claude card is tinted by what Claude is doing (${lead.state}: blue while working), not pink`, lead.state === 'working' && lead.chip.includes('Working') && lead.bg.includes(await tok('--info-bg')) && !lead.bg.includes(await tok('--accent-soft')), JSON.stringify(lead));
    await H.put(page, 'workers/claude', { ...DOCS['workers/claude'], state: 'waiting', waitingFor: 'owner' }); await H.settle(page, 400);
    ok(`(${scheme}) ... and when Claude waits for her the tint follows the waiting colour`, await page.evaluate(async (wait) => document.querySelector('article.wk-card.is-lead').dataset.state === 'waiting' && getComputedStyle(document.querySelector('article.wk-card.is-lead')).backgroundImage.includes(wait), await tok('--warn-bg')));
    await H.put(page, 'workers/claude', DOCS['workers/claude']); await H.settle(page, 400);
    const face = await page.evaluate(() => [...document.querySelectorAll('.wk-badge')].map((b) => { const f = b.querySelector('.wk-face'), r = b.getBoundingClientRect(), fr = f.getBoundingClientRect(); return { who: b.closest('.wk-card').dataset.wid, text: f.textContent, w: Math.round(r.width), h: Math.round(r.height), cutX: b.scrollWidth > b.clientWidth + 1, cutY: b.scrollHeight > b.clientHeight + 1, faceW: Math.round(fr.width), faceInside: fr.left >= r.left - 0.5 && fr.right <= r.right + 0.5 && fr.top >= r.top - 0.5 && fr.bottom <= r.bottom + 0.5 }; }));
    ok(`(${scheme}) the round faces (letters like "MD" and emoji) are not cut off and fit inside their circle (${face.length} faces)`, face.length > 10 && face.some((f) => /^[A-Z]{2}$/.test(f.text)) && face.every((f) => !f.cutX && !f.cutY && f.faceInside), JSON.stringify(face.filter((f) => f.cutX || f.cutY || !f.faceInside).slice(0, 3)));
    const chips = await page.evaluate(() => [...document.querySelectorAll('a.wk-task')].map((a) => Math.round(a.getBoundingClientRect().height)));
    ok(`(${scheme}) the task chips on a card are at least 40 px high (${chips.length} of them)`, chips.length > 1 && chips.every((x) => x >= 40), chips.join());
    const cnt = await page.evaluate(() => { const b = document.querySelector('.wk-count'), cs = getComputedStyle(b); return { border: cs.borderTopWidth + ' ' + cs.borderTopStyle, radius: cs.borderTopLeftRadius, bg: cs.backgroundColor, cursor: cs.cursor }; });
    ok(`(${scheme}) the counters look like the Tasks filters: a real border, rounded, a pointer`, parseFloat(cnt.border) >= 2 && /solid/.test(cnt.border) && parseFloat(cnt.radius) >= 6 && cnt.cursor === 'pointer', JSON.stringify(cnt));
    const before = await page.evaluate(() => { const b = document.querySelector('[data-fid="flt-working"]'), cs = getComputedStyle(b); return { bg: cs.backgroundColor, border: cs.borderTopColor }; });
    await page.click(fid('flt-working')); await H.settle(page, 300);
    const after = await page.evaluate(() => { const b = document.querySelector('[data-fid="flt-working"]'), cs = getComputedStyle(b); return { bg: cs.backgroundColor, border: cs.borderTopColor, mark: getComputedStyle(b, '::after').content, pressed: b.getAttribute('aria-pressed') }; });
    ok(`(${scheme}) a pressed counter looks different (panel colour, dark border, a small cross) and says so`, after.pressed === 'true' && (after.bg !== before.bg || after.border !== before.border) && /✕/.test(after.mark), JSON.stringify([before, after]));
    await page.click(fid('flt-working')); await H.settle(page, 200);
    await H.put(page, 'workers/map-b', { ...DOCS['workers/map-b'], state: 'waiting', waitingFor: 'owner' }); await H.settle(page, 400);
    const low = await page.evaluate((LUMSRC) => { const { ratio, backOf } = new Function(LUMSRC + ' return { ratio, backOf };')(); return [...document.querySelectorAll('.wk-chip')].map((c) => { const cs = getComputedStyle(c); return { t: c.textContent.trim(), ratio: Math.round(ratio(cs.color, backOf(c)) * 100) / 100 }; }).filter((x) => x.ratio < 4.5); }, LUM);
    ok(`(${scheme}) every state chip ("Working", "Waiting for you", "Resting", "Finished", "Stopped") reads well: contrast at least 4.5`, low.length === 0, JSON.stringify(low));
    const you = await page.evaluate((LUMSRC) => { const { ratio, backOf } = new Function(LUMSRC + ' return { ratio, backOf };')(); const c = [...document.querySelectorAll('.wk-chip.accent')][0]; if (!c) return null; const cs = getComputedStyle(c); return { t: c.textContent.trim(), ratio: Math.round(ratio(cs.color, backOf(c)) * 100) / 100 }; }, LUM);
    ok(`(${scheme}) "Waiting for you" is there and its contrast is at least 4.5`, !!you && /Waiting for you/.test(you.t) && you.ratio >= 4.5, JSON.stringify(you));
    ok(`(${scheme}) no page errors`, page.__errs.length === 0, page.__errs.join(' | '));
    await page.context().close();
  }
});

/* ---------- 1c. plain words: "task" not "job", "worker" not "helper", "Claude" not "I" (the words the page itself writes, not the notebook's) ---------- */
await H.block('1c plain words', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'words: ' });
  await goWorkers(page);
  const w = await page.evaluate(() => {
    const own = [...document.querySelectorAll('.wk-help, .wk-top, .wk-strip, .wk-sumbar, .wk-actions')].map((e) => e.innerText + ' ' + [...e.querySelectorAll('[aria-label]')].map((x) => x.getAttribute('aria-label')).join(' ')).join(' ');
    const aria = [...document.querySelectorAll('#qt-view [aria-label], #qt-view [title], #qt-view [placeholder]')].filter((e) => !e.closest('article.wk-card .wk-id')).map((e) => (e.getAttribute('aria-label') || '') + ' ' + (e.getAttribute('title') || '') + ' ' + (e.getAttribute('placeholder') || '')).join(' ');
    return { own: own.replace(/\s+/g, ' '), aria: aria.replace(/\s+/g, ' '), legend: [...document.querySelectorAll('.wk-legend li')].map((l) => l.innerText.replace(/\s+/g, ' ').trim()) };
  });
  ok('the page\'s own words never say "job", "helper", "agent" or "I"/"we"', !/\b(jobs?|helpers?|agents?|we|our)\b/i.test(w.own + ' ' + w.aria) && !/\bI\b/.test(w.own), (w.own + ' ' + w.aria).match(/\b(jobs?|helpers?|agents?|we|our)\b/gi) + '');
  ok('the word legend says "Finished the task and handed it back."', w.legend.some((l) => /Finished the task and handed it back\./.test(l)), w.legend.join(' / '));
  ok('the intro says "Claude is the boss of a farm crew. This page shows each worker, what they are doing now, and what they finished."', /Claude is the boss of a farm crew\. This page shows each worker, what they are doing now, and what they finished\./.test(w.own), w.own.slice(0, 300));
  await page.click(fid('flt-stopped')); await H.settle(page, 200);
  await H.put(page, 'workers/b-sections', { ...DOCS['workers/b-sections'], state: 'resting', finishedAt: null }); await H.settle(page, 400);
  const none = await textOf(page);
  ok('a filter that matches nobody says "Nobody here right now."', /Nobody here right now\./.test(none) && !/matches this filter/.test(none), none.slice(0, 160));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 2. the summary strip and filters ---------- */
await H.block('2 strip and filters', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'strip: ' });
  await goWorkers(page);
  const strip = await page.evaluate(() => Object.fromEntries([...document.querySelectorAll('.wk-count')].map((b) => [b.dataset.state, { n: parseInt(b.innerText, 10), label: b.getAttribute('aria-label'), pressed: b.getAttribute('aria-pressed'), h: Math.round(b.getBoundingClientRect().height) }])));
  ok('counters for working, waiting, resting, finished and stopped are there as buttons with names and a pressed state', ['working', 'waiting', 'resting', 'done', 'stopped'].every((s) => strip[s] && strip[s].label && strip[s].pressed === 'false'), JSON.stringify(strip));
  ok('counter buttons are at least 40 px high', Object.values(strip).every((x) => x.h >= 40), JSON.stringify(Object.values(strip).map((x) => x.h)));
  const badge = (await tabsInfo(page)).tabs[1].text;
  const workingTotal = DOCS && Object.values(DOCS).filter((d) => d && d.kind && d.state === 'working').length;
  ok(`the Workers tab badge (${badge}) and the "working" counter (${strip.working && strip.working.n}) say the same number of working workers`, strip.working && new RegExp('\\b' + strip.working.n + '\\b').test(badge), `tab "${badge}", strip ${strip.working && strip.working.n}, workers with state working in the notebook: ${workingTotal}`);
  ok('the strip counts every worker of that state (waiting 1, resting 3, finished 4, stopped 1)', strip.waiting.n === 1 && strip.resting.n === 3 && strip.done.n === 4 && strip.stopped.n === 1, JSON.stringify(Object.fromEntries(Object.entries(strip).map(([k, v]) => [k, v.n]))));
  ok(`the strip counts the ${workingTotal} working workers (lead and teams included, like the tab badge)`, strip.working.n === workingTotal, 'strip says ' + strip.working.n);
  // filter
  await page.click(fid('flt-waiting')); await H.settle(page, 300);
  const f1 = await visibleIds(page);
  ok('tap "waiting": only Map drawer B is a card on screen (plus the bosses above it)', f1.includes('map-b') && !f1.includes('map-a') && !f1.includes('b-question'), f1.join());
  ok('the tapped counter is pressed and says so', await page.evaluate(() => document.querySelector('[data-fid="flt-waiting"]').getAttribute('aria-pressed') === 'true'));
  await page.click(fid('flt-waiting')); await H.settle(page, 300);
  ok('tap it again: the filter goes away and the whole crew is back', (await visibleIds(page)).includes('map-a'));
  await page.click(fid('flt-resting')); await H.settle(page, 300);
  const f2 = await visibleIds(page);
  ok('tap "resting": the resting helpers show (map-d, q-cathy)', f2.includes('map-d') && f2.includes('q-cathy') && !f2.includes('map-a'), f2.join());
  await page.click(fid('flt-stopped')); await H.settle(page, 300);
  ok('tap "stopped": Sections builder shows', (await visibleIds(page)).includes('b-sections'));
  await page.click(fid('flt-done')); await H.settle(page, 300);
  const f3 = await visibleIds(page);
  ok('tap "finished" (really): map-c and b-core are on screen', f3.includes('map-c') && f3.includes('b-core'), f3.join());
  await page.click(fid('flt-done')); await H.settle(page, 200);
  // empty filter
  await H.put(page, 'workers/b-sections', { ...DOCS['workers/b-sections'], state: 'resting', finishedAt: null });
  await page.click(fid('flt-stopped')).catch(() => {}); await H.settle(page, 300);
  ok('a filter with nobody in it says so in friendly words ("Nobody here right now.")', /Nobody here right now|Nobody to show/.test(await textOf(page)) || (await page.evaluate(() => document.querySelector('[data-fid="flt-stopped"]') == null)), (await textOf(page)).slice(0, 120));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 3. folding teams, "What they did", the how-to card ---------- */
await H.block('3 folding and fold-outs', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'fold: ' });
  await goWorkers(page);
  const fold = fid('fold-team-maps');
  ok('a team has a fold button with a name and aria-expanded=true at first', await page.evaluate((s) => { const b = document.querySelector(s); return !!b && b.getAttribute('aria-expanded') === 'true' && /Close/.test(b.getAttribute('aria-label') || ''); }, fold), '');
  await page.click(fold); await H.settle(page, 400);
  ok('folding the Map drawers hides its helpers (map-a is gone, the team card stays)', !(await visibleIds(page)).includes('map-a') && (await visibleIds(page)).includes('team-maps'), (await visibleIds(page)).join());
  ok('the fold button now says "Open Map drawers" and aria-expanded=false', await page.evaluate((s) => { const b = document.querySelector(s); return b.getAttribute('aria-expanded') === 'false' && /Open/.test(b.getAttribute('aria-label')); }, fold));
  await page.reload({ waitUntil: 'load' }); await H.ready(page); await goWorkers(page);
  ok('the fold state is remembered after a reload', !(await visibleIds(page)).includes('map-a'), (await visibleIds(page)).join());
  await page.focus(fold); await page.keyboard.press('Enter'); await H.settle(page, 300);
  ok('Enter on the fold button opens it again (keyboard)', (await visibleIds(page)).includes('map-a'));
  await page.keyboard.press(' '); await H.settle(page, 300);
  ok('Space folds it again', !(await visibleIds(page)).includes('map-a'));
  await page.keyboard.press('Enter'); await H.settle(page, 300);
  const lead = fid('fold-claude');
  ok('the lead can fold too (hides the teams)', await (async () => { await page.click(lead); await H.settle(page, 300); const v = await visibleIds(page); await page.click(lead); await H.settle(page, 300); return !v.includes('team-maps') && v.includes('claude'); })());
  // "What they did"
  const act = await page.evaluate(() => { const a = document.querySelector('article.wk-card[data-wid="map-a"]'); const d = a.querySelector('[data-fid="act-map-a"], details, [aria-expanded][aria-controls]'); return { has: !!d, text: (a.innerText.match(/What they did \((\d+)\)/) || [])[1] }; });
  ok('"What they did (8)" shows how many lines there are (map-a keeps at most 8)', act.text === '8', JSON.stringify(act));
  await page.evaluate(() => { const a = document.querySelector('article.wk-card[data-wid="map-a"]'); const s = [...a.querySelectorAll('summary, button')].find((x) => /What they did/.test(x.innerText)); s && s.click(); });
  await H.settle(page, 300);
  const order = await page.evaluate(() => { const t = document.querySelector('article.wk-card[data-wid="map-a"]').innerText; return ['Coloured the first hill', 'Drew the barn', 'Started the picture', 'Joined the crew'].map((x) => t.indexOf(x)); });
  ok('opening it lists the lines newest first (Coloured the first hill ... Joined the crew)', order.every((x) => x >= 0) && order.every((x, i) => i === 0 || order[i - 1] < x), JSON.stringify(order));
  ok('each line says how long ago it was ("2 min ago" style)', /Coloured the first hill[^A-Z]{0,20}\d+ min ago|\d+ min ago[^A-Z]{0,10}Coloured the first hill/.test(await cardText(page, 'map-a')) || /min ago/.test(await cardText(page, 'map-a')));
  // how-to card
  const t = await textOf(page);
  ok('the "How to read this" card is open the first time, with the colour legend', /How to read this/.test(t) && /Busy right now/.test(t) && /Claude is the boss of a farm crew/.test(t));
  await page.click(fid('help-close')); await H.settle(page, 300);
  ok('"Got it" closes it', !/Claude is the boss of a farm crew/.test(await textOf(page)));
  await page.reload({ waitUntil: 'load' }); await H.ready(page); await goWorkers(page);
  ok('it stays closed after a reload', !/Claude is the boss of a farm crew/.test(await textOf(page)));
  ok('and a small "How to read this" button brings it back', await (async () => { const b = await page.evaluate(() => [...document.querySelectorAll('#qt-view button')].some((x) => /How to read this/.test(x.innerText))); if (!b) return false; await page.evaluate(() => [...document.querySelectorAll('#qt-view button')].find((x) => /How to read this/.test(x.innerText)).click()); await H.settle(page, 300); return /Claude is the boss of a farm crew/.test(await textOf(page)); })());
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 4. links to tasks ---------- */
await H.block('4 task links', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'links: ' });
  await goWorkers(page);
  const chips = await page.evaluate(() => [...document.querySelectorAll('article.wk-card[data-wid="map-a"] a.wk-task')].map((a) => ({ text: a.innerText.trim(), label: a.getAttribute('aria-label'), href: a.getAttribute('href'), h: Math.round(a.getBoundingClientRect().height) })));
  ok('a worker card shows its tasks as chips (map-a: 2 tasks) with names and a 40 px target', chips.length === 2 && chips.every((c) => c.label && c.label.length > 5 && c.h >= 40), JSON.stringify(chips));
  await page.evaluate(() => document.querySelector('article.wk-card[data-wid="map-a"] a.wk-task').click());
  await H.settle(page, 600);
  ok('tapping a task chip opens the Tasks part', (await currentPart(page)) === 'tasks' && (await tabsInfo(page)).tabs[2].selected === 'true', await currentPart(page));
  const sel = await page.evaluate(() => { const n = document.querySelector('li.tk-node.selected, li.tk-node[aria-selected="true"], li.tk-node:focus'); return n ? n.dataset.id : null; });
  ok('and that task is the one in focus (t-map-a) and in view', sel === 't-map-a' || sel === 't-map-a1', String(sel));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 5. asking a worker ---------- */
await H.block('5 ask a worker', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'ask: ' });
  await goWorkers(page);
  const ta = fid('ta-map-a'), send = fid('send-map-a');
  ok('"Ask this worker" is a button with a clear name, closed at first (aria-expanded=false)', await page.evaluate(() => { const b = document.querySelector('[data-fid="ask-map-a"]'); return !!b && b.getAttribute('aria-expanded') === 'false' && /^Ask this worker: Map drawer A/.test(b.getAttribute('aria-label')); }));
  await page.click(fid('ask-map-a')); await H.settle(page, 300);
  const info1 = await page.evaluate(() => { const t = document.querySelector('[data-fid="ta-map-a"]'); const b = document.querySelector('[data-fid="send-map-a"]'); return { ta: !!t, max: t && t.getAttribute('maxlength'), ph: t && t.placeholder, label: t && t.getAttribute('aria-label'), disabled: b && b.disabled, focused: document.activeElement === t, note: (document.querySelector('article.wk-card[data-wid="map-a"]').innerText.match(/Your question goes to Claude first[^.]*\./) || [''])[0] }; });
  ok('a text box opens, holds at most 600 characters, has a name and a helpful hint, and the cursor is in it', info1.ta && info1.max === '600' && /Ask anything about what/.test(info1.ph) && info1.label && info1.focused, JSON.stringify(info1));
  ok('"Send" waits (is disabled) while the box is empty', info1.disabled === true);
  ok('it says in plain words that the question goes to Claude first', /goes to Claude first/.test(info1.note), info1.note);
  await H.clearWrites(page);
  await page.fill(ta, 'x'.repeat(700));
  ok('700 typed characters are cut at 600', (await page.inputValue(ta)).length === 600);
  await page.fill(ta, 'How many hills are you drawing today?');
  ok('"Send" wakes up when there are words', await page.evaluate((s) => !document.querySelector(s).disabled, send));
  await page.click(send); await H.settle(page, 500);
  const ws = await writesTo(page, 'asks/');
  ok('exactly ONE write to asks/<id> with id, targetKind "worker", targetId "map-a", her text, a createdAt time', ws.length === 1 && ws[0].data && ws[0].data.id === ws[0].path.split('/')[1] && /^[a-z0-9_-]+$/.test(ws[0].data.id) && ws[0].data.targetKind === 'worker' && ws[0].data.targetId === 'map-a' && ws[0].data.text === 'How many hills are you drawing today?' && !isNaN(Date.parse(ws[0].data.createdAt)), JSON.stringify(ws.map((w) => w.data)));
  ok('only her fields are written (no workers / tasks / replies documents)', (await H.writes(page)).every((w) => /^(asks|meta)\//.test(w.path)), (await H.writes(page)).map((w) => w.path).join());
  const askId = ws[0] && ws[0].data.id;
  const bubbleText = await cardText(page, 'map-a');
  ok('her message shows as a bubble on the card with the chip "Sent · waiting for Claude to see it"', /How many hills are you drawing today\?/.test(bubbleText) && /Sent · waiting for Claude to see it/.test(bubbleText), bubbleText.slice(-300));
  ok('the box is empty again (or closed) after sending', await page.evaluate((s) => { const t = document.querySelector(s); return !t || t.value === ''; }, ta));
  ok('"Your questions (2)" now counts both (the old one and the new one)', /Your questions \(2\)/.test(await cardText(page, 'map-a')), (await cardText(page, 'map-a')).match(/Your questions \(\d+\)/));
  // Claude sees it
  await H.put(page, 'replies/' + askId, { id: askId, targetKind: 'worker', targetId: 'map-a', state: 'seen', text: '', from: 'Claude', at: new Date().toISOString() });
  ok('Claude marks it seen: the chip of THAT question becomes "Claude saw it ✓" (the older unseen question keeps its "Sent" chip)', await H.until(page, () => /drawing today\? You asked · [^✓]{0,30}(Claude saw it ✓)/.test(document.querySelector('article.wk-card[data-wid="map-a"]').innerText.replace(/\s+/g, ' ')), null, 4000), (await cardText(page, 'map-a')).slice(-260));
  await H.put(page, 'replies/' + askId, { id: askId, targetKind: 'worker', targetId: 'map-a', state: 'working', text: '', from: 'Claude', at: new Date().toISOString() });
  ok('Claude is working on it: the chip says so (with moving dots)', await H.until(page, () => /Claude is working|working on it/i.test(document.querySelector('article.wk-card[data-wid="map-a"]').innerText), null, 4000), (await cardText(page, 'map-a')).slice(-200));
  await H.put(page, 'replies/' + askId, { id: askId, targetKind: 'worker', targetId: 'map-a', state: 'answered', text: 'Three hills: two green and one yellow.', from: 'Map drawer A: Storybook Hills', at: new Date().toISOString() });
  ok('the answer arrives as a speech bubble "Answer from Map drawer A: Storybook Hills" with the words', await H.until(page, () => /Answer from Map drawer A: Storybook Hills/.test(document.querySelector('article.wk-card[data-wid="map-a"]').innerText) && /Three hills: two green and one yellow\./.test(document.querySelector('article.wk-card[data-wid="map-a"]').innerText), null, 4000), (await cardText(page, 'map-a')).slice(-250));
  ok('the newest answer opened by itself (no tap needed): its text is visible on screen', await page.evaluate(() => { const e = [...document.querySelectorAll('article.wk-card[data-wid="map-a"] *')].find((x) => x.children.length === 0 && /Three hills/.test(x.textContent)); return !!e && e.getClientRects().length > 0; }));
  ok('the old chip "Sent · waiting for Claude to see it" is gone for that question', !/Three hills[\s\S]*Sent · waiting/.test(await cardText(page, 'map-a')));
  // double send
  await page.click(fid('ask-map-b')).catch(async () => { await page.evaluate(() => document.querySelector('[data-fid="ask-map-b"]').click()); });
  await H.settle(page, 250);
  await H.clearWrites(page);
  await page.fill(fid('ta-map-b'), 'Why are you waiting?');
  await page.evaluate(() => { const b = document.querySelector('[data-fid="send-map-b"]'); b.click(); b.click(); b.click(); });
  await H.settle(page, 600);
  ok('three quick taps on Send make only ONE question', (await writesTo(page, 'asks/')).length === 1, String((await writesTo(page, 'asks/')).length));
  // ping
  await H.until(page, () => window.__mock.pings.length > 0, null, 3000);
  const pings = await H.pings(page);
  ok('Claude is nudged with ONE doorbell line "Question for \u201cMap drawer A: Storybook Hills\u201d, open the Terminal to read it" (the second question waits: one nudge per 20 s)', pings.length === 1 && pings[0].text === 'Question for \u201cMap drawer A: Storybook Hills\u201d, open the Terminal to read it', JSON.stringify(pings.map((p) => p.text)));
  ok('the doorbell carries NONE of her words (privacy: only who it is for)', !pings.some((p) => /hills|today|Why are you waiting/i.test(p.text.replace(/Storybook Hills/g, ''))), JSON.stringify(pings.map((p) => p.text)));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 5b. the ask box opens where she can see it, with its Send button ---------- */
await H.block('5b ask box in view', async () => {
  for (const reduced of [false, true]) {
    const page = await openParts(h, { w: 700, h: 800, reduced, label: `ask in view${reduced ? ' (reduced motion)' : ''}: ` });
    await goWorkers(page);
    const id = await page.evaluate(() => { const bs = [...document.querySelectorAll('[data-fid^="ask-"]')].filter((b) => b.getClientRects().length); return bs[Math.floor(bs.length / 2)].getAttribute('data-fid').slice(4); });      // a card in the middle of the page, so the middle of the window can be reached
    // bring its button to the very bottom edge of the window, like a card she has just scrolled to
    await page.evaluate((i) => document.querySelector(`[data-fid="ask-${i}"]`).scrollIntoView({ block: 'end' }), id);
    await H.settle(page, 200);
    await page.click(fid('ask-' + id));
    await H.settle(page, reduced ? 300 : 1400);
    const r = await page.evaluate((i) => { const send = document.querySelector(`[data-fid="send-${i}"]`), ta = document.querySelector(`[data-fid="ta-${i}"]`), form = ta.closest('.wk-form'), f = form.getBoundingClientRect(), s = send.getBoundingClientRect(), top = document.querySelector('.pt-strip').getBoundingClientRect().bottom; return { vh: innerHeight, formTop: Math.round(f.top), formBottom: Math.round(f.bottom), sendBottom: Math.round(s.bottom), covered: top, mid: Math.round((f.top + f.bottom) / 2) }; }, id);
    ok(`${reduced ? 'reduced motion' : 'normal'}: after "Ask this worker" the whole box and its Send button are inside the window (not at the bottom edge)`, r.sendBottom <= r.vh - 8 && r.formTop >= r.covered, JSON.stringify(r));
    ok(`${reduced ? 'reduced motion' : 'normal'}: the box is brought to about the middle of the window`, Math.abs(r.mid - r.vh / 2) <= r.vh * 0.2, JSON.stringify(r));
    ok(`${reduced ? 'reduced motion' : 'normal'}: no page errors`, page.__errs.length === 0, page.__errs.join(' | '));
    await page.context().close();
  }
});

/* ---------- 6. asking a finished worker, a failing write, offline ---------- */
await H.block('6 ask edge cases', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'edge: ' });
  await goWorkers(page); await showFinished(page);
  await page.evaluate(() => document.querySelector('[data-fid="ask-map-c"]').click()); await H.settle(page, 300);
  ok('a finished worker can be asked; the box says "This worker has finished. Claude will answer from their notes."', (await page.evaluate(() => (document.querySelector('[data-fid="ta-map-c"]') || {}).placeholder)) === 'This worker has finished. Claude will answer from their notes.');
  // write failure
  await page.evaluate(() => { window.__mock.failWrites = true; });
  await H.clearWrites(page);
  await page.fill(fid('ta-map-c'), 'What did you hand back?');
  await page.click(fid('send-map-c')); await H.settle(page, 800);
  const t = await cardText(page, 'map-c');
  ok('when the write fails she is told ("Not saved. Your words are still here...") and her words stay in the box', /Not saved|try again/i.test(t) && (await page.evaluate(() => (document.querySelector('[data-fid="ta-map-c"]') || {}).value)) === 'What did you hand back?', t.slice(-200));
  ok('a failed question is not shown as sent (no "Sent · waiting" bubble for it)', !/What did you hand back\?[\s\S]*Sent · waiting for Claude/.test(t) || !/Sent · waiting for Claude to see it/.test(t.split('Your questions')[1] || ''));
  await page.evaluate(() => { window.__mock.failWrites = false; });
  await page.click(fid('send-map-c')); await H.settle(page, 800);
  ok('after the notebook is back, sending again works (one write)', (await writesTo(page, 'asks/')).filter((w) => w.data && w.data.text === 'What did you hand back?').length === 1, JSON.stringify((await H.writes(page)).map((w) => w.path)));
  // notebook goes away
  await page.evaluate(() => window.__mock.db.revoke()); await H.settle(page, 800);
  await page.evaluate(() => document.querySelector('[data-fid="ask-map-b"]').click()); await H.settle(page, 300);
  await H.clearWrites(page);
  await page.fill(fid('ta-map-b'), 'Anyone there?').catch(() => {});
  await page.evaluate(() => { const b = document.querySelector('[data-fid="send-map-b"]'); b && !b.disabled && b.click(); }); await H.settle(page, 600);
  const t2 = await textOf(page);
  ok('with no connection: no write happens and a plain line says questions will not send yet', (await writesTo(page, 'asks/')).length === 0 && /No connection|not send|cannot|not saved/i.test(t2), t2.slice(0, 160));
  ok('no uncaught exceptions', page.__errs.filter((e) => /pageerror/.test(e)).length === 0, page.__errs.join(' | '));
  await page.context().close();
  // no notebook at all
  const off = await H.open(h, { w: 700, h: 800, docs: {}, mock: { db: null }, label: 'nodb: ' });
  await H.ready(off); await goWorkers(off);
  const ot = await textOf(off, '#qt-main');
  ok('no notebook: the Workers part says plainly that the crew cannot be shown until the connection is back', /cannot be shown until the connection is back|No connection/.test(ot), ot.slice(0, 200));
  ok('no notebook: no errors', off.__errs.length === 0, off.__errs.join(' | '));
  await off.context().close();
});

/* ---------- 7. empty crew, live progress, unsafe text ---------- */
await H.block('7 empty, progress, unsafe', async () => {
  const e = await openParts(h, { docs: partsDocs({ noCrew: true }), label: 'empty: ' });
  await goWorkers(e);
  ok('no workers yet: friendly text ("No crew yet. When Claude has workers, they will show up here.")', /No crew yet/.test(await textOf(e)) && /When Claude has workers, they will show up here/.test(await textOf(e)), (await textOf(e)).slice(0, 160));
  ok('empty crew: no counters with zeros pretending to be a crew, no errors', e.__errs.length === 0, e.__errs.join(' | '));
  await H.put(e, 'workers/claude', DOCS['workers/claude']);
  ok('the first worker Claude writes shows up at once', await H.until(e, () => /Checking the new answers/.test(document.getElementById('qt-view').innerText), null, 4000));
  await e.context().close();
  const page = await openParts(h, { w: 1366, h: 900, label: 'prog: ' });
  await goWorkers(page);
  const bar = () => page.evaluate(() => { const b = document.querySelector('article.wk-card[data-wid="map-b"] [role=progressbar]'); return b ? b.getAttribute('aria-valuenow') : null; });
  ok('no bar while progress is null (map-b)', (await bar()) === null);
  await H.put(page, 'workers/map-b', { ...DOCS['workers/map-b'], progress: 75 });
  ok('a real number makes a bar appear (75)', await H.until(page, () => { const b = document.querySelector('article.wk-card[data-wid="map-b"] [role=progressbar]'); return !!b && b.getAttribute('aria-valuenow') === '75'; }, null, 3000));
  for (const [bad, expect] of [[150, 'clamp'], [-20, 'clamp'], ['half', 'none'], [NaN, 'none'], [null, 'none']]) {
    await H.put(page, 'workers/map-b', { ...DOCS['workers/map-b'], progress: bad });
    await H.settle(page, 250);
    const v = await bar();
    ok(`progress ${JSON.stringify(bad)} never shows a made-up number (${expect === 'clamp' ? 'kept within 0-100' : 'no bar'})`, expect === 'none' ? v === null : (v !== null && Number(v) >= 0 && Number(v) <= 100), String(v));
  }
  await H.put(page, 'workers/map-b', { ...DOCS['workers/map-b'], progress: 0 });
  await H.settle(page, 250);
  ok('progress 0 is a real number: the bar shows 0 (not hidden like null)', (await bar()) === '0', String(await bar()));
  // unsafe text
  const r = await unsafeReport(page);
  ok('unsafe worker text (name, role, now, activity) is shown as plain words: no <img>, no script, no alert', r.img === 0 && r.scripts === 0 && !r.flag && r.alerts === 0 && r.handlers === 0 && page.__dialogs.length === 0 && (await textOf(page)).includes('<img src=x onerror=alert(1)>'), JSON.stringify(r));
  const m = await page.evaluate(H.measure);
  ok('very long unbroken words do not widen the page or the card', m.docW <= m.vw + 1 && m.wide.length === 0 && m.cut.length === 0, `doc ${m.docW} ${m.wide.slice(0, 2).join('|')} ${m.cut.slice(0, 2).join('|')}`);
  await page.setViewportSize({ width: 400, height: 800 }); await H.settle(page, 300);
  const m2 = await page.evaluate(H.measure);
  ok('and at 400 px wide', m2.docW <= m2.vw + 1 && m2.wide.length === 0 && m2.overlap.length === 0, `doc ${m2.docW} ${m2.wide.slice(0, 2).join('|')} ${m2.overlap.slice(0, 2).join('|')}`);
  // odd values in a worker document
  await H.put(page, 'workers/odd', { id: 'odd', name: 5, parentId: 'claude', kind: 'boss', icon: 12, role: null, state: 'sleeping', now: 7, waitingFor: 'x', startedAt: 'x', updatedAt: 'x', finishedAt: 'x', activity: 'text', result: 3, taskIds: 'x', brain: 'GPT', progress: 'half', order: 'x' });
  await H.settle(page, 400);
  ok('a worker document with wrong kinds of values does not break the page', page.__errs.filter((x) => /pageerror/.test(x)).length === 0 && (await textOf(page)).length > 100, page.__errs.join(' | '));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 8. keyboard ---------- */
await H.block('8 keyboard', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'kbd: ' });
  await goWorkers(page);
  await page.evaluate(() => { const st = document.createElement('span'); st.id = '__start'; st.tabIndex = -1; document.getElementById('qt-view').insertBefore(st, document.getElementById('qt-view').firstChild); st.focus(); });
  const stops = [];
  for (let i = 0; i < 60; i++) { await page.keyboard.press('Tab'); const s = await page.evaluate(() => { const e = document.activeElement; if (!e || e === document.body) return null; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); const ring = (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) >= 2) || (cs.boxShadow && cs.boxShadow !== 'none') || (e.closest('label') && getComputedStyle(e.closest('label').querySelector('.track') || e).boxShadow !== 'none'); return { tag: e.tagName.toLowerCase(), name: (e.getAttribute('aria-label') || e.innerText || e.value || '').replace(/\s+/g, ' ').trim().slice(0, 40), ring: !!ring, inView: r.top >= -1 && r.top + Math.min(r.height, 28) <= innerHeight + 1, covered: (() => { const t = document.elementFromPoint(Math.min(innerWidth - 1, Math.max(0, r.left + Math.min(r.width / 2, 30))), Math.min(innerHeight - 1, Math.max(0, r.top + r.height / 2))); return !(t && (e === t || e.contains(t) || t.contains(e))); })() }; }); if (!s) break; stops.push(s); }
  ok(`Tab reaches ${stops.length} controls in the Workers part`, stops.length >= 15, String(stops.length));
  ok('every one has a spoken name', stops.every((s) => s.name), stops.filter((s) => !s.name).map((s) => s.tag).join());
  ok('every one shows a focus ring', stops.every((s) => s.ring), stops.filter((s) => !s.ring).slice(0, 4).map((s) => s.tag + ' "' + s.name + '"').join(' | '));
  ok('none is hidden under the sticky bars when it has the focus', stops.every((s) => s.inView && !s.covered), stops.filter((s) => !s.inView || s.covered).slice(0, 4).map((s) => s.name).join(' | '));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 9. odd crews: loops, a worker under itself, ids that look like object keys or hold quotes (nothing may hang or crash) ---------- */
await H.block('9 loops and odd ids', async () => {
  const wk = (id, name, parentId, extra = {}) => ({ id, name, parentId, kind: 'helper', icon: '', role: 'Test job ' + name, state: 'working', now: 'Doing ' + name, waitingFor: 'none', startedAt: null, updatedAt: new Date().toISOString(), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 50, ...extra });
  const odd = {
    'workers/loop-a': wk('loop-a', 'Loop A', 'loop-b'), 'workers/loop-b': wk('loop-b', 'Loop B', 'loop-a'),
    'workers/loop-x': wk('loop-x', 'Loop X', 'loop-y'), 'workers/loop-y': wk('loop-y', 'Loop Y', 'loop-z'), 'workers/loop-z': wk('loop-z', 'Loop Z', 'loop-x'),
    'workers/hangs-off': wk('hangs-off', 'Hangs off the loop', 'loop-a'),
    'workers/self': wk('self', 'Under itself', 'self'),
    'workers/ctor': wk('ctor', 'Parent is constructor', 'constructor'),
    'workers/proto': wk('proto', 'Parent is proto', '__proto__', { taskIds: ['constructor', '__proto__'] }),
    'workers/q-uote': wk('q-uote', 'Quote worker', null),
  };
  // (the notebook layer never lets an id like "constructor" or one with a quote into the page; the page must cope with such a PARENT id and with such a "go to" value anyway)
  const docs = { ...partsDocs(), ...odd };
  const page = await openParts(h, { docs, w: 1366, h: 900, label: 'loops: ' });
  const t0 = Date.now();
  await goWorkers(page);
  const alive = await Promise.race([page.evaluate(() => document.querySelectorAll('article.wk-card').length), sleep(15000).then(() => -1)]);
  ok('a loop of two, a loop of three, a worker under itself and parents called "constructor" or "__proto__": the Workers part still draws and answers', alive > 20, `cards: ${alive} after ${Date.now() - t0} ms`);
  const names = await page.evaluate(() => [...document.querySelectorAll('article.wk-card')].map((a) => a.dataset.wid));
  ok('every one of the odd workers has a card (nobody disappears because of a loop)', ['loop-a', 'loop-b', 'loop-x', 'loop-y', 'loop-z', 'hangs-off', 'self', 'ctor', 'proto', 'q-uote'].every((i) => names.includes(i)), names.join());
  ok('each card appears once (a loop is not drawn twice or forever)', new Set(names).size === names.length, names.length + ' cards, ' + new Set(names).size + ' different');
  ok('a worker that hangs off a loop sits under it (not lost)', await page.evaluate(() => { const c = document.querySelector('article.wk-card[data-wid="hangs-off"]'); return !!c && !!c.closest('li') && !!c.closest('li').parentElement.closest('li'); }));
  // the "go to this worker" jump (used by links from other parts) with a loop and with a quote in the id: no hang, no throw
  const jumped = await Promise.race([page.evaluate(async () => { window.QT.route.go('workers', { focus: 'loop-b' }); await new Promise((r) => setTimeout(r, 400)); window.QT.route.go('workers', { focus: 'a"b]c' }); await new Promise((r) => setTimeout(r, 400)); return document.querySelectorAll('article.wk-card').length; }), sleep(15000).then(() => -1)]);
  ok('jumping to a worker inside a loop, or to a name with a quote and a bracket in it, does not hang or throw', jumped > 20 && page.__errs.length === 0, `${jumped} ${page.__errs.join(' | ')}`);
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 9b. a very long loop (longer than the 50 steps the page walks) and a very long chain: still no hang, every worker once ---------- */
await H.block('9b long loop', async () => {
  const wk = (id, name, parentId, extra = {}) => ({ id, name, parentId, kind: 'helper', icon: '', role: 'Checks ' + name, state: 'working', now: 'Doing ' + name, waitingFor: 'none', startedAt: null, updatedAt: new Date().toISOString(), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 50, ...extra });
  const odd = {};
  const N = 70;                                   // a ring of 70 workers: each one is the parent of the next, the last one of the first
  for (let i = 0; i < N; i++) odd['workers/ring-' + i] = wk('ring-' + i, 'Ring ' + i, 'ring-' + ((i + N - 1) % N));
  for (let i = 0; i < 60; i++) odd['workers/chain-' + i] = wk('chain-' + i, 'Chain ' + i, i === 0 ? null : 'chain-' + (i - 1));   // a plain chain 60 deep
  const page = await openParts(h, { docs: { ...partsDocs(), ...odd }, w: 1366, h: 900, label: 'long loop: ' });
  const t0 = Date.now();
  await goWorkers(page);
  const alive = await Promise.race([page.evaluate(() => document.querySelectorAll('article.wk-card').length), sleep(20000).then(() => -1)]);
  ok(`a ring of ${N} workers and a chain 60 deep: the page still draws (${alive} cards in ${Date.now() - t0} ms)`, alive > 20 + N, String(alive));
  const ids = await page.evaluate(() => [...document.querySelectorAll('article.wk-card')].map((a) => a.dataset.wid));
  ok('every worker of the ring and of the chain has exactly one card', Array.from({ length: N }, (_, i) => 'ring-' + i).every((i) => ids.filter((x) => x === i).length === 1) && Array.from({ length: 60 }, (_, i) => 'chain-' + i).every((i) => ids.filter((x) => x === i).length === 1), `${ids.length} cards, ${new Set(ids).size} different`);
  const jumped = await Promise.race([page.evaluate(async () => { window.QT.route.go('workers', { focus: 'ring-35' }); await new Promise((r) => setTimeout(r, 500)); window.QT.route.go('workers', { focus: 'chain-59' }); await new Promise((r) => setTimeout(r, 500)); return document.querySelectorAll('article.wk-card').length; }), sleep(20000).then(() => -1)]);
  ok('jumping to a worker in the long ring or at the end of the chain does not hang', jumped > 20 + N && page.__errs.length === 0, `${jumped} ${page.__errs.join(' | ')}`);
  ok('QT.parts (the tab badge numbers) also copes with the ring', await page.evaluate(() => { const t0 = performance.now(); const r = window.QT.parts.workerRoots().length; const k = window.QT.parts.workers().length; return r > 0 && k > 90 && performance.now() - t0 < 500; }));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

await H.stop(h);
