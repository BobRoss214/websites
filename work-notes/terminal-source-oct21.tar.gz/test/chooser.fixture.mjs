/* Made-up picture-chooser questions for the tests and the screenshots (NOT content for the owner; every photo is a little drawing made here).
 *   shareCard()     1 place   the base is the drawing of the farm (1200 x 630), the chosen photo sits in a white-framed corner
 *   holidayStrip()  2 places  the base is a wide strip (1200 x 200), one photo on the left and one on the right
 *   manyPhotos(n)   1 place   a gallery of n photos (60 is the most the page shows)
 *   chooserDocs(extra)  the standard rich notebook plus these questions (and `extra`, an object 'collection/id' -> doc)
 */
import { seed } from './fixtures.mjs';

const enc = (s) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
const SKY = [['#9fd3f0', '#e8f4fb'], ['#f6c28b', '#fde9cf'], ['#b9d9a8', '#eef7e0'], ['#c9c0e6', '#f0ecfa'], ['#a8d0d8', '#e5f3f5'], ['#f2a7a0', '#fde3df']];
const KINDS = ['barn', 'pumpkins', 'sunflowers', 'sheep', 'tractor', 'tree', 'berries', 'wagon', 'people', 'hay'];

function subject(kind, tint) {
  switch (kind) {
    case 'barn': return `<rect x="250" y="270" width="300" height="200" fill="#b8232f"/><polygon points="230,275 400,170 570,275" fill="#8d1a24"/><rect x="345" y="340" width="110" height="130" fill="#f6ecdc"/><path d="M345 340L455 470M455 340L345 470" stroke="#8d1a24" stroke-width="8"/><rect x="560" y="230" width="60" height="240" fill="#c9bfae"/>`;
    case 'pumpkins': return [0, 1, 2, 3, 4].map((i) => `<ellipse cx="${190 + i * 100}" cy="${430 + (i % 2) * 28}" rx="${54 + (i % 3) * 8}" ry="${44 + (i % 3) * 6}" fill="${i % 2 ? '#e8832a' : '#f09a3a'}"/><rect x="${184 + i * 100}" y="${376 + (i % 2) * 28}" width="12" height="18" fill="#3c6b2a"/>`).join('');
    case 'sunflowers': return [0, 1, 2, 3].map((i) => `<rect x="${178 + i * 150}" y="${300 + (i % 2) * 40}" width="9" height="200" fill="#3c6b2a"/><circle cx="${182 + i * 150}" cy="${290 + (i % 2) * 40}" r="62" fill="#f5c518"/><circle cx="${182 + i * 150}" cy="${290 + (i % 2) * 40}" r="30" fill="#6b3f1d"/>`).join('');
    case 'sheep': return [0, 1, 2].map((i) => `<ellipse cx="${210 + i * 190}" cy="${400 + (i % 2) * 24}" rx="78" ry="52" fill="#f8f4ea"/><circle cx="${275 + i * 190}" cy="${386 + (i % 2) * 24}" r="30" fill="#40342b"/><rect x="${182 + i * 190}" y="${440 + (i % 2) * 24}" width="12" height="42" fill="#40342b"/><rect x="${232 + i * 190}" y="${440 + (i % 2) * 24}" width="12" height="42" fill="#40342b"/>`).join('');
    case 'tractor': return `<rect x="280" y="330" width="230" height="110" rx="14" fill="#2f7d3a"/><rect x="380" y="260" width="110" height="90" rx="10" fill="#276a31"/><circle cx="330" cy="450" r="62" fill="#222"/><circle cx="330" cy="450" r="26" fill="#bbb"/><circle cx="505" cy="470" r="42" fill="#222"/><circle cx="505" cy="470" r="18" fill="#bbb"/>`;
    case 'tree': return `<rect x="378" y="320" width="44" height="170" fill="#6b4a2b"/><circle cx="400" cy="270" r="130" fill="#3c8a3a"/><circle cx="330" cy="320" r="80" fill="#2f7d3a"/><circle cx="470" cy="320" r="80" fill="#2f7d3a"/>${[0, 1, 2, 3, 4].map((i) => `<circle cx="${330 + i * 36}" cy="${250 + (i % 3) * 36}" r="12" fill="#d33"/>`).join('')}`;
    case 'berries': return `<ellipse cx="400" cy="420" rx="230" ry="90" fill="#6b4a2b"/><ellipse cx="400" cy="400" rx="205" ry="70" fill="#3a3f8f"/>${Array.from({ length: 26 }, (_, i) => `<circle cx="${230 + (i * 53) % 340}" cy="${360 + (i * 31) % 70}" r="22" fill="${i % 3 ? '#3e46b3' : '#5b63cf'}"/>`).join('')}`;
    case 'wagon': return `<rect x="220" y="320" width="360" height="90" rx="10" fill="#9a6a3a"/><circle cx="290" cy="430" r="44" fill="#4a3320"/><circle cx="510" cy="430" r="44" fill="#4a3320"/>${[0, 1, 2, 3].map((i) => `<ellipse cx="${290 + i * 72}" cy="305" rx="38" ry="30" fill="#ee8b2e"/>`).join('')}`;
    case 'people': return [0, 1, 2].map((i) => `<circle cx="${250 + i * 150}" cy="${300 + (i % 2) * 20}" r="42" fill="#e8b98f"/><path d="M${190 + i * 150} ${470 + (i % 2) * 20}q60-130 120 0z" fill="${['#2d6cb5', '#c8505a', '#4c9a5b'][i]}"/>`).join('');
    default: return `<ellipse cx="300" cy="440" rx="130" ry="80" fill="#e6c25a"/><ellipse cx="520" cy="440" rx="130" ry="80" fill="#d9b24a"/><ellipse cx="410" cy="400" rx="120" ry="70" fill="#f0d070"/>`;
  }
}
/** One made-up photo (800 x 600). kind: one of KINDS; i picks the colours. */
export function photo(kind, i = 0) {
  const [top, bot] = SKY[i % SKY.length];
  const hill = ['#7fb069', '#8bbd6c', '#a8c66c', '#6fa36b'][i % 4];
  return enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${top}"/><stop offset="1" stop-color="${bot}"/></linearGradient></defs><rect width="800" height="600" fill="url(#g)"/><circle cx="${120 + (i * 83) % 560}" cy="110" r="44" fill="#fff6c8" opacity=".9"/><ellipse cx="200" cy="520" rx="420" ry="150" fill="${hill}"/><ellipse cx="650" cy="540" rx="380" ry="130" fill="${hill}" opacity=".85"/>${subject(kind, i)}</svg>`);
}
const BASE_CARD = enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630"><defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f7c98b"/><stop offset="1" stop-color="#fdeccf"/></linearGradient></defs><rect width="1200" height="630" fill="url(#s)"/><circle cx="1010" cy="130" r="74" fill="#ffd54a"/><ellipse cx="300" cy="640" rx="620" ry="210" fill="#86b365"/><ellipse cx="980" cy="660" rx="520" ry="190" fill="#6fa056"/><rect x="190" y="290" width="250" height="170" fill="#b8232f"/><polygon points="170,295 315,205 460,295" fill="#8d1a24"/><rect x="260" y="350" width="110" height="110" fill="#f6ecdc"/><rect x="520" y="400" width="190" height="60" rx="8" fill="#9a6a3a"/><circle cx="560" cy="470" r="24" fill="#4a3320"/><circle cx="670" cy="470" r="24" fill="#4a3320"/>${[0, 1, 2, 3].map((i) => `<ellipse cx="${550 + i * 46}" cy="385" rx="26" ry="20" fill="#ee8b2e"/>`).join('')}<text x="60" y="80" font-family="Georgia,serif" font-size="46" font-weight="700" fill="#5a2a10">Organic u-pick fun</text><text x="60" y="132" font-family="Georgia,serif" font-size="46" font-weight="700" fill="#5a2a10">for the whole family</text></svg>`);
const BASE_STRIP = enc(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 200" width="1200" height="200"><rect width="1200" height="200" fill="#2f6b3a"/>${Array.from({ length: 30 }, (_, i) => `<rect x="${i * 44}" y="0" width="22" height="200" fill="#a8232f" opacity=".35"/>`).join('')}${Array.from({ length: 14 }, (_, i) => `<circle cx="${40 + i * 86}" cy="${24 + (i % 3) * 14}" r="6" fill="#fff" opacity=".8"/>`).join('')}<text x="600" y="112" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="#fff">Happy holidays from the farm</text></svg>`);

const LABELS = ['Red barn', 'Pumpkin pile', 'Sunflower row', 'Sheep on the hill', 'Old green tractor', 'Apple tree', 'Blueberry basket', 'Hay wagon', 'Family day', 'Haystacks'];
/** n photos (the 3rd, 9th, ... carry people). */
export function gallery(n = 12) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const kind = KINDS[i % KINDS.length];
    const label = LABELS[i % KINDS.length] + (i >= KINDS.length ? ' ' + (Math.floor(i / KINDS.length) + 1) : '');
    out.push({ id: 'p' + (i + 1), url: photo(kind, i), alt: label + ' (a drawing for the test)', w: 800, h: 600, label, people: kind === 'people' });
  }
  return out;
}

const base = (o) => ({
  sectionId: 'look', kind: 'chooser', createdAt: new Date(Date.now() - 3600e3).toISOString(), ownTip: 'Want something else? Say it in your own words.',
  choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null, ...o,
});

export function shareCard(o = {}) {
  return base({
    id: 'ch-card', order: 40, title: 'Which photo should sit in the corner of the share picture?',
    story: ['When someone shares your web address, a small card shows up. Pick the photo that goes in the corner of the drawing.'],
    why: 'A real photo in the corner makes the card feel like your farm.',
    chooser: {
      slots: [{ id: 'corner', label: 'Corner photo', hint: 'This photo goes in the bottom corner' }],
      gallery: gallery(o.n || 12),
      preview: { base: { url: BASE_CARD, alt: 'The share picture: a drawing of the farm with the words Organic u-pick fun for the whole family', w: 1200, h: 630 }, overlays: [{ slot: 'corner', x: 63, y: 50, w: 31, h: 42, rotate: -3, frame: 'white' }] },
      allowNone: !!o.allowNone,
    },
    ...(o.peopleNote ? { peopleNote: o.peopleNote } : {}),
  });
}
export function holidayStrip(o = {}) {
  return base({
    id: 'ch-strip', order: 41, title: 'Which two photos go on the holiday strip?',
    story: ['The strip at the top of the home page shows two photos at holiday time. Pick one for the left and one for the right.'],
    why: 'Holiday photos make people smile when they open the page.',
    chooser: {
      slots: [{ id: 'left', label: 'Left side', hint: 'The photo on the left' }, { id: 'right', label: 'Right side', hint: 'The photo on the right' }],
      gallery: gallery(o.n || 12),
      preview: { base: { url: BASE_STRIP, alt: 'The holiday strip: green with red stripes and the words Happy holidays from the farm', w: 1200, h: 200 }, overlays: [{ slot: 'left', x: 2, y: 8, w: 21, h: 84, rotate: -2, frame: 'white' }, { slot: 'right', x: 77, y: 8, w: 21, h: 84, rotate: 2, frame: 'yellow' }] },
    },
  });
}
export function manyPhotos(n = 60, o = {}) {
  return base({
    id: o.id || 'ch-many', order: 42, title: 'Which photo is best for the top of the page?',
    story: ['A lot of photos to choose from.'], why: '',
    chooser: { slots: [{ id: 'top', label: 'Top photo' }], gallery: gallery(n), preview: { base: { url: BASE_CARD, alt: 'The top of the page', w: 1200, h: 630 } } },
  });
}

/** The standard rich notebook with the three chooser questions added. */
export function chooserDocs(extra = {}, o = {}) {
  const D = seed({ count: 6, ...(o.seed || {}) });
  for (const q of [shareCard(o.card || {}), holidayStrip(o.strip || {}), manyPhotos(60)]) D['questions/' + q.id] = q;
  return Object.assign(D, extra);
}
export { BASE_CARD, BASE_STRIP, KINDS };
