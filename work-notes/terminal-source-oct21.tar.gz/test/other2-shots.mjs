/* other2-shots.mjs (owner: other) - looks at the F1 / F3 screens: T/shots/other2-*.png   QT_PAGE=dist-other2/index.html node test/other2-shots.mjs   (port 9800+) */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const h = await H.start(9800);
const docs = seed({ downloads: true, cathy: true });
async function shot(name, id, w, hh, scheme, fn, view = 'question') {
  const p = await H.open(h, { docs, w, h: hh, scheme });
  await H.go(p, view, view === 'question' ? { id } : { id });
  if (fn) await fn(p);
  await H.settle(p, 300);
  const m = await p.evaluate(() => ({ docH: document.documentElement.scrollHeight, vh: innerHeight }));
  console.log(name, JSON.stringify(m));
  await H.shot(p, 'other2-' + name);
  await H.shot(p, 'other2-' + name + '-full', { full: true });
  await p.context().close();
}
await shot('safety-700', 'd-sample-safety', 700, 800, 'light');
await shot('safety-open-700', 'd-sample-safety', 700, 800, 'light', async (p) => { await p.evaluate(() => document.querySelectorAll('.sf-fold').forEach((d) => d.open = true)); });
await shot('safety-dark-700', 'd-sample-safety', 700, 800, 'dark');
await shot('safety-400', 'd-sample-safety', 400, 800, 'light');
await shot('safety-1366', 'd-sample-safety', 1366, 768, 'light');
await shot('clean-700', 'd-sample-clean', 700, 800, 'light');
await shot('notsafe-700', 'd-sample-notsafe', 700, 800, 'light');
await shot('unchecked-700', 'd-sample-unchecked', 700, 800, 'light');
await shot('choice-700', 'c-unseen', 700, 800, 'light');
await shot('visual-700', 'v-map-1', 700, 800, 'light');
await shot('visual-400', 'v-map-1', 400, 800, 'light');
await shot('cathy-saved-700', 'c-normal', 700, 800, 'light', async (p) => { await p.click('[data-fid="x-cathy"]'); await H.settle(p, 400); });
await shot('cathy-answered-700', 'c-short', 700, 800, 'light');
await shot('recheck-saved-700', 'd-sample-safety', 700, 800, 'light', async (p) => { await p.click('[data-fid="x-recheck"]'); await H.settle(p, 400); });
await shot('kathy-view-700', 'kathy', 700, 800, 'light', null, 'section');
await shot('kathy-view-dark-400', 'kathy', 400, 800, 'dark', null, 'section');
console.log('errors', h.errs);
await H.stop(h);
