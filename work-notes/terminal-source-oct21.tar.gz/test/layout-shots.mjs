/* Layout screenshots + checks.  NODE_PATH=/opt/node22/lib/node_modules node T/test/layout-shots.mjs  (port 9200) */
import path from 'node:path';
import { startServer, launch, ok, info, finish } from './lib.mjs';
import { T } from './harness.mjs';
const SHOTS = path.join(T, 'shots');
const site = await startServer({ root: T, port: 9200 });
const browser = await launch();
const errs = [];
const sizes = [[700, 800], [1366, 768], [1920, 1080], [400, 800]];
async function open(w, h, qs = '', scheme = 'light') {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: scheme });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error') errs.push('console ' + m.text()); });
  await p.goto(site.url + 'test/layout-harness.html' + (qs ? '?' + qs : ''));
  await p.waitForSelector('#qt-view .card, #qt-view .qbar, #qt-view h1', { timeout: 5000 });
  return p;
}
for (const [w, h] of sizes) {
  for (const view of ['home', 'question']) {
    const p = await open(w, h, 'view=' + view);
    await p.screenshot({ path: path.join(SHOTS, `layout-${view}-${w}x${h}.png`) });
    const over = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, sh: document.documentElement.scrollHeight, ch: document.documentElement.clientHeight }));
    ok(`${view} ${w}x${h}: no horizontal scroll`, over.sw <= over.cw, JSON.stringify(over));
    await p.context().close();
  }
}
await finish({ browser, site, errs });
