/* axe colour-contrast + a few rules on the real page in both themes (port 9203). */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const { ok, info, axeSource } = H;
const src = axeSource();
if (!src) { console.log('SKIP axe-core not installed'); process.exit(0); }
const h = await H.start(9203);
const views = [['home', {}], ['section', { id: 'look' }], ['question', { id: 'v-map-1' }], ['question', { id: 'c-normal' }], ['section', { id: 'kathy' }], ['done', {}], ['newsection', {}], ['section', { id: 'account-features' }]];
for (const scheme of ['light', 'dark']) {
  const page = await H.open(h, { docs: seed(), w: 700, h: 800, scheme });
  await page.evaluate(src);
  for (const [view, params] of views) {
    await H.go(page, view, params); await H.settle(page, 300);
    const res = await page.evaluate(async () => {
      const r = await axe.run(document, { runOnly: { type: 'rule', values: ['color-contrast', 'landmark-one-main', 'region', 'aria-allowed-attr', 'aria-valid-attr-value', 'button-name', 'link-name', 'label', 'heading-order', 'duplicate-id', 'nested-interactive', 'scrollable-region-focusable'] } });
      return r.violations.map((v) => ({ id: v.id, n: v.nodes.length, ex: v.nodes.slice(0, 3).map((n) => (n.target.join(' ') + ' :: ' + (n.any[0] && n.any[0].message || '').slice(0, 130))) }));
    });
    ok(`${scheme} ${view} ${JSON.stringify(params)}: axe clean`, res.length === 0, JSON.stringify(res, null, 0).slice(0, 900));
  }
  // menu open (narrow)
  await page.click('.menu-btn'); await H.settle(page, 100);
  const res = await page.evaluate(async () => (await axe.run(document, { runOnly: { type: 'rule', values: ['color-contrast', 'aria-allowed-attr', 'button-name'] } })).violations.map((v) => v.id + ':' + v.nodes.length));
  ok(`${scheme}: open menu axe clean`, res.length === 0, res.join(','));
  await page.context().close();
}
await H.stop(h);
