/* Fit test: does every view fit the panel the owner really uses (700x800 beside the chat), a laptop, a big monitor and a very narrow window?
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/fit.test.mjs
 * Checks per view / size / colour scheme:
 *   no sideways scroll, no element wider than the window, sticky question bar stays visible while scrolling,
 *   buttons and chips do not clip their text, text contrast >= 4.5 (3 for large text) in LIGHT and DARK.
 * KEY RULE (SPEC section 2): at 700x800 the picture question and a normal choice question need NO vertical page scroll.
 * F1 / F3 (SPEC3): the Safety check card, a question sent to Miss Cathy and Rob, the Miss Cathy and Rob page with "You sent these", the Downloads and skills section
 *   -> measured with the same checks; a question with a safety card needs at most 1.5 screens at 700x800; the picture question still needs no scroll with its fifth extra button.
 * Screenshots: T/shots/fit-<view>-<w>x<h>[-dark].png        Port range 9700-9719.
 */
import * as H from './harness.mjs';
import { ok, info, measure, scrollAll, qbarState } from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';

const SIZES = [[700, 800], [1366, 768], [1920, 1080], [400, 800]];
const VIEWS = [
  { name: 'home', view: 'home', params: {} },
  { name: 'section-look', view: 'section', params: { id: 'look' } },
  { name: 'section-kathy', view: 'section', params: { id: 'kathy' } },
  { name: 'section-big', view: 'section', params: { id: IDS.sections.big } },
  { name: 'section-small', view: 'section', params: { id: IDS.sections.small } },
  { name: 'q-visual', view: 'question', params: { id: IDS.visual }, q: true, key: true },
  { name: 'q-choice', view: 'question', params: { id: IDS.choiceNormal }, q: true, key: true },
  { name: 'q-choice-short', view: 'question', params: { id: IDS.choiceShort }, q: true },
  { name: 'q-choice-long', view: 'question', params: { id: IDS.choiceLong }, q: true, long: true },
  { name: 'q-choice-xss', view: 'question', params: { id: IDS.choiceXss }, q: true, long: true },
  { name: 'q-readonly', view: 'question', params: { id: IDS.readonly }, q: true },
  { name: 'q-done', view: 'question', params: { id: IDS.done }, q: true },
  { name: 'q-working-visual', view: 'question', params: { id: IDS.visualChange }, q: true },
  { name: 'done', view: 'done', params: {} },
  { name: 'newsection', view: 'newsection', params: {} },
];

/* ---------- the test ---------- */
const h = await H.start(Number(process.env.QT_PORT) || 9701);   // QT_PORT moves the range (it tries 15 ports from there)
{
  // the checks themselves must be able to FAIL: put bad things on a page and see that they are caught
  const p = await H.open(h, { docs: seed(), w: 700, h: 800, label: 'selftest ' });
  await H.ready(p);
  await H.go(p, 'home');
  await p.evaluate(() => {
    const d = document.createElement('div'); d.id = 'bad1'; d.textContent = 'Very pale grey words'; d.style.cssText = 'color:#cccccc;background:#ffffff;padding:4px';
    const w = document.createElement('div'); w.id = 'bad2'; w.textContent = 'wide'; w.style.cssText = 'width:1500px;height:10px;background:red';
    const b = document.createElement('button'); b.className = 'btn'; b.id = 'bad3'; b.textContent = 'A button with a very long label that cannot fit'; b.style.cssText = 'width:60px;overflow:hidden;white-space:nowrap;display:block';
    const v = document.getElementById('qt-view'); v.append(d, w, b);
  });
  await p.evaluate(() => {
    const v = document.getElementById('qt-view');
    const a = document.createElement('p'); a.id = 'ov1'; a.textContent = 'Story text that is hidden behind a button'; a.style.cssText = 'position:relative;margin:0;height:30px';
    const b = document.createElement('button'); b.id = 'ov2'; b.className = 'btn'; b.textContent = 'Covering button'; b.style.cssText = 'position:relative;margin-top:-26px;display:block;width:300px';
    v.append(a, b);
  });
  const m = await p.evaluate(measure);
  ok('(self test) the overlap check catches a button sitting on top of text', m.overlap.some((o) => /Covering button/.test(o) && /Story text/.test(o)), m.overlap.join(' | '));
  ok('(self test) the contrast check catches pale text', m.contrast.some((c) => /Very pale/.test(c.text)), JSON.stringify(m.contrast.slice(0, 2)));
  ok('(self test) the width check catches a 1500 px wide element', m.docW > m.vw || m.wide.length > 0, `doc ${m.docW}`);
  ok('(self test) the clipping check catches a squeezed button', m.clipped.some((c) => /very long label/.test(c)), m.clipped.join(' | '));
  await p.context().close();
}
const table = [];   // for the final print-out
const DOCS = seed();

for (const scheme of ['light', 'dark']) {
  for (const [w, hh] of SIZES) {
    const tag = `${w}x${hh}${scheme === 'dark' ? ' dark' : ''}`;
    const page = await H.open(h, { docs: DOCS, w, h: hh, scheme, label: tag + ' ' });
    ok(`[${tag}] app draws`, await H.ready(page));
    const theme = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    ok(`[${tag}] body has an explicit background (${theme})`, theme && !/rgba\(0, 0, 0, 0\)/.test(theme));
    for (const v of VIEWS) {
      await H.go(page, v.view, v.params);
      await page.evaluate(() => window.scrollTo(0, 0));
      await H.settle(page, 100);
      const m = await page.evaluate(measure);
      const name = `[${tag}] ${v.name}`;
      ok(`${name}: no sideways scroll`, m.docW <= m.vw + 1 && m.bodyW <= m.vw + 1, `doc ${m.docW} body ${m.bodyW} window ${m.vw}`);
      ok(`${name}: nothing wider than the window`, m.wide.length === 0, m.wide.slice(0, 4).join(' | '));
      ok(`${name}: no clipped text in buttons / chips`, m.clipped.length === 0, m.clipped.slice(0, 4).join(' | '));
      ok(`${name}: nothing is drawn on top of anything else (no overlapping text, buttons or pictures)`, m.overlap.length === 0, m.overlap.slice(0, 3).join(' | '));
      if (v.q) {
        const sy = m.story;
        ok(`${name}: the story text is there, inside the window and not covered`, !!sy && sy.shown && sy.w > 20 && sy.h > 8 && sy.left >= -1 && sy.right <= sy.vw + 1 && sy.covered === 0, JSON.stringify(sy));
      }
      ok(`${name}: no text cut off inside cards, tiles or rows`, m.cut.length === 0, m.cut.slice(0, 4).join(' | '));
      ok(`${name}: text contrast ok (${m.nText} texts)`, m.contrast.length === 0, m.contrast.slice(0, 4).map((c) => `${c.ratio}<${c.need} ${c.el} "${c.text}" ${c.fg} on ${c.bg}`).join(' | '));
      if (v.q) {
        ok(`${name}: question bar is there and shows the question + a status chip`, !!m.qbar && m.qbar.text.length > 8 && m.qbar.hasChip, m.qbar ? m.qbar.text : 'no .qbar');
        // scroll to the very bottom: the bar must still be on screen, not covered
        const moved = await page.evaluate(scrollAll);
        await H.settle(page, 80);
        const s = await page.evaluate(qbarState);
        ok(`${name}: question bar stays visible after scrolling${moved ? ' (' + Math.round(moved) + ' px)' : ' (nothing to scroll)'}`, !!s && s.visible && !s.covered, JSON.stringify(s));
        if (v.long && w === 700) ok(`${name}: (test is real) the long question really scrolls`, moved > 0, 'moved ' + moved);
        await page.evaluate(() => window.scrollTo(0, 0));
      }
      table.push({ tag, view: v.name, docH: m.docH, vh: m.vh, lastBottom: m.lastBottom, scroll: Math.max(0, m.docH - m.vh) });
      // The KEY rule
      if (v.key && w === 700 && hh === 800 && scheme === 'light') {
        const noScroll = m.docH <= m.vh + 1;
        ok(`KEY ${name}: NO vertical page scroll at 700x800 (page ${m.docH} px, window ${m.vh} px)`, noScroll, `page is ${m.docH - m.vh} px too tall; lowest picture/button edge at ${m.lastBottom} px`);
        ok(`KEY ${name}: every picture and button is inside the window (lowest edge ${m.lastBottom} <= ${m.vh})`, m.lastBottom <= m.vh + 1);
      }
      if (v.name === 'q-visual') {
        const imgs = m.imgs;
        ok(`${name}: all 4 versions are shown as tiles (the broken picture gets a placeholder)`, m.tiles === 4, `${m.tiles} tiles, ${imgs.length} <img>`);
        const bigScreen = w >= 1600;   // item 13: on a big monitor the 4 tiles grow to about 420 px
        const tooBig = imgs.filter((i) => i.w > (bigScreen ? 440 : 302) || i.h > (bigScreen ? 190 : 172));
        ok(`${name}: thumbnails are at most ${bigScreen ? '440x190' : '300x170'} (${imgs.map((i) => i.w + 'x' + i.h).join(' ')})`, tooBig.length === 0, tooBig.map((i) => i.w + 'x' + i.h + ' ' + i.alt).join(', '));
        if (bigScreen) ok(`${name}: on a big monitor the tiles are at least 380 px wide (${imgs.map((i) => i.w + 'x' + i.h).join(' ')})`, imgs.length > 0 && imgs.every((i) => i.w >= 380), imgs.map((i) => i.w + 'x' + i.h).join(' '));
        if (w >= 1100 && imgs.length && m.ansBtns.length) {
          const picRight = Math.max(...imgs.map((i) => i.r)), btnLeft = Math.min(...m.ansBtns.map((b) => b.l));
          ok(`${name}: wide screen shows pictures left, answers right`, picRight <= btnLeft + 4, `pictures end at x=${picRight}, buttons start at x=${btnLeft}`);
        }
        const texts = m.btns.map((b) => b.text.toLowerCase());
        ok(`${name}: has the extra buttons (not sure / explain / change)`, /not sure/.test(texts.join('|')) && /another way|explain/.test(texts.join('|')) && /change/.test(texts.join('|')), texts.join(' | ').slice(0, 300));
      }
      if (v.name === 'q-readonly') {
        const t = m.btns.map((b) => b.text.toLowerCase()).join('|');
        ok(`${name}: no answer buttons on a read-only question`, !/not sure|type my own|another way|change this/.test(t), t.slice(0, 200));
      }
      if (scheme === 'light' || v.key) await H.shot(page, `fit-${v.name}-${w}x${hh}${scheme === 'dark' ? '-dark' : ''}`);
      if (v.key && w === 700 && scheme === 'light') await H.shot(page, `fit-${v.name}-${w}x${hh}-full`, { full: true });
    }
    // explicit theme attribute beats the OS setting
    await page.evaluate((s) => { document.documentElement.setAttribute('data-theme', s === 'dark' ? 'light' : 'dark'); }, scheme);
    await H.settle(page, 80);
    const bg2 = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    ok(`[${tag}] data-theme overrides the OS colour scheme (${theme} -> ${bg2})`, bg2 !== theme);
    ok(`[${tag}] no page errors while browsing`, page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
    await page.context().close();
  }
}


/* ---------- F1 / F3: the Safety check card, "sent to Miss Cathy and Rob", "You sent these", "Downloads and skills" ---------- */
await H.block('safety card, sent questions, downloads section', async () => {
  const DOCS2 = seed({ downloads: true, cathy: true });
  const V2 = [
    { name: 'q-safety', view: 'question', params: { id: IDS.safety }, q: true, screens: 1.5, folds: true },
    { name: 'q-safety-clean', view: 'question', params: { id: IDS.safetyClean }, q: true, screens: 1.5, folds: true },
    { name: 'q-safety-bad', view: 'question', params: { id: IDS.safetyBad }, q: true, screens: 1.5, folds: true },
    { name: 'q-safety-unchecked', view: 'question', params: { id: IDS.safetyNone }, q: true, screens: 1.5 },
    { name: 'q-sent-to-cathy', view: 'question', params: { id: 'c-normal' }, q: true, key: true },
    { name: 'section-kathy-sent', view: 'section', params: { id: 'kathy' } },
    { name: 'section-downloads', view: 'section', params: { id: 'downloads' } },
  ];
  for (const scheme of ['light', 'dark']) {
    for (const [w, hh] of SIZES) {
      const tag = `${w}x${hh}${scheme === 'dark' ? ' dark' : ''}`;
      const page = await H.open(h, { docs: DOCS2, w, h: hh, scheme, label: 'F1/F3 ' + tag + ' ' });
      ok(`[${tag}] (F1/F3) app draws`, await H.ready(page));
      for (const v of V2) {
        for (const opened of v.folds ? [false, true] : [false]) {
          await H.go(page, v.view, v.params);
          if (opened) await page.evaluate(() => document.querySelectorAll('.sf-fold').forEach((d) => { d.open = true; }));
          await page.evaluate(() => window.scrollTo(0, 0));
          await H.settle(page, 100);
          const m = await page.evaluate(measure);
          const name = `[${tag}] ${v.name}${opened ? ' (fold-outs open)' : ''}`;
          ok(`${name}: no sideways scroll`, m.docW <= m.vw + 1 && m.bodyW <= m.vw + 1, `doc ${m.docW} body ${m.bodyW} window ${m.vw}`);
          ok(`${name}: nothing wider than the window`, m.wide.length === 0, m.wide.slice(0, 4).join(' | '));
          ok(`${name}: no clipped text in buttons / chips`, m.clipped.length === 0, m.clipped.slice(0, 4).join(' | '));
          ok(`${name}: nothing is drawn on top of anything else`, m.overlap.length === 0, m.overlap.slice(0, 3).join(' | '));
          ok(`${name}: no text cut off inside cards, tiles or rows`, m.cut.length === 0, m.cut.slice(0, 4).join(' | '));
          ok(`${name}: text contrast ok (${m.nText} texts)`, m.contrast.length === 0, m.contrast.slice(0, 4).map((c) => `${c.ratio}<${c.need} ${c.el} "${c.text}" ${c.fg} on ${c.bg}`).join(' | '));
          if (v.q) {
            ok(`${name}: the story is there and not covered`, !!m.story && m.story.shown && m.story.covered === 0, JSON.stringify(m.story));
            const moved = await page.evaluate(scrollAll);
            await H.settle(page, 80);
            const st = await page.evaluate(qbarState);
            ok(`${name}: question bar stays visible after scrolling${moved ? ' (' + Math.round(moved) + ' px)' : ''}`, !!st && st.visible && !st.covered, JSON.stringify(st));
            await page.evaluate(() => window.scrollTo(0, 0));
          }
          if (w === 700 && hh === 800 && scheme === 'light' && !opened) {
            if (v.screens) ok(`${name}: KEY at most ${v.screens} screens at 700x800 (page ${m.docH} px, window ${m.vh} px)`, m.docH <= m.vh * v.screens + 1, `page ${m.docH}, limit ${Math.round(m.vh * v.screens)}`);
            if (v.key) ok(`${name}: KEY NO vertical page scroll at 700x800 (page ${m.docH} px)`, m.docH <= m.vh + 1, `page is ${m.docH - m.vh} px too tall`);
            await H.shot(page, `fit-${v.name}-${w}x${hh}`, { full: true });
          }
        }
      }
      ok(`[${tag}] (F1/F3) no page errors`, page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
      await page.context().close();
    }
  }
  /* the picture question has a fifth extra button now: the whole page must still need no scroll at 700x800, and the choice question with a long "explain" row too */
  const pv = await H.open(h, { docs: DOCS2, w: 700, h: 800, label: 'F1 picture ' });
  await H.go(pv, 'question', { id: IDS.visual });
  await H.settle(pv, 150);
  const vm = await pv.evaluate(() => ({ docH: document.documentElement.scrollHeight, vh: innerHeight, extra: document.querySelector('.qa-extra').getBoundingClientRect().height, cathy: !!document.querySelector('[data-fid="x-cathy"]') }));
  ok(`KEY q-visual with the "Miss Cathy and Rob" button: NO vertical page scroll at 700x800 (page ${vm.docH} px, extra buttons ${Math.round(vm.extra)} px high)`, vm.cathy && vm.docH <= vm.vh + 1 && vm.extra <= 88, JSON.stringify(vm));
  await pv.context().close();
});

/* ---------- the drop-down menu on narrow windows ---------- */
await H.block('menu drop-down', async () => {
  for (const [w, hh] of [[700, 800], [400, 800], [800, 600]]) {
    const page = await H.open(h, { docs: DOCS, w, h: hh, label: `menu ${w}: ` });
    await H.ready(page);
    const name = `[${w}x${hh}] menu`;
    const closed = await page.evaluate(() => { const m = document.getElementById('qt-menu'); const r = m.getBoundingClientRect(); const cs = getComputedStyle(m); return { shown: cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 0 && r.right > 0 && r.left < innerWidth && r.height > 0 }; });
    ok(`${name}: closed at first (the question gets the whole width)`, !closed.shown, JSON.stringify(closed));
    await page.click('.menu-btn');
    await H.settle(page, 250);
    const o = await page.evaluate(() => { const m = document.getElementById('qt-menu'); const r = m.getBoundingClientRect(); const items = [...m.querySelectorAll('button.mi')].filter((e) => e.getClientRects().length); const last = items[items.length - 1]; const lr = last ? last.getBoundingClientRect() : null; return { l: Math.round(r.left), r: Math.round(r.right), t: Math.round(r.top), b: Math.round(r.bottom), n: items.length, lastBottom: lr ? Math.round(lr.bottom) : 0, lastText: last ? last.innerText.trim() : '', expanded: document.querySelector('.menu-btn').getAttribute('aria-expanded'), docW: document.documentElement.scrollWidth, vw: innerWidth, vh: innerHeight, scrolls: m.scrollHeight > m.clientHeight + 1, overflowY: getComputedStyle(m).overflowY }; });
    ok(`${name}: opens, lists all ${o.n} places, button says it is open`, o.n >= 8 && o.expanded === 'true' && o.l >= -1 && o.r <= o.vw + 1, JSON.stringify(o));
    ok(`${name}: no sideways scroll while open`, o.docW <= o.vw + 1, JSON.stringify(o));
    ok(`${name}: the last item ("${o.lastText}") can be reached (fits on screen or the menu scrolls)`, o.lastBottom <= o.vh + 1 || /(auto|scroll)/.test(o.overflowY), JSON.stringify(o));
    await H.shot(page, `fit-menu-open-${w}x${hh}`);
    await page.keyboard.press('Escape');
    await H.settle(page, 200);
    ok(`${name}: Esc closes it and focus goes back to the Menu button`, (await page.evaluate(() => document.querySelector('.menu-btn').getAttribute('aria-expanded'))) === 'false' && (await page.evaluate(() => document.activeElement === document.querySelector('.menu-btn'))));
    await page.click('.menu-btn');
    await H.settle(page, 200);
    await H.clickText(page, 'Other questions', { within: '#qt-menu' });
    await H.settle(page, 300);
    ok(`${name}: picking a place goes there and closes the menu`, /Other questions/.test(await H.text(page, '#qt-view h1, #qt-view .sx-h1') || '') && (await page.evaluate(() => document.querySelector('.menu-btn').getAttribute('aria-expanded'))) === 'false', await H.text(page, '#qt-view h1'));
    await page.click('.menu-btn'); await H.settle(page, 200);
    await page.mouse.click(w - 5, hh - 5);
    await H.settle(page, 250);
    ok(`${name}: a click outside closes it`, (await page.evaluate(() => document.querySelector('.menu-btn').getAttribute('aria-expanded'))) === 'false');
    // growing the window makes the menu a side bar again
    await page.click('.menu-btn'); await page.setViewportSize({ width: 1200, height: hh }); await H.settle(page, 300);
    const side = await page.evaluate(() => { const m = document.getElementById('qt-menu'); const r = m.getBoundingClientRect(); return { shown: r.width > 100 && r.left >= 0, menuBtnShown: getComputedStyle(document.querySelector('.menu-btn')).display !== 'none' }; });
    ok(`${name}: on a wide window the menu is a side bar and the Menu button is gone`, side.shown && !side.menuBtnShown, JSON.stringify(side));
    ok(`${name}: no page errors`, page.__errs.length === 0, page.__errs.join(' | '));
    await page.context().close();
  }
});

/* what she would see: measured heights, 700x800 light first */
console.log('\nMEASURED HEIGHTS (page height vs window; "over" = how many px she would have to scroll)');
console.log('size / view'.padEnd(34) + 'page'.padStart(6) + 'window'.padStart(8) + 'over'.padStart(6) + '  lowest control');
for (const r of table.filter((r) => !r.tag.includes('dark'))) console.log((r.tag + ' / ' + r.view).padEnd(34) + String(r.docH).padStart(6) + String(r.vh).padStart(8) + String(r.scroll).padStart(6) + '  ' + r.lastBottom);
info('Screenshots are in T/shots/fit-*.png');
await H.stop(h);
