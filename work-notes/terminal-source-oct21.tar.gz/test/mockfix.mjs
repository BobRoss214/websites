/* mockfix.mjs  (owner: core)  -  glue between Playwright and test/mock-claude.js
 *
 *   import { injectMock, newPage, seedFromDocs, sampleSeed } from './mockfix.mjs';
 *   const page = await (await browser.newContext({ viewport: { width: 700, height: 800 } })).newPage();
 *   await injectMock(page, sampleSeed(), { comments: 'available' });      // BEFORE page.goto
 *   await page.goto(base + 'dist/index.html');
 *
 * injectMock(page, seed, options)
 *   seed     { 'questions/q1': {...}, ... }   or an array of docs that carry "_collection" and "id" (the T/seed/*.json format)
 *   options  db:null | dbNull:true     use('db') resolves null (the page runs without a notebook)
 *            comments:'writers_only'|'no_session'|'off'|{can}|null     what comments.canSendToClaude() answers (null: use('comments') is null)
 *            user:null                 use('user') resolves null
 *            dbReject:true | useReject:true | useThrow:true | dbHang:true     use('db') rejects / use() rejects / use() throws / use('db') never answers
 *            silent:['plans']          collections that never deliver their first snapshot
 *            cacheFirst:true|ms        every collection first delivers half of its documents marked fromCache, then the complete snapshot after ms (default 40)
 *            writeDelay:ms  useDelay:ms  persist:true (data survives a reload inside this tab)
 *            doctype:false             do NOT put "<!doctype html>" in front of the page (default: it is added, like the Artifact skeleton does)
 * The page file is served WITH "<!doctype html><meta charset><meta viewport>" in front, because the published page sits inside such a skeleton:
 * without it the browser would use "quirks mode" and measure things differently from the real thing.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const MOCK_PATH = path.join(HERE, 'mock-claude.js');
export const MOCK_SRC = fs.readFileSync(MOCK_PATH, 'utf8');
export const PRELUDE = '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';

/** [{_collection:'questions', id:'q1', ...}] -> { 'questions/q1': {...} } */
export function seedFromDocs(list) {
  const out = {};
  for (const d of list || []) {
    if (!d || !d._collection || !d.id) continue;
    const { _collection, ...rest } = d;
    out[_collection + '/' + d.id] = rest;
  }
  return out;
}

/** Reads seed json files (arrays in the T/seed format) into one seed object. Missing files are skipped. */
export function seedFromFiles(...files) {
  const out = {};
  for (const f of files) {
    try { Object.assign(out, seedFromDocs(JSON.parse(fs.readFileSync(f, 'utf8')))); } catch (e) { /* skipped */ }
  }
  return out;
}

/** Made-up documents for the Workers and Tasks parts (SPEC2.md section 3): a crew of 5, a task tree with 7 tasks, her own add / edit, 2 asks (one answered).
 *  Use:  sampleSeed(Date.now(), { parts: true })   or   Object.assign(sampleSeed(), partsSeed()).  NOT content for the owner. */
export function partsSeed(now = Date.now()) {
  const iso = (msAgo) => new Date(now - msAgo).toISOString();
  const w = (id, parentId, kind, name, extra = {}) => ({ id, name, parentId, kind, icon: '', role: 'Does a made-up job', state: 'resting', now: '', waitingFor: 'none', startedAt: null, updatedAt: iso(120e3), finishedAt: null,
    activity: [], result: '', taskIds: [], brain: '', progress: null, order: 1, ...extra });
  const t = (id, parentId, title, extra = {}) => ({ id, parentId, title, plain: 'A made-up job: ' + title + '.', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 1,
    createdAt: iso(7200e3), updatedAt: iso(300e3), doneAt: null, createdBy: 'claude', seenAt: iso(250e3), ...extra });
  return {
    'workers/claude': w('claude', null, 'lead', 'Claude', { icon: '\ud83e\uddd1\u200d\ud83c\udf3e', role: 'The boss of the crew', state: 'working', now: 'Putting the pieces together', startedAt: iso(7200e3), brain: 'Opus', order: 0, activity: [{ at: iso(120e3), text: 'Checked the new pictures' }] }),
    'workers/builders': w('builders', 'claude', 'team', 'Page builders', { icon: '\ud83e\uddf1', role: 'Make the pages', state: 'working', order: 1 }),
    'workers/map-a': w('map-a', 'builders', 'helper', 'Map drawer A', { icon: '\ud83d\uddfa\ufe0f', role: 'Draws the farm map', state: 'working', now: 'Making the roads grey', startedAt: iso(1500e3), progress: 40, brain: 'Sonnet', taskIds: ['map-draw'], order: 1 }),
    'workers/map-b': w('map-b', 'builders', 'helper', 'Map drawer B', { icon: '\ud83d\uddfa\ufe0f', role: 'Draws the farm map', state: 'done', startedAt: iso(5000e3), finishedAt: iso(900e3), result: 'Handed back a finished sample picture.', order: 2 }),
    'workers/checker': w('checker', 'claude', 'helper', 'Site checker', { icon: '\ud83d\udd0e', role: 'Checks the pages', state: 'waiting', waitingFor: 'owner', now: 'Needs your answer about the field', order: 3, taskIds: ['map-ask'] }),
    'tasks/map': t('map', null, 'Redraw the farm map', { state: 'working', workerIds: ['builders'], note: 'Four samples are ready' }),
    'tasks/map-draw': t('map-draw', 'map', 'Draw the samples', { state: 'working', workerIds: ['map-a'] }),
    'tasks/map-ask': t('map-ask', 'map', 'Ask which field is the farm\u2019s', { state: 'waiting', waitingFor: 'owner', questionIds: ['q1'], workerIds: ['checker'] }),
    'tasks/map-old': t('map-old', 'map', 'Look at the old map', { state: 'done', doneAt: iso(3600e3), workerIds: ['map-b'] }),
    'tasks/photos': t('photos', null, 'Holiday photos', { state: 'todo' }),
    'tasks/photos-pick': t('photos-pick', 'photos', 'Pick the photos', { state: 'paused' }),
    'tasks/u-mine1': t('u-mine1', null, 'Fix the menu spelling', { createdBy: 'owner', state: 'todo', seenAt: iso(100e3), createdAt: iso(200e3) }),
    'taskAdds/u-mine1': { id: 'u-mine1', parentId: null, title: 'Fix the menu spelling', plain: '', createdAt: iso(200e3) },
    'taskAdds/u-new1': { id: 'u-new1', parentId: 'photos', title: 'Ask Cathy for more photos', plain: 'She said she has some.', createdAt: iso(30e3) },
    'taskEdits/map-ask': { id: 'map-ask', plain: 'Please ask in simple words.', updatedAt: iso(20e3) },
    'asks/u-ask1': { id: 'u-ask1', targetKind: 'worker', targetId: 'map-a', text: 'How long until the map is ready?', createdAt: iso(600e3) },
    'replies/u-ask1': { id: 'u-ask1', targetKind: 'worker', targetId: 'map-a', state: 'answered', text: 'About an hour. The roads are done.', from: 'Map drawer A', at: iso(400e3) },
    'asks/u-ask2': { id: 'u-ask2', targetKind: 'task', targetId: 'photos', text: 'Which photos are in?', createdAt: iso(10e3) },
  };
}

/** A small made-up notebook for tests (NOT content for the owner). Options: { parts: true } also adds partsSeed(). */
export function sampleSeed(now = Date.now(), opts = {}) {
  const iso = (msAgo) => new Date(now - msAgo).toISOString();
  const q = (id, sectionId, order, extra = {}) => ({
    id, sectionId, kind: 'choice', order, createdAt: iso(3600e3), title: 'Test question ' + id, story: ['A made-up story for ' + id + '.'], why: 'Because this is a test.',
    choices: ['A', 'B', 'C', 'D'].map((k) => ({ key: k, label: 'Choice ' + k, explain: 'If you pick ' + k + ' something happens.' })),
    required: false, round: 1, parentId: null, who: 'owner', previouslyNotSure: false, oldId: null, ...extra,
  });
  return {
    'sections/look': { id: 'look', title: 'Look and feel', kind: 'builtin', order: 1, size: 'small', hold: false, readOnly: false, blurb: 'Pictures I made.', archived: false, createdAt: iso(86400e3), createdBy: 'claude' },
    'sections/other': { id: 'other', title: 'Other questions', kind: 'builtin', order: 2, size: 'small', hold: false, readOnly: false, blurb: 'Everything else.', archived: false, createdAt: iso(86400e3), createdBy: 'claude' },
    'sections/later': { id: 'later', title: 'Ideas for later', kind: 'builtin', order: 3, size: 'small', hold: false, readOnly: false, blurb: 'Parked ideas.', archived: false, createdAt: iso(86400e3), createdBy: 'claude' },
    'sections/kathy': { id: 'kathy', title: 'Questions for Miss Kathy and Rob', kind: 'builtin', order: 4, size: 'small', hold: false, readOnly: true, blurb: 'Only they can answer.', archived: false, createdAt: iso(86400e3), createdBy: 'claude' },
    'sections/my-topic': { id: 'my-topic', title: 'My topic', kind: 'custom', order: 10, size: 'big', hold: false, readOnly: false, blurb: '', archived: false, createdAt: iso(7200e3), createdBy: 'owner' },
    'questions/q1': q('q1', 'other', 1),
    'questions/q2': q('q2', 'other', 2, { required: true }),
    'questions/q3': q('q3', 'my-topic', 1, { required: true }),
    'answers/q2': { id: 'q2', status: 'answered', key: 'B', ownText: '', changeText: '', note: '', label: 'Choice B', answeredAt: iso(600e3), round: 1 },
    'status/q2': { id: 'q2', state: 'seen', seenAt: iso(300e3), note: '', doneNote: '', doneImages: [], followupId: null, at: iso(300e3) },
    'ideas/i1': { id: 'i1', sectionId: 'my-topic', text: 'I would like a simple page about gifts.', createdAt: iso(1800e3), sentAt: iso(1790e3) },
    'ideaStatus/i1': { id: 'i1', state: 'read', at: iso(1700e3), note: '' },
    'plans/my-topic': { sectionId: 'my-topic', version: 1, summary: 'A made-up plan.', steps: ['Step one', 'Step two'], needs: [], at: iso(900e3) },
    'meta/heartbeat': { at: iso(120e3), note: 'working' },
    ...(opts.parts ? partsSeed(now) : {}),
  };
}

/** Puts the fake `window.claude` into a Playwright page (call BEFORE page.goto). */
export async function injectMock(page, seed = {}, options = {}) {
  const config = { ...options };
  if (options.db === null) config.dbNull = true;
  await page.addInitScript(([s, c]) => { window.__MOCK_SEED__ = s; window.__MOCK_CONFIG__ = c; }, [seed || {}, config]);
  await page.addInitScript(MOCK_SRC);
  if (options.doctype !== false) {
    await page.route((url) => /\/(index\.html)?$/.test(url.pathname) && /\.html$|\/$/.test(url.pathname), async (route) => {
      if (route.request().resourceType() !== 'document') return route.continue();
      let res;
      for (let i = 0; i < 3 && !res; i++) {
        try { res = await route.fetch(); } catch (e) { if (i === 2) return route.abort(); await new Promise((r) => setTimeout(r, 200 * (i + 1))); }
      }
      const type = res.headers()['content-type'] || '';
      const body = await res.text();
      if (!/html/i.test(type) || /^\s*<!doctype/i.test(body)) return route.fulfill({ response: res, body });
      return route.fulfill({ response: res, body: PRELUDE + '\n' + body, headers: { ...res.headers(), 'content-type': 'text/html; charset=utf-8' } });
    });
  }
}

/** A fresh page (own browser context) with the mock in it, errors collected into `errs` (default: a new array on page.__errs). */
export async function newPage(browser, { seed = {}, options = {}, viewport = { width: 700, height: 800 }, errs = [], colorScheme = 'light', init } = {}) {
  const ctx = await browser.newContext({ viewport, locale: 'en-US', timezoneId: 'America/New_York', colorScheme });
  const page = await ctx.newPage();
  page.__errs = errs;
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|Failed to load resource|net::ERR/.test(m.text())) errs.push('console: ' + m.text()); });
  if (init) await page.addInitScript(init);
  await injectMock(page, seed, options);
  return page;
}

/** Waits until the page's QT.ready has resolved (resolves true) or the limit is up (false). */
export async function waitReady(page, limit = 15000) {
  try {
    await page.waitForFunction(() => window.QT && window.QT.isReady === true, null, { timeout: limit });
    return true;
  } catch (e) { return false; }
}
