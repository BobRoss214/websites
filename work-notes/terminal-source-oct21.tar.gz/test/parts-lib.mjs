/* Shared helpers for the tests of the Terminal's new parts (SPEC2: Questions | Workers | Tasks).  Owner: tester.
 * The parts are built by several helpers, so the tests find things by ROLE, TEXT and by data-attributes in a few likely spellings, and say
 * exactly what they could not find. Nothing here edits the page.
 */
import * as H from './harness.mjs';
import { ok, info } from './harness.mjs';
import { seed, IDS, IDS2, EXPECT2 } from './fixtures.mjs';

export { H, ok, info, seed, IDS, IDS2, EXPECT2 };
export const sleep = H.sleep;

/** The standard rich notebook for the parts. Options as seed(): noCrew, noTasks, bigTasks ... */
export const partsDocs = (o = {}) => seed({ parts: true, ...o });

/** Opens the page with the rich notebook (or `docs`). */
export async function openParts(h, o = {}) {
  const page = await H.open(h, { docs: o.docs || partsDocs(o.seed || {}), ...o });
  if (o.wait !== false) await H.ready(page);
  return page;
}

/** What a part needs from window.QT, so a missing piece is one clear failure and not fifty. */
export async function apiReport(page) {
  return page.evaluate(() => {
    const Q = window.QT || {};
    const has = (o, k) => !!o && typeof o[k] === 'function';
    const P = Q.parts || {};
    return {
      collections: (Q.collections || []).slice(),
      partsFns: ['current', 'go', 'workers', 'workerKids', 'workerRoots', 'tasks', 'taskKids', 'taskRoots', 'progress', 'seen', 'counts'].filter((k) => !has(P, k)),
      writeFns: ['taskAdd', 'taskEdit', 'ask'].filter((k) => !has(Q.write, k)),
      views: ['workers', 'tasks'].filter((k) => !has(Q.views, k)),
      hasParts: !!Q.parts,
    };
  });
}

/** Tab strip as the page shows it. */
export function tabsInfo(page) {
  return page.evaluate(() => {
    const list = document.querySelector('[role=tablist]');
    const tabs = list ? [...list.querySelectorAll('[role=tab]')] : [];
    const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
    return {
      list: !!list, label: list ? (list.getAttribute('aria-label') || list.getAttribute('aria-labelledby') || '') : '', visible: list ? vis(list) : false,
      sticky: list ? (() => { for (let e = list; e && e !== document.body; e = e.parentElement) if (getComputedStyle(e).position === 'sticky' || getComputedStyle(e).position === 'fixed') return true; return false; })() : false,
      tabs: tabs.map((t) => ({ text: t.innerText.replace(/\s+/g, ' ').trim(), name: t.getAttribute('aria-label') || '', selected: t.getAttribute('aria-selected'), tabindex: t.tabIndex, controls: t.getAttribute('aria-controls'), id: t.id, w: Math.round(t.getBoundingClientRect().width), h: Math.round(t.getBoundingClientRect().height), badge: (t.querySelector('.count, .badge, [class*=count], [class*=badge]') || {}).innerText || '' })),
    };
  });
}

/** Which part is on screen according to the page itself. */
export const currentPart = (page) => page.evaluate(() => (window.QT && window.QT.parts && window.QT.parts.current ? window.QT.parts.current() : null));

/** Is the left menu showing? (display / size) */
export const menuShown = (page) => page.evaluate(() => { const m = document.getElementById('qt-menu'); if (!m) return false; const r = m.getBoundingClientRect(); const cs = getComputedStyle(m); return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 20 && r.height > 20 && r.right > 0 && r.left < innerWidth; });
export const hamburgerShown = (page) => page.evaluate(() => { const b = document.querySelector('.menu-btn'); if (!b) return false; const cs = getComputedStyle(b); const r = b.getBoundingClientRect(); return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 0; });
export const mainLeft = (page) => page.evaluate(() => { const v = document.getElementById('qt-view'); const r = v.getBoundingClientRect(); return { left: Math.round(r.left), width: Math.round(r.width), vw: innerWidth }; });

/** Tries a list of likely selectors for "the node of this worker / task"; falls back to the text of its name. Marks the found element with data-tester-node and returns its short description (or null). */
export async function markNode(page, kind, id, name) {
  return page.evaluate(([kind, id, name]) => {
    document.querySelectorAll('[data-tester-node]').forEach((e) => e.removeAttribute('data-tester-node'));
    const k = kind === 'worker' ? ['worker', 'w', 'wid'] : ['task', 't', 'tid'];
    const cand = [];
    for (const a of ['data-id', 'data-key', ...k.map((x) => 'data-' + x + '-id'), ...k.map((x) => 'data-' + x), 'data-' + kind]) cand.push(`[${a}="${id}"]`, `[${a}="${kind[0]}:${id}"]`, `[${a}="${kind}:${id}"]`);
    cand.push('#' + CSS.escape(kind + '-' + id), '#' + CSS.escape(id));
    let el = null;
    for (const c of cand) { try { const f = [...document.querySelectorAll(c)].find((e) => e.getClientRects().length); if (f) { el = f; break; } } catch (e) { /* bad selector */ } }
    if (!el && name) {
      const leaf = [...document.querySelectorAll('#qt-view *')].find((e) => e.children.length === 0 && e.textContent.trim() === name && e.getClientRects().length);
      if (leaf) { el = leaf.closest('[role=treeitem], [role=listitem], li, article, section, [class*=card], [class*=node], [class*=worker], [class*=task]') || leaf.parentElement; }
    }
    if (!el) return null;
    el.setAttribute('data-tester-node', '1');
    return { tag: el.tagName.toLowerCase(), cls: String(el.className).slice(0, 60), role: el.getAttribute('role'), text: el.innerText.replace(/\s+/g, ' ').slice(0, 120) };
  }, [kind, id, name]);
}
export const NODE = '[data-tester-node="1"]';

/** Click a button/link INSIDE the marked node whose text or aria-label matches. */
export async function clickIn(page, rx, within = NODE) {
  const done = await page.evaluate(([src, flags, within]) => {
    const rx = new RegExp(src, flags);
    const root = document.querySelector(within) || document.getElementById('qt-view');
    const list = [...root.querySelectorAll('button, a, [role=button], [role=tab], summary, [role=switch], label')].filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && rx.test((e.innerText || '') + ' ' + (e.getAttribute('aria-label') || '') + ' ' + (e.title || '')); });
    if (!list.length) return false;
    list[0].setAttribute('data-tester-click', '1');
    return true;
  }, [rx.source, rx.flags, within]);
  if (!done) return false;
  try { await page.click('[data-tester-click="1"]', { timeout: 5000 }); } finally { await page.evaluate(() => document.querySelectorAll('[data-tester-click]').forEach((e) => e.removeAttribute('data-tester-click'))); }
  return true;
}

/** Visible text of the view (or of one marked node). */
export const textOf = (page, sel = '#qt-view') => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.innerText.replace(/\s+/g, ' ').trim() : ''; }, sel);

/** Chime/alert/image safety counters after unsafe text. */
export const unsafeReport = (page) => page.evaluate(() => ({ img: document.querySelectorAll('img[src="x"]').length, scripts: document.querySelectorAll('#app script').length, flag: window.__xss || null, alerts: (window.__alerts || []).length, handlers: [...document.querySelectorAll('#app *')].filter((e) => e.hasAttribute('onerror') || e.hasAttribute('onload')).length }));

/** Timing of an action in the page (ms, with 2 frames after). */
export async function timed(page, fn, arg) {
  return page.evaluate(async ([src, a]) => { const f = new Function('a', 'return (' + src + ')(a)'); const t0 = performance.now(); await f(a); await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))); return Math.round(performance.now() - t0); }, [fn.toString(), arg]);
}
