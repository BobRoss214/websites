/* A made-up crew for the Workers part (NOT content for the owner): 1 lead, 4 teams, 13 helpers in mixed states, a few tasks,
   two questions she asked (one answered, one waiting for Claude to see it, one seen).  fixture(now) -> { workers, tasks, taskAdds, replies, asks }  (objects keyed by id). */
export function fixture(now = Date.now()) {
  const iso = (msAgo) => new Date(now - msAgo).toISOString();
  const MIN = 60e3, H = 3600e3;
  let order = 0;
  const w = (id, over) => ({ id, name: id, parentId: null, kind: 'helper', icon: '', role: '', state: 'resting', now: '', waitingFor: 'none', startedAt: null, updatedAt: iso(5 * MIN), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: ++order, ...over });
  const list = [
    w('claude', { name: 'Claude', kind: 'lead', icon: '🧑‍🌾', role: 'The boss. Plans the work, talks to you and passes your questions on.', state: 'working', now: 'Checking the new pictures and answering your questions', startedAt: iso(6 * H), updatedAt: iso(1 * MIN), brain: 'Opus', taskIds: ['t-terminal'],
      activity: [{ at: iso(1 * MIN), text: 'Looked at the crew and checked who needs help' }, { at: iso(14 * MIN), text: 'Sent the winter tree pictures to the checkers' }] }),

    w('team-map', { name: 'Map drawers', kind: 'team', parentId: 'claude', icon: '🗺️', role: 'Redraw the farm map, one place at a time', state: 'working', startedAt: iso(5 * H), updatedAt: iso(3 * MIN) }),
    w('map-a', { name: 'Map drawer A: Storybook Hills', parentId: 'team-map', icon: '🏰', role: 'Draws the Storybook Hills spot', state: 'working', now: 'Drawing the barn and the little silo', startedAt: iso(48 * MIN), updatedAt: iso(2 * MIN), brain: 'Sonnet', progress: 60, taskIds: ['t-map-hills', 't-map'],
      activity: [{ at: iso(2 * MIN), text: 'Added the red barn' }, { at: iso(12 * MIN), text: 'Drew the path from the gate' }, { at: iso(30 * MIN), text: 'Looked at your farm photos for colors' }] }),
    w('map-b', { name: 'Map drawer B: The GreenHouse', parentId: 'team-map', icon: '🌿', role: 'Draws the GreenHouse next door', state: 'done', startedAt: iso(4 * H), updatedAt: iso(70 * MIN), finishedAt: iso(70 * MIN), brain: 'Sonnet', taskIds: ['t-map'],
      result: 'The GreenHouse is drawn with the tree lot and the shop door. Ready for a look.', activity: [{ at: iso(70 * MIN), text: 'Finished the picture and checked the sizes' }] }),
    w('map-c', { name: 'Map drawer C: Pumpkin Patch', parentId: 'team-map', icon: '🎃', role: 'Draws the pumpkin patch and the wagon ride', state: 'working', now: 'Placing the pumpkin rows', startedAt: iso(35 * MIN), updatedAt: iso(4 * MIN), brain: 'Sonnet', taskIds: ['t-map'] }),
    w('map-d', { name: 'Map checker', parentId: 'team-map', icon: '🔍', role: 'Looks at every drawing and spots mistakes', state: 'waiting', waitingFor: 'owner', now: 'Needs you to pick the winter map look (question in Look and feel)', startedAt: iso(3 * H), updatedAt: iso(20 * MIN), brain: 'Sonnet', taskIds: ['t-map'] }),

    w('team-photos', { name: 'Photos, words and winter crew', kind: 'team', parentId: 'claude', icon: '❄️', role: 'Photos, season words and the winter tree game', state: 'working', startedAt: iso(5 * H), updatedAt: iso(9 * MIN) }),
    w('winter-a', { name: 'Winter tree builder', parentId: 'team-photos', icon: '🎄', role: 'Builds the winter tree game', state: 'working', now: 'Lighting the 6th tree and checking the words', startedAt: iso(2 * H), updatedAt: iso(9 * MIN), brain: 'Opus', taskIds: ['t-winter'],
      activity: [{ at: iso(9 * MIN), text: 'Changed the words for the 6th light' }, { at: iso(50 * MIN), text: 'Made the trees tap-able' }] }),
    w('photos-a', { name: 'Holiday photo helper', parentId: 'team-photos', icon: '📸', role: 'Shows holiday photos at the right time of year', state: 'resting', startedAt: iso(4 * H), updatedAt: iso(2 * H), brain: 'Sonnet', taskIds: ['t-holiday'], activity: [{ at: iso(2 * H), text: 'Waiting for your answer about how long a photo shows' }] }),
    w('oldmac', { name: 'Old Mac photo copies', parentId: 'team-photos', icon: '🖥️', role: 'Makes copies of photos that old computers can show', state: 'stopped', startedAt: iso(6 * H), updatedAt: iso(3 * H), finishedAt: iso(3 * H), brain: 'Sonnet', result: 'Stopped early: the old Mac is not needed for now.' }),
    w('words-a', { name: 'Season words helper', parentId: 'team-photos', icon: '✏️', role: 'Checks the "See the farm in" words', state: 'done', startedAt: iso(7 * H), updatedAt: iso(5 * H), finishedAt: iso(5 * H), brain: 'Sonnet', result: 'All four seasons use the same friendly words. Nothing to change.' }),

    w('team-build', { name: 'Terminal builders', kind: 'team', parentId: 'claude', icon: '🛠️', role: 'Build this Terminal page', state: 'working', startedAt: iso(8 * H), updatedAt: iso(2 * MIN) }),
    w('build-core', { name: 'Notebook builder', parentId: 'team-build', icon: '📒', role: 'Makes the page remember things', state: 'done', startedAt: iso(8 * H), updatedAt: iso(6 * H), finishedAt: iso(6 * H), brain: 'Sonnet', result: 'The page now remembers workers, tasks and your questions.', taskIds: ['t-terminal'] }),
    w('build-workers', { name: 'Workers page builder', parentId: 'team-build', icon: '🚜', role: 'Builds the Workers page you are reading', state: 'working', now: 'Making the cards and the ask boxes', startedAt: iso(25 * MIN), updatedAt: iso(2 * MIN), brain: 'Sonnet', taskIds: ['t-terminal'] }),
    w('build-tasks', { name: 'Tasks page builder', parentId: 'team-build', icon: '🌳', role: 'Builds the Tasks tree', state: 'waiting', waitingFor: 'claude', now: 'Waiting for Claude to finish the notebook words', startedAt: iso(30 * MIN), updatedAt: iso(11 * MIN), brain: 'Sonnet', taskIds: ['t-terminal'] }),

    w('team-check', { name: 'Site checkers', kind: 'team', parentId: 'claude', icon: '✅', role: 'Look over the website for mistakes', state: 'resting', startedAt: iso(9 * H), updatedAt: iso(50 * MIN) }),
    w('check-a', { name: 'Translation checker', parentId: 'team-check', icon: '🌍', role: 'Reads the translated pages', state: 'done', startedAt: iso(9 * H), updatedAt: iso(4 * H), finishedAt: iso(4 * H), brain: 'Sonnet', result: 'No wrong words found in the nine languages.' }),
    w('check-b', { name: 'Picture checker', parentId: 'team-check', icon: '🖼️', role: 'Looks for squashed or blurry pictures', state: 'done', startedAt: iso(9 * H), updatedAt: iso(3 * H), finishedAt: iso(3 * H), brain: 'Sonnet', result: 'All pictures look sharp. Two big ones were made smaller.' }),
    w('check-c', { name: 'Link checker', parentId: 'team-check', icon: '🔗', role: 'Clicks every link to see if it works', state: 'resting', startedAt: iso(5 * H), updatedAt: iso(50 * MIN), brain: 'Sonnet' }),
  ];
  const workers = {}; list.forEach((d) => { workers[d.id] = d; });
  const t = (id, title) => ({ id, parentId: null, title, plain: '', state: 'working', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 1, createdAt: iso(24 * H), updatedAt: iso(1 * H), doneAt: null, createdBy: 'claude', seenAt: null });
  const tasks = { 't-map': t('t-map', 'Redraw the farm map'), 't-map-hills': t('t-map-hills', 'Storybook Hills map'), 't-winter': t('t-winter', 'Winter tree game'), 't-holiday': t('t-holiday', 'Holiday photos on the home page'), 't-terminal': t('t-terminal', 'The Terminal itself') };
  const asks = {
    'a-1': { id: 'a-1', targetKind: 'worker', targetId: 'map-a', text: 'Will the barn look like my real barn?', createdAt: iso(40 * MIN) },
    'a-2': { id: 'a-2', targetKind: 'worker', targetId: 'map-a', text: 'Can you add the big oak tree by the gate?', createdAt: iso(3 * MIN) },
    'a-3': { id: 'a-3', targetKind: 'worker', targetId: 'winter-a', text: 'How many trees are lit now?', createdAt: iso(9 * MIN) },
  };
  const replies = {
    'a-1': { id: 'a-1', targetKind: 'worker', targetId: 'map-a', state: 'answered', text: 'It uses your photos of the red barn, so the roof and the door match. Claude will show you the picture when it is ready.', from: 'Map drawer A: Storybook Hills', at: iso(30 * MIN) },
    'a-3': { id: 'a-3', targetKind: 'worker', targetId: 'winter-a', state: 'seen', text: '', from: 'Claude', at: iso(6 * MIN) },
  };
  return { workers, tasks, taskAdds: {}, replies, asks };
}
