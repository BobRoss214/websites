/* core-stub-layout.js (owner: core) - a tiny fake layout so the core can be tested alone. NOT part of the page (not in src).
 *   python3 T/build.py --only "" --extra T/test/core-stub-layout.js --out T/dist-core/index.html
 * It draws: one line of state, and the current view's name; it logs what happens to window.__stub.
 */
(function () {
  'use strict';
  var QT = window.QT;
  var S = window.__stub = { mounted: 0, routes: [], stores: [], offlineEvents: 0, writeErrors: [], readyEvents: 0, wrote: [], answered: [] };
  QT.on('route', function (r) { S.routes.push(r); draw(); });
  QT.on('store', function (e) { S.stores.push(e); });
  QT.on('offline', function () { S.offlineEvents++; });
  QT.on('ready', function () { S.readyEvents++; });
  QT.on('writeerror', function (e) { S.writeErrors.push({ path: e.path, op: e.op, code: e.error && e.error.code }); });
  QT.on('wrote', function (e) { S.wrote.push({ collection: e.collection, id: e.id, op: e.op }); });
  QT.on('answered', function (e) { S.answered.push(e.qid); });
  var root = null;
  function draw() {
    if (!root) return;
    var r = QT.route.current();
    QT.clear(root);
    root.appendChild(QT.el('p', { id: 'stub-state' }, QT.offline ? 'offline' : 'online'));
    root.appendChild(QT.el('p', { id: 'stub-view' }, r.view + (r.params.id ? ':' + r.params.id : '')));
    root.appendChild(QT.el('p', { id: 'stub-count' }, 'questions: ' + Object.keys(QT.store.questions).length));
  }
  QT.layout = {
    mount: function (el) { root = el; S.mounted++; draw(); QT.on('store', draw); QT.on('offline', draw); }
  };
})();
