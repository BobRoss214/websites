/* Tests for the "read it out loud" buttons (src/js/60-speak.js + src/css/60-speak.css), with a pretend speechSynthesis (test/speak-mock.mjs).
 *   NODE_PATH=/opt/node22/lib/node_modules AXE_PATH=/tmp/claude-0/axe-core/axe.min.js node test/speak.test.mjs        ports 9620-9640
 *   (builds a fresh copy of T/src by itself; QT_PAGE=<file> tests exactly that file instead; WA_SLOW=6 makes every time limit longer)
 * Covers: where the buttons are (and are not), start / stop / switch / Esc / leaving the view / keyboard, long text in pieces, errors, the Voice switch
 * (remembered), a browser without speech, PRIVATE VOICES ONLY (local only, google only, online only, mixed, empty, late arrival, vanishing),
 * new text on the page, no doubles, text that is not on screen is not read, 300 paragraphs, the Workers and Tasks parts, fit, look (dark, reduced motion,
 * outline), axe. */
import * as H from './harness.mjs';
import { ok, info, ms, until, okSoon, measure, axeSource } from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';
import { MOCK, VOICES } from './speak-mock.mjs';

const h = await H.start(9620, { src: true });
const DOCS = seed({ parts: true, downloads: true });
const AXE = axeSource();
const sleep = H.sleep;

/** opens a page with a pretend voice; waits until the buttons are drawn (or `wait:false`) */
async function open(o = {}) {
  const init = (o.init || '') + '\n' + MOCK(Object.assign({ auto: 0 }, o.mock || {}));
  const ho = { docs: DOCS, w: o.w || 700, h: o.h || 800, scheme: o.scheme, reduced: o.reduced, init };
  const p = await H.open(h, ho);
  if (o.wait !== false) await until(p, () => document.querySelectorAll('.qt-speak').length > 0, null, 8000);
  await H.settle(p, 200);
  return p;
}
const spoken = (p) => p.evaluate(() => window.__speech.spoken.slice());
const E = (p, fn, arg) => p.evaluate(fn, arg);
const count = (p, sel) => p.evaluate((s) => document.querySelectorAll(s).length, sel);
const speakingNow = (p) => p.evaluate(() => window.QT.speak.speaking());
/** the speaker of the first element matching `sel` in the main area */
const speakerOf = (p, sel, nth = 0) => p.evaluateHandle(([s, n]) => {
  const host = document.querySelectorAll('#qt-main ' + s)[n];
  if (!host) return null;
  return host.querySelector('.qt-speak:not(.qt-inbtn)') || (host.nextElementSibling && host.nextElementSibling.classList.contains('qt-speak') ? host.nextElementSibling : null);
}, [sel, nth]);
async function clickSpeaker(p, sel, nth = 0) {
  const hd = (await speakerOf(p, sel, nth)).asElement();
  if (!hd) throw new Error('no speaker next to ' + sel + ' #' + nth);
  await hd.scrollIntoViewIfNeeded();
  await hd.click();
  await H.settle(p, 80);
  return hd;
}
const hostText = (p, sel, nth = 0) => p.evaluate(([s, n]) => window.QT.speak.textOf(document.querySelectorAll('#qt-main ' + s)[n]), [sel, nth]);
const finishOne = (p) => E(p, () => window.__speech.finish());
/** lets the reading that is going on run to its end (piece after piece) and returns the pieces said since `from` */
async function readAll(p, from) {
  for (let i = 0; i < 40; i++) {
    await sleep(60);
    if (!(await speakingNow(p))) break;
    await finishOne(p);
  }
  return (await spoken(p)).slice(from).map((x) => x.text);
}
const QID = IDS.choiceNormal;

/* ------------------------------------------------------------------------------------------------------------------------ 1. where the buttons are */
await H.block('places', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qa-choice .qt-speak').length === 4, null, 6000);
  const m = await E(p, () => {
    const q = (s) => [...document.querySelectorAll(s)];
    const hasSp = (e) => !!(e && e.querySelector('.qt-speak:not(.qt-inbtn)'));
    return {
      title: q('.qbar-title').every((e) => e.nextElementSibling && e.nextElementSibling.classList.contains('qt-speak')) && q('.qbar-title').length === 1,
      story: q('.qv-story').map((e) => e.querySelectorAll('.qt-speak').length),
      storyParas: q('.qv-story p').length,
      storyEnd: q('.qv-story').map((e) => { const b = e.querySelector('.qt-speak'), last = [...e.querySelectorAll('p')].pop(); return !!b && !!last && last.contains(b); }),
      storyOwn: q('.qv-story p').filter((e) => e.querySelector('.qt-speak')).length,
      why: q('.qv-why p').map(hasSp),
      choices: q('.qa-choices > .qa-choice').map((e) => !!e.querySelector('.qt-speak')),
      heading: q('.qa h2').map(hasSp),
      inButtons: q('button .qt-speak, [role=button] .qt-speak').filter((e) => !e.classList.contains('qt-inbtn')).length,
      inChips: q('.chip .qt-speak, .count .qt-speak, .savestat .qt-speak, .btn .qt-speak, nav .qt-speak, label .qt-speak, .qa-extra .qt-speak, textarea .qt-speak').length,
      all: q('.qt-speak').length,
      labels: [...new Set(q('button.qt-speak').map((e) => e.getAttribute('aria-label')))],
      qaExtraBtn: q('.qa-x .qt-speak').length,
      inbtnHidden: q('.qt-inbtn').every((e) => e.getAttribute('aria-hidden') === 'true' && e.tagName === 'SPAN'),
    };
  });
  ok('the question in the sticky bar has a speaker', m.title);
  ok('the whole story (all its paragraphs) has ONE speaker, at the end of its last paragraph', m.storyParas >= 2 && m.story.length === 1 && m.story[0] === 1 && m.storyEnd[0] && m.storyOwn === 1, JSON.stringify(m));
  ok('the "why Claude is asking" line has a speaker', m.why.length === 1 && m.why[0]);
  ok('each of the 4 answer choices has a speaker', m.choices.length === 4 && m.choices.every(Boolean), JSON.stringify(m.choices));
  ok('the label "Pick one answer" has no speaker (it only names the choices)', m.heading.length >= 1 && m.heading.every((x) => !x));
  ok('one question = the title, the story, the why line and the 4 choices: 7 speakers, not a pile', m.all === 7, String(m.all));
  ok('no speaker on button labels, menu items, counters, chips, inputs or the quiet answer buttons', m.inButtons === 0 && m.inChips === 0 && m.qaExtraBtn === 0, JSON.stringify(m));
  ok('the speaker inside an answer choice is only a picture (aria-hidden span), never a second button in the button', m.inbtnHidden);
  ok('the button name is "Read this out loud"', m.labels.length === 1 && m.labels[0] === 'Read this out loud', JSON.stringify(m.labels));
  // size and touch area
  const sz = await E(p, () => {
    const b = document.querySelector('.qv-story .qt-speak');
    const r = b.getBoundingClientRect(), a = getComputedStyle(b, '::after');
    return { w: r.width, h: r.height, area: parseFloat(a.width), areaH: parseFloat(a.height), text: b.textContent, tag: b.tagName, type: b.type };
  });
  ok('a speaker is 28 px across on the screen', Math.abs(sz.w - 28) <= 1.5 && Math.abs(sz.h - 28) <= 1.5, `${sz.w}x${sz.h}`);
  ok('its touch area is 40 px (the ::after box)', sz.area >= 39.5 && sz.areaH >= 39.5, `${sz.area}x${sz.areaH}`);
  ok('a speaker is a real <button type=button> with no words inside (copying text does not copy it)', sz.tag === 'BUTTON' && sz.type === 'button' && sz.text === '');
  ok('nothing was spoken by itself', (await spoken(p)).length === 0);
  ok('no page errors so far', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 2. start, stop, switch, Esc, leave */
await H.block('reading', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  const story1 = await hostText(p, '.qv-story', 0), story2 = await hostText(p, '.qv-why p', 0);
  ok('the text of the story is exactly what is on the screen (both paragraphs, one after the other)', story1 === 'Right now the button is at the bottom of the home page. Many people never scroll that far.\nClaude can move it up, so it is the first thing people see after the main picture.', story1);
  const b1 = await clickSpeaker(p, '.qv-story', 0);
  await okSoon('a click on a speaker reads the whole story out loud, piece by piece (the first piece is the first paragraph)', () => spoken(p), (s) => s.length === 1 && s[0].text === story1.split('\n')[0], 3000);
  const restOfStory = await readAll(p, 1);
  ok('...and then the second paragraph, nothing more', restOfStory.length === 1 && restOfStory[0] === story1.split('\n')[1], JSON.stringify(restOfStory));
  await clickSpeaker(p, '.qv-story', 0);
  await okSoon('clicking it again after the end reads it again', () => spoken(p), (s) => s.length === 3, 3000);
  const s0 = (await spoken(p))[0];
  ok('it uses a private English voice, rate 0.95, volume 1, language en-US', s0.voice === 'Microsoft David - English (United States)' && s0.voiceLocal === true && s0.rate === 0.95 && s0.volume === 1 && s0.lang === 'en-US', JSON.stringify(s0));
  const st = await E(p, () => { const hst = document.querySelectorAll('.qv-story')[0], b = hst.querySelector('.qt-speak'); const cs = getComputedStyle(hst); return { cls: hst.classList.contains('qt-speaking'), label: b.getAttribute('aria-label'), state: b.dataset.state, speaking: window.QT.speak.speaking(), outline: cs.outlineStyle, ow: parseFloat(cs.outlineWidth), bg: cs.backgroundColor, n: document.querySelectorAll('.qt-speaking').length }; });
  ok('while reading: the words are highlighted, the speaker says "Stop reading", the page knows', st.cls && st.label === 'Stop reading' && st.state === 'speaking' && st.speaking && st.n === 1, JSON.stringify(st));
  ok('the highlight is not only a colour: a dashed outline of at least 2 px, and a soft background', st.outline === 'dashed' && st.ow >= 2 && st.bg !== 'rgba(0, 0, 0, 0)', JSON.stringify(st));
  await b1.click();
  await H.settle(p, 80);
  ok('click again = stop (the voice was cancelled, the highlight is gone, the name is back)', await E(p, () => !window.QT.speak.speaking() && window.__speech.cancels >= 1 && !document.querySelector('.qt-speaking') && document.querySelectorAll('.qv-story')[0].querySelector('.qt-speak').getAttribute('aria-label') === 'Read this out loud'));
  // switching: another speaker stops the first
  await clickSpeaker(p, '.qv-story', 0);
  await clickSpeaker(p, '.qv-why p', 0);
  await okSoon('click another speaker while one is reading: the first stops, the second reads', () => E(p, () => ({ n: document.querySelectorAll('.qt-speaking').length, who: (document.querySelector('.qt-speaking') || {}).textContent, last: window.__speech.spoken.slice(-1)[0].text })), (v) => v.n === 1 && v.who.startsWith('Why Claude is asking') && v.last === story2, 3000);
  ok('the first one stopped (its speaker is back to "Read this out loud")', await E(p, () => document.querySelectorAll('.qv-story')[0].querySelector('.qt-speak').getAttribute('aria-label') === 'Read this out loud'));
  // Esc
  await p.keyboard.press('Escape');
  await H.settle(p, 80);
  ok('Esc stops the reading', await E(p, () => !window.QT.speak.speaking() && !document.querySelector('.qt-speaking') && !window.__speech.speaking));
  const c0 = await E(p, () => window.__speech.cancels);
  await p.keyboard.press('Escape');
  ok('Esc when nothing is read does nothing (no extra cancel)', (await E(p, () => window.__speech.cancels)) === c0);
  // leaving the view
  await clickSpeaker(p, '.qv-story', 0);
  ok('reading again after a stop works', await speakingNow(p));
  await H.go(p, 'workers', {});
  ok('leaving the view stops the reading', await E(p, () => !window.QT.speak.speaking() && !document.querySelector('.qt-speaking')));
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  await E(p, () => window.dispatchEvent(new Event('pagehide')));
  ok('leaving the page (pagehide) stops the reading', await E(p, () => !window.QT.speak.speaking()));
  // a reading that ends by itself
  await clickSpeaker(p, '.qv-story', 0);
  await readAll(p, (await spoken(p)).length);
  await okSoon('a reading that ends by itself clears the highlight and the button', () => E(p, () => !window.QT.speak.speaking() && !document.querySelector('.qt-speaking') && document.querySelectorAll('.qt-speak[data-state="speaking"]').length === 0), (v) => v, 3000);
  // an error
  await clickSpeaker(p, '.qv-story', 0);
  await E(p, () => window.__speech.fail('synthesis-failed'));
  await okSoon('a voice error stops the reading and says so in a plain message', () => E(p, () => ({ s: window.QT.speak.speaking(), t: (document.querySelector('.toast') || {}).textContent || '' })), (v) => !v.s && /could not read that out loud/.test(v.t), 3000);
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 3. answer choices, keyboard */
await H.block('choices and keyboard', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qa-choice .qt-speak').length === 4, null, 6000);
  await H.clearWrites(p);
  const before = await E(p, () => [...document.querySelectorAll('.qa-choice')].map((b) => b.getAttribute('aria-checked')));
  // mouse click on the little speaker inside the choice
  const sp = p.locator('.qa-choice').nth(1).locator('.qt-speak');
  await sp.click();
  await H.settle(p, 100);
  const s = await readAll(p, 0);
  ok('a click on the speaker in a choice reads its label, then what happens when she picks it', s.join(' ') === 'Under the main picture. The button shows right after the main picture.', JSON.stringify(s));
  ok('and it does NOT pick that answer', (await E(p, () => [...document.querySelectorAll('.qa-choice')].map((b) => b.getAttribute('aria-checked')))).join() === before.join() && (await H.writes(p)).length === 0, JSON.stringify(await H.writes(p)));
  await sp.click();
  await H.settle(p, 80);
  ok('a second click on the same speaker starts again, a third stops', (await speakingNow(p)) && (await (async () => { await sp.click(); await H.settle(p, 80); return !(await speakingNow(p)); })()));
  // clicking elsewhere in the choice still picks it (the speaker took only its own corner)
  await p.locator('.qa-choice').nth(1).locator('.qa-lab').click();
  await H.settle(p, 200);
  ok('a click on the words of the choice still picks it', (await H.writes(p)).some((w) => /answers\//.test(w.path)), JSON.stringify(await H.writes(p)));
  // keyboard: Tab to a real speaker, Enter starts, Space stops
  await E(p, () => window.__speech.finish());
  const spk = p.locator('.qv-story .qt-speak').first();
  await spk.focus();
  await p.keyboard.press('Enter');
  await H.settle(p, 100);
  ok('keyboard: Enter on a focused speaker starts reading', await speakingNow(p));
  await p.keyboard.press('Space');
  await H.settle(p, 100);
  ok('keyboard: Space on it stops', !(await speakingNow(p)));
  const reach = await E(p, () => { const t = [...document.querySelectorAll('.qt-speak')].filter((e) => e.tagName === 'BUTTON'); return t.every((b) => b.tabIndex === 0); });
  ok('every real speaker can be reached with Tab', reach);
  // Alt+R reads the choice the keyboard is on
  await p.locator('.qa-choice').nth(2).focus();
  const from = (await spoken(p)).length;
  await p.keyboard.press('Alt+r');
  await H.settle(p, 100);
  const alt = await readAll(p, from);
  ok('keyboard: Alt+R reads the answer choice that has the focus', alt.join(' ') === 'Stay at the bottom. Nothing changes.', JSON.stringify(alt));
  await p.locator('.qa-choice').nth(2).focus();
  await p.keyboard.press('Alt+r');
  await H.settle(p, 100);
  await p.keyboard.press('Alt+r');
  ok('Alt+R again stops', !(await speakingNow(p)));
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 4. long text in pieces */
await H.block('long text', async () => {
  const p = await open();
  await H.go(p, 'question', { id: IDS.choiceLong });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  await okSoon('a long story (5 paragraphs, one speaker) starts with ONE short piece', () => spoken(p), (s) => s.length === 1 && s[0].text.length <= 175, 3000);
  for (let i = 0; i < 60; i++) { await finishOne(p); await sleep(120); if (!(await speakingNow(p))) break; }
  const all = await spoken(p);
  ok('it is read in several pieces, each short enough for the browser (<= 175 characters)', all.length >= 3 && all.every((x) => x.text.length <= 175), all.map((x) => x.text.length).join(','));
  const full = await hostText(p, '.qv-story', 0);
  const norm = (x) => x.replace(/\./g, '').replace(/\s+/g, ' ').trim();
  ok('together the pieces are the whole story (all 5 paragraphs), in order', norm(all.map((x) => x.text).join(' ')) === norm(full), all.map((x) => x.text).join(' ').slice(0, 120));
  // stop in the middle: nothing more is said
  await clickSpeaker(p, '.qv-story', 0);
  const k = (await spoken(p)).length;
  await clickSpeaker(p, '.qv-story', 0);
  await finishOne(p);
  await sleep(250);
  ok('stopping in the middle: the next piece is never started', (await spoken(p)).length === k && !(await speakingNow(p)));
  // a reading that never reports its end is not stuck for ever (the browser may lose "end")
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 5. the switch */
await H.block('switch', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  const sw = await E(p, () => { const b = document.querySelector('.topbar .qt-voice-btn'); return b ? { pressed: b.getAttribute('aria-pressed'), prev: b.previousElementSibling && b.previousElementSibling.className, label: b.getAttribute('aria-label'), title: b.title, cls: b.className, w: b.getBoundingClientRect().width, h: b.getBoundingClientRect().height } : null; });
  ok('the Voice switch is in the top bar, right after the sound button', !!sw && /sound-btn/.test(sw.prev), JSON.stringify(sw));
  ok('it is on by default and says what it does (name and tooltip)', sw.pressed === 'true' && /^Voice: on/.test(sw.label) && /Voice buttons: on/.test(sw.title) && sw.h >= 39.5 && /tgl/.test(sw.cls), JSON.stringify(sw));
  await clickSpeaker(p, '.qv-story', 0);
  await p.locator('.topbar .qt-voice-btn').click();
  await H.settle(p, 150);
  const off = await E(p, () => ({ n: document.querySelectorAll('.qt-speak').length, sp: window.QT.speak.speaking(), en: window.QT.speak.enabled(), ls: localStorage.getItem('qt.speak'), pressed: document.querySelector('.qt-voice-btn').getAttribute('aria-pressed'), cls: document.documentElement.classList.contains('qt-speak-off'), pad: getComputedStyle(document.querySelector('.qa-choice')).paddingRight }));
  ok('switch off: reading stops and every speaker is gone from the page', off.n === 0 && !off.sp && !off.en && off.pressed === 'false', JSON.stringify(off));
  ok('it is remembered (localStorage qt.speak = 0) and the choices have their old padding back', off.ls === '0' && off.cls && parseFloat(off.pad) <= 12, JSON.stringify(off));
  await H.go(p, 'workers', {});
  await H.go(p, 'question', { id: QID });
  await sleep(400);
  ok('while it is off, a new view gets no speakers', (await count(p, '.qt-speak')) === 0);
  await p.reload({ waitUntil: 'load' });
  await H.ready(p);
  await sleep(500);
  ok('after a reload it is still off (no speakers, switch says Voice: off)', (await count(p, '.qt-speak')) === 0 && (await E(p, () => document.querySelector('.qt-voice-btn').getAttribute('aria-pressed'))) === 'false');
  await p.locator('.topbar .qt-voice-btn').click();
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 5000);
  ok('switch on again: the speakers come back (once each)', await E(p, () => [...document.querySelectorAll('.qv-story')].every((e) => e.querySelectorAll('.qt-speak').length === 1) && document.querySelector('.qt-voice-btn').getAttribute('aria-pressed') === 'true'));
  ok('QT.speak.setEnabled works from code too', await E(p, () => { window.QT.speak.setEnabled(false); const a = document.querySelectorAll('.qt-speak').length === 0; window.QT.speak.setEnabled(true); return a; }));
  // wide: the words "Voice: on" show
  await p.setViewportSize({ width: 1366, height: 768 });
  await H.settle(p, 300);
  ok('on a wide window the switch shows the words "Voice: on" (same look as the Sound switch)', /Voice: on/.test(await E(p, () => document.querySelector('.qt-voice-btn').innerText)));
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 6. a browser without speech */
await H.block('no speech in this browser', async () => {
  for (const [name, mock] of [['no speechSynthesis', { none: true }], ['speechSynthesis throws when touched', { throws: true }], ['no SpeechSynthesisUtterance', { noUtter: true }]]) {
    const p = await open({ mock, wait: false });
    await H.go(p, 'question', { id: QID });
    await sleep(500);
    const m = await E(p, () => ({ sp: document.querySelectorAll('.qt-speak').length, sw: document.querySelectorAll('.qt-voice-btn').length, sup: window.QT.speak.supported(), st: window.QT.speak.status(), say: window.QT.speak.say('hello'), btn: (() => { const b = window.QT.speak.button('x'); return { hidden: b.hidden, tag: b.tagName }; })(), stop: window.QT.speak.stop(), ok: !!document.getElementById('qt-view') }));
    ok(`${name}: no speakers, no switch, nothing breaks`, m.sp === 0 && m.sw === 0 && !m.sup && m.st === 'unsupported' && m.say === false && m.btn.hidden && m.ok, JSON.stringify(m));
    ok(`${name}: no page errors`, p.__errs.length === 0, p.__errs.join(' | '));
    await p.context().close();
  }
  // speak() that throws
  const p = await open({ mock: { failSpeak: true } });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  await okSoon('speak() that throws: the reading ends with a plain message, the page goes on', () => E(p, () => ({ s: window.QT.speak.speaking(), t: (document.querySelector('.toast') || {}).textContent || '', view: !!document.querySelector('.qv-story') })), (v) => !v.s && /could not read that out loud/.test(v.t) && v.view, 3000);
  ok('speak() that throws: no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 7. PRIVATE VOICES ONLY */
await H.block('private voices', async () => {
  const GRACE = 'window.QT_SPEAK_GRACE = 500;';
  // local only
  let p = await open({ mock: { voices: VOICES.local }, init: GRACE });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  let s = await spoken(p);
  ok('local voices only: the speakers are there and the en-US local voice speaks (not the en-GB one)', s.length === 1 && s[0].voice === 'Microsoft David - English (United States)' && s[0].voiceLocal === true, JSON.stringify(s));
  await p.context().close();

  // mixed: only the good local ones are used
  p = await open({ mock: { voices: VOICES.mixed }, init: GRACE });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  s = await spoken(p);
  ok('mixed list: a private voice is used (localService true, no "Google" start, no "Online" in the name), the best English one (Samantha, not Alex, not the novelty voice)', s.length === 1 && s[0].voice === 'Samantha' && s[0].voiceLocal === true, JSON.stringify(s));
  const picked = await E(p, () => { const out = []; for (const x of window.__speech.spoken) out.push(x.voice); return out; });
  ok('never one of the cloud voices', picked.every((v) => !/^Google|Online|says it is remote|Pretender/.test(v)), picked.join(','));
  await p.context().close();

  // google only / online only / no flag / empty: no buttons, a greyed switch with the reason, nothing ever spoken
  for (const [name, list] of [['Google voices only', VOICES.googleOnly], ['Online (Natural) voices only', VOICES.onlineOnly], ['a voice with no localService flag', VOICES.noFlag], ['an empty voice list', []]]) {
    p = await open({ mock: { voices: list }, init: GRACE, wait: false });
    await H.go(p, 'question', { id: QID });
    await okSoon(`${name}: the Voice switch shows up greyed out (voice list known)`, () => E(p, () => { const b = document.querySelector('.qt-voice-btn'); return b ? b.getAttribute('aria-disabled') : null; }), (v) => v === 'true', 4000);
    await sleep(300);
    const m = await E(p, () => { const b = document.querySelector('.qt-voice-btn'); return { sp: document.querySelectorAll('.qt-speak').length, st: window.QT.speak.status(), sup: window.QT.speak.supported(), say: window.QT.speak.say('hello there'), title: b.title, label: b.getAttribute('aria-label'), pressed: b.getAttribute('aria-pressed'), spoken: window.__speech.spoken.length, calls: window.__speech.calls, pad: getComputedStyle(document.querySelector('.qa-choice')).paddingRight }; });
    ok(`${name}: no speaker buttons at all`, m.sp === 0 && m.st === 'none' && !m.sup, JSON.stringify(m));
    ok(`${name}: nothing is ever spoken (speak() was never called, say() says no)`, m.say === false && m.spoken === 0 && m.calls === 0, JSON.stringify(m));
    ok(`${name}: the switch says "Voice: off" and its tooltip gives the reason in one line`, m.pressed === 'false' && /This computer has no built-in voice/.test(m.title) && /internet/.test(m.title) && /^Voice: off/.test(m.label), m.title);
    await p.locator('.topbar .qt-voice-btn').click({ force: true });
    await okSoon(`${name}: clicking the greyed switch explains it in a message`, () => E(p, () => (document.querySelector('.toast') || {}).textContent || ''), (t) => /no built-in voice/.test(t), 3000);
    ok(`${name}: the answer choices keep their normal padding (no room kept for a speaker)`, parseFloat(m.pad) <= 12, m.pad);
    ok(`${name}: no page errors`, p.__errs.length === 0, p.__errs.join(' | '));
    await p.context().close();
  }

  // headless-like: the browser says at once "my list changed" and it is empty: that is final, no long wait (the switch is there from the start, greyed out)
  p = await open({ mock: { voices: [], eventAtStart: true }, init: 'window.QT_SPEAK_GRACE=20000;', wait: false });
  await okSoon('an empty list announced by the browser: the greyed switch is there at once (no 20 s grace)', () => E(p, () => { const b = document.querySelector('.qt-voice-btn'); return b ? b.getAttribute('aria-disabled') : null; }), (v) => v === 'true', 3000);
  ok('an empty list announced by the browser: no speakers', (await count(p, '.qt-speak')) === 0);
  await p.context().close();

  // late arrival: nothing flashes up before the list is here, the buttons come once (a sampler written into the page from the very start looks every 20 ms)
  const SAMPLER = 'window.__trace=[];setInterval(()=>{try{window.__trace.push([Math.round(performance.now()),document.querySelectorAll(".qt-speak").length,document.querySelectorAll(".qt-voice-btn").length]);}catch(e){}},20);window.QT_SPEAK_GRACE=8000;';
  p = await open({ mock: { voices: VOICES.local, late: 2500 }, init: SAMPLER, wait: false });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 12000);
  await sleep(1500);
  const tr = await E(p, () => ({ trace: window.__trace, at: window.__speech.arrivedAt }));
  const before = tr.trace.filter((r) => r[0] < tr.at - 20), after = tr.trace.filter((r) => r[0] > tr.at + 300);
  let dropped = false; { let seen = false; for (const r of tr.trace) { if (r[1] > 0) seen = true; else if (seen) dropped = true; } }
  ok(`late voice list: for ${before.length} looks before the list arrived there were no speakers and no switch (no flicker)`, before.length > 20 && before.every((r) => r[1] === 0 && r[2] === 0), JSON.stringify(before.filter((r) => r[1] || r[2]).slice(0, 3)));
  ok('late voice list: after it arrives the speakers appear, and they never vanish again', after.length > 5 && after.every((r) => r[1] > 3) && !dropped, JSON.stringify(after.slice(0, 3)));
  ok('late voice list: the switch is on and not greyed out', await E(p, () => { const b = document.querySelector('.qt-voice-btn'); return !!b && b.getAttribute('aria-pressed') === 'true' && !b.hasAttribute('aria-disabled'); }));
  await p.context().close();

  // late arrival with only cloud voices: the speakers NEVER show up
  p = await open({ mock: { voices: VOICES.googleOnly, late: 300 }, init: GRACE, wait: false });
  await H.go(p, 'question', { id: QID });
  const t2 = await E(p, () => new Promise((res) => { const t0 = performance.now(); let maxSp = 0; const tick = () => { maxSp = Math.max(maxSp, document.querySelectorAll('.qt-speak').length); if (performance.now() - t0 < 1500) setTimeout(tick, 25); else res({ maxSp, dis: (document.querySelector('.qt-voice-btn') || {}).ariaDisabled }); }; tick(); }));
  ok('late list with only cloud voices: speakers never appeared; the switch ends up greyed out', t2.maxSp === 0 && t2.dis === 'true', JSON.stringify(t2));
  // a private voice arrives later still (voiceschanged): the buttons come
  await E(p, () => window.__speech.setVoices([{ name: 'Microsoft David - English (United States)', lang: 'en-US', localService: true, default: true }]));
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 5000);
  ok('a private voice that arrives after the grace time brings the buttons and un-greys the switch', await E(p, () => document.querySelectorAll('.qt-speak').length > 3 && !document.querySelector('.qt-voice-btn').hasAttribute('aria-disabled')));
  // and the voices vanish again
  await clickSpeaker(p, '.qv-story', 0);
  await E(p, () => window.__speech.setVoices([]));
  await sleep(300);
  await okSoon('the private voice goes away: reading stops, buttons go, switch greys out', () => E(p, () => ({ n: document.querySelectorAll('.qt-speak').length, s: window.QT.speak.speaking(), d: document.querySelector('.qt-voice-btn').getAttribute('aria-disabled') })), (v) => v.n === 0 && !v.s && v.d === 'true', 4000);
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();

  // another language: the voice of that language (still private)
  p = await open({ init: GRACE });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await E(p, () => document.documentElement.setAttribute('lang', 'es'));
  await clickSpeaker(p, '.qv-story', 0);
  s = await spoken(p);
  ok('page language es: the private Spanish voice is used, language es-ES', s.length === 1 && /Helena/.test(s[0].voice || '') && s[0].lang === 'es-ES', JSON.stringify(s));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 8. text on screen */
await H.block('what is read', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await E(p, () => {
    const v = document.getElementById('qt-view');
    const box = document.createElement('div');
    box.id = 'probe';
    box.innerHTML = '<p id="p1">Hello   there, friend.  <span hidden>HIDDENATTR</span><span style="display:none">DISPLAYNONE</span><span style="visibility:hidden">VISHIDDEN</span><span class="sr">SRONLY</span>' +
      '<span aria-hidden="true">🚜</span> Plant🌽 the corn ✓ now.<br>Second line<svg width="10" height="10"><text>SVGTEXT</text></svg><img alt="IMGALT" src="data:image/gif;base64,R0lGODlhAQABAAAAACw="> done<textarea>TEXTAREA</textarea><button>BUTTONLABEL</button><span data-nospeak>NOSPEAKINNER</span> end</p>' +
      '<div id="d1" data-speak>Block <b>one</b> text here.<p>Inner paragraph kept in the block.</p><details><summary>Summary words</summary>CLOSEDDETAILS</details><span hidden>H2</span></div>' +
      '<p id="p2" data-nospeak>This paragraph is not for the voice.</p>' +
      '<p id="p3">Tall <span style="display:inline-block;width:1px;height:1px;overflow:hidden">TINYCLIP</span>box</p>';
    v.appendChild(box);
  });
  await sleep(400);
  const t1 = await E(p, () => window.QT.speak.textOf(document.getElementById('p1')));
  ok('only what is on the screen is read: no hidden, display:none, visibility:hidden, screen-reader-only, aria-hidden, svg, img, textarea, button or data-nospeak text; no emoji; no extra spaces', t1 === 'Hello there, friend. Plant the corn now.\nSecond line done end', JSON.stringify(t1));
  const t2 = await E(p, () => window.QT.speak.textOf(document.getElementById('d1')));
  ok('data-speak on a block: its visible text (nested paragraph included, closed details and hidden spans left out)', /Block one text here\.[\s\S]*Inner paragraph kept in the block\.[\s\S]*Summary words/.test(t2) && !/CLOSEDDETAILS|H2/.test(t2), JSON.stringify(t2));
  ok('data-speak puts ONE speaker next to the block, and none on the paragraph inside it', await E(p, () => document.getElementById('d1').querySelectorAll(':scope > .qt-speak').length === 1 && document.querySelectorAll('#d1 p .qt-speak').length === 0));
  ok('data-nospeak: no speaker', await E(p, () => document.getElementById('p2').querySelectorAll('.qt-speak').length === 0));
  ok('a 1 px clipped box inside a paragraph is not read', !/TINYCLIP/.test(await E(p, () => window.QT.speak.textOf(document.getElementById('p3')))));
  const from0 = (await spoken(p)).length;
  await clickSpeaker(p, '#probe #p1', 0);
  const said = (await readAll(p, from0)).join(' ');
  ok('what the voice is given is that same clean text', /^Hello there, friend\. Plant the corn now\. Second line done end\.$/.test(said) && !/HIDDEN|SRONLY|NOSPEAK|BUTTONLABEL|TEXTAREA/.test(said), said);
  await E(p, () => window.QT.speak.stop());
  // symbols
  const sym = await E(p, () => { const x = document.createElement('p'); x.textContent = 'Started 5 hours ago · last update 2 min ago → next & done ✓'; document.getElementById('probe').appendChild(x); return window.QT.speak.textOf(x); });
  ok('separator dots, arrows, ticks and "&" become plain words', sym === 'Started 5 hours ago, last update 2 min ago to next and done', JSON.stringify(sym));
  // closed fold-out content in a real view is not read, open is
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 9. dynamic content, no doubles */
await H.block('dynamic content and no doubles', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  const dupes = () => E(p, () => { const bad = []; for (const b of document.querySelectorAll('.qt-speak')) { const host = b.parentElement.classList.contains('qt-glue') ? b.parentElement.parentElement : b.parentElement; const n = host.querySelectorAll(':scope > .qt-speak, :scope > .qt-glue > .qt-speak').length; if (n > 1) bad.push(host.className); } return { bad, total: document.querySelectorAll('.qt-speak').length }; });
  const d0 = await dupes();
  await E(p, () => { for (let i = 0; i < 20; i++) window.QT.speak.refresh(); });
  const d1 = await dupes();
  ok('asking to look again 20 times makes no second button anywhere', d1.bad.length === 0 && d1.total === d0.total, JSON.stringify([d0, d1]));
  // new text arrives
  await E(p, () => { const x = document.createElement('p'); x.id = 'late1'; x.textContent = 'This paragraph was added a moment later.'; document.getElementById('qt-view').appendChild(x); });
  await until(p, () => document.querySelectorAll('#late1 .qt-speak').length === 1, null, 3000);
  ok('a paragraph added later gets its speaker (about 100 ms later)', (await count(p, '#late1 .qt-speak')) === 1);
  // text replaced: the speaker is made again, once
  await E(p, () => { document.getElementById('late1').textContent = 'Now the paragraph says something else.'; });
  await sleep(350);
  ok('when a view redraws a paragraph (textContent) the speaker comes back, exactly one', (await count(p, '#late1 .qt-speak')) === 1);
  // empty becomes filled
  await E(p, () => { const x = document.createElement('p'); x.id = 'late2'; document.getElementById('qt-view').appendChild(x); });
  await sleep(300);
  const none = await count(p, '#late2 .qt-speak');
  await E(p, () => { document.getElementById('late2').textContent = 'Words arrive in an empty paragraph.'; });
  await until(p, () => document.querySelectorAll('#late2 .qt-speak').length === 1, null, 3000);
  ok('an empty paragraph has no speaker; when words arrive it gets one', none === 0 && (await count(p, '#late2 .qt-speak')) === 1);
  // removed with its block
  await E(p, () => { document.getElementById('late1').remove(); });
  await sleep(300);
  ok('a block that is removed takes its speaker with it (no stray speakers)', await E(p, () => [...document.querySelectorAll('.qt-speak')].every((b) => b.parentElement && b.isConnected) && document.querySelectorAll('#late1').length === 0));
  // data-speak added to anything, later
  await E(p, () => { const x = document.createElement('div'); x.id = 'opt1'; x.setAttribute('data-speak', ''); x.textContent = 'Anything with this mark gets a voice.'; document.getElementById('qt-view').appendChild(x); });
  await until(p, () => document.querySelectorAll('#opt1 .qt-speak').length === 1, null, 3000);
  ok('data-speak on any element added later: a speaker', (await count(p, '#opt1 .qt-speak')) === 1);
  // the question view redraws because Claude changed something: still one speaker each
  await H.put(p, 'status/' + QID, { id: QID, state: 'working', note: 'Moving the button', at: new Date().toISOString() });
  await H.put(p, 'questions/' + QID, Object.assign({}, await H.get(p, 'questions/' + QID), { why: 'A new reason that Claude just wrote for this question.' }));
  await sleep(700);
  const d2 = await dupes();
  ok('after Claude changes the question live: still no doubles and the new line has its speaker', d2.bad.length === 0 && (await E(p, () => [...document.querySelectorAll('.qv-why p')].some((e) => /A new reason/.test(e.textContent) && e.querySelectorAll('.qt-speak').length === 1))), JSON.stringify(d2));
  // reading goes on when the same words are drawn again; stops when they are gone
  await clickSpeaker(p, '.qv-story', 0);
  const k0 = (await spoken(p)).length;
  await H.put(p, 'status/' + QID, { id: QID, state: 'working', note: 'Still moving the button', at: new Date().toISOString() });
  await sleep(600);
  const keep = await E(p, () => ({ s: window.QT.speak.speaking(), mark: document.querySelectorAll('.qt-speaking').length }));
  ok('a live update that draws the same words again does not cut the reading off (and the highlight follows the new copy)', keep.s && keep.mark === 1, JSON.stringify(keep));
  const q = await H.get(p, 'questions/' + QID);
  await H.put(p, 'questions/' + QID, Object.assign({}, q, { story: [q.story[0], 'A different second paragraph.'] }));
  await okSoon('when the words being read are gone from the page the reading stops', () => E(p, () => ({ s: window.QT.speak.speaking(), mark: document.querySelectorAll('.qt-speaking').length })), (v) => !v.s && v.mark === 0, 4000);
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 10. 300 paragraphs */
await H.block('speed', async () => {
  const p = await open();
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  const t = await E(p, async () => {
    const box = document.createElement('div'); box.id = 'many';
    for (let i = 0; i < 300; i++) { const x = document.createElement('p'); x.textContent = 'Paragraph number ' + i + '. The crew planted the corn rows early today and it looks like a good year for the farm.'; box.appendChild(x); }
    document.getElementById('qt-view').appendChild(box);
    const t0 = performance.now();
    window.QT.speak.refresh();
    const scan = performance.now() - t0;
    return { scan, n: box.querySelectorAll(':scope > p .qt-speak').length, doubles: [...box.querySelectorAll('p')].filter((x) => x.querySelectorAll('.qt-speak').length !== 1).length };
  });
  ok(`300 paragraphs: all get exactly one speaker (${t.n}), the look-through takes ${Math.round(t.scan)} ms`, t.n === 300 && t.doubles === 0 && t.scan < ms(600), JSON.stringify(t));
  const t3 = await E(p, async () => {
    const t0 = performance.now(); const x = document.createElement('div'); x.id = 'many2';
    for (let i = 0; i < 300; i++) { const y = document.createElement('p'); y.textContent = 'Second batch ' + i + ': the tractor is parked by the red barn for the night.'; x.appendChild(y); }
    document.getElementById('qt-view').appendChild(x);
    await new Promise((r) => setTimeout(r, 260));
    return { done: x.querySelectorAll(':scope > p .qt-speak').length, t: performance.now() - t0 };
  });
  ok(`300 more paragraphs added at once are done by the page's own timer (${t3.done} of 300 after ${Math.round(t3.t)} ms)`, t3.done === 300 || t3.t > 0 && (await until(p, () => document.querySelectorAll('#many2 > p .qt-speak').length === 300, null, 3000)), JSON.stringify(t3));
  const t4 = await E(p, () => { const b = document.querySelectorAll('#many > p')[299].querySelector('.qt-speak'); const t0 = performance.now(); b.click(); return performance.now() - t0; });
  ok(`clicking the last of 300 starts the reading at once (${Math.round(t4)} ms)`, t4 < ms(150));
  await E(p, () => window.QT.speak.stop());
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 11. Workers and Tasks */
await H.block('workers and tasks', async () => {
  const p = await open({ w: 1366, h: 900 });
  await H.go(p, 'workers', {});
  await until(p, () => document.querySelectorAll('.wk-id .qt-speak').length > 3, null, 6000);
  const w = await E(p, () => {
    const card = document.querySelector('.wk-card[data-wid="map-a"]') || document.querySelector('.wk-card:not(.is-lead)');
    const metaSp = document.querySelectorAll('.wk-line .qt-speak, .wk-times .qt-speak, .wk-bw .qt-speak, .tiny .qt-speak, .wk-when .qt-speak, .wk-me .qt-speak').length;
    const perCard = [...document.querySelectorAll('.wk-card')].map((c) => c.querySelectorAll('.wk-id .qt-speak, .wk-now .qt-speak, .wk-result .qt-speak, .wk-head .qt-speak').length);
    return { role: !!card.querySelector('.wk-id .qt-speak'), now: !!card.querySelector('.wk-now .qt-speak'), name: !!card.querySelector('.wk-name .qt-speak'), btns: card.querySelectorAll('.wk-id .qt-speak, .wk-now .qt-speak, .wk-result .qt-speak, .wk-head .qt-speak').length, helpSp: !!document.querySelector('.wk-help h2 .qt-speak'), title: !!document.querySelector('h1 .qt-speak'), metaSp, maxPerCard: Math.max(...perCard) };
  });
  ok('a worker card has ONE speaker (at the end of the job line); none at "Right now"', w.role && !w.now && !w.name && w.btns === 1 && w.maxPerCard <= 1, JSON.stringify(w));
  ok('no speaker on time or meta lines ("Started 5 hours ago", "You asked 40 min ago") and none on her own words', w.metaSp === 0, JSON.stringify(w));
  ok('the Workers title and the "How to read this" card have one', w.title && w.helpSp);
  const card = '.wk-card[data-wid="map-a"]';
  const nameTxt = await E(p, (c) => document.querySelector(c + ' .wk-name').textContent.trim(), card);
  const from1 = (await spoken(p)).length;
  const nowTxt = await E(p, (c) => { const n = document.querySelector(c + ' .wk-now'); return n ? n.textContent.replace(/^\s*Right now:\s*/, '').trim() : ''; }, card);
  await p.locator(card + ' .wk-id .qt-speak').click();
  await H.settle(p, 100);
  const s1 = (await readAll(p, from1)).join(' ');
  ok('the speaker at the job line reads the worker name, then the job, then what the worker does right now', s1.startsWith(nameTxt) && s1.length > nameTxt.length + 10 && (!nowTxt || s1.includes(nowTxt.slice(0, 20))), s1);
  const from2 = (await spoken(p)).length;
  await p.locator('.wk-help h2 .qt-speak').click();
  await H.settle(p, 100);
  const s2 = (await readAll(p, from2)).join(' ');
  ok('the "How to read this" speaker reads the whole card (starts with the heading, then the words, not the buttons)', /^How to read this\. Claude is the boss of a farm crew/.test(s2) && !/Got it/.test(s2), s2);
  await E(p, () => window.QT.speak.stop());
  // Tasks
  await H.go(p, 'tasks', {});
  await E(p, () => localStorage.setItem('qt.tasks.howto', 'open'));
  await until(p, () => document.querySelectorAll('.tk-card .tk-title .qt-speak').length > 2, null, 6000);
  const t = await E(p, () => {
    const tree = document.querySelector('[role=tree]');
    const sp = [...tree.querySelectorAll('.qt-speak')];
    return { n: sp.length, allMinus: sp.every((b) => b.tabIndex === -1), howSp: !!document.querySelector('.tk-how h2 .qt-speak'), howInner: document.querySelectorAll('.tk-how li .qt-speak, .tk-how p .qt-speak').length, title: !!document.querySelector('h1 .qt-speak') };
  });
  ok('Tasks: a speaker at the page title and at the "How to read this" heading (not on each line), one at each task title', t.n > 2 && t.howSp && t.howInner === 0 && t.title, JSON.stringify(t));
  ok('inside the task tree the speakers are not extra tab stops (the tree keeps its single tab stop; Alt+R reads the task you are on)', t.allMinus);
  const first = await E(p, () => { const li = document.querySelector('[role=tree] > li'); const title = li.querySelector(':scope > .tk-card .tk-title'); const plain = li.querySelector(':scope > .tk-card .tk-plain'); return { title: title.textContent.trim(), plain: plain ? plain.textContent.trim().slice(0, 30) : '', sel: li.getAttribute('aria-selected'), exp: li.getAttribute('aria-expanded'), id: li.dataset.id }; });
  const from3 = (await spoken(p)).length;
  await p.locator('[role=tree] > li').first().locator(':scope > .tk-card .tk-title .qt-speak').click();
  await H.settle(p, 150);
  const after = await E(p, () => { const li = document.querySelector('[role=tree] > li'); return { sel: li.getAttribute('aria-selected'), exp: li.getAttribute('aria-expanded') }; });
  const s3 = (await readAll(p, from3)).join(' ');
  ok('a task speaker reads the title, then the plain words', s3.includes(first.title) && (!first.plain || s3.includes(first.plain.slice(0, 20))), s3.slice(0, 160));
  ok('clicking it does not select or open the task', after.sel === first.sel && after.exp === first.exp, JSON.stringify([first, after]));
  await E(p, () => window.QT.speak.stop());
  // Alt+R on the focused tree item
  await p.locator('[role=tree] > li').first().focus();
  const from4 = (await spoken(p)).length;
  await p.keyboard.press('Alt+r');
  await H.settle(p, 150);
  const s4 = (await readAll(p, from4)).join(' ');
  ok('Alt+R on a focused task reads that task (not the ones below it)', s4.includes(first.title), s4.slice(0, 160));
  await E(p, () => window.QT.speak.stop());
  // Enter on a speaker must not open the task
  await p.locator('[role=tree] > li').first().locator(':scope > .tk-card .tk-title .qt-speak').focus();
  await p.keyboard.press('Enter');
  await H.settle(p, 150);
  const after2 = await E(p, () => { const li = document.querySelector('[role=tree] > li'); return { exp: li.getAttribute('aria-expanded'), sel: li.getAttribute('aria-selected') }; });
  ok('Enter on a task speaker reads; it does not open or select the task', (await speakingNow(p)) && after2.exp === first.exp && after2.sel === first.sel, JSON.stringify(after2));
  ok('no page errors', p.__errs.length === 0, p.__errs.join(' | '));
  await p.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 11b. one speaker per block, glued to the last word */
await H.block('one speaker per block', async () => {
  const LONELY = () => {
    // a speaker that stands alone on a line: its middle is not on the same line as the words just before it
    const bad = [];
    for (const b of document.querySelectorAll('#qt-main .qt-speak')) {
      if (b.classList.contains('qt-inbtn') || b.classList.contains('qt-qbar') || b.classList.contains('qt-after')) continue;
      const r = b.getBoundingClientRect();
      if (!r.width) continue;
      const glue = b.parentElement && b.parentElement.classList.contains('qt-glue') ? b.parentElement : null;
      if (glue && glue.getClientRects().length !== 1) { bad.push('glue broken over two lines: ' + glue.textContent); continue; }
      let prev = glue ? glue.previousSibling : b.previousSibling, host = glue ? glue.parentElement : b.parentElement;
      if (((host.textContent || '').trim().split(/\s+/).pop() || '').length > 24) continue;      // a web address or a made-up long word cannot be glued (it would not fit a narrow line)
      if (glue && glue.textContent.length > 0) {                       // the last word sits inside the box: it must be on the speaker's line
        const rg = document.createRange(); rg.selectNodeContents(glue.firstChild); const rr = [...rg.getClientRects()].pop();
        if (rr && Math.abs((rr.top + rr.height / 2) - (r.top + r.height / 2)) > 16) bad.push('word and speaker on two lines: ' + glue.textContent);
        continue;
      }
      while (prev && prev.nodeType === 3 && !/\S/.test(prev.nodeValue)) prev = prev.previousSibling;
      if (!prev) continue;                                               // nothing before it in the block
      const rg = document.createRange(); rg.selectNodeContents(prev);
      const rr = [...rg.getClientRects()].pop();
      if (rr && Math.abs((rr.top + rr.height / 2) - (r.top + r.height / 2)) > 16) bad.push('alone on a line: ' + (host.className || host.tagName) + ' / ' + (host.textContent || '').slice(0, 30));
    }
    return bad;
  };
  const META_SP = '.tiny .qt-speak, .wk-line .qt-speak, .wk-times .qt-speak, .wk-bw .qt-speak, .wk-when .qt-speak, .item-sub .qt-speak, .sf-when .qt-speak, .tk-meta .qt-speak, .sx-progline .qt-speak, .qt-note .qt-speak, .hint .qt-speak, .small.muted .qt-speak, .muted.small .qt-speak';
  const VIEWS = [
    ['question', { id: QID }], ['question', { id: IDS.choiceLong }], ['question', { id: IDS.visual }], ['question', { id: IDS.safety }], ['question', { id: IDS.done }],
    ['home', {}], ['section', { id: 'look' }], ['workers', {}], ['tasks', {}],
  ];
  for (const w of [700, 400]) {
    const p = await open({ w, h: 800 });
    const spk = {};
    for (const [view, params] of VIEWS) {
      await H.go(p, view, params);
      await until(p, () => document.querySelectorAll('#qt-view .qt-speak').length > 0, null, 6000);
      await sleep(300);
      const name = view + (params.id ? ':' + params.id : '');
      const m = await E(p, ([META, lonelySrc]) => ({ n: document.querySelectorAll('#qt-main .qt-speak').length, meta: document.querySelectorAll(META).length, lonely: eval('(' + lonelySrc + ')')() }), [META_SP, LONELY.toString()]);
      spk[name] = m.n;
      ok(`[${w}] ${name}: no speaker on time or meta lines`, m.meta === 0, String(m.meta));
      ok(`[${w}] ${name}: no speaker stands alone on a line (each is glued to the last word of its block)`, m.lonely.length === 0, m.lonely.slice(0, 3).join(' | '));
    }
    ok(`[${w}] a story of 5 paragraphs has one speaker, not five`, await (async () => { await H.go(p, 'question', { id: IDS.choiceLong }); await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length > 0, null, 6000); return E(p, () => document.querySelectorAll('.qv-story p').length === 5 && document.querySelectorAll('.qv-story .qt-speak').length === 1 && document.querySelectorAll('.qv-story p .qt-speak').length === 1); })());
    ok(`[${w}] the safety card has ONE speaker (not one per note, check or fact)`, await (async () => { await H.go(p, 'question', { id: IDS.safety }); await until(p, () => document.querySelectorAll('.sf .qt-speak').length > 0, null, 6000); return E(p, () => document.querySelectorAll('.sf .qt-speak').length === 1); })());
    ok(`[${w}] a question never has more than 8 speakers (the title, the story, the why line, 4 choices, the safety card)`, Math.max(...Object.entries(spk).filter(([k]) => k.startsWith('question')).map(([, v]) => v)) <= 8, JSON.stringify(spk));
    ok(`[${w}] home and a section page have a handful, not a pile`, spk.home <= 5 && spk['section:look'] <= 4, JSON.stringify(spk));
    await H.go(p, 'question', { id: QID });
    await until(p, () => document.querySelectorAll('.qbar .qt-speak, .qbar-main .qt-speak').length > 0, null, 6000);
    const q = await E(p, () => { const bar = document.querySelector('.qbar'), b = bar.querySelector('.qt-qbar'), rb = bar.getBoundingClientRect(), r = b.getBoundingClientRect(), t = document.querySelector('.qbar-title').getBoundingClientRect(); return { inside: r.top >= rb.top - 1 && r.bottom <= rb.bottom + 1 && r.right <= rb.right + 1 && r.left >= rb.left, overTitle: r.left < t.right - 1 && r.right > t.left + 1 && r.top < t.bottom && r.bottom > t.top && getComputedStyle(document.querySelector('.qbar-title')).paddingRight === '0px' }; });
    ok(`[${w}] the speaker of the sticky question bar stays inside the bar and does not cover the title`, q.inside && !q.overTitle, JSON.stringify(q));
    await p.context().close();
  }
});

/* ------------------------------------------------------------------------------------------------------------------------ 12. fit and look */
await H.block('fit and look', async () => {
  const VIEWS = [
    { name: 'q-choice', view: 'question', params: { id: QID }, key: true },
    { name: 'q-visual', view: 'question', params: { id: IDS.visual }, key: true },
    { name: 'q-choice-long', view: 'question', params: { id: IDS.choiceLong } },
    { name: 'home', view: 'home', params: {} },
    { name: 'workers', view: 'workers', params: {} },
    { name: 'tasks', view: 'tasks', params: {} },
  ];
  for (const [w, hh] of [[700, 800], [1366, 768], [1920, 1080], [400, 800]]) {
    const p = await open({ w, h: hh });
    for (const v of VIEWS) {
      await H.go(p, v.view, v.params);
      await until(p, () => document.querySelectorAll('#qt-view .qt-speak').length > 0, null, 6000);
      await sleep(250);
      await E(p, () => window.scrollTo(0, 0));
      const m = await p.evaluate(measure);
      const tag = `[${w}x${hh}] ${v.name}`;
      ok(`${tag}: no sideways scroll, nothing wider than the window`, m.docW <= m.vw + 1 && m.wide.length === 0, `doc ${m.docW} ${m.wide.slice(0, 2).join(' | ')}`);
      const mine = [...m.overlap, ...m.clipped, ...m.cut].filter((x) => /qt-speak|qt-voice|Read this out loud|Voice (on|off)/.test(x));
      const others = [...m.overlap, ...m.clipped, ...m.cut].filter((x) => !mine.includes(x));
      ok(`${tag}: speakers cause no overlap, clipped or cut text`, mine.length === 0, mine.slice(0, 3).join(' | '));
      if (others.length) info(`${tag}: (not from the speakers, the page already had these) ${others.slice(0, 2).join(' | ').slice(0, 200)}`);
      if (v.key && w === 700 && hh === 800) ok(`KEY ${tag}: still NO vertical page scroll at 700x800 with the speakers (page ${m.docH}, window ${m.vh})`, m.docH <= m.vh + 1, `${m.docH - m.vh} px too tall`);
      const small = await E(p, () => [...document.querySelectorAll('#qt-view .qt-speak')].filter((b) => { const r = b.getBoundingClientRect(); return r.width && (r.width < 27 || r.height < 27); }).length);
      ok(`${tag}: every visible speaker is at least 28 px`, small === 0);
      await p.screenshot({ path: `${H.SHOTS}/voice/fit-${v.name}-${w}x${hh}.png` }).catch(() => {});
    }
    await p.context().close();
  }
});

await H.block('dark, reduced motion, outline', async () => {
  const p = await open({ scheme: 'dark' });
  await H.go(p, 'question', { id: QID });
  await until(p, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p, '.qv-story', 0);
  const m = await p.evaluate(measure);
  ok('dark theme, one text being read: text contrast stays fine (>= 4.5)', m.contrast.length === 0, JSON.stringify(m.contrast.slice(0, 3)));
  const c = await E(p, () => { const hst = document.querySelectorAll('.qv-story')[0], cs = getComputedStyle(hst), b = hst.querySelector('.qt-speak'), bs = getComputedStyle(b); return { bg: cs.backgroundColor, ink: cs.color, outline: cs.outlineStyle + ' ' + cs.outlineColor, btnBg: bs.backgroundColor, btnInk: bs.color }; });
  const lum = (s) => { const [r, g, b] = s.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  ok(`dark: words on the highlight are readable (ratio ${ratio(c.bg, c.ink).toFixed(1)}), the speaking button icon on its fill too (${ratio(c.btnBg, c.btnInk).toFixed(1)})`, ratio(c.bg, c.ink) >= 4.5 && ratio(c.btnBg, c.btnInk) >= 3, JSON.stringify(c));
  await p.context().close();

  const p2 = await open({ reduced: true });
  await H.go(p2, 'question', { id: QID });
  await until(p2, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p2, '.qv-story', 0);
  const r = await E(p2, () => { const b = document.querySelector('.qt-speak[data-state="speaking"]'); const bf = getComputedStyle(b, '::before'); return { anim: bf.animationName, content: bf.content, tr: getComputedStyle(b).transitionDuration, hl: getComputedStyle(document.querySelector('.qt-speaking')).transitionDuration }; });
  ok('reduced motion: the speaking ring does not animate and nothing eases', (r.anim === 'none' || r.content === 'none') && r.tr.split(',').every((x) => parseFloat(x) < 0.01) && r.hl.split(',').every((x) => parseFloat(x) < 0.01), JSON.stringify(r));
  await p2.context().close();
  const p3 = await open({});
  await H.go(p3, 'question', { id: QID });
  await until(p3, () => document.querySelectorAll('.qv-story .qt-speak').length >= 1, null, 6000);
  await clickSpeaker(p3, '.qv-story', 0);
  const r3 = await E(p3, () => { const b = document.querySelector('.qt-speak[data-state="speaking"]'); const bf = getComputedStyle(b, '::before'); return { anim: bf.animationName }; });
  ok('with motion allowed the speaking button has a calm pulsing ring', r3.anim === 'qt-sp-ring', JSON.stringify(r3));
  await p3.context().close();
  // the data-theme attribute beats the colour scheme of the computer
  const p4 = await open({ scheme: 'light' });
  await E(p4, () => document.documentElement.setAttribute('data-theme', 'dark'));
  const hl = await E(p4, () => getComputedStyle(document.documentElement).getPropertyValue('--sp-hl').trim());
  ok('data-theme="dark" gives the dark highlight colour', hl === '#4d3f12', hl);
  await p4.context().close();
});

/* ------------------------------------------------------------------------------------------------------------------------ 13. axe */
await H.block('axe', async () => {
  if (!AXE) { info('axe-core not found (set AXE_PATH): axe checks skipped'); return; }
  for (const scheme of ['light', 'dark']) {
    const p = await open({ scheme });
    for (const [name, view, params, speak] of [['question', 'question', { id: QID }, '.qv-story'], ['visual question', 'question', { id: IDS.visual }, '.qv-why p'], ['workers', 'workers', {}, '.wk-id'], ['tasks', 'tasks', {}, '.tk-lead']]) {
      await H.go(p, view, params);
      await until(p, () => document.querySelectorAll('#qt-view .qt-speak').length > 0, null, 6000);
      await sleep(300);
      for (const reading of [false, true]) {
        if (reading) { await clickSpeaker(p, speak, 0).catch(() => {}); }
        if (!(await E(p, () => !!window.axe))) await p.evaluate(AXE);
        const viol = await p.evaluate(async () => {
          const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] }, resultTypes: ['violations'], rules: { 'html-has-lang': { enabled: false } } });
          return r.violations.map((v) => ({ id: v.id, count: v.nodes.length, mine: v.nodes.filter((n) => /qt-speak|qt-voice|qt-speaking/.test(n.html) || n.target.join(' ').includes('qt-speak')).length, sample: v.nodes.slice(0, 2).map((n) => n.target.join(' ') + ' ' + n.html.slice(0, 80)) }));
        });
        const mine = viol.filter((v) => v.mine > 0);
        ok(`[${scheme}] ${name}${reading ? ' (one text being read)' : ''}: axe finds nothing wrong with the speakers or the Voice switch`, mine.length === 0, JSON.stringify(mine));
        if (viol.length && !mine.length) info(`[${scheme}] ${name}: axe also lists ${viol.map((v) => v.id + ' x' + v.count).join(', ')} (not from the speakers)`);
        if (reading) await E(p, () => window.QT.speak.stop());
      }
    }
    await p.context().close();
  }
});

await H.stop(h);
