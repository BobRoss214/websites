/* Test stand-in for the layout, used ONLY by the Workers tests (not part of the page that is published).
   It reads window.__WK__ (the fixture, set by the test before the page starts), fills QT.store directly when the real core does not know the
   new collections yet, gives QT.write.ask a small stand-in when core has none, and mounts QT.views.workers into a ".view" box. */
(function () {
  var QT = window.QT;
  var F = window.__WK__ || {};
  var NEW = ['workers', 'tasks', 'taskAdds', 'replies', 'asks'];
  window.__wkStub = { fixtureInStore: false, askStub: false };
  function fill() {
    NEW.forEach(function (c) {
      QT.store[c] = QT.store[c] || {};
      if (F[c] && !Object.keys(QT.store[c]).length) { Object.keys(F[c]).forEach(function (k) { QT.store[c][k] = JSON.parse(JSON.stringify(F[c][k])); }); window.__wkStub.fixtureInStore = true; }
    });
  }
  fill();
  QT.write = QT.write || {};
  if (typeof QT.write.ask !== 'function') {
    window.__wkStub.askStub = true;
    window.__asked = [];
    QT.write.ask = function (o) {
      if (QT.offline) return Promise.reject(Object.assign(new Error('offline'), { code: 'offline' }));
      if (window.__failAsk) { window.__failAsk--; return Promise.reject(Object.assign(new Error('x'), { code: 'unavailable' })); }
      var id = 'u-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
      var doc = { id: id, targetKind: o.targetKind, targetId: o.targetId, text: o.text, createdAt: new Date().toISOString() };
      window.__asked.push(doc);
      QT.store.asks[id] = doc;
      QT.emit('store', { collection: 'asks', ids: [id], initial: false });
      return Promise.resolve(id);
    };
  }
  window.__wk = {
    set: function (coll, id, doc) { QT.store[coll] = QT.store[coll] || {}; QT.store[coll][id] = doc; QT.emit('store', { collection: coll, ids: [id], initial: false }); },
    del: function (coll, id) { if (QT.store[coll]) delete QT.store[coll][id]; QT.emit('store', { collection: coll, ids: [id], initial: false }); }
  };
  QT.layout = QT.layout || {};
  QT.layout.mount = function (app) {
    fill();
    var q = new URLSearchParams(location.search);
    app.textContent = '';
    var main = document.createElement('main'); main.id = 'qt-main'; main.setAttribute('tabindex', '-1');
    var view = document.createElement('div'); view.className = 'view'; view.id = 'qt-view';
    if (q.get('full')) { view.style.maxWidth = 'none'; }
    main.appendChild(view); app.appendChild(main);
    window.__wkCleanup = QT.views.workers(view, q.get('focus') ? { focus: q.get('focus') } : {});
    window.__wkMounted = true;
  };
})();
