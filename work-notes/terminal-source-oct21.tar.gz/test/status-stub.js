/* Test stub for the status helper: a tiny fake of 00-core.js (events, store, fmt, route, write.meta). NOT part of the page. */
(function () {
  var QT = window.QT = window.QT || {};
  var ls = {};
  QT.on = function (e, f) { (ls[e] = ls[e] || []).push(f); };
  QT.off = function (e, f) { ls[e] = (ls[e] || []).filter(function (x) { return x !== f; }); };
  QT.emit = function (e, d) { (ls[e] || []).slice().forEach(function (f) { f(d); }); };
  QT.listenerCount = function (e) { return (ls[e] || []).length; };
  QT.offline = false;
  QT.store = { sections: {}, questions: {}, answers: {}, status: {}, ideas: {}, ideaStatus: {}, plans: {}, planReplies: {}, meta: {}, workers: {}, tasks: {}, replies: {}, taskAdds: {}, taskEdits: {}, asks: {} };
  var resolveReady; QT.ready = new Promise(function (r) { resolveReady = r; });
  QT.fmt = {
    ago: function (iso) { var m = Math.floor((Date.now() - Date.parse(iso)) / 60000); if (m < 1) return 'just now'; if (m < 60) return m + ' min ago'; var h = Math.floor(m / 60); if (h < 24) return h + (h === 1 ? ' hour ago' : ' hours ago'); var d = Math.floor(h / 24); return d + (d === 1 ? ' day ago' : ' days ago'); },
    time: function (iso) { return new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }); }
  };
  QT.route = { current: { view: 'home', params: {} }, go: function (v, p) { QT.route.current = { view: v, params: p || {} }; QT.emit('route', { view: v, params: p || {} }); } };
  window.__metaWrites = [];
  QT.write = { meta: function (id, obj) { window.__metaWrites.push([id, obj]); QT.store.meta[id] = Object.assign({ id: id }, QT.store.meta[id], obj); return Promise.resolve(); } };

  /* load the first snapshot: docs = { collection: { id: doc } }.  Emits an "initial" store event per collection, then QT.ready. */
  window.__load = function (docs) {
    Object.keys(docs || {}).forEach(function (c) { QT.store[c] = Object.assign(QT.store[c] || {}, docs[c]); });
    Object.keys(QT.store).forEach(function (c) { QT.emit('store', { collection: c, ids: Object.keys(QT.store[c]), initial: true }); });
    resolveReady();
    return QT.ready;
  };
  /* a slow notebook: QT.ready comes first, a collection's first snapshot arrives later */
  window.__readyOnly = function () { resolveReady(); return QT.ready; };
  window.__initial = function (c, docs) { QT.store[c] = Object.assign(QT.store[c] || {}, docs); QT.emit('store', { collection: c, ids: Object.keys(docs), initial: true }); };
  window.__put = function (c, id, doc) { QT.store[c][id] = doc; QT.emit('store', { collection: c, ids: [id], initial: false }); };
  window.__del = function (c, id) { delete QT.store[c][id]; QT.emit('store', { collection: c, ids: [id], initial: false }); };
  window.__iso = function (msAgo) { return new Date(Date.now() - msAgo).toISOString(); };
})();
