/* Runs every T/test/*.test.mjs (one after the other, each in its own process) and prints a table.
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/run-all.mjs [filter] [--build] [--show-fails] [--verbose]
 *     filter        only files whose name contains the text (e.g. "fit" or "flow")
 *     --build       run python3 T/build.py first
 *     --show-fails  print the FAIL lines of every test under the table (default: first 12 per test)
 *     --verbose     print everything the tests print
 *     --src         test a fresh build of T/src (python3 build.py --out <snapshot>) instead of T/dist/index.html (dist is never touched)
 *     --list        only list the test files that would run
 *     --skip a,b    leave out files whose name contains a or b (e.g. --skip zoom,sandbox)
 *   Groups by name: `parts` = parts.test + parts.e2e.test (tab strip, QT.parts), `workers`, `tasks`; the other helpers' new test files are picked up by name automatically (every *.test.mjs).
 * Exit code 0 only when every test file passed (SKIPPED counts as not failed).
 */
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const T = path.resolve(dir, '..');
const args = process.argv.slice(2);
const flags = new Set(args.filter((a) => a.startsWith('--')));
const skipArg = args.indexOf('--skip') >= 0 ? (args[args.indexOf('--skip') + 1] || '') : '';
const skips = skipArg.split(',').filter(Boolean);
const filter = args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--skip');

if (flags.has('--build')) {
  try { execFileSync('python3', [path.join(T, 'build.py')], { cwd: T, stdio: 'inherit' }); } catch (e) { console.log('build.py failed'); process.exit(2); }
}
const files = fs.readdirSync(dir).filter((f) => f.endsWith('.test.mjs') && (!filter || f.includes(filter)) && !skips.some((x) => f.includes(x))).sort();
if (flags.has('--list')) { console.log(files.join('\n')); process.exit(0); }
if (!files.length) { console.log('No test files found' + (filter ? ' for "' + filter + '"' : '')); process.exit(2); }

const env = Object.assign({}, process.env, { NODE_PATH: process.env.NODE_PATH || '/opt/node22/lib/node_modules', QT_NOBUILD: '1', PLAYWRIGHT_BROWSERS_PATH: process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers', AXE_PATH: process.env.AXE_PATH || '/tmp/claude-0/axe-core/axe.min.js' });
delete env.WA_URL;
if (flags.has('--src')) env.QT_FROM_SRC = '1';

function runOne(file) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const p = spawn(process.execPath, [path.join(dir, file)], { cwd: T, env });
    let out = '';
    const timer = setTimeout(() => { out += '\nFAIL test timed out after 9 minutes\n'; p.kill('SIGKILL'); }, 9 * 60 * 1000);
    p.stdout.on('data', (d) => { out += d; if (flags.has('--verbose')) process.stdout.write(d); });
    p.stderr.on('data', (d) => { out += d; if (flags.has('--verbose')) process.stderr.write(d); });
    p.on('close', (code) => {
      clearTimeout(timer);
      const lines = out.split('\n');
      const pass = lines.filter((l) => l.startsWith('PASS ')).length;
      const failLines = lines.filter((l) => l.startsWith('FAIL '));
      const skipped = lines.some((l) => l.startsWith('SKIP '));
      resolve({ file, code, pass, fail: failLines.length, failLines, skipped, secs: Math.round((Date.now() - t0) / 100) / 10, out });
    });
  });
}

const results = [];
for (const f of files) {
  process.stdout.write(`running ${f} ... `);
  let r = await runOne(f);
  // another helper may be running the same test on the same port right now: wait and try again (up to 4 times)
  for (let i = 0; i < 4 && r.code && !r.pass && /EADDRINUSE/.test(r.out); i++) { process.stdout.write('(port busy, waiting) '); await new Promise((x) => setTimeout(x, 10000)); r = await runOne(f); }
  results.push(r); console.log(r.skipped ? 'skipped' : r.fail || r.code ? 'FAILED' : 'ok');
}

console.log('\n' + 'test file'.padEnd(26) + 'result'.padEnd(10) + 'passed'.padStart(8) + 'failed'.padStart(8) + 'seconds'.padStart(9));
console.log('-'.repeat(61));
for (const r of results) console.log(r.file.padEnd(26) + (r.skipped ? 'SKIPPED' : r.fail || r.code ? 'FAILED' : 'ok').padEnd(10) + String(r.pass).padStart(8) + String(r.fail).padStart(8) + String(r.secs).padStart(9));
const tp = results.reduce((a, r) => a + r.pass, 0), tf = results.reduce((a, r) => a + r.fail, 0);
console.log('-'.repeat(61));
console.log('total'.padEnd(36) + String(tp).padStart(8) + String(tf).padStart(8));

for (const r of results.filter((r) => r.fail || (r.code && !r.skipped))) {
  const max = flags.has('--show-fails') ? 1e9 : 12;
  console.log(`\n--- ${r.file}: ${r.fail} failed${r.code && !r.fail ? ' (exit code ' + r.code + ', no FAIL line: the test crashed)' : ''}`);
  for (const l of r.failLines.slice(0, max)) console.log('  ' + l.slice(0, 400));
  if (r.failLines.length > max) console.log(`  ... and ${r.failLines.length - max} more (run with --show-fails)`);
  if (r.code && !r.fail) console.log(r.out.split('\n').slice(-12).join('\n'));
}
const bad = results.some((r) => (r.fail || r.code) && !r.skipped);
console.log(bad ? '\nSOME TESTS FAILED' : '\nALL TEST FILES PASSED');
process.exit(bad ? 1 : 0);
