/* Picture chooser test (SPEC3 F4).   NODE_PATH=/opt/node22/lib/node_modules AXE_PATH=/tmp/claude-0/axe-core/axe.min.js node T/test/chooser.test.mjs      Ports 9405+.
 * Builds the page from T/src into its own snapshot (QT_PAGE=dist-visual3/index.html tests that file instead). Made-up photos: test/chooser.fixture.mjs.
 * Screenshots: T/shots/chooser/*.png (look at them!).
 */
import fs from 'node:fs';
import path from 'node:path';
import * as H from './harness.mjs';
import { ok, info, ms } from './harness.mjs';
import { chooserDocs, shareCard, holidayStrip, manyPhotos, gallery, photo } from './chooser.fixture.mjs';

const SHOTDIR = path.join(H.SHOTS, 'chooser');
fs.mkdirSync(SHOTDIR, { recursive: true });
const AXE = H.axeSource();
const h = await H.start(9405, { src: true });
const DOCS = chooserDocs();
const sleep = H.sleep;

/* ---------- little helpers ---------- */
async function openQ(qid, o = {}) {
  const page = await H.open(h, { docs: o.docs || DOCS, w: o.w || 700, h: o.h || 800, scheme: o.scheme, reduced: o.reduced, label: o.label || (qid + ': '), init: o.init, mock: o.mock });
  page.setDefaultTimeout(ms(30000));
  if (o.go !== false) await showQ(page, qid);
  return page;
}
async function showQ(page, qid) {
  await H.go(page, 'question', { id: qid });
  await page.waitForSelector('.chs', { state: 'attached' });
  await H.settle(page, 250);
}
const st = (page) => page.evaluate(() => {
  const slots = {};
  document.querySelectorAll('.chs-slot').forEach((b) => { slots[b.dataset.slot] = b.getAttribute('data-gid') || ''; });
  const q = (s) => document.querySelector(s);
  const tab = q('.chs-tab.is-on');
  return {
    slots, pressed: [...document.querySelectorAll('.chs-thumb[aria-pressed="true"]')].map((b) => b.dataset.gid),
    commitDisabled: q('.chs-commit').disabled, commitText: q('.chs-commit').textContent.trim(), msg: (q('.chs-msg') || {}).textContent || '', status: (q('.chs-status') || {}).textContent || '',
    undo: !q('.chs-undo').hidden, next: !q('.chs-next').hidden, cur: tab ? tab.dataset.tab : '', start: !q('.chs-start').disabled,
  };
});
const tap = async (page, gid) => {
  await page.evaluate((g) => { const b = document.querySelector(`.chs-thumb[data-gid="${g}"]`); if (b) b.scrollIntoView({ block: 'center' }); }, gid);
  await page.click(`.chs-thumb[data-gid="${gid}"]`);
  await H.settle(page, 80);
};
const writesTo = async (page, p) => (await H.writes(page)).filter((w) => w.path === p);
const commit = async (page) => { await page.evaluate(() => document.querySelector('.chs-commit').scrollIntoView({ block: 'nearest' })); await page.click('.chs-commit'); await H.settle(page, 200); };
const rectOf = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, r: r.right, b: r.bottom }; }, sel);
const noSideScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1 && document.body.scrollWidth <= window.innerWidth + 1);
const shot = (page, name) => page.screenshot({ path: path.join(SHOTDIR, name + '.png') }).catch(() => {});
async function axeRun(page) {
  if (!AXE) return [];
  if (!(await page.evaluate(() => !!window.axe))) await page.evaluate(AXE);
  return page.evaluate(async () => {
    const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] }, resultTypes: ['violations'], rules: { 'html-has-lang': { enabled: false }, 'document-title': { enabled: true } } });
    return r.violations.map((v) => ({ id: v.id, impact: v.impact, count: v.nodes.length, nodes: v.nodes.slice(0, 3).map((n) => n.target.join(' ') + ' <' + n.html.slice(0, 70) + '> ' + (n.failureSummary || '').split('\n').slice(1, 3).join(' ').slice(0, 200)) }));
  });
}
const axeText = (v) => v.map((x) => `${x.id} (${x.impact}, ${x.count}x) ${x.nodes.slice(0, 2).join(' ## ')}`).join(' || ').slice(0, 900);
const lastWrite = async (page, p) => { const w = await writesTo(page, p); return w[w.length - 1]; };

/* ===================================================================== 1. the pure parts: parse and clamp */
await H.block('1 parse and clamp', async () => {
  const page = await openQ('ch-card', { label: 'parse: ' });
  const r = await page.evaluate(() => {
    const C = window.QT.chooser, out = {};
    out.api = typeof C.render === 'function' && typeof C.parse === 'function' && typeof C.clampOverlay === 'function';
    out.clamped = C.clampOverlay({ x: -5, y: 200, w: 150, h: 2, rotate: 99, frame: 'gold' });
    out.fallback = C.clampOverlay({ x: 'a', y: NaN, w: null }, { x: 10, y: 20, w: 30, h: 40, rotate: 5, frame: 'yellow' });
    out.inside = C.clampOverlay({ x: 95, y: 95, w: 50, h: 50, rotate: -50, frame: 'white' });
    const good = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg"/>');
    const long = Array.from({ length: 70 }, (_, i) => ({ id: 'g' + i, url: good, alt: 'a' + i }));
    const p1 = C.parse({ id: 'x', chooser: { slots: [{ id: 'Bad Id!', label: ' ' }, { id: 'ok', label: 'Two' }, { id: 'ok', label: 'dup' }, { id: 'c' }, { id: 'd' }, { id: 'e' }], gallery: long } });
    out.slotIds = p1.slots.map((s) => s.id); out.slotLabels = p1.slots.map((s) => s.label); out.gal = p1.gallery.length;
    const p2 = C.parse({ id: 'x', chooser: { gallery: [{ id: 'a', url: 'javascript:alert(1)' }, { id: 'b', url: 'http://example.com/a.png' }, { id: 'c', url: 'data:text/html,<script>1</script>' }, { id: 'd', url: '//evil.example/x.png' }, { id: 'e', url: 'https://example.com/ok.png', alt: 'A tree' }, { id: 'f', url: '/_blob/0123456789abcdef0123456789abcdef' }, { id: 'g', url: '/_blob/nothex' }, { id: 'h', url: good, people: 'yes' }, { id: 'i', url: good, people: true }, { id: '', url: good }, { url: good }] } });
    out.safe = p2.gallery.map((g) => g.id); out.people = p2.gallery.map((g) => g.people); out.label = p2.gallery[0].label; out.oneSlot = p2.slots.map((s) => s.id);
    out.baseBad = C.parse({ id: 'x', chooser: { preview: { base: { url: 'javascript:1' } } } }).base;
    out.note = [C.parse({ id: 'x' }).peopleNote, C.parse({ id: 'x', peopleNote: 'Ask first.' }).peopleNote];
    out.noChooser = (() => { try { return C.parse({ id: 'x' }).slots.length; } catch (e) { return 'threw'; } })();
    out.defaults = [1, 2, 3, 4].map((n) => { const p = C.parse({ id: 'x', chooser: { slots: Array.from({ length: n }, (_, i) => ({ id: 's' + i })), preview: { base: { url: good, w: 1200, h: 630 } } } }); return Object.values(p.overlays).every((o) => o.x >= 0 && o.y >= 0 && o.x + o.w <= 100.001 && o.y + o.h <= 100.001 && o.w >= 4 && o.h >= 4); });
    out.ratio = C.parse({ id: 'x', chooser: { preview: { base: { url: good, w: 1200, h: 600 } } } }).ratio;
    out.ratioNone = C.parse({ id: 'x', chooser: {} }).ratio;
    return out;
  });
  ok('QT.chooser has render, parse and clampOverlay', r.api);
  ok('clampOverlay keeps size 4..100, position inside the picture, turn within 45 degrees, unknown frame becomes none', r.clamped.w === 100 && r.clamped.h === 4 && r.clamped.x === 0 && r.clamped.y === 96 && r.clamped.rotate === 45 && r.clamped.frame === 'none', JSON.stringify(r.clamped));
  ok('clampOverlay uses the fallback for words, NaN and null', r.fallback.x === 10 && r.fallback.y === 20 && r.fallback.w === 30 && r.fallback.h === 40 && r.fallback.frame === 'yellow', JSON.stringify(r.fallback));
  ok('a box pushed over the edge is pulled back inside (x 95 w 50 -> x 50)', r.inside.x === 50 && r.inside.y === 50 && r.inside.rotate === -45, JSON.stringify(r.inside));
  ok('at most 4 places; a bad or repeated id gets a safe one or is dropped; an empty label becomes "Place 1"', r.slotIds.length === 4 && r.slotIds[0] === 's1' && r.slotIds[1] === 'ok' && r.slotLabels[0] === 'Place 1', JSON.stringify([r.slotIds, r.slotLabels]));
  ok('at most 60 photos', r.gal === 60, String(r.gal));
  ok('unsafe picture addresses are dropped (javascript:, http:, data:text/html, //host, /_blob/ without a real id, no id); https, data:image and /_blob/<32 hex> stay', r.safe.join() === 'e,f,h,i', r.safe.join());
  ok('"people" counts only when it is exactly true; the label falls back to the alt text', r.people.join() === 'false,false,false,true' && r.label === 'A tree', r.people.join() + ' / ' + r.label);
  ok('no places given: one place called "photo"', r.oneSlot.join() === 'photo', r.oneSlot.join());
  ok('an unsafe base picture is left out; no chooser data at all is fine', r.baseBad === null && r.noChooser === 1, JSON.stringify([r.baseBad, r.noChooser]));
  ok('the people note has a friendly default and can come from the question', /have not said yes to photos with people/.test(r.note[0]) && r.note[1] === 'Ask first.', JSON.stringify(r.note));
  ok('places without an overlay get a default that sits inside the picture (1 to 4 places)', r.defaults.every(Boolean), r.defaults.join());
  ok('the preview ratio comes from the base size (1200 x 600 = 2) or is 16:9 without a base', r.ratio === 2 && Math.abs(r.ratioNone - 16 / 9) < 0.001, `${r.ratio} ${r.ratioNone}`);
  await page.context().close();
});

/* ===================================================================== 2. share card: one place */
await H.block('2 share card (1 place)', async () => {
  const page = await openQ('ch-card', { label: 'card: ' });
  const s0 = await st(page);
  const info0 = await page.evaluate(() => ({
    base: (() => { const i = document.querySelector('.chs-base'); return !!i && i.complete && i.naturalWidth > 0; })(), thumbs: document.querySelectorAll('.chs-thumb').length, tabs: document.querySelectorAll('.chs-tab').length,
    empty: (document.querySelector('.chs-slot .chs-pick') || {}).textContent || '', kind: document.querySelector('.qv-grid').className, ans: !!document.querySelector('.qv-answer .qa'), h1: (document.querySelector('.qbar') || {}).textContent || '',
  }));
  ok('the question draws the chooser (kind "chooser"): the drawing, 12 photos, no tabs for one place', info0.base && info0.thumbs === 12 && info0.tabs === 0 && /is-chooser/.test(info0.kind), JSON.stringify(info0));
  ok('the empty place says "Pick a photo"', /Pick a photo/.test(info0.empty), info0.empty);
  ok('nothing chosen: the big button is off and says what is missing; "Start over" is off', s0.commitDisabled && /Pick a photo for the last place first/.test(s0.msg) && !s0.start, JSON.stringify(s0));
  await tap(page, 'p3');
  const s1 = await st(page);
  ok('tap a photo: it is in the preview at once; its thumbnail is pressed; the big button turns on', s1.slots.corner === 'p3' && s1.pressed.join() === 'p3' && !s1.commitDisabled, JSON.stringify(s1));
  ok('the thumbnail shows a check mark badge', await page.evaluate(() => /✓/.test(document.querySelector('.chs-thumb[data-gid="p3"] .chs-badge').textContent)));
  ok('nothing is saved yet (preview before committing)', (await H.writes(page)).length === 0, JSON.stringify(await H.writes(page)));
  await tap(page, 'p5');
  const s2 = await st(page);
  ok('tap another photo: it replaces the first one (one place, one photo)', s2.slots.corner === 'p5' && s2.pressed.join() === 'p5', JSON.stringify(s2));
  await tap(page, 'p5');
  const s3 = await st(page);
  ok('tap it again: it is taken out and the place is empty again', s3.slots.corner === '' && s3.pressed.length === 0 && s3.commitDisabled, JSON.stringify(s3));
  await tap(page, 'p2');
  await shot(page, 'card-700-picked-before-save');
  await commit(page);
  await H.settle(page, 250);
  const w1 = await writesTo(page, 'answers/ch-card');
  const d1 = w1[w1.length - 1] && w1[w1.length - 1].data;
  ok('commit writes ONE answer: key picks, label, picks and pickLabels, round, time', w1.length === 1 && w1[0].op === 'set' && d1.status === 'answered' && d1.key === 'picks' && d1.label === 'My picture choice' && d1.picks.corner === 'p2' && d1.pickLabels.corner === 'Pumpkin pile' && d1.round === 1 && !isNaN(Date.parse(d1.answeredAt)), JSON.stringify(w1));
  ok('only the places that have a photo are in picks (no extra keys)', Object.keys(d1.picks).join() === 'corner' && Object.keys(d1.pickLabels).join() === 'corner', JSON.stringify(d1));
  const s4 = await st(page);
  ok('after commit: "Saved ✓", Undo and Next question are there; the big button rests', /Saved ✓/.test(s4.msg) && s4.undo && s4.next && s4.commitDisabled, JSON.stringify(s4));
  await H.okSoon('the "Saved ✓" mark takes the place of the pale big button once the message has gone', () => page.evaluate(() => ({ commitHidden: document.querySelector('.chs-commit').hidden, tag: !document.querySelector('.chs-savedtag').hidden })), (x) => x.commitHidden && x.tag, 15000);
  ok('"Start over" has a border like a button; Undo is red and underlined like the Undo of the other questions', await page.evaluate(() => { const a = getComputedStyle(document.querySelector('.chs-start')), u = getComputedStyle(document.querySelector('.chs-undo')); return parseFloat(a.borderTopWidth) >= 2 && a.borderTopColor !== 'rgba(0, 0, 0, 0)' && /underline/.test(u.textDecorationLine) && u.color !== a.color; }));
  ok('Claude is told about the new answer', (await H.pings(page)).length >= 1, JSON.stringify(await H.pings(page)));
  ok('no write overlapped another', (await H.overlaps(page)).length === 0);
  // answer again: replaces it
  await tap(page, 'p4');
  const s5 = await st(page);
  ok('picking another photo after saving: the big button turns on again and says you changed something', !s5.commitDisabled && /changed something/.test(s5.msg), JSON.stringify(s5));
  await commit(page);
  await H.settle(page, 250);
  const w2 = await writesTo(page, 'answers/ch-card');
  ok('answering again replaces the answer (a second set, picks p4)', w2.length === 2 && w2[1].op === 'set' && w2[1].data.picks.corner === 'p4' && w2[1].data.pickLabels.corner === 'Sheep on the hill', JSON.stringify(w2.map((w) => w.data && w.data.picks)));
  // undo goes back to the earlier saved choice; the new pick stays on the screen as a try-out
  await page.click('.chs-undo');
  await H.settle(page, 300);
  const w3 = await writesTo(page, 'answers/ch-card');
  const s6 = await st(page);
  ok('Undo writes the earlier answer back (p2) and the picks on screen stay as an unsaved try-out (p4)', w3.length === 3 && w3[2].data.picks.corner === 'p2' && s6.slots.corner === 'p4' && !s6.commitDisabled && /Back to your earlier saved choice/.test(s6.msg), JSON.stringify([w3[2] && w3[2].data.picks, s6]));
  ok('the Undo button goes away after it is used', !s6.undo);
  await H.okSoon('a changed choice tells Claude again (the next ping goes out after the 20 s gap between automatic pings; checked last because the Undo button only stays 8 s)', () => H.pings(page), (p) => p.length >= 2, 40000);
  await page.context().close();
});

/* ---------- Undo with nothing saved before = the answer is removed ---------- */
await H.block('2b undo removes the first answer', async () => {
  const page = await openQ('ch-card', { label: 'undo: ' });
  await tap(page, 'p7');
  await commit(page);
  ok('saved once', (await writesTo(page, 'answers/ch-card')).length === 1);
  await page.click('.chs-undo');
  await H.settle(page, 300);
  const w = await writesTo(page, 'answers/ch-card');
  const s = await st(page);
  ok('Undo with nothing saved before deletes the answer', w.length === 2 && w[1].op === 'delete', JSON.stringify(w.map((x) => x.op)));
  ok('her pick is still on the screen, not saved, the big button is on', s.slots.corner === 'p7' && !s.commitDisabled && /Your picks are still here/.test(s.msg), JSON.stringify(s));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 3. holiday strip: two places */
await H.block('3 holiday strip (2 places)', async () => {
  const page = await openQ('ch-strip', { label: 'strip: ' });
  const t0 = await page.evaluate(() => ({ tabs: [...document.querySelectorAll('.chs-tab')].map((t) => t.dataset.tab + ':' + t.getAttribute('aria-selected') + ':' + t.getAttribute('role')), list: (document.querySelector('.chs-tabs') || {}).getAttribute && document.querySelector('.chs-tabs').getAttribute('role'), picks: [...document.querySelectorAll('.chs-slot .chs-pick')].map((p) => p.textContent.replace(/\s+/g, ' ').trim()) }));
  ok('two tabs (Left side, Right side) in a tablist; the first is selected', t0.tabs.join() === 'left:true:tab,right:false:tab' && t0.list === 'tablist', JSON.stringify(t0));
  ok('both empty places say "Pick a photo" and their own name', t0.picks.length === 2 && /Pick a photo/.test(t0.picks[0]) && /Left side/.test(t0.picks[0]) && /Right side/.test(t0.picks[1]), JSON.stringify(t0.picks));
  await tap(page, 'p1');
  let s = await st(page);
  ok('first tap goes to the left place and the right place becomes the one being chosen', s.slots.left === 'p1' && s.slots.right === '' && s.cur === 'right' && /Choosing for: Right side/.test(s.status), JSON.stringify(s));
  ok('the thumbnail shows which place it is in ("Left side")', await page.evaluate(() => /Left side/.test(document.querySelector('.chs-thumb[data-gid="p1"] .chs-badge').textContent)));
  ok('with one place still empty the big button stays off and says so', s.commitDisabled && /last place/.test(s.msg), JSON.stringify(s));
  await tap(page, 'p6');
  s = await st(page);
  ok('second tap goes to the right place; now the big button is on', s.slots.left === 'p1' && s.slots.right === 'p6' && !s.commitDisabled, JSON.stringify(s));
  // a photo sits in one place only: choosing the left one for the right place moves it
  await page.click('.chs-tab[data-tab="right"]');
  await tap(page, 'p1');
  s = await st(page);
  ok('a photo is in one place only: tapping the left photo for the right place MOVES it (left becomes empty and is next)', s.slots.right === 'p1' && s.slots.left === '' && s.cur === 'left' && s.commitDisabled, JSON.stringify(s));
  await tap(page, 'p8');
  s = await st(page);
  ok('the empty left place takes the next tap', s.slots.left === 'p8' && s.slots.right === 'p1' && !s.commitDisabled, JSON.stringify(s));
  // a click on the picture's place chooses that place
  await page.click('.chs-slot[data-slot="right"]');
  s = await st(page);
  ok('clicking a place in the preview selects it', s.cur === 'right', JSON.stringify(s));
  await page.click('.chs-slot[data-slot="left"]');
  await tap(page, 'p8');
  s = await st(page);
  ok('tapping the photo that is already in the chosen place takes it out', s.slots.left === '' && s.slots.right === 'p1', JSON.stringify(s));
  await tap(page, 'p8');
  await shot(page, 'strip-700-both-picked');
  await commit(page);
  const d = (await lastWrite(page, 'answers/ch-strip')).data;
  ok('commit writes both places with their labels', d.key === 'picks' && d.picks.left === 'p8' && d.picks.right === 'p1' && d.pickLabels.left === 'Hay wagon' && d.pickLabels.right === 'Red barn', JSON.stringify(d));
  // tab keys
  await page.focus('.chs-tab[data-tab="left"]');
  await page.keyboard.press('ArrowRight');
  s = await st(page);
  ok('the tabs use the arrow keys (Right selects the next place and moves the focus)', s.cur === 'right' && await page.evaluate(() => document.activeElement.dataset.tab === 'right'), JSON.stringify(s));
  await page.keyboard.press('Home');
  ok('Home goes to the first tab', (await st(page)).cur === 'left');
  ok('the selected tab is the only tab stop of the tab list', await page.evaluate(() => [...document.querySelectorAll('.chs-tab')].filter((t) => t.tabIndex === 0).length === 1));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 4. preview math */
await H.block('4 preview math', async () => {
  const wild = { id: 'ch-wild', sectionId: 'look', kind: 'chooser', order: 50, title: 'Wild overlays', story: [], chooser: {
    slots: [{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }, { id: 'c', label: 'C' }, { id: 'd', label: 'D' }],
    gallery: gallery(6), preview: { base: { url: photo('barn', 2), w: 800, h: 600 }, overlays: [{ slot: 'a', x: 95, y: 95, w: 50, h: 50 }, { slot: 'b', x: -20, y: -20, w: 5, h: 5, rotate: 400 }, { slot: 'c', x: 'x', y: null, w: 'wide' }, { slot: 'nope', x: 1, y: 1, w: 10, h: 10 }, { slot: 'd', x: 10, y: 10, w: 1000, h: 1000, frame: 'gold' }] } } };
  const docs = chooserDocs({ 'questions/ch-wild': wild });
  const page = await openQ('ch-card', { docs, w: 1366, h: 900, label: 'math: ' });
  const g = await page.evaluate(() => {
    const stage = document.querySelector('.chs-stage'), slot = document.querySelector('.chs-slot'), m = new DOMMatrix(getComputedStyle(slot).transform);
    return { sw: stage.clientWidth, sh: stage.clientHeight, x: slot.offsetLeft, y: slot.offsetTop, w: slot.offsetWidth, h: slot.offsetHeight, rot: Math.round(Math.atan2(m.b, m.a) * 180 / Math.PI * 100) / 100, cls: slot.className, ratio: stage.clientWidth / stage.clientHeight };
  });
  const near = (a, b, tol = 1.5) => Math.abs(a - b) <= tol;
  ok('the share card: the preview keeps the picture shape (1200 x 630)', near(g.ratio, 1200 / 630, 0.03), String(g.ratio));
  ok('the corner photo sits at x 63%, y 50%, 31% wide, 42% high of the picture', near(g.x / g.sw * 100, 63, 0.5) && near(g.y / g.sh * 100, 50, 0.5) && near(g.w / g.sw * 100, 31, 0.5) && near(g.h / g.sh * 100, 42, 0.5), JSON.stringify(g));
  ok('it is turned -3 degrees and has the white frame', near(g.rot, -3, 0.1) && /f-white/.test(g.cls), `${g.rot} ${g.cls}`);
  await showQ(page, 'ch-strip');
  const s = await page.evaluate(() => [...document.querySelectorAll('.chs-slot')].map((b) => ({ id: b.dataset.slot, cls: b.className, x: b.offsetLeft, w: b.offsetWidth, sw: b.parentElement.clientWidth })));
  ok('the strip: left photo at 2%, right photo at 77%, each 21% wide', near(s[0].x / s[0].sw * 100, 2, 0.5) && near(s[1].x / s[1].sw * 100, 77, 0.5) && near(s[0].w / s[0].sw * 100, 21, 0.5), JSON.stringify(s));
  ok('left has a white frame, right a yellow one', /f-white/.test(s[0].cls) && /f-yellow/.test(s[1].cls), s.map((x) => x.cls).join(' | '));
  await showQ(page, 'ch-wild');
  const w = await page.evaluate(() => { const stage = document.querySelector('.chs-stage'); return [...document.querySelectorAll('.chs-slot')].map((b) => ({ id: b.dataset.slot, x: b.offsetLeft, y: b.offsetTop, w: b.offsetWidth, h: b.offsetHeight, sw: stage.clientWidth, sh: stage.clientHeight, rot: Math.round(Math.atan2(new DOMMatrix(getComputedStyle(b).transform).b, new DOMMatrix(getComputedStyle(b).transform).a) * 180 / Math.PI), f: b.className })); });
  ok('wild overlays are pulled inside the picture (4 places, none sticks out)', w.length === 4 && w.every((b) => b.x >= -0.5 && b.y >= -0.5 && b.x + b.w <= b.sw + 0.5 && b.y + b.h <= b.sh + 0.5), JSON.stringify(w));
  ok('a turn of 400 degrees becomes 45; a tiny box is at least 4%; an unknown frame gets the default white one; an overlay for an unknown place is ignored', w[1].rot === 45 && w[1].w / w[1].sw * 100 >= 3.9 && /f-white/.test(w[3].f) && w.length === 4, JSON.stringify(w));
  await showQ(page, 'ch-many');
  const plain = await page.evaluate(() => { const s = document.querySelector('.chs-slot'); return { n: document.querySelectorAll('.chs-slot').length, ok: s.offsetLeft >= 0 && s.offsetLeft + s.offsetWidth <= s.parentElement.clientWidth + 1, ratio: (document.querySelector('.chs-stage').clientWidth / document.querySelector('.chs-stage').clientHeight) }; });
  ok('a place with no overlay in the question gets a default spot inside the picture', plain.n === 1 && plain.ok, JSON.stringify(plain));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 5. many photos */
await H.block('5 many photos', async () => {
  const page = await openQ('ch-card', { label: 'many: ' });
  const t = await page.evaluate(async () => {
    const t0 = performance.now();
    window.QT.route.go('question', { id: 'ch-many' });
    await new Promise((r) => { const f = () => (document.querySelectorAll('.chs-thumb').length === 60 ? r() : requestAnimationFrame(f)); f(); });
    return Math.round(performance.now() - t0);
  });
  ok(`60 photos are drawn in ${t} ms (limit ${ms(1500)})`, t < ms(1500), String(t));
  const g = await page.evaluate(() => {
    const th = [...document.querySelectorAll('.chs-thumb')], r0 = th[0].getBoundingClientRect();
    const row = th.filter((b) => Math.abs(b.getBoundingClientRect().top - r0.top) < 4).length;
    const gal = document.querySelector('.chs-gal'), cs = getComputedStyle(gal), grid = document.querySelector('.chs-grid');
    return { n: th.length, row, w: Math.round(r0.width), lazy: [...document.querySelectorAll('.chs-img')].filter((i) => i.loading === 'lazy').length, galOverflow: cs.overflowY, galScroll: gal.scrollHeight - gal.clientHeight, gridOverflow: getComputedStyle(grid).overflowY, pageScroll: document.documentElement.scrollHeight > innerHeight + 400, label: document.querySelector('.chs-count').textContent };
  });
  ok('700 x 800: 4 thumbnails per row, each at least 88 px wide', g.row >= 3 && g.row <= 4 && g.w >= 88, JSON.stringify(g));
  ok('the gallery scrolls with the page (no little scroll box of its own)', g.galOverflow === 'visible' && g.gridOverflow === 'visible' && g.galScroll <= 1 && g.pageScroll, JSON.stringify(g));
  ok('the photos after the first 12 load lazily; "60 photos" is said', g.lazy >= 40 && /60 photos/.test(g.label), JSON.stringify(g));
  // 70 in the data -> 60 on the page
  const big = chooserDocs({ 'questions/ch-70': manyPhotos(70, { id: 'ch-70' }) });
  const p2 = await openQ('ch-70', { docs: big, label: 'seventy: ' });
  ok('70 photos in the question: only 60 are drawn', (await p2.evaluate(() => document.querySelectorAll('.chs-thumb').length)) === 60);
  await p2.context().close();
  // a tap is fast with 60 photos
  const dt = await page.evaluate(async () => {
    const b = document.querySelector('.chs-thumb[data-gid="p33"]'); b.scrollIntoView({ block: 'center' });
    const t0 = performance.now(); b.click(); await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    return { ms: Math.round(performance.now() - t0), placed: document.querySelector('.chs-slot').getAttribute('data-gid') };
  });
  ok(`a tap shows in the preview in ${dt.ms} ms (limit ${ms(300)})`, dt.placed === 'p33' && dt.ms < ms(300), JSON.stringify(dt));
  // wide window: 3 per row beside the preview; a phone: 2 per row
  await page.setViewportSize({ width: 1366, height: 768 }); await H.settle(page, 250);
  const w1366 = await page.evaluate(() => { const th = [...document.querySelectorAll('.chs-thumb')], r0 = th[0].getBoundingClientRect(); return { row: th.filter((b) => Math.abs(b.getBoundingClientRect().top - r0.top) < 4).length, w: Math.round(r0.width) }; });
  ok('1366 x 768: 3 per row, wide enough', w1366.row >= 3 && w1366.w >= 88, JSON.stringify(w1366));
  await page.setViewportSize({ width: 390, height: 844 }); await H.settle(page, 250);
  const w390 = await page.evaluate(() => { const th = [...document.querySelectorAll('.chs-thumb')], r0 = th[0].getBoundingClientRect(); return { row: th.filter((b) => Math.abs(b.getBoundingClientRect().top - r0.top) < 4).length, w: Math.round(r0.width), side: document.documentElement.scrollWidth <= innerWidth + 1 }; });
  ok('phone (390 wide): 2 per row, at least 88 px wide, no sideways scroll', w390.row >= 2 && w390.w >= 88 && w390.side, JSON.stringify(w390));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 6. keyboard */
await H.block('6 keyboard', async () => {
  const page = await openQ('ch-many', { w: 1366, h: 900, label: 'kbd: ' });
  const act = () => page.evaluate(() => { const a = document.activeElement; return a ? (a.dataset.gid || a.dataset.fid || a.tagName) : ''; });
  await page.focus('.chs-thumb[data-gid="p1"]');
  ok('exactly one photo is a tab stop (the others are reached with the arrow keys)', await page.evaluate(() => document.querySelectorAll('.chs-thumb[tabindex="0"]').length === 1));
  await page.keyboard.press('ArrowRight');
  ok('Right arrow: next photo', (await act()) === 'p2', await act());
  const cols = await page.evaluate(() => { const th = [...document.querySelectorAll('.chs-thumb')], r0 = th[0].getBoundingClientRect(); return th.filter((b) => Math.abs(b.getBoundingClientRect().top - r0.top) < 4).length; });
  await page.keyboard.press('ArrowDown');
  ok(`Down arrow: one row down (${cols} per row, so p${2 + cols})`, (await act()) === 'p' + (2 + cols), await act());
  await page.keyboard.press('ArrowUp');
  ok('Up arrow: back up', (await act()) === 'p2', await act());
  await page.keyboard.press('End');
  ok('End: the last photo', (await act()) === 'p60', await act());
  await page.keyboard.press('Home');
  ok('Home: the first photo', (await act()) === 'p1', await act());
  await page.keyboard.press('ArrowLeft');
  ok('Left arrow at the first photo stays there', (await act()) === 'p1', await act());
  await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight');
  await page.keyboard.press('Space');
  let s = await st(page);
  ok('Space picks the focused photo', s.slots.top === 'p3' && s.pressed.join() === 'p3', JSON.stringify(s));
  ok('the focus stays on the photo after picking', (await act()) === 'p3', await act());
  await page.keyboard.press('Enter');
  s = await st(page);
  ok('Enter takes it out again', s.slots.top === '' && s.pressed.length === 0, JSON.stringify(s));
  await page.keyboard.press('Enter');
  ok('Enter picks it', (await st(page)).slots.top === 'p3');
  // the viewer
  await page.keyboard.press('e');
  await page.waitForSelector('.qtl', { state: 'attached' });
  ok('"e" opens the big viewer on that photo', await page.evaluate(() => /3 of 60/.test((document.querySelector('.qtl-count') || {}).textContent || '')), await page.evaluate(() => (document.querySelector('.qtl-count') || {}).textContent));
  await page.keyboard.press('Escape');
  await H.settle(page, 250);
  ok('Esc closes the viewer and the focus is back on the photo', !(await page.evaluate(() => !!document.querySelector('.qtl'))) && (await act()) === 'p3', await act());
  // tab order reaches the big button
  await page.focus('.chs-thumb[data-gid="p3"]');
  const seen = [];
  for (let i = 0; i < 6; i++) { await page.keyboard.press('Tab'); seen.push(await page.evaluate(() => { const a = document.activeElement; return (a.dataset && (a.dataset.fid || a.dataset.gid)) || a.className || a.tagName; })); }
  ok('Tab leaves the grid after the magnifier and reaches "Start over" and "Use these photos"', seen.some((x) => /start/.test(x)) && seen.some((x) => /commit/.test(x)), seen.join(' > '));
  ok('every control has a name and none is hidden under the sticky parts when focused', await page.evaluate(() => [...document.querySelectorAll('.chs button')].filter((b) => b.getClientRects().length).every((b) => (b.getAttribute('aria-label') || b.textContent || '').trim().length > 0)));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 7. the big viewer */
await H.block('7 big viewer', async () => {
  const page = await openQ('ch-strip', { w: 1366, h: 900, label: 'viewer: ' });
  await page.click('.chs-thumb[data-gid="p4"] ~ .chs-big');
  await page.waitForSelector('.qtl', { state: 'attached' });
  await H.settle(page, 300);
  const v0 = await page.evaluate(() => ({ count: (document.querySelector('.qtl-count') || {}).textContent, btn: (document.querySelector('.qtl-pick') || {}).textContent, hidden: !!(document.querySelector('.qtl-pick') || {}).hidden, title: (document.querySelector('.qtl-title') || {}).textContent }));
  ok('the enlarge button opens the viewer on that photo (4 of 12) with its name', /4 of 12/.test(v0.count) && /Sheep/.test(v0.title), JSON.stringify(v0));
  ok('the viewer has a button of its own: "Use this photo for Left side"', !v0.hidden && /Use this photo for Left side/.test(v0.btn), JSON.stringify(v0));
  await page.click('.qtl-pick');
  await H.settle(page, 200);
  const v1 = await page.evaluate(() => ({ btn: document.querySelector('.qtl-pick').textContent, pressed: document.querySelector('.qtl-pick').getAttribute('aria-pressed'), open: !!document.querySelector('.qtl') }));
  ok('pressing it picks the photo and the viewer stays open; the button says it is chosen and can take it out', v1.open && v1.pressed === 'true' && /Chosen for Left side/.test(v1.btn), JSON.stringify(v1));
  await page.keyboard.press('ArrowRight');
  await H.settle(page, 200);
  const v2 = await page.evaluate(() => document.querySelector('.qtl-pick').textContent);
  ok('the next photo offers the next empty place ("Use this photo for Right side")', /Use this photo for Right side/.test(v2), v2);
  await page.click('.qtl-pick');
  await page.keyboard.press('Escape');
  await H.settle(page, 300);
  const s = await st(page);
  ok('Esc closes it; the preview shows both choices (p4 left, p5 right)', s.slots.left === 'p4' && s.slots.right === 'p5' && !(await page.evaluate(() => !!document.querySelector('.qtl'))), JSON.stringify(s));
  ok('the focus goes back to the last photo she looked at (p5)', await page.evaluate(() => document.activeElement && document.activeElement.dataset.gid === 'p5'), await page.evaluate(() => document.activeElement && (document.activeElement.dataset.gid || document.activeElement.tagName)));
  // take out through the viewer
  await page.click('.chs-thumb[data-gid="p4"] ~ .chs-big');
  await page.waitForSelector('.qtl', { state: 'attached' });
  await page.click('.qtl-pick');
  await H.settle(page, 150);
  await page.keyboard.press('Escape');
  await H.settle(page, 250);
  const s2 = await st(page);
  ok('the viewer button on a chosen photo takes it out (left becomes empty, and is the place being chosen)', s2.slots.left === '' && s2.slots.right === 'p5' && s2.cur === 'left', JSON.stringify(s2));
  // long press (touch)
  await page.evaluate(() => { document.querySelector('.chs-thumb[data-gid="p7"]').scrollIntoView({ block: 'center' }); });
  const sel = '.chs-thumb[data-gid="p7"]';
  await page.dispatchEvent(sel, 'pointerdown', { pointerType: 'touch', pointerId: 7, isPrimary: true, bubbles: true });
  await sleep(750);
  ok('a long press with a finger opens the viewer', await page.evaluate(() => !!document.querySelector('.qtl')));
  await page.dispatchEvent(sel, 'pointerup', { pointerType: 'touch', pointerId: 7, isPrimary: true, bubbles: true });
  await page.keyboard.press('Escape');
  await H.settle(page, 250);
  const before = (await st(page)).pressed.join();
  await page.dispatchEvent(sel, 'pointerdown', { pointerType: 'touch', pointerId: 8, isPrimary: true, bubbles: true });
  await sleep(100);
  await page.dispatchEvent(sel, 'pointerup', { pointerType: 'touch', pointerId: 8, isPrimary: true, bubbles: true });
  await sleep(700);
  ok('a quick tap with a finger does not open the viewer', !(await page.evaluate(() => !!document.querySelector('.qtl'))));
  await page.dispatchEvent(sel, 'pointerdown', { pointerType: 'touch', pointerId: 9, isPrimary: true, bubbles: true });
  await sleep(750);
  ok('while the viewer is open the page behind is not reachable (inert); nothing was saved by looking', await page.evaluate(() => !!document.querySelector('.qtl') && !!document.querySelector('.chs-bar').closest('[inert]')) && (await H.writes(page)).length === 0 && before !== undefined);
  await page.dispatchEvent(sel, 'pointerup', { pointerType: 'touch', pointerId: 9, isPrimary: true, bubbles: true });
  await page.keyboard.press('Escape');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 8. photos that show people */
await H.block('8 people', async () => {
  const page = await openQ('ch-card', { label: 'people: ' });
  const m = await page.evaluate(() => ({ marks: [...document.querySelectorAll('.chs-thumb .chs-people')].map((e) => e.closest('.chs-thumb').dataset.gid + ':' + e.textContent.trim()), line: (document.querySelector('.chs-peopleline') || {}).textContent || '', aria: document.querySelector('.chs-thumb[data-gid="p9"]').getAttribute('aria-label') }));
  ok('a photo that shows people has a small "Shows people" mark (p9 only)', m.marks.join() === 'p9:Shows people', JSON.stringify(m));
  ok('one calm line says why: Miss Cathy and Rob have not said yes to photos with people yet', /Miss Cathy and Rob have not said yes to photos with people yet/.test(m.line), m.line);
  ok('the spoken name of that photo says it shows people', /shows people/i.test(m.aria), m.aria);
  await tap(page, 'p1');
  ok('a photo without people: no note under the preview', !/people/i.test((await st(page)).status), (await st(page)).status);
  await tap(page, 'p9');
  const s = await st(page);
  ok('choosing the photo with people shows the note under the preview', /Shows people/.test(s.status) && /have not said yes to photos with people yet/.test(s.status), s.status);
  ok('it can still be chosen and saved (the page only says it, the owner decides)', !s.commitDisabled && s.slots.corner === 'p9', JSON.stringify(s));
  await shot(page, 'card-700-people');
  await page.context().close();
  const custom = chooserDocs({ 'questions/ch-card': shareCard({ peopleNote: 'Ask Cathy before you use this one.' }) });
  const p2 = await openQ('ch-card', { docs: custom, label: 'people2: ' });
  await tap(p2, 'p9');
  ok('the note can come from the question (peopleNote)', /Ask Cathy before you use this one/.test((await st(p2)).status), (await st(p2)).status);
  await p2.context().close();
  const none = shareCard(); none.chooser.gallery = none.chooser.gallery.filter((g) => !g.people);
  const p3 = await openQ('ch-card', { docs: chooserDocs({ 'questions/ch-card': none }), label: 'people3: ' });
  ok('no photo shows people: no mark and no note line at all', await p3.evaluate(() => !document.querySelector('.chs-people') && !document.querySelector('.chs-peopleline')));
  await p3.context().close();
});

/* ===================================================================== 9. offline and failed saves */
await H.block('9 offline and failures', async () => {
  const page = await openQ('ch-card', { label: 'offline: ' });
  await tap(page, 'p3');
  await page.evaluate(() => { window.QT.offline = true; window.QT.emit('offline', { reason: 'test' }); });
  await H.settle(page, 200);
  let s = await st(page);
  ok('offline: she can still look and choose, but the big button is off and the line says it cannot be saved', s.commitDisabled && s.slots.corner === 'p3' && /this cannot be saved/.test(s.msg), JSON.stringify(s));
  await tap(page, 'p4');
  ok('offline: tapping photos still changes the preview', (await st(page)).slots.corner === 'p4');
  await page.evaluate(() => document.querySelector('.chs-commit').click());
  ok('offline: pressing the big button writes nothing', (await H.writes(page)).length === 0);
  ok('the page says "No connection" through the one banner of the layout; the chooser only adds its own plain line about its big button (item 35)', await page.evaluate(() => !/No connection/.test(document.querySelector('.chs').textContent.replace('No connection right now, so this cannot be saved.', ''))));
  await page.evaluate(() => { window.QT.offline = false; window.QT.emit('online', {}); });
  await H.settle(page, 200);
  s = await st(page);
  ok('back online: the big button is on again', !s.commitDisabled, JSON.stringify(s));
  // a refused save
  await page.evaluate(() => { window.__mock.failWrites = true; });
  await commit(page);
  await H.okSoon('a refused save says so kindly and keeps her choice and the big button', () => st(page), (x) => /Not saved/.test(x.msg) && x.slots.corner === 'p4' && !x.commitDisabled && !x.undo && !x.next, 20000);
  await page.evaluate(() => { window.__mock.failWrites = false; });
  await commit(page);
  await H.okSoon('pressing it again saves', async () => ({ s: await st(page), n: (await writesTo(page, 'answers/ch-card')).length }), (x) => /Saved ✓/.test(x.s.msg) && x.n === 1, 20000);
  // double click does not write twice
  await tap(page, 'p5');
  await page.evaluate(() => { window.__mock.db.writeDelay = 150; const b = document.querySelector('.chs-commit'); b.click(); b.click(); b.click(); });
  await H.settle(page, 600);
  ok('a quick double click saves once (no overlapping writes)', (await writesTo(page, 'answers/ch-card')).length === 2 && (await H.overlaps(page)).length === 0, JSON.stringify((await writesTo(page, 'answers/ch-card')).length));
  await page.context().close();
});

/* ===================================================================== 10. drafts and an answer that is already saved */
await H.block('10 draft and saved answer', async () => {
  const page = await openQ('ch-strip', { label: 'draft: ' });
  await tap(page, 'p2');
  await H.go(page, 'home');
  await showQ(page, 'ch-strip');
  let s = await st(page);
  ok('leaving and coming back keeps the picks she tried (nothing was saved)', s.slots.left === 'p2' && (await H.writes(page)).length === 0, JSON.stringify(s));
  await page.reload({ waitUntil: 'load' });
  await H.ready(page);
  await showQ(page, 'ch-strip');
  s = await st(page);
  ok('a reload keeps them too (kept in this browser only)', s.slots.left === 'p2', JSON.stringify(s));
  await tap(page, 'p3');
  await commit(page);
  ok('after saving, the try-out is forgotten', await page.evaluate(() => !Object.keys(localStorage).some((k) => /^qt\.chooser\.d\./.test(k))), await page.evaluate(() => Object.keys(localStorage).join()));
  await page.context().close();

  // already answered
  const saved = chooserDocs({ 'answers/ch-card': { id: 'ch-card', status: 'answered', key: 'picks', label: 'My picture choice', picks: { corner: 'p7' }, pickLabels: { corner: 'Hay wagon' }, ownText: '', changeText: '', note: '', round: 1, answeredAt: new Date().toISOString() } });
  const p2 = await openQ('ch-card', { docs: saved, label: 'saved: ' });
  s = await st(p2);
  ok('a saved choice is shown as chosen; the big button rests and says so; Next is offered', s.slots.corner === 'p7' && s.commitDisabled && /saved choice/.test(s.msg) && s.next, JSON.stringify(s));
  await H.put(p2, 'answers/ch-card', { id: 'ch-card', status: 'answered', key: 'picks', label: 'My picture choice', picks: { corner: 'p8' }, pickLabels: { corner: 'x' }, ownText: '', changeText: '', note: '', round: 1, answeredAt: new Date().toISOString() });
  await H.settle(p2, 300);
  s = await st(p2);
  ok('when the saved choice changes somewhere else, the screen follows (she had changed nothing)', s.slots.corner === 'p8', JSON.stringify(s));
  await tap(p2, 'p3');
  await H.put(p2, 'answers/ch-card', { id: 'ch-card', status: 'answered', key: 'picks', label: 'My picture choice', picks: { corner: 'p10' }, pickLabels: { corner: 'x' }, ownText: '', changeText: '', note: '', round: 1, answeredAt: new Date().toISOString() });
  await H.settle(p2, 300);
  s = await st(p2);
  ok('but it never jumps under her hand when she is in the middle of trying photos', s.slots.corner === 'p3' && !s.commitDisabled, JSON.stringify(s));
  await p2.context().close();
  // a saved photo that is not in the gallery any more is ignored
  const gone = chooserDocs({ 'answers/ch-card': { id: 'ch-card', status: 'answered', key: 'picks', label: 'My picture choice', picks: { corner: 'zzz' }, pickLabels: {}, ownText: '', changeText: '', note: '', round: 1, answeredAt: new Date().toISOString() } });
  const p3 = await openQ('ch-card', { docs: gone, label: 'gone: ' });
  s = await st(p3);
  ok('a saved photo that is no longer in the gallery is ignored (empty place, nothing breaks)', s.slots.corner === '' && p3.__errs.length === 0, JSON.stringify(s) + p3.__errs.join());
  await p3.context().close();
  // no usable localStorage
  const p4 = await openQ('ch-card', { label: 'nostorage: ', go: false, init: `Object.defineProperty(window, 'localStorage', { get() { throw new Error('no storage'); } });` });
  await showQ(p4, 'ch-card');
  await tap(p4, 'p2');
  await commit(p4);
  ok('without browser storage the chooser still works and saves', (await writesTo(p4, 'answers/ch-card')).length === 1 && p4.__errs.filter((e) => !/no storage/.test(e)).length === 0, p4.__errs.join(' | '));
  await p4.context().close();
});

/* ===================================================================== 11. the quiet buttons and the note */
await H.block('11 quiet buttons', async () => {
  const page = await openQ('ch-card', { label: 'quiet: ' });
  const names = await page.evaluate(() => [...document.querySelectorAll('.qv-answer .qa-x')].filter((b) => b.getClientRects().length).map((b) => b.textContent.trim().replace(/\s+/g, ' ')));
  ok('the four quiet buttons are there', ["I'm not sure yet", 'Explain another way', 'Type my own answer', 'This is a question for Miss Cathy and Rob'].every((n) => names.includes(n)), names.join(' | '));
  ok('there is no A-D row (and no "press the A key" tip)', await page.evaluate(() => document.querySelectorAll('.qa-choice').length === 0 && !document.querySelector('.qa-tip:not([hidden])')));
  await page.keyboard.press('a');
  await H.settle(page, 150);
  ok('the A key does nothing here', (await H.writes(page)).length === 0);
  ok('no "Go to the answers" link for a chooser question', await page.evaluate(() => ![...document.querySelectorAll('.qv-link')].some((b) => /Go to the answers/.test(b.textContent) && !b.hidden)));
  await tap(page, 'p3');
  await page.click('[data-fid="note-open"]');
  await page.fill('.qa-note-ta', 'The barn one please.');
  await commit(page);
  await H.settle(page, 250);
  const d = (await lastWrite(page, 'answers/ch-card')).data;
  ok('a note typed in the note box is saved together with the choice', d.key === 'picks' && d.note === 'The barn one please.' && d.picks.corner === 'p3', JSON.stringify(d));
  ok('after the choice is saved the usual "Next question" is there too', await page.evaluate(() => !!document.querySelector('.qa-next') && !document.querySelector('.qa-next').hidden));
  await page.click('[data-fid="x-unsure"]');
  await H.settle(page, 300);
  const d2 = (await lastWrite(page, 'answers/ch-card')).data;
  const s = await st(page);
  ok('"I\'m not sure yet" replaces the choice with that answer (the note stays); the chooser follows: empty places, no old "Saved / Undo" of its own', d2.key === 'unsure' && d2.note === 'The barn one please.' && s.slots.corner === '' && !s.undo && /Pick a photo/.test(s.msg), JSON.stringify([d2.key, s]));
  await page.click('.qa-undo');
  await H.settle(page, 400);
  const s2 = await st(page);
  ok('Undo of that answer brings the picture choice back on the screen', s2.slots.corner === 'p3' && s2.commitDisabled && /saved choice/.test(s2.msg), JSON.stringify(s2));
  await page.click('[data-fid="x-own"]');
  await page.fill('.qa-ta[data-fid="own-text"]', 'A different photo, I will send one.');
  await page.click('[data-fid="own-save"]');
  await H.settle(page, 250);
  ok('"Type my own answer" works as before', (await lastWrite(page, 'answers/ch-card')).data.key === 'own');
  await page.click('[data-fid="x-cathy"]');
  await H.settle(page, 250);
  ok('"This is a question for Miss Cathy and Rob" works as before', (await lastWrite(page, 'answers/ch-card')).data.key === 'cathy');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 12. safety and odd data */
await H.block('12 safety and odd data', async () => {
  const XSS = '<img src=x onerror="window.__xss=1">';
  const bad = { id: 'ch-bad', sectionId: 'look', kind: 'chooser', order: 60, title: XSS + ' title', story: [XSS], peopleNote: XSS, chooser: {
    slots: [{ id: 'a', label: XSS, hint: XSS }, { id: 'b', label: '"><script>window.__xss=2</script>' }],
    gallery: [{ id: 'ok1', url: photo('barn', 1), alt: XSS, label: XSS, people: true }, { id: 'js', url: 'javascript:window.__xss=3', label: 'js' }, { id: 'http', url: 'http://example.com/a.png', label: 'http' }, { id: 'txt', url: 'data:text/html,<script>window.__xss=4</script>', label: 'html' },
      { id: 'broken', url: 'https://broken.invalid/nope.png', alt: 'A broken one', label: 'Broken one' }, { id: 'long', url: photo('tree', 2), label: 'Supercalifragilisticexpialidocious'.repeat(8) }],
    preview: { base: { url: 'javascript:window.__xss=5', alt: XSS } } } };
  const page = await openQ('ch-card', { docs: chooserDocs({ 'questions/ch-bad': bad }), label: 'safety: ', mock: undefined });
  await showQ(page, 'ch-bad');
  await H.settle(page, 400);
  await H.until(page, () => !!document.querySelector('.chs-ph'), null, 20000);   // an address that does not exist can take a while to fail on a slow computer
  const r = await page.evaluate(() => ({
    xss: window.__xss || null, imgx: document.querySelectorAll('img[src="x"]').length, scripts: document.querySelectorAll('#qt-view script').length, thumbs: document.querySelectorAll('.chs-thumb').length,
    srcs: [...document.querySelectorAll('.chs img')].map((i) => i.getAttribute('src') || '').filter((s) => /^(javascript|http:|data:text)/i.test(s)), tabs: [...document.querySelectorAll('.chs-tab-t')].map((t) => t.textContent),
    ph: [...document.querySelectorAll('.chs-ph')].map((p) => p.textContent), side: document.documentElement.scrollWidth <= innerWidth + 1, base: !!document.querySelector('.chs-base'), plain: !!document.querySelector('.chs-stage.is-plain'),
  }));
  ok('words with HTML inside are shown as plain words: nothing runs, no extra picture, no script', !r.xss && r.imgx === 0 && r.scripts === 0, JSON.stringify(r));
  ok('only the safe photos are drawn (ok1, broken, long = 3); unsafe addresses never reach a picture', r.thumbs === 3 && r.srcs.length === 0, JSON.stringify(r));
  ok('the HTML-looking place names stay as text', r.tabs.length === 2 && /<img/.test(r.tabs[0]), r.tabs.join(' | '));
  ok('an unsafe base picture is left out and the preview is a plain box', !r.base && r.plain);
  ok('a picture that cannot load shows a calm box with its name', r.ph.length >= 1 && /Broken one/.test(r.ph.join(' ')) && /did not load/.test(r.ph.join(' ')), r.ph.join(' | '));
  ok('a very long word does not break the page sideways', r.side);
  await page.click('.chs-thumb[data-gid="broken"]');
  ok('a photo that did not load can still be chosen', (await st(page)).pressed.join() === 'broken');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
  // no photos / no chooser data
  const none = { id: 'ch-none', sectionId: 'look', kind: 'chooser', order: 61, title: 'Nothing yet', story: [] };
  const p2 = await openQ('ch-card', { docs: chooserDocs({ 'questions/ch-none': none }), label: 'none: ' });
  await showQ(p2, 'ch-none');
  const t = await p2.evaluate(() => ({ text: document.querySelector('.chs').innerText.replace(/\s+/g, ' '), commit: document.querySelector('.chs-commit').disabled, quiet: document.querySelectorAll('.qa-x').length }));
  ok('a chooser question with no photos says so kindly, keeps the quiet buttons, and does not break', /no photos to choose from yet/.test(t.text) && t.commit && t.quiet >= 3 && p2.__errs.length === 0, JSON.stringify(t) + p2.__errs.join());
  await p2.context().close();
  // allowNone
  const an = chooserDocs({ 'questions/ch-card': shareCard({ allowNone: true }) });
  const p3 = await openQ('ch-card', { docs: an, label: 'allownone: ' });
  let s = await st(p3);
  ok('allowNone: the big button is on without a photo and says "Use no photo"', !s.commitDisabled && s.commitText === 'Use no photo', JSON.stringify(s));
  await commit(p3);
  const d = (await lastWrite(p3, 'answers/ch-card')).data;
  ok('allowNone: committing with nothing chosen saves empty picks', d.key === 'picks' && Object.keys(d.picks).length === 0, JSON.stringify(d));
  await p3.context().close();
});

/* ===================================================================== 13. layout, sticky parts, big text */
await H.block('13 layout and sticky parts', async () => {
  for (const [w, hh] of [[320, 640], [390, 844], [700, 800], [1100, 800], [1366, 768], [1920, 1080]]) {
    for (const qid of ['ch-card', 'ch-strip']) {
      const page = await openQ(qid, { w, h: hh, label: `fit ${w}: ` });
      const g = await page.evaluate(() => { const r = (s) => { const e = document.querySelector(s); const b = e.getBoundingClientRect(); return { x: b.left, y: b.top, r: b.right, b: b.bottom, w: b.width }; }; return { side: document.documentElement.scrollWidth <= innerWidth + 1, prev: r('.chs-prev'), gal: r('.chs-gal'), bar: r('.chs-bar'), vw: innerWidth }; });
      const two = w >= 1100;
      ok(`${qid} at ${w} x ${hh}: no sideways scroll; ${two ? 'two columns (preview left, photos right)' : 'one column (preview on top)'}`, g.side && (two ? g.gal.x >= g.prev.r - 2 : g.gal.y >= g.prev.b - 2), JSON.stringify(g));
      ok(`${qid} at ${w}: the preview and the bar stay inside the window`, g.prev.x >= -1 && g.prev.r <= g.vw + 1 && g.bar.x >= -1 && g.bar.r <= g.vw + 1);
      await page.context().close();
    }
  }
  // sticky: the preview stays under the bars and the big button stays at the bottom while she scrolls the gallery (single column)
  const page = await openQ('ch-many', { w: 700, h: 800, label: 'sticky: ' });
  await page.evaluate(() => window.scrollTo(0, 900)); await H.settle(page, 400);
  const g = await page.evaluate(() => { const r = (s) => { const b = document.querySelector(s).getBoundingClientRect(); return { y: b.top, b: b.bottom }; }; const bars = [...document.querySelectorAll('.topbar, .pt-strip, .qbar')].map((e) => e.getBoundingClientRect().bottom); return { prev: r('.chs-prev'), bar: r('.chs-bar'), bars: Math.max(...bars), vh: innerHeight, sy: scrollY }; });
  ok('scrolled down the gallery: the preview sits right under the sticky bars (not hidden, not far below)', g.prev.y >= g.bars - 1 && g.prev.y <= g.bars + 24, JSON.stringify(g));
  ok('and the big button is still on screen at the bottom', g.bar.b <= g.vh + 1 && g.bar.y > g.prev.b, JSON.stringify(g));
  ok('the preview leaves room for the photos (more than 150 px between it and the big button)', g.bar.y - g.prev.b > 150, JSON.stringify(g));
  await shot(page, 'many-700-scrolled');
  // big text (200%)
  await page.evaluate(() => { document.documentElement.style.fontSize = '32px'; });
  await H.settle(page, 400);
  const big = await page.evaluate(() => ({ side: document.documentElement.scrollWidth <= innerWidth + 1, th: document.querySelectorAll('.chs-thumb').length, w: Math.round(document.querySelector('.chs-thumb').getBoundingClientRect().width), btn: document.querySelector('.chs-commit').getBoundingClientRect().height }));
  ok('text twice as big: no sideways scroll, photos still drawn, the big button is big', big.side && big.th === 60 && big.btn >= 40, JSON.stringify(big));
  await page.context().close();
  const st2 = await openQ('ch-strip', { w: 1366, h: 768, label: 'sticky2: ' });
  await tap(st2, 'p4');
  await st2.evaluate(() => window.scrollTo(0, 400)); await H.settle(st2, 300);
  const g2 = await st2.evaluate(() => { const b = document.querySelector('.chs-prev').getBoundingClientRect(); const bars = Math.max(...[...document.querySelectorAll('.topbar, .pt-strip, .qbar')].map((e) => e.getBoundingClientRect().bottom)); return { y: b.top, bars, sy: scrollY, bar: document.querySelector('.chs-bar').getBoundingClientRect().bottom, vh: innerHeight }; });
  ok('two columns: the preview stays in view while the photos scroll (1366 x 768)', g2.sy > 0 && g2.y >= g2.bars - 1 && g2.y < g2.bars + 24 && g2.bar <= g2.vh + 1, JSON.stringify(g2));
  await st2.context().close();
});

/* ===================================================================== 14. accessibility, dark theme, reduced motion */
await H.block('14 accessibility', async () => {
  for (const scheme of ['light', 'dark']) {
    const page = await openQ('ch-strip', { scheme, label: `axe ${scheme}: ` });
    let v = await axeRun(page);
    ok(`[${scheme}] empty chooser (2 places): axe finds no problems`, v.length === 0, axeText(v));
    await tap(page, 'p9'); await tap(page, 'p2');
    v = await axeRun(page);
    ok(`[${scheme}] both places chosen (one shows people): axe finds no problems`, v.length === 0, axeText(v));
    await commit(page);
    v = await axeRun(page);
    ok(`[${scheme}] after saving (Saved, Undo, Next): axe finds no problems`, v.length === 0, axeText(v));
    await page.click('.chs-thumb[data-gid="p4"] ~ .chs-big');
    await page.waitForSelector('.qtl', { state: 'attached' });
    await H.settle(page, 400);
    v = await axeRun(page);
    ok(`[${scheme}] big viewer with the "Use this photo" button: axe finds no problems`, v.length === 0, axeText(v));
    await page.keyboard.press('Escape');
    await page.evaluate(() => { window.QT.offline = true; window.QT.emit('offline', {}); });
    await H.settle(page, 200);
    v = await axeRun(page);
    ok(`[${scheme}] offline: axe finds no problems`, v.length === 0, axeText(v));
    ok(`[${scheme}] no page errors`, page.__errs.length === 0, page.__errs.join(' | '));
    await page.context().close();
  }
  const wide = await openQ('ch-card', { w: 1366, h: 768, label: 'axe wide: ' });
  await tap(wide, 'p3');
  const v = await axeRun(wide);
  ok('1366 x 768, one place chosen: axe finds no problems', v.length === 0, axeText(v));
  const roles = await wide.evaluate(() => ({ region: !!document.querySelector('section.chs[aria-label]'), list: document.querySelector('.chs-grid').getAttribute('role'), items: document.querySelectorAll('.chs-li').length, pressed: document.querySelectorAll('.chs-thumb[aria-pressed]').length, live: !!document.querySelector('.chs [aria-live]'), alt: document.querySelector('.chs-base').getAttribute('alt').length > 10 }));
  ok('the chooser is a labelled region, the photos are a list of toggle buttons, there is a live line, the drawing has a description', roles.region && roles.list === 'list' && roles.items === 12 && roles.pressed === 12 && roles.live && roles.alt, JSON.stringify(roles));
  await wide.context().close();
  const calm = await openQ('ch-strip', { reduced: true, label: 'reduced: ' });
  await tap(calm, 'p1');
  const anim = await calm.evaluate(() => { const els = [...document.querySelectorAll('.chs *')]; return els.filter((e) => { const cs = getComputedStyle(e); return (cs.animationName && cs.animationName !== 'none') || (parseFloat(cs.transitionDuration) > 0.001); }).length; });
  ok('reduced motion: nothing in the chooser animates or fades', anim === 0, String(anim));
  await calm.context().close();
  const lively = await openQ('ch-strip', { label: 'motion: ' });
  const anim2 = await lively.evaluate(() => [...document.querySelectorAll('.chs-thumb')].some((e) => parseFloat(getComputedStyle(e).transitionDuration) > 0));
  ok('with motion allowed there is a short, gentle fade on the thumbnails', anim2);
  await lively.context().close();
});

/* ===================================================================== 15. the screenshots to LOOK at */
await H.block('15 screenshots', async () => {
  const sets = [['card', 'ch-card', ['p3']], ['strip', 'ch-strip', ['p1', 'p5']]];
  for (const [name, qid, picks] of sets) {
    for (const [w, hh] of [[700, 800], [1366, 768], [1920, 1080]]) {
      const page = await openQ(qid, { w, h: hh, label: `shot ${name} ${w}: ` });
      await shot(page, `${name}-${w}-empty`);
      for (const p of picks) await tap(page, p);
      await page.evaluate(() => window.scrollTo(0, 0)); await H.settle(page, 400);
      await shot(page, `${name}-${w}`);
      if (w === 1366) {
        await page.close();
        const d = await openQ(qid, { w, h: hh, scheme: 'dark', label: `shot ${name} dark: ` });
        for (const p of picks) await tap(d, p);
        await d.evaluate(() => window.scrollTo(0, 0)); await H.settle(d, 300);
        await shot(d, `${name}-${w}-dark`);
        await d.context().close();
      } else await page.context().close();
    }
  }
  const v = await openQ('ch-strip', { w: 1366, h: 768, label: 'shot viewer: ' });
  await v.click('.chs-thumb[data-gid="p4"] ~ .chs-big');
  await v.waitForSelector('.qtl', { state: 'attached' });
  await H.settle(v, 500);
  await shot(v, 'strip-1366-viewer');
  await v.context().close();
  ok('screenshots written to T/shots/chooser/', fs.readdirSync(SHOTDIR).filter((f) => /^(card|strip)-(700|1366|1920)\.png$/.test(f)).length === 6, fs.readdirSync(SHOTDIR).join(' '));
});

/* ===================================================================== 16. ids that look like object keys or hold quotes; pictures send no referrer */
await H.block('16 odd ids and referrer', async () => {
  const g = gallery(6);
  const odd = ['constructor', '__proto__', 'toString', 'q"uote', "a'b]c", 'hasOwnProperty'];
  g.forEach((x, i) => { x.id = odd[i]; });
  const q = { id: 'ch-odd', sectionId: 'look', kind: 'chooser', order: 70, title: 'Odd ids', story: [], chooser: {
    slots: [{ id: 'constructor', label: 'First' }, { id: '__proto__', label: 'Second' }, { id: 'toString', label: 'Third' }],
    gallery: g, preview: { base: { url: photo('barn', 1), w: 800, h: 600 }, overlays: [{ slot: 'constructor', x: 5, y: 5, w: 30, h: 30 }, { slot: '__proto__', x: 40, y: 5, w: 30, h: 30 }] } } };
  const saved = { id: 'ch-odd2', status: 'answered', key: 'picks', label: 'My picture choice', picks: { corner: 'constructor', toString: 'hasOwnProperty', zzz: 'p1' }, pickLabels: {}, ownText: '', changeText: '', note: '', round: 1, answeredAt: new Date().toISOString() };
  const q2 = shareCard(); q2.id = 'ch-odd2'; q2.order = 71;
  const docs = chooserDocs({ 'questions/ch-odd': q, 'questions/ch-odd2': q2, 'answers/ch-odd2': saved });
  const page = await openQ('ch-odd', { docs, label: 'odd: ' });
  const r = await page.evaluate(() => ({ thumbs: document.querySelectorAll('.chs-thumb').length, slots: [...document.querySelectorAll('.chs-slot')].map((b) => b.dataset.slot), tabs: [...document.querySelectorAll('.chs-tab')].map((t) => t.dataset.tab) }));
  ok('keys like constructor, __proto__, toString, a quote or a bracket as photo ids: all 6 photos are drawn', r.thumbs === 6, JSON.stringify(r));
  ok('a place called constructor works; ones called __proto__ or toString (not a lower-case id) get a safe name (s2, s3)', r.slots.join() === 'constructor,s2,s3', r.slots.join());
  await page.click('.chs-thumb[data-gid="constructor"]');
  await page.click('.chs-thumb[data-gid="q\\"uote"]');
  await page.click('.chs-thumb[data-gid="__proto__"]');
  let s = await st(page);
  ok('tapping photos with such ids fills the places in order', s.slots.constructor === 'constructor' && s.slots.s2 === 'q"uote' && s.slots.s3 === '__proto__' && !s.commitDisabled, JSON.stringify(s));
  await commit(page);
  const d = (await lastWrite(page, 'answers/ch-odd')).data;
  ok('the saved answer keeps them as plain keys and values', d.key === 'picks' && Object.keys(d.picks).sort().join() === 'constructor,s2,s3' && d.picks.constructor === 'constructor' && d.picks.s2 === 'q"uote' && d.picks.s3 === '__proto__' && d.pickLabels.s2, JSON.stringify(d.picks));
  await page.click('.chs-start');
  ok('"Start over" with a quote in a photo id (the focus goes to the first photo) does not throw', page.__errs.length === 0 && (await page.evaluate(() => document.activeElement && document.activeElement.dataset.gid)) === 'constructor', page.__errs.join(' | '));
  await page.click('.chs-thumb[data-gid="q\\"uote"] ~ .chs-big');
  await page.waitForSelector('.qtl', { state: 'attached' });
  await H.settle(page, 300);
  const v = await page.evaluate(() => ({ ref: document.querySelector('.qtl-img') && document.querySelector('.qtl-img').referrerPolicy, count: (document.querySelector('.qtl-count') || {}).textContent }));
  ok('the big viewer picture sends no referrer', v.ref === 'no-referrer', JSON.stringify(v));
  await page.keyboard.press('Escape');
  await H.settle(page, 300);
  ok('closing the viewer gives the focus back to that photo (an id with a quote)', await page.evaluate(() => document.activeElement && document.activeElement.dataset.gid === 'q"uote'));
  const refs = await page.evaluate(() => { const im = [...document.querySelectorAll('.chs img')]; return { n: im.length, bad: im.filter((i) => i.referrerPolicy !== 'no-referrer').length }; });
  ok('every picture of the chooser (drawing, photos, the ones in the preview) sends no referrer', refs.n >= 7 && refs.bad === 0, JSON.stringify(refs));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
  // an old saved answer that names a photo or a place that is not there (or is called constructor) is ignored
  const p2 = await openQ('ch-odd2', { docs, label: 'odd2: ' });
  s = await st(p2);
  ok('a saved answer that names photos or places that are not there is ignored without a fuss', s.slots.corner === '' && p2.__errs.length === 0, JSON.stringify(s) + p2.__errs.join());
  await p2.context().close();
});

await H.stop(h);
