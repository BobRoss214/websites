/* Layout test stub: a tiny fake of the other modules so 10-layout.js + the CSS can be looked at alone. NOT part of the page. */
(function () {
  var q = new URLSearchParams(location.search);
  var QT = window.QT = window.QT || {};
  var ls = {};
  QT.on = function (e, f) { (ls[e] = ls[e] || []).push(f); };
  QT.off = function (e, f) { ls[e] = (ls[e] || []).filter(function (x) { return x !== f; }); };
  QT.emit = function (e, d) { (ls[e] || []).slice().forEach(function (f) { f(d); }); };
  QT.offline = q.get('offline') === '1';
  QT.store = { sections: {}, questions: {}, answers: {}, status: {}, ideas: {}, ideaStatus: {}, plans: {}, planReplies: {}, meta: {} };
  var S = QT.store;
  function sec(id, title, order, kind) { S.sections[id] = { id: id, title: title, order: order, kind: kind || 'builtin', size: 'big' }; }
  if (!QT.offline) {
    sec('look', 'Look and feel', 1); sec('other', 'Other questions', 2); sec('later', 'Ideas for later', 3); sec('kathy', 'Questions for Miss Cathy and Rob', 4);
    sec('account-features', 'Account features', 10, 'custom'); sec('gift-shop', 'Gift shop and a very long section name that wraps', 11, 'custom');
    if (q.get('many') === '1') for (var i = 0; i < 14; i++) sec('c' + i, 'My topic number ' + i, 20 + i, 'custom');
    for (var k = 0; k < 12; k++) S.questions['q' + k] = { id: 'q' + k, sectionId: k < 5 ? 'look' : k < 7 ? 'other' : 'kathy', title: 'Question ' + k, order: k, kind: k < 5 ? 'visual' : 'choice' };
    S.questions.qa = { id: 'qa', sectionId: 'account-features', title: 'Account q', order: 1, kind: 'choice' };
  }
  QT.sections = {
    list: function () { return Object.keys(S.sections).map(function (k) { return S.sections[k]; }).sort(function (a, b) { return a.order - b.order; }); },
    questionsOf: function (id) { return Object.keys(S.questions).map(function (k) { return S.questions[k]; }).filter(function (x) { return x.sectionId === id; }); }
  };
  var hb = q.get('stale') === '1' ? { text: 'Claude last looked: 45 min ago (Claude may be busy)', stale: true } : { text: 'Claude last looked: 2 min ago', stale: false };
  var sound = false;
  QT.status = {
    heartbeatLabel: function () { return QT.offline ? { text: 'Claude last looked: unknown', stale: false } : hb; },
    badgeCount: function (id) { return { look: 3, other: 12, later: 0, 'account-features': 2 }[id] || 0; },
    state: function () { return 'waiting'; },
    testConnection: function () { return new Promise(function (r) { setTimeout(function () { r('Claude was notified ✓'); }, 400); }); }
  };
  QT.sound = { enabled: function () { return sound; }, set: function (b) { sound = !!b; }, chime: function () { window.__chimes = (window.__chimes || 0) + 1; } };
  var cur = { view: q.get('view') || 'home', params: q.get('id') ? { id: q.get('id') } : {} };
  QT.route = { current: function () { return cur; }, go: function (v, p) { cur = { view: v, params: p || {} }; QT.emit('route', cur); } };
  QT.ready = new Promise(function (r) { setTimeout(r, 30); });

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; for (var i = 3; i < arguments.length; i++) e.appendChild(arguments[i]); return e; }
  function chip(txt, cls) { return el('span', 'chip ' + (cls || ''), txt); }
  var LONG = 'On the home page, under the pizza picture, the site says that you can order online and we would like to know which of these four pictures looks best to you and your customers.';
  var views = QT.views = {};
  views.home = function (v) {
    v.appendChild(el('h1', '', 'Welcome back'));
    var st = el('div', 'stack mt-m');
    st.appendChild(el('div', 'card', null, el('h2', '', 'Waiting for you'), el('p', 'muted mt-s', '3 questions in Look and feel, 12 in Other questions.'), el('div', 'row mt-m', null, el('button', 'btn primary', 'Start with the first one'), el('button', 'btn', 'See all'))));
    st.appendChild(el('div', 'banner info', null, el('span', 'banner-text', 'Claude is working on 2 things right now.')));
    var list = el('div', 'list');
    ['One', 'Two', 'Three'].forEach(function (t, i) { var b = el('button', 'item' + (i === 1 ? ' current' : '')); b.type = 'button'; b.appendChild(el('span', 'item-main', null, el('div', 'item-title', 'Question ' + t), el('div', 'item-sub', 'Look and feel'))); b.appendChild(el('span', 'item-end', null, chip(i === 0 ? 'Waiting for you' : 'Claude saw it ✓', i === 0 ? '' : 'info'))); list.appendChild(b); });
    st.appendChild(list);
    var sw = el('label', 'switch'); var inp = el('input'); inp.type = 'checkbox'; inp.setAttribute('role', 'switch'); sw.appendChild(inp); sw.appendChild(el('span', 'track')); sw.appendChild(el('span', 'lbl', 'Pause: do not start anything here.')); st.appendChild(sw);
    v.appendChild(st);
    for (var i = 0; i < (q.get('long') === '1' ? 12 : 0); i++) st.appendChild(el('div', 'card', LONG));
  };
  views.section = function (v, p) {
    v.appendChild(el('h1', '', (S.sections[p.id] || {}).title || 'Section'));
    var st = el('div', 'stack mt-m');
    var f = el('div', 'field'); var l = el('label', '', 'Tell Claude what you want here'); l.htmlFor = 'idea'; var ta = el('textarea'); ta.id = 'idea'; ta.placeholder = 'Type here…'; f.appendChild(l); f.appendChild(ta); f.appendChild(el('div', 'hint', 'Claude turns your ideas into questions.'));
    st.appendChild(f); st.appendChild(el('button', 'btn primary', 'Send to Claude'));
    var pr = el('div', 'card tight'); pr.appendChild(el('div', 'row between', null, el('strong', '', 'Before I start: 3 of 7 important questions answered'), chip('Big', 'quiet'))); var pg = el('div', 'progress mt-s'); var i = document.createElement('i'); i.style.width = '43%'; pg.appendChild(i); pr.appendChild(pg); st.appendChild(pr);
    v.appendChild(st);
  };
  views.question = function (v, p) {
    var bar = el('div', 'qbar'), main = el('div', 'qbar-main');
    main.appendChild(el('div', 'qbar-kicker', 'Look and feel · Question 2 of 5'));
    main.appendChild(el('h1', 'qbar-title', q.get('title') || 'Which version of the home picture do you like best for the top of the page?'));
    bar.appendChild(main); bar.appendChild(el('div', 'qbar-chip', null, chip(q.get('chip') || 'Waiting for you')));
    v.appendChild(bar);
    var sp = el('div', 'split');
    var pics = el('div', 'grid2');
    ['A', 'B', 'C', 'D'].forEach(function (k) { var f = el('figure'); f.style.margin = '0'; var b = el('div'); b.style.cssText = 'height:150px;background:var(--panel);border:1px solid var(--line);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700'; b.textContent = 'Picture ' + k; f.appendChild(b); f.appendChild(el('figcaption', 'tiny muted', 'Version ' + k + ' · warm and simple')); pics.appendChild(f); });
    sp.appendChild(pics);
    var right = el('div', 'stack');
    right.appendChild(el('p', '', LONG)); right.appendChild(el('div', 'panel small', 'Why I am asking: it is the first thing people see.'));
    var g = el('div', 'grid2 auto'); ['A', 'B', 'C', 'D'].forEach(function (k) { var b = el('button', 'btn' + (k === 'B' ? ' on' : ''), 'Pick ' + k); b.type = 'button'; if (k === 'B') b.setAttribute('aria-pressed', 'true'); g.appendChild(b); }); right.appendChild(g);
    var r2 = el('div', 'row'); ['I’m not sure yet', 'Explain another way'].forEach(function (t) { var b = el('button', 'btn quiet small', t); b.type = 'button'; r2.appendChild(b); }); right.appendChild(r2);
    var ta = el('textarea'); ta.placeholder = 'Type my own answer…'; right.appendChild(ta);
    right.appendChild(el('div', 'savestat ok', 'Saved ✓'));
    sp.appendChild(right); v.appendChild(sp);
    if (q.get('long') === '1') for (var i = 0; i < 10; i++) v.appendChild(el('div', 'card mt-m', LONG + LONG));
  };
  views.done = function (v) { v.appendChild(el('h1', '', 'Done')); v.appendChild(el('p', 'muted mt-s', 'Nothing here yet.')); };
  views.newsection = function (v) { v.appendChild(el('h1', '', 'New section')); };
  if (q.get('theme')) document.documentElement.setAttribute('data-theme', q.get('theme'));
})();
