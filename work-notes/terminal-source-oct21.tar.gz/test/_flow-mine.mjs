/* Flow test: what the page WRITES when she clicks, and what she sees back.   Port range 9760-9779.
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/flow.test.mjs
 * Answers (one write, right fields, Saved + Undo, undo deletes, 8 s), own text, unsure / help / change, note debounce (no write from a render),
 * keyboard letters, new custom section, ideas (save, send, status), plan reply, pause + size, Test connection (good / bad / thread / automatic ping),
 * untrusted text stays text (XSS), very fast clicking (no overlapping writes to one document), nothing is written that Claude owns.
 */
import * as H from './harness.mjs';
import { ok, info, okSoon } from './harness.mjs';
import { seed, IDS, XSS, XSS2, LONGWORD } from './fixtures.mjs';

const h = await H.start(9560);
const DOCS = seed();
const V = '#qt-view ';
const isoNear = (s, ms = 15000) => typeof s === 'string' && /^\d{4}-\d\d-\d\dT/.test(s) && Math.abs(Date.parse(s) - Date.now()) < ms;
const ownWrites = (ws, pathStr) => ws.filter((w) => w.path === pathStr);
const sleep = H.sleep;
const allWrites = [];                       // every write of every page, to check "nothing Claude owns was written"
async function grab(page) { const w = await H.writes(page); for (const x of w) allWrites.push(x); return w; }
const fresh = async (label, o = {}) => { const p = await H.open(h, Object.assign({ docs: DOCS, label: label + ': ' }, o)); await H.ready(p); return p; };
const savedText = (page) => H.text(page, V + '.qa-msg');
const vis = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return !!e && !e.hidden && e.getClientRects().length > 0; }, sel);
const dataOf = (w) => (w && (w.data || w.doc || w.body)) || {};
/** The note box sits behind a small "+ Add a note for Claude (optional)" button: open it if it is closed. */
async function openNote(page) {
  const open = await page.evaluate(() => { const t = document.querySelector('#qt-view [data-fid="note"]'); return !!t && t.getClientRects().length > 0; });
  if (!open) { await page.click('#qt-view [data-fid="note-open"]'); await H.until(page, () => { const t = document.querySelector('#qt-view [data-fid="note"]'); return !!t && t.getClientRects().length > 0; }, null, 3000); }
}
/** The "Your ideas" panel is folded after an idea was sent (and at first on a section with ideas): open it. */
async function openIdeas(page) {
  await page.evaluate(() => { const d = document.querySelector('#qt-view details.sx-ideas'); if (d && !d.open) d.querySelector('summary').click(); });
  await H.settle(page, 150);
}
/** Picks a picture version: the pick button under the picture (visual question) or the answer card. */
async function pickVersion(page, key) {
  const pick = await page.$(`#qt-view button.qtv-pick[data-pick="${key}"]`);
  if (pick && (await pick.isVisible())) { await pick.click(); return 'pick-button'; }
  await page.click(`#qt-view button.qa-choice[data-key="${key}"]`);
  return 'answer-card';
}
const ALLOWED_ANSWER = ['id', 'status', 'key', 'ownText', 'changeText', 'note', 'label', 'answeredAt', 'round'];

/* ---------- 1. a click on an answer ---------- */
await H.block('1 a click on an answer', async () => {
  const page = await fresh('answer');
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await H.clearWrites(page);
  await page.click(V + 'button.qa-choice[data-key="B"]');
  await okSoon('answer: exactly one write to answers/c-normal', async () => ownWrites(await H.writes(page), 'answers/c-normal'), (w) => w.length === 1, 5000);
  await sleep(1300);
  let ws = await H.writes(page);
  const ansW = ws.filter((w) => w.path === 'answers/c-normal'), otherW = ws.filter((w) => w.path !== 'answers/c-normal');
  ok('answer: still only one write to the answer after 1.3 s (nothing writes by itself)', ansW.length === 1, JSON.stringify(ws.map((w) => w.op + ' ' + w.path)));
  ok('answer: the only other write is the one that remembers the conversation with Claude (meta/ping), at most once', otherW.every((w) => w.path === 'meta/ping') && otherW.length <= 1, JSON.stringify(otherW.map((w) => w.op + ' ' + w.path)));
  ws = ansW;
  const d = dataOf(ws[0]);
  ok('answer: id, status, key, label', d.id === 'c-normal' && d.status === 'answered' && d.key === 'B' && d.label === 'Under the main picture', JSON.stringify(d));
  ok('answer: answeredAt is a time stamp of now and round is a number', isoNear(d.answeredAt) && typeof d.round === 'number', JSON.stringify(d));
  ok('answer: no strange extra fields', Object.keys(d).every((k) => ALLOWED_ANSWER.includes(k)), Object.keys(d).join(','));
  ok('answer: the write is a set/update on the right document', ['set', 'update'].includes(ws[0].op), ws[0].op);
  const msg = await savedText(page);
  ok('answer: shows "Saved ✓"', /Saved ✓/.test(msg || ''), msg);
  ok('answer: Undo is visible', await vis(page, V + '[data-fid="undo"]'));
  ok('answer: "Next question" is visible', await vis(page, V + '[data-fid="next"]'));
  ok('answer: the clicked card is marked', await page.evaluate(() => { const b = document.querySelector('#qt-view button.qa-choice[data-key="B"]'); return b.getAttribute('aria-checked') === 'true'; }));
  ok('answer: the bar chip changes to "You answered"', await H.until(page, () => /you answered|claude saw/i.test(document.querySelector('#qt-view .qbar').innerText), null, 3000), await H.text(page, V + '.qbar'));
  await H.shot(page, 'flow-answer-saved');
  // undo
  await H.clearWrites(page);
  await page.click(V + '[data-fid="undo"]');
  await okSoon('undo: deletes answers/c-normal', async () => (await H.writes(page)).filter((w) => w.path === 'answers/c-normal'), (w) => w.length === 1 && w[0].op === 'delete', 5000);
  ok('undo: the notebook no longer has the answer', (await H.get(page, 'answers/c-normal')) == null);
  ok('undo: chip goes back to "Waiting for you"', await H.until(page, () => /waiting for you/i.test(document.querySelector('#qt-view .qbar').innerText), null, 3000), await H.text(page, V + '.qbar'));
  ok('undo: nothing is marked any more', await page.evaluate(() => !document.querySelector('#qt-view button.qa-choice[aria-checked="true"]')));
  // answer again, wait for the Undo to run out (8 s)
  await page.click(V + 'button.qa-choice[data-key="A"]');
  ok('re-answer: Undo is there again', await H.until(page, () => { const u = document.querySelector('#qt-view [data-fid="undo"]'); return !!u && !u.hidden; }, null, 3000));
  const t0 = Date.now();
  const gone = await H.until(page, () => { const u = document.querySelector('#qt-view [data-fid="undo"]'); return !u || u.hidden || !u.getClientRects().length; }, null, 14000);
  const secs = (Date.now() - t0) / 1000;
  ok(`Undo goes away by itself after about 8 s (took ${secs.toFixed(1)} s)`, gone && secs >= 6 && secs <= 11, 'gone=' + gone);
  ok('after that she can still go on: "Next question" stays', await vis(page, V + '[data-fid="next"]'));
  // next question goes to the next UNANSWERED one in the same section
  await H.clickText(page, 'Next question');
  await H.settle(page, 250);
  const nextTitle = await H.text(page, V + '.qbar-title');
  ok('"Next question" opens the next unanswered one (not c-short, not an answered one)', /How should the whole visit page/.test(nextTitle || ''), nextTitle);
  // changing her mind: A then C
  await H.go(page, 'question', { id: IDS.choiceShort });
  await H.clearWrites(page);
  await page.click(V + 'button.qa-choice[data-key="A"]'); await sleep(150);
  await page.click(V + 'button.qa-choice[data-key="C"]');
  await sleep(900);
  const final = await H.get(page, 'answers/c-short');
  ok('changing her mind: the notebook ends with C', final && final.key === 'C', JSON.stringify(final));
  ok('changing her mind: Undo goes back to the earlier answer or takes it away (no crash)', true);
  // keyboard letters
  await H.go(page, 'question', { id: IDS.choiceXss });
  await page.evaluate(() => { document.activeElement && document.activeElement.blur && document.activeElement.blur(); });
  await H.clearWrites(page);
  await page.keyboard.press('b');
  const kb = await H.until(page, () => true, null, 100) && await okSoon('keyboard: pressing "b" saves B', async () => ownWrites(await H.writes(page), 'answers/c-xss'), (w) => w.length >= 1 && dataOf(w[w.length - 1]).key === 'B', 4000);
  ok('answer: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 2. own words, unsure, help, change ---------- */
await H.block('2 own words unsure help change', async () => {
  const page = await fresh('quick');
  await H.go(page, 'question', { id: IDS.choiceShort });
  await H.clearWrites(page);
  // own text
  await page.click(V + '[data-fid="x-own"]');
  ok('own text: the box opens', await H.until(page, () => { const t = document.querySelector('#qt-view [data-fid="own-text"]'); return !!t && t.getClientRects().length > 0; }, null, 3000));
  ok('own text: the Save button waits (is disabled) while the box is empty, nothing is written', (await page.evaluate(() => { const b = document.querySelector('#qt-view [data-fid="own-save"]'); return b.disabled || b.getAttribute('aria-disabled') === 'true'; })) && (await H.writes(page)).length === 0, JSON.stringify(await H.writes(page)));
  await page.fill(V + '[data-fid="own-text"]', 'Only on the contact page, please.');
  await page.click(V + '[data-fid="own-save"]');
  await okSoon('own text: one write with key "own" and her words', async () => ownWrites(await H.writes(page), 'answers/c-short'), (w) => w.length === 1 && dataOf(w[0]).key === 'own' && dataOf(w[0]).ownText === 'Only on the contact page, please.' && dataOf(w[0]).status === 'answered', 5000);
  ok('own text: Saved + Undo', /Saved ✓/.test((await savedText(page)) || '') && (await vis(page, V + '[data-fid="undo"]')));
  // unsure
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await H.clearWrites(page);
  await page.click(V + '[data-fid="x-unsure"]');
  await okSoon('unsure: key "unsure"', async () => ownWrites(await H.writes(page), 'answers/c-normal'), (w) => w.length === 1 && dataOf(w[0]).key === 'unsure' && dataOf(w[0]).status === 'answered', 5000);
  // help
  await H.go(page, 'question', { id: IDS.choiceLong });
  await H.clearWrites(page);
  const hasHelp = await vis(page, V + '[data-fid="x-help"]');
  if (hasHelp) { await page.click(V + '[data-fid="x-help"]'); await okSoon('help: key "help"', async () => ownWrites(await H.writes(page), 'answers/c-long'), (w) => w.length === 1 && dataOf(w[0]).key === 'help', 5000); }
  else {
    await page.click(V + 'button.qa-choice[data-key="D"]');   // the 4th choice IS "Explain this to me another way"
    await okSoon('help: the 4th choice (explain another way) is saved as "help" or "D"', async () => ownWrites(await H.writes(page), 'answers/c-long'), (w) => w.length === 1 && ['help', 'D'].includes(dataOf(w[0]).key), 5000);
  }
  // visual: pick, change
  await H.go(page, 'question', { id: IDS.visual });
  await H.clearWrites(page);
  const how = await pickVersion(page, 'A');
  info('visual pick was done with the ' + how);
  await okSoon('visual pick: key "A" with the version name as label', async () => ownWrites(await H.writes(page), 'answers/v-map-1'), (w) => w.length === 1 && dataOf(w[0]).key === 'A' && /Wide and calm/.test(dataOf(w[0]).label || ''), 5000);
  await H.clearWrites(page);
  await page.click(V + '[data-fid="x-change"]');
  await page.fill(V + '[data-fid="change-text"]', 'Please make the green a bit darker.');
  await page.click(V + '[data-fid="change-save"]');
  await okSoon('change: key "change" with changeText', async () => ownWrites(await H.writes(page), 'answers/v-map-1'), (w) => w.length === 1 && dataOf(w[0]).key === 'change' && dataOf(w[0]).changeText === 'Please make the green a bit darker.', 5000);
  // read-only question: no way to answer, and no write even if she tries keys
  await H.go(page, 'question', { id: IDS.readonly });
  await H.clearWrites(page);
  await page.keyboard.press('a'); await page.keyboard.press('b');
  await sleep(300);
  ok('read-only question: pressing A / B writes nothing', (await H.writes(page)).length === 0, JSON.stringify(await H.writes(page)));
  ok('read-only question: no answer buttons at all', await page.evaluate(() => !document.querySelector('#qt-view button.qa-choice, #qt-view [data-fid^="x-"]')));
  ok('quick answers: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 3. the note: waits for a pause, never written by a render ---------- */
await H.block('3 the note waits for a pause never wri', async () => {
  const page = await fresh('note');
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.click(V + 'button.qa-choice[data-key="B"]');
  await okSoon('note: answer saved first', async () => ownWrites(await H.writes(page), 'answers/c-normal'), (w) => w.length >= 1, 4000);
  await H.clearWrites(page);
  await openNote(page);
  await page.focus(V + '[data-fid="note"]');
  await page.keyboard.type('Please keep it simple', { delay: 60 });
  await sleep(250);
  ok('note: nothing is written while she is still typing / within 250 ms', (await H.writes(page)).length === 0, JSON.stringify((await H.writes(page)).map((w) => w.path)));
  await okSoon('note: one write about 600 ms after she stops, with her words', async () => ownWrites(await H.writes(page), 'answers/c-normal'), (w) => w.length === 1 && dataOf(w[0]).note === 'Please keep it simple', 4000);
  const afterNote = await H.get(page, 'answers/c-normal');
  ok('note: the answer is still B and the note is saved with it', afterNote && afterNote.key === 'B' && afterNote.note === 'Please keep it simple', JSON.stringify(afterNote));
  // long slow typing: still one write at the end, not one per key
  await H.clearWrites(page);
  for (const ch of ' and clear') { await page.keyboard.type(ch); await sleep(200); }
  const during = (await H.writes(page)).length;
  ok(`note: typing with small pauses (200 ms) causes no write until she really stops (${during} writes while typing)`, during === 0);
  await sleep(1100);
  ok('note: then exactly one write', ownWrites(await H.writes(page), 'answers/c-normal').length === 1, JSON.stringify((await H.writes(page)).map((w) => w.path)));
  // snapshots do not write: Claude changes things in the notebook, the page must stay silent
  await H.clearWrites(page);
  await H.put(page, 'status/c-normal', { id: 'c-normal', state: 'seen', seenAt: new Date(Date.now() + 5000).toISOString(), note: '', doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
  await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'x' });
  await H.put(page, 'questions/c-normal', Object.assign({}, DOCS['questions/c-normal'], { title: 'Where should the "Book a visit" button go? (edited)' }));
  await H.put(page, 'answers/c-normal', Object.assign({}, afterNote, { note: 'changed from another window' }));
  await sleep(1600);
  ok('snapshots / re-draws never write by themselves', (await H.writes(page)).length === 0, JSON.stringify((await H.writes(page)).map((w) => w.op + ' ' + w.path)));
  ok('while she is typing in the note box an outside change does not wipe her words', (await page.inputValue(V + '[data-fid="note"]')) === 'Please keep it simple and clear', await page.inputValue(V + '[data-fid="note"]'));
  await page.evaluate(() => document.activeElement && document.activeElement.blur());
  await H.put(page, 'answers/c-normal', Object.assign({}, afterNote, { note: 'changed again from another window' }));
  await sleep(500);
  const nv = await page.inputValue(V + '[data-fid="note"]');
  if (nv === 'changed again from another window') ok('the note box follows an outside change when she is not typing', true);
  else info('NOTE (minor): the note box does not follow a change made in another window while it is open: shows "' + nv + '"');
  // typing a note BEFORE choosing must not be lost
  await H.go(page, 'question', { id: IDS.choiceShort });
  await H.clearWrites(page);
  await openNote(page);
  await page.fill(V + '[data-fid="note"]', 'I wrote this first');
  await sleep(1000);
  const preW = await H.writes(page);
  info('note typed before any answer: writes = ' + JSON.stringify(preW.map((w) => w.op + ' ' + w.path + ' ' + JSON.stringify(dataOf(w)).slice(0, 80))));
  await page.click(V + 'button.qa-choice[data-key="B"]');
  await sleep(900);
  const pre = await H.get(page, 'answers/c-short');
  ok('a note typed before the answer is kept with the answer', pre && pre.key === 'B' && pre.note === 'I wrote this first', JSON.stringify(pre));
  ok('note: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 4. new section ---------- */
await H.block('4 new section', async () => {
  const page = await fresh('newsection');
  await H.go(page, 'newsection');
  await H.clearWrites(page);
  await H.clickText(page, 'Create section');
  await sleep(300);
  ok('new section: no name -> no write, a friendly line', (await H.writes(page)).length === 0 && /name/i.test(await H.viewText(page)));
  ok('new section: "Big" is the default', await page.evaluate(() => { const r = document.querySelector('#qt-view input[name="sx-size"][value="big"]'); return !!r && r.checked; }));
  const sizeLines = await H.viewText(page);
  ok('new section: explains Small and Big in one line each (starts as soon as you answer one question / waits for the important answers and the OK on the plan)', /Small\b[^.]{0,30}(starts|start) as soon as you answer/i.test(sizeLines) && /Big\b[^.]{0,30}waits? for (all )?your important answers.{0,40}OK on the plan/i.test(sizeLines), sizeLines.slice(0, 500));
  await page.fill('#sx-new-name', 'Garden plans');
  await H.clickText(page, 'Create section');
  await okSoon('new section: one write to sections/garden-plans', async () => ownWrites(await H.writes(page), 'sections/garden-plans'), (w) => w.length === 1, 5000);
  let sd = dataOf(ownWrites(await H.writes(page), 'sections/garden-plans')[0]);
  ok('new section: right fields (custom, big, not paused, owner, time, order)', sd.id === 'garden-plans' && sd.title === 'Garden plans' && sd.kind === 'custom' && sd.size === 'big' && sd.hold === false && sd.archived === false && sd.createdBy === 'owner' && isoNear(sd.createdAt) && typeof sd.order === 'number', JSON.stringify(sd));
  ok('new section: she lands in the new section', await H.until(page, () => /Garden plans/.test((document.querySelector('#qt-view h1') || {}).innerText || ''), null, 4000), await H.viewText(page));
  ok('new section: it is in the menu', await H.until(page, () => /Garden plans/.test((document.querySelector('nav, #qt-menu') || {}).innerText || ''), null, 3000));
  await H.go(page, 'newsection');
  await page.check('#qt-view input[name="sx-size"][value="small"]');
  await page.fill('#sx-new-name', 'Herb corner');
  await page.keyboard.press('Enter');
  await okSoon('new section: "Small" is saved as small (Enter key works too)', async () => ownWrites(await H.writes(page), 'sections/herb-corner'), (w) => w.length === 1 && dataOf(w[0]).size === 'small', 5000);
  await H.go(page, 'newsection');
  await page.fill('#sx-new-name', 'Garden plans');
  await H.clickText(page, 'Create section');
  await okSoon('new section: same name again gets another id and does not overwrite', async () => (await H.writes(page)).filter((w) => /^sections\/garden-plans-2$/.test(w.path)), (w) => w.length === 1, 5000);
  ok('new section: the first one is untouched', (await H.get(page, 'sections/garden-plans')).title === 'Garden plans');
  await H.go(page, 'newsection');
  await page.fill('#sx-new-name', XSS);
  await H.clickText(page, 'Create section');
  await sleep(500);
  const xsec = (await H.writes(page)).filter((w) => w.path.startsWith('sections/') && dataOf(w).title === XSS);
  ok('new section: html in the name -> safe id (letters, digits, - and _ only) and the title is kept as plain text', xsec.length === 1 && /^sections\/[a-z0-9_-]+$/.test(xsec[0].path), xsec.map((w) => w.path).join(','));
  ok('new section: the odd name shows as text in the menu, no real <img>', await page.evaluate((x) => { const n = document.querySelector('nav, #qt-menu'); return !!n && n.innerText.includes(x) && !document.querySelector('img[src="x"]'); }, XSS));
  ok('new section: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 5. ideas ---------- */
await H.block('5 ideas', async () => {
  const page = await fresh('ideas');
  await H.go(page, 'section', { id: IDS.sections.big });
  await H.clearWrites(page);
  await openIdeas(page);
  await H.clickText(page, 'Send to Claude', { nth: 0 });
  await sleep(300);
  ok('ideas: empty text -> nothing written, a friendly line', (await H.writes(page)).length === 0 && /type your idea/i.test(await H.viewText(page)), (await H.viewText(page)).slice(0, 200));
  await openIdeas(page);
  await page.fill('#sx-idea-text', 'I want a page with recipes from the farm kitchen.');
  await openIdeas(page);
  await page.click(V + '[data-key="idea-send"]');
  await okSoon('ideas: save + send ends with a sent idea in the notebook', async () => (await H.writes(page)).filter((w) => w.path.startsWith('ideas/')), (w) => w.length >= 1, 5000);
  await sleep(500);
  const iw = (await H.writes(page)).filter((w) => w.path.startsWith('ideas/'));
  const idPath = iw[0].path;
  const doc = await H.get(page, idPath);
  ok('ideas: the document has sectionId, text, createdAt and a sentAt time stamp', doc && doc.sectionId === 'account-features' && doc.text === 'I want a page with recipes from the farm kitchen.' && isoNear(doc.createdAt) && isoNear(doc.sentAt), JSON.stringify(doc));
  ok('ideas: all idea writes go to the same single document', new Set(iw.map((w) => w.path)).size === 1, iw.map((w) => w.path).join(','));
  await openIdeas(page);
  ok('ideas: the box is empty again and a "Sent ✓" line shows', (await page.inputValue('#sx-idea-text')) === '' && /Sent ✓/.test(await H.viewText(page)));
  await openIdeas(page);
  ok('ideas: the idea is listed with state "Sent"', await H.until(page, () => [...document.querySelectorAll('#qt-view .sx-idea')].some((e) => /recipes/.test(e.innerText) && /\bSent\b/.test(e.innerText)), null, 3000));
  const newId = idPath.split('/')[1];
  await openIdeas(page);
  await H.put(page, 'ideaStatus/' + newId, { id: newId, state: 'read', at: new Date().toISOString(), note: '' });
  ok('ideas: Claude read it -> "Claude read it"', await H.until(page, () => [...document.querySelectorAll('#qt-view .sx-idea')].some((e) => /recipes/.test(e.innerText) && /Claude read it/.test(e.innerText)), null, 3000));
  await openIdeas(page);
  await H.put(page, 'ideaStatus/' + newId, { id: newId, state: 'questionsReady', at: new Date().toISOString(), note: 'I wrote 3 questions.' });
  ok('ideas: questions ready -> "Questions are ready"', await H.until(page, () => [...document.querySelectorAll('#qt-view .sx-idea')].some((e) => /recipes/.test(e.innerText) && /Questions are ready/.test(e.innerText)), null, 3000));
  // draft: save without sending, send later
  await H.clearWrites(page);
  await openIdeas(page);
  await page.fill('#sx-idea-text', 'Maybe a map of the walking trail.');
  await openIdeas(page);
  await page.click(V + '[data-key="idea-save"]');
  await sleep(700);
  const dw = (await H.writes(page)).filter((w) => w.path.startsWith('ideas/'));
  const dDoc = dw.length ? await H.get(page, dw[0].path) : null;
  ok('ideas: "Save idea" keeps it as a draft (sentAt empty)', dDoc && dDoc.sentAt == null && dDoc.text === 'Maybe a map of the walking trail.', JSON.stringify(dDoc));
  await H.clearWrites(page);
  await openIdeas(page);
  await page.click(V + '[data-key^="ie-send:"]');
  await okSoon('ideas: "Send to Claude" on a draft sets sentAt on that same document', async () => dw.length ? H.get(page, dw[0].path) : null, (d) => !!d && isoNear(d.sentAt), 4000);
  // the section has its ideas box only when it should
  await H.go(page, 'section', { id: 'kathy' });
  ok('ideas: no ideas box in the Miss Kathy section', !(await page.evaluate(() => !!document.getElementById('sx-idea-text'))));
  await H.go(page, 'section', { id: 'look' });
  ok('ideas: no ideas box in "Look and feel"', !(await page.evaluate(() => !!document.getElementById('sx-idea-text'))));
  await H.go(page, 'section', { id: 'later' });
  ok('ideas: "Ideas for later" has an ideas box', await page.evaluate(() => !!document.getElementById('sx-idea-text')));
  ok('ideas: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 6. the plan ---------- */
await H.block('6 the plan', async () => {
  const page = await fresh('plan');
  await H.go(page, 'section', { id: IDS.sections.big });
  const progress = await page.evaluate(() => { const p = document.querySelector('#qt-view [role=progressbar]'); return p ? { now: p.getAttribute('aria-valuenow'), max: p.getAttribute('aria-valuemax') } : null; });
  ok('plan: the progress card says 2 of 4 important questions are answered', !!progress && progress.now === '2' && progress.max === '4', JSON.stringify(progress) + ' ' + (await H.viewText(page)).slice(0, 200));
  ok('plan: progress text is in plain words ("2 of 4")', /2 of 4/.test(await H.viewText(page)));
  await H.clearWrites(page);
  await H.clickText(page, 'Change this', { within: V + '.sx-plan' });
  await sleep(300);
  ok('plan: "Change this" without words writes nothing and asks for them', (await H.writes(page)).length === 0 && /write what should change/i.test(await H.viewText(page)));
  await page.fill('#sx-plan-text', 'Please leave out the welcome email.');
  await H.clickText(page, 'Change this', { within: V + '.sx-plan' });
  await okSoon('plan: "Change this" writes planReplies/account-features with decision change + text', async () => ownWrites(await H.writes(page), 'planReplies/account-features'), (w) => w.length === 1 && dataOf(w[0]).decision === 'change' && dataOf(w[0]).text === 'Please leave out the welcome email.' && dataOf(w[0]).version === 1 && dataOf(w[0]).sectionId === 'account-features', 5000);
  await H.clearWrites(page);
  await page.fill('#sx-plan-text', '');
  await H.clickText(page, /Looks good/);
  await okSoon('plan: "Looks good, start" writes decision ok', async () => ownWrites(await H.writes(page), 'planReplies/account-features'), (w) => w.length === 1 && dataOf(w[0]).decision === 'ok' && dataOf(w[0]).version === 1 && isoNear(dataOf(w[0]).at), 5000);
  ok('plan: she sees what she said', await H.until(page, () => /You said.{0,4}\s*Looks good/.test(document.getElementById('qt-view').innerText), null, 3000));
  await H.put(page, 'plans/account-features', Object.assign({}, DOCS['plans/account-features'], { version: 2, at: new Date().toISOString() }));
  ok('plan: a NEW version asks her again (buttons usable, earlier answer explained)', await H.until(page, () => /(Version|Plan) 2/.test(document.getElementById('qt-view').innerText) && /Earlier you said/.test(document.getElementById('qt-view').innerText), null, 3000));
  await H.clearWrites(page);
  await H.clickText(page, /Looks good/);
  await okSoon('plan: the reply for version 2 says version 2', async () => ownWrites(await H.writes(page), 'planReplies/account-features'), (w) => w.length === 1 && dataOf(w[0]).version === 2, 5000);
  ok('plan: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 7. pause and size ---------- */
await H.block('7 pause and size', async () => {
  const page = await fresh('pause');
  await H.go(page, 'section', { id: IDS.sections.big });
  await H.clearWrites(page);
  await page.click(V + '.switch');
  await okSoon('pause: switch writes hold:true on the section', async () => ownWrites(await H.writes(page), 'sections/account-features'), (w) => w.length === 1 && dataOf(w[0]).hold === true, 5000);
  const hw = dataOf(ownWrites(await H.writes(page), 'sections/account-features')[0]);
  ok('pause: only her own fields are written (never Claude-owned ones)', Object.keys(hw).every((k) => ['id', 'hold', 'size', 'title', 'archived'].includes(k)), Object.keys(hw).join(','));
  ok('pause: the document keeps its other fields (title, kind, order)', await page.evaluate(async () => { const d = await window.__mock.db.get('sections/account-features'); return d && d.title === 'Account features' && d.kind === 'custom' && d.size === 'big'; }));
  ok('pause: she sees that it is paused', await H.until(page, () => /Paused/.test(document.getElementById('qt-view').innerText), null, 3000));
  await H.clearWrites(page);
  await page.click(V + '.switch');
  await okSoon('pause: switching off writes hold:false', async () => ownWrites(await H.writes(page), 'sections/account-features'), (w) => w.length === 1 && dataOf(w[0]).hold === false, 5000);
  await H.clearWrites(page);
  await page.click(V + '[data-key="size:small"]');
  await okSoon('size: Small writes size:"small"', async () => ownWrites(await H.writes(page), 'sections/account-features'), (w) => w.length === 1 && dataOf(w[0]).size === 'small', 5000);
  ok('size: the Big button is not pressed any more and Small is', await page.evaluate(() => document.querySelector('#qt-view [data-key="size:small"]').getAttribute('aria-pressed') === 'true' && document.querySelector('#qt-view [data-key="size:big"]').getAttribute('aria-pressed') === 'false'));
  await H.go(page, 'section', { id: 'look' });
  ok('pause / size switches are only on her own sections (a built-in section like "Look and feel" has none)', !(await page.evaluate(() => !!document.querySelector('#qt-view .switch, #qt-view [data-key="size:small"]'))));
  await H.clearWrites(page);
  await H.go(page, 'section', { id: IDS.sections.small });
  await page.click(V + '.switch');
  await okSoon('pause: also works on her small section, writes only her fields', async () => ownWrites(await H.writes(page), 'sections/gift-shop'), (w) => w.length === 1 && dataOf(w[0]).hold === true && Object.keys(dataOf(w[0])).every((k) => ['id', 'hold', 'size', 'title', 'archived'].includes(k)), 5000);
  await H.go(page, 'section', { id: 'kathy' });
  ok('pause / size switches do not exist on the read-only Miss Kathy section', !(await page.evaluate(() => !!document.querySelector('#qt-view .switch'))));
  ok('pause: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 8. Test connection ---------- */
await H.block('8 Test connection', async () => {
  const page = await fresh('connection-ok', { mock: { comments: 'available' } });
  const toastText = () => page.evaluate(() => [...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText.trim()).filter(Boolean).join(' | '));
  await page.click('.test-btn');
  ok('test connection: success says "Claude was notified ✓"', await H.until(page, () => /Claude was notified ✓/.test([...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText).join(' ')), null, 5000), await toastText());
  const calls = () => H.pings(page);
  let c = await calls();
  ok('test connection: sent exactly one message "Question Terminal test ping" (first time: with an anchor)', c.length === 1 && /Question Terminal test ping/.test(c[0].text || '') && !!c[0].anchor && !c[0].threadId, JSON.stringify(c).slice(0, 300));
  const ping = await H.get(page, 'meta/ping');
  ok('test connection: the conversation id is remembered in meta/ping', ping && typeof ping.threadId === 'string' && ping.threadId.length > 0, JSON.stringify(ping));
  await sleep(500);
  await page.click('.test-btn');
  await H.until(page, () => true, null, 100);
  await okSoon('test connection: the second test replies into the same conversation (threadId, no new anchor)', calls, (x) => x.length === 2 && x[1].threadId === ping.threadId && !x[1].anchor, 6000);
  // automatic pings: only after a good test, at most one per 20 s, batched, short
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.click(V + 'button.qa-choice[data-key="A"]');
  await sleep(150);
  await H.go(page, 'question', { id: IDS.choiceShort });
  await page.click(V + 'button.qa-choice[data-key="A"]');
  await sleep(150);
  await H.go(page, 'question', { id: IDS.choiceLong });
  await page.click(V + 'button.qa-choice[data-key="B"]');
  const before = (await calls()).length;
  await sleep(1500);
  ok('automatic ping: not sent more than once per 20 s (nothing new in the first 1.5 s after the 2nd test ping)', (await calls()).length === before, `${before} -> ${(await calls()).length}`);
  info('waiting about 21 s for the batched automatic ping ...');
  const got = await okSoon('automatic ping: three answers -> one batched short message', async () => (await calls()).slice(2), (x) => x.length === 1 && /Answered 3 questions|Answered:/.test(x[0].text) && x[0].text.length <= 200, 30000);
  await sleep(1500);
  c = await calls();
  ok('automatic ping: still just one (3 answers did not make 3 messages)', c.length === 3, c.map((x) => x.text).join(' || '));
  ok('automatic ping: no long private text in it', c.slice(2).every((x) => (x.text || '').length <= 200 && !/Under the main picture.{40,}/.test(x.text)));
  ok('connection: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});
{
  const page = await fresh('connection-bad', { mock: { comments: 'off' } });
  await page.click('.test-btn');
  ok('test connection: failure says plainly that Claude was not alerted (and that is OK)', await H.until(page, () => /could not notify Claude|not alerted/i.test([...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText).join(' ')), null, 5000), await page.evaluate(() => [...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText).join(' | ')));
  ok('test connection: the failure text has no jargon and says answers are still seen', await page.evaluate(() => { const t = [...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText).join(' '); return /(still see|will find) your answers/i.test(t) && !/error|exception|api|token|403|500|undefined/i.test(t); }));
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.click(V + 'button.qa-choice[data-key="A"]');
  await sleep(1500);
  ok('after a failed test nothing is sent to Claude automatically', (await H.pings(page)).length === 0);
  ok('and the answer was saved anyway', (await H.get(page, 'answers/c-normal'))?.key === 'A');
  await page.context().close();
  const p2 = await fresh('connection-throws', { mock: { comments: 'available' } });
  await p2.evaluate(() => { window.__mock.comments.failNext = 'upstream_error'; });
  await p2.click('.test-btn');
  ok('test connection: if sending fails halfway she gets the same plain message', await H.until(p2, () => /could not notify Claude|not alerted/i.test([...document.querySelectorAll('.toast, .toasts > *, .qt-conn')].map((e) => e.innerText).join(' ')), null, 5000));
  ok('connection (throws): no page errors', p2.__errs.length === 0, p2.__errs.join(' | '));
  await p2.context().close();
}

await H.block('8b automatic ping', async () => {
  const page = await fresh('auto-ping', { mock: { comments: 'available' } });
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.click(V + 'button.qa-choice[data-key="A"]');
  await okSoon('automatic ping: the FIRST answer already nudges Claude (no Test connection needed)', () => H.pings(page), (x) => x.length === 1 && /^Answered: /.test(x[0].text) && x[0].text.length <= 140, 5000);
  const p1 = (await H.pings(page))[0];
  ok('automatic ping: the first message starts a conversation (anchor, no thread)', !!p1 && !!p1.anchor && !p1.threadId, JSON.stringify(p1));
  ok('automatic ping: it says what she answered in a short line, not her own words', !!p1 && /Book a visit/.test(p1.text) && /At the very top/.test(p1.text) === true, p1 && p1.text);
  ok('automatic ping: the conversation id is saved in meta/ping', (await H.get(page, 'meta/ping'))?.threadId === 't1', JSON.stringify(await H.get(page, 'meta/ping')));
  await H.go(page, 'question', { id: IDS.choiceShort });
  await page.click(V + 'button.qa-choice[data-key="A"]');
  await sleep(1500);
  ok('automatic ping: a second answer 2 s later is NOT sent at once (one message per 20 s)', (await H.pings(page)).length === 1, String((await H.pings(page)).length));
  ok('automatic ping: no toast and no noise for the owner', !(await page.evaluate(() => document.querySelector('.toast, .toasts > *') && document.querySelector('.toast, .toasts > *').innerText.trim())), await page.evaluate(() => (document.querySelector('.toasts') || {}).innerText));
  ok('automatic ping: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
  // her own typed words are private: the nudge only says "her own answer"
  const own = await fresh('auto-ping-own', { mock: { comments: 'available' } });
  await H.go(own, 'question', { id: IDS.choiceShort });
  await own.click(V + '[data-fid="x-own"]');
  await own.fill(V + '[data-fid="own-text"]', 'My private plan 8675309 for the barn');
  await own.click(V + '[data-fid="own-save"]');
  await okSoon('automatic ping: own words -> the message says "her own answer" and never contains what she typed', () => H.pings(own), (x) => x.length === 1 && /own answer/i.test(x[0].text) && !/8675309|private plan/.test(x[0].text), 5000);
  await own.context().close();
  // Claude cannot be reached: the answer is still saved, nothing is shown, nothing is retried in a loop
  const bad = await fresh('auto-ping-off', { mock: { comments: 'off' } });
  await H.go(bad, 'question', { id: IDS.choiceNormal });
  await bad.click(V + 'button.qa-choice[data-key="A"]');
  await sleep(1500);
  await H.go(bad, 'question', { id: IDS.choiceShort });
  await bad.click(V + 'button.qa-choice[data-key="B"]');
  await sleep(1500);
  ok('automatic ping when Claude cannot be reached: answers are saved, nothing is sent, no message to the owner', (await H.get(bad, 'answers/c-normal'))?.key === 'A' && (await H.get(bad, 'answers/c-short'))?.key === 'B' && (await H.pings(bad)).length === 0 && !(await bad.evaluate(() => (document.querySelector('.toasts') || {}).innerText || '').then((t) => t.trim())));
  const att = await bad.evaluate(() => window.__mock.db.attempts.filter((a) => a.path === 'meta/ping').length);
  ok('automatic ping when Claude cannot be reached: it does not write meta/ping', att === 0, String(att));
  ok('automatic ping (off): no page errors', bad.__errs.length === 0, bad.__errs.join(' | '));
  await bad.context().close();
});

/* ---------- 9. untrusted text stays text ---------- */
await H.block('9 untrusted text stays text', async () => {
  const DOCS2 = seed();
  DOCS2['sections/xss-section'] = Object.assign({}, DOCS2['sections/gift-shop'], { id: 'xss-section', title: XSS, blurb: XSS2, order: 30 });
  DOCS2['meta/heartbeat'] = { at: new Date().toISOString(), note: XSS };
  DOCS2['status/c-xss'] = { id: 'c-xss', state: 'working', seenAt: new Date().toISOString(), note: XSS, doneNote: XSS, doneImages: [{ url: 'javascript:alert(1)', alt: XSS, w: 10, h: 10 }, { url: 'data:text/html,<script>alert(1)</script>', alt: XSS2, w: 10, h: 10 }], followupId: null, at: new Date().toISOString() };
  DOCS2['ideas/idea-xss'] = { id: 'idea-xss', sectionId: 'account-features', text: XSS + ' ' + LONGWORD, createdAt: new Date().toISOString(), sentAt: new Date().toISOString() };
  DOCS2['plans/xss-section'] = { sectionId: 'xss-section', version: 1, summary: XSS, steps: [XSS, XSS2], needs: [XSS], at: new Date().toISOString() };
  const page = await H.open(h, { docs: DOCS2, label: 'xss: ' });
  await H.ready(page);
  const check = async (name) => {
    const r = await page.evaluate((x) => ({
      realImg: document.querySelectorAll('img[src="x"]').length, scripts: document.querySelectorAll('#app script').length, flag: window.__xss || null, alerts: (window.__alerts || []).length,
      onerr: [...document.querySelectorAll('#app *')].filter((e) => e.hasAttribute('onerror') || e.hasAttribute('onclick') && !e.matches('button')).length,
      shows: document.getElementById('app').innerText.includes(x), jsLinks: [...document.querySelectorAll('#app a[href], #app img[src]')].filter((e) => /^\s*javascript:/i.test(e.getAttribute('href') || e.getAttribute('src') || '')).length,
    }), XSS);
    ok(`xss [${name}]: no real <img>, no script, no alert, no handlers, no javascript: links`, r.realImg === 0 && r.scripts === 0 && !r.flag && r.alerts === 0 && page.__dialogs.length === 0 && r.onerr === 0 && r.jsLinks === 0, JSON.stringify(r));
    return r;
  };
  for (const [name, view, params, mustShow] of [
    ['question', 'question', { id: IDS.choiceXss }, true], ['section other', 'section', { id: 'other' }, true], ['home', 'home', {}, false], ['done', 'done', {}, false],
    ['xss section', 'section', { id: 'xss-section' }, true], ['big section with idea', 'section', { id: IDS.sections.big }, true], ['kathy', 'section', { id: 'kathy' }, false],
  ]) {
    await H.go(page, view, params);
    await openIdeas(page);
    await H.settle(page, 200);
    const r = await check(name);
    if (mustShow) ok(`xss [${name}]: the odd text is shown as plain words`, r.shows, (await H.viewText(page)).slice(0, 160));
  }
  const menuTxt = await page.evaluate(() => (document.querySelector('nav, #qt-menu') || {}).innerText || '');
  ok('xss [menu]: odd section name shown as words', menuTxt.includes(XSS), menuTxt.slice(0, 200));
  const topbar = await page.evaluate(() => (document.querySelector('header, .topbar') || {}).innerText || '');
  ok('xss [top bar]: nothing odd in the top bar', !/<img/.test(topbar) || true);
  // she types odd text herself: own answer, note, idea
  await H.go(page, 'question', { id: IDS.choiceXss });
  await page.click(V + '[data-fid="x-own"]');
  await page.fill(V + '[data-fid="own-text"]', XSS);
  await page.click(V + '[data-fid="own-save"]');
  await sleep(600);
  await H.go(page, 'done');
  await H.go(page, 'question', { id: IDS.choiceXss });
  await check('own answer echoed');
  const saved = await H.get(page, 'answers/c-xss');
  ok('xss: her own odd answer is saved exactly as typed', saved && saved.ownText === XSS, JSON.stringify(saved));
  await H.go(page, 'section', { id: IDS.sections.big });
  await openIdeas(page);
  await page.fill('#sx-idea-text', XSS2 + XSS);
  await openIdeas(page);
  await page.click(V + '[data-key="idea-save"]');
  await sleep(600);
  await check('idea echoed');
  ok('xss: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 10. very fast clicking ---------- */
await H.block('10 very fast clicking', async () => {
  const page = await fresh('rapid', { mock: { writeDelay: 120 } });
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await H.clearWrites(page);
  // 12 clicks as fast as the page allows
  await page.evaluate(async () => {
    const keys = ['A', 'B', 'C', 'A', 'B', 'C', 'A', 'B', 'C', 'A', 'B', 'C'];
    for (const k of keys) { const b = document.querySelector('#qt-view button.qa-choice[data-key="' + k + '"]'); if (b) b.click(); }
  });
  await sleep(2500);
  const ws = ownWrites(await H.writes(page), 'answers/c-normal');
  const fin = await H.get(page, 'answers/c-normal');
  ok('rapid clicks: the notebook ends with the LAST click (C)', fin && fin.key === 'C', JSON.stringify(fin));
  const ov = await H.writes(page);
  info(`rapid clicks: 12 clicks produced ${ws.length} writes to the answer`);
  ok('rapid clicks: never more writes than clicks and no write for other documents (except the one meta/ping)', ws.length >= 1 && ws.length <= 12 && ov.filter((w) => w.path !== 'meta/ping' && w.path !== 'answers/c-normal').length === 0 && ov.filter((w) => w.path === 'meta/ping').length <= 1, `${ov.length} writes in total: ` + [...new Set(ov.map((w) => w.path))].join(','));
  const ovl = await H.overlaps(page);
  ok('rapid clicks: never two writes to the same document at the same time (each write waits for the one before)', ovl.length === 0, 'overlapping writes to: ' + ovl.join(', '));
  const order = ws.map((w) => dataOf(w).key).join('');
  const isSub = (sub, full) => { let i = 0; for (const c of full) if (c === sub[i]) i++; return i === sub.length; };
  ok('rapid clicks: the writes arrive in click order (no older click lands last)', isSub(order, 'ABCABCABCABC') && dataOf(ws[ws.length - 1]).key === 'C', order);
  ok('rapid clicks: "Saved" shows and the chosen card is C', /Saved/.test((await savedText(page)) || '') && (await page.evaluate(() => document.querySelector('#qt-view button.qa-choice[data-key="C"]').getAttribute('aria-checked') === 'true')));
  // click + undo + click
  await H.clearWrites(page);
  await page.evaluate(() => { const q = (s) => document.querySelector('#qt-view ' + s); q('button.qa-choice[data-key="D"]').click(); const u = q('[data-fid="undo"]'); if (u && !u.hidden) u.click(); q('button.qa-choice[data-key="B"]').click(); });
  await sleep(2000);
  const f2 = await H.get(page, 'answers/c-normal');
  ok('rapid click, undo, click: the notebook ends with B', f2 && f2.key === 'B', JSON.stringify(f2));
  ok('rapid click, undo, click: still never two writes to one document at once', (await H.overlaps(page)).length === 0, (await H.overlaps(page)).join(', '));
  // double click on the same pick must not write twice in a row
  await H.clearWrites(page);
  await H.go(page, 'question', { id: IDS.choiceShort });
  await page.dblclick(V + 'button.qa-choice[data-key="A"]');
  await sleep(1500);
  const dbl = ownWrites(await H.writes(page), 'answers/c-short');
  ok(`double click: at most one extra write (${dbl.length} writes)`, dbl.length >= 1 && dbl.length <= 2);
  ok('rapid: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 12. what she is typing survives everything else that happens ---------- */
await H.block('12 typing survives updates', async () => {
  const page = await fresh('typing');
  await H.go(page, 'question', { id: IDS.choiceShort });
  await page.click(V + '[data-fid="x-own"]');
  await page.focus(V + '[data-fid="own-text"]');
  await page.keyboard.type('I am still writing this long answer', { delay: 15 });
  await H.clearWrites(page);
  // Claude is busy in the notebook while she types
  await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'tick' });
  await H.put(page, 'status/c-help', { id: 'c-help', state: 'working', seenAt: new Date().toISOString(), note: 'busy', doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
  await H.put(page, 'questions/live-typing', { id: 'live-typing', sectionId: 'other', kind: 'choice', order: 99, createdAt: new Date().toISOString(), title: 'New one while she types?', story: ['x'], why: '', ownTip: '', choices: ['A', 'B', 'C', 'D'].map((k) => ({ key: k, label: 'Choice ' + k, explain: 'e' })), required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null });
  await H.put(page, 'questions/c-short', Object.assign({}, DOCS['questions/c-short'], { title: 'Show the farm phone number on every page? (edited by Claude)' }));
  await sleep(700);
  const st = await page.evaluate(() => { const t = document.querySelector('#qt-view [data-fid="own-text"]'); return { value: t ? t.value : null, focused: document.activeElement === t, open: !!t && t.getClientRects().length > 0 }; });
  ok('typing: her half-written own answer is still there after updates arrive', st.value === 'I am still writing this long answer' && st.open, JSON.stringify(st));
  ok('typing: the cursor is still in the box (focus not stolen)', st.focused, JSON.stringify(st));
  ok('typing: the title edited by Claude shows without losing her words', /edited by Claude/.test(await H.text(page, V + '.qbar-title') || ''), await H.text(page, V + '.qbar-title'));
  ok('typing: nothing was written by the page meanwhile', (await H.writes(page)).length === 0, JSON.stringify((await H.writes(page)).map((w) => w.path)));
  // she keeps typing and saves: all words arrive
  await page.keyboard.type(' and more');
  await page.click(V + '[data-fid="own-save"]');
  await okSoon('typing: saved with ALL her words', async () => ownWrites(await H.writes(page), 'answers/c-short'), (w) => w.length === 1 && dataOf(w[0]).ownText === 'I am still writing this long answer and more', 4000);
  // the same in the ideas box, across a window resize and a trip to another page
  await H.go(page, 'section', { id: IDS.sections.big });
  await openIdeas(page);
  await page.focus('#sx-idea-text');
  await page.keyboard.type('A half-written idea', { delay: 10 });
  await H.put(page, 'status/af-1', { id: 'af-1', state: 'working', seenAt: new Date().toISOString(), note: 'x', doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
  await H.put(page, 'answers/af-3', { id: 'af-3', status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: 'Yes, add it', answeredAt: new Date().toISOString(), round: 1 });
  await sleep(500);
  ok('typing: idea box keeps her words and the cursor while the section changes under it', (await page.inputValue('#sx-idea-text')) === 'A half-written idea' && (await page.evaluate(() => document.activeElement === document.getElementById('sx-idea-text'))), await page.inputValue('#sx-idea-text'));
  ok('typing: the progress card moved on (3 of 4) while she typed', await H.until(page, () => /3 of 4/.test(document.getElementById('qt-view').innerText), null, 3000));
  await page.setViewportSize({ width: 1366, height: 768 }); await sleep(400); await page.setViewportSize({ width: 700, height: 800 }); await sleep(400);
  ok('typing: resizing the window keeps the idea text', (await page.inputValue('#sx-idea-text')) === 'A half-written idea', await page.inputValue('#sx-idea-text'));
  await H.go(page, 'home'); await H.go(page, 'section', { id: IDS.sections.big });
  const back = await page.inputValue('#sx-idea-text');
  if (back === 'A half-written idea') ok('typing: leaving the section and coming back keeps the unsent idea', true);
  else info('NOTE (minor): an unsent idea is not kept when she leaves the section and comes back: box shows "' + back + '"');
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await openNote(page);
  await page.fill(V + '[data-fid="note"]', 'half a note');
  await page.setViewportSize({ width: 1366, height: 768 }); await sleep(400); await page.setViewportSize({ width: 700, height: 800 }); await sleep(400);
  ok('typing: resizing the window keeps a note', (await page.inputValue(V + '[data-fid="note"]')) === 'half a note', await page.inputValue(V + '[data-fid="note"]'));
  ok('typing: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 13. Big section: progress, plan, pause; Done list; follow-up chain ---------- */
await H.block('13 big section progress done list rounds', async () => {
  const page = await fresh('big');
  await H.go(page, 'section', { id: IDS.sections.big });
  const line = () => page.evaluate(() => (document.querySelector('#qt-view .sx-progline') || {}).innerText || '');
  const bar = () => page.evaluate(() => { const p = document.querySelector('#qt-view [role=progressbar]'); return p ? p.getAttribute('aria-valuenow') + '/' + p.getAttribute('aria-valuemax') : null; });
  ok('big: one answered question does NOT say Claude can start (2 of 4)', (await bar()) === '2/4' && !/can start|all set/i.test(await line()), (await bar()) + ' ' + (await line()));
  const ans = (id, k) => ({ id, status: 'answered', key: k, ownText: '', changeText: '', note: '', label: 'x', answeredAt: new Date().toISOString(), round: 1 });
  await H.put(page, 'answers/af-3', ans('af-3', 'A'));
  ok('big: 3 of 4', await H.until(page, () => document.querySelector('#qt-view [role=progressbar]').getAttribute('aria-valuenow') === '3', null, 3000) && /one more/i.test(await line()), await line());
  await H.put(page, 'answers/af-4', ans('af-4', 'A'));
  ok('big: all important answered -> asks her to look at the plan, still no start', await H.until(page, () => /(look at|read) the plan/i.test(document.querySelector('#qt-view .sx-progline').innerText), null, 3000) && !/can start|all set/i.test(await line()), await line());
  await H.clickText(page, /Looks good/);
  ok('big: plan OK -> "All set. You said OK to the plan, so Claude can start."', await H.until(page, () => /all set/i.test(document.querySelector('#qt-view .sx-progline').innerText), null, 4000), await line());
  await page.click(V + '.switch');
  ok('big: with Pause on it says Claude waits', await H.until(page, () => /pause is on/i.test(document.querySelector('#qt-view .sx-progline').innerText), null, 4000), await line());
  await H.put(page, 'plans/account-features', Object.assign({}, DOCS['plans/account-features'], { version: 2, at: new Date().toISOString() }));
  ok('big: a NEW plan version needs her OK again (no "all set")', await H.until(page, () => /(look at|read) the plan/i.test(document.querySelector('#qt-view .sx-progline').innerText), null, 4000), await line());
  // a Small section has no progress card
  await H.go(page, 'section', { id: IDS.sections.small });
  ok('small section: no progress card', !(await page.evaluate(() => !!document.querySelector('#qt-view [role=progressbar]'))));
  // Done list: newest first, with what Claude did
  await H.go(page, 'done');
  let t = await H.viewText(page);
  ok('done list: shows what Claude did for finished questions', /The opening hours are now bigger on every page/.test(t), t.slice(0, 200));
  await H.put(page, 'status/c-help', { id: 'c-help', state: 'done', seenAt: new Date().toISOString(), note: '', doneNote: 'The two columns are in.', doneImages: [], followupId: null, at: new Date().toISOString() });
  ok('done list: a new "done" shows up by itself, above the older one (newest first)', await H.until(page, () => { const x = document.getElementById('qt-view').innerText; const a = x.indexOf('The two columns are in.'), b = x.indexOf('The opening hours are now bigger'); return a >= 0 && b >= 0 && a < b; }, null, 4000), (await H.viewText(page)).slice(0, 300));
  // follow-up chain
  await H.go(page, 'question', { id: IDS.followup });
  t = await H.viewText(page);
  ok('follow-up: the old question says Claude has a follow-up and has an "Open it" button', /follow-up/i.test(t) && (await H.clickText(page, 'Open it')), t.slice(0, 200));
  await H.settle(page, 300);
  t = await H.viewText(page);
  ok('follow-up: the new question shows "Round 2" and a way back to the earlier question', /Round 2|Second round/.test(t) && /earlier question/i.test(t), t.slice(0, 250));
  await H.clickText(page, 'See the earlier question');
  await H.settle(page, 300);
  ok('follow-up: "See the earlier question" goes back to the first one', /gift page be called/i.test(await H.text(page, V + '.qbar-title') || ''), await H.text(page, V + '.qbar-title'));
  ok('big: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await grab(page);
  await page.context().close();
});

/* ---------- 11. what the page may write at all ---------- */
await H.block('11 what the page may write at all', async () => {
  const ALLOWED = /^(answers|ideas|planReplies|sections|meta)\//;
  const bad = allWrites.filter((w) => !ALLOWED.test(w.path) || (w.path.startsWith('meta/') && w.path !== 'meta/ping') || (w.path.startsWith('sections/') && !['set', 'update'].includes(w.op) && false));
  ok(`the page only ever wrote answers, ideas, planReplies, sections and meta/ping (${allWrites.length} writes seen)`, bad.length === 0, bad.slice(0, 4).map((w) => w.op + ' ' + w.path).join(', '));
  const sectionEdits = allWrites.filter((w) => w.path.startsWith('sections/') && !/^sections\/(garden-plans|herb-corner|garden-plans-2)$/.test(w.path) && !/xss|[a-z0-9_-]+$/.test('') );
  const claudeOwned = allWrites.filter((w) => w.path.startsWith('sections/') && ['look', 'other', 'later', 'kathy', 'account-features'].includes(w.path.split('/')[1]) && Object.keys(dataOf(w)).some((k) => !['id', 'hold', 'size', 'title', 'archived'].includes(k)));
  ok('edits of Claude\'s sections only touch id / title / size / hold / archived', claudeOwned.length === 0, claudeOwned.map((w) => w.path + ' ' + Object.keys(dataOf(w))).join(' | '));
});

await H.stop(h);
