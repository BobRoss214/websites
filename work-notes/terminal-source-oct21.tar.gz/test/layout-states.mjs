/* Layout states: menu drop-down, dark, offline, stale heartbeat, long title, sticky bar, toasts, keyboard.  Port 9201. */
import path from 'node:path';
import { startServer, launch, ok, info, finish } from './lib.mjs';
import { T } from './harness.mjs';
const SHOTS = path.join(T, 'shots');
const site = await startServer({ root: T, port: 9201 });
const browser = await launch();
const errs = [];
async function open(w, h, qs = '', scheme = 'light') {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: scheme });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/view failed/.test(m.text())) errs.push('console ' + m.text()); });
  await p.goto(site.url + 'test/layout-harness.html' + (qs ? '?' + qs : ''));
  await p.waitForSelector('#qt-view h1', { timeout: 5000 });
  return p;
}
const shot = (p, n) => p.screenshot({ path: path.join(SHOTS, `layout-${n}.png`) });
const noHScroll = async (p, name) => { const o = await p.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]); ok(name + ': no horizontal scroll', o[0] <= o[1], o.join('/')); };

// 1. drop-down menu at 700 and 400
for (const w of [700, 400]) {
  const p = await open(w, 800, 'view=question');
  ok(`${w}: menu is hidden at first`, !(await p.locator('#qt-menu').isVisible()));
  await p.click('.menu-btn');
  ok(`${w}: menu opens`, await p.locator('#qt-menu').isVisible());
  ok(`${w}: aria-expanded true`, (await p.getAttribute('.menu-btn', 'aria-expanded')) === 'true');
  const box = await p.locator('#qt-menu').boundingBox();
  ok(`${w}: menu inside the window`, box.x >= 0 && box.x + box.width <= w && box.y + box.height <= 800, JSON.stringify(box));
  await shot(p, `menu-open-${w}`);
  await p.keyboard.press('Escape');
  ok(`${w}: Esc closes menu`, !(await p.locator('#qt-menu').isVisible()));
  ok(`${w}: focus back on the menu button`, await p.evaluate(() => document.activeElement.classList.contains('menu-btn')));
  await p.click('.menu-btn'); await p.click('#qt-menu [data-key="s:other"]');
  ok(`${w}: choosing an item closes the menu and goes there`, !(await p.locator('#qt-menu').isVisible()) && (await p.locator('#qt-view h1').textContent()) === 'Other questions');
  await p.click('.menu-btn'); await p.mouse.click(w - 10, 700);
  ok(`${w}: click outside closes menu`, !(await p.locator('#qt-menu').isVisible()));
  await noHScroll(p, `menu ${w}`);
  await p.context().close();
}
// menu closes when the window grows
{
  const p = await open(700, 800); await p.click('.menu-btn'); await p.setViewportSize({ width: 1000, height: 800 }); await p.waitForTimeout(150);
  ok('growing the window shows the side menu and drops the drop-down state', (await p.locator('#qt-menu').isVisible()) && !(await p.evaluate(() => document.querySelector('#qt-menu').classList.contains('open'))));
  ok('menu button hidden when wide', !(await p.locator('.menu-btn').isVisible()));
  await p.context().close();
}
// 2. dark + offline + stale
{
  const p = await open(700, 800, 'view=question&theme=dark&stale=1&chip=' + encodeURIComponent('You answered · waiting for Claude to see it'));
  await shot(p, 'dark-question-700x800'); await noHScroll(p, 'dark'); await p.context().close();
  const p2 = await open(700, 800, 'view=home&theme=dark&offline=1'); await shot(p2, 'dark-offline-700x800');
  ok('offline: banner shown', await p2.locator('#qt-offline').isVisible());
  ok('offline: Offline label', (await p2.locator('.live').textContent()).trim() === 'Not connected');
  ok('offline: menu still lists the built-in sections', (await p2.locator('#qt-menu .mi').count()) >= 6);
  await p2.context().close();
  const p3 = await open(1366, 768, 'view=home&offline=1'); await shot(p3, 'offline-1366x768'); await p3.context().close();
  const p4 = await open(1366, 768, 'view=question&stale=1&theme=dark&many=1'); await shot(p4, 'dark-stale-many-1366x768');
  const mb = await p4.evaluate(() => { const m = document.querySelector('#qt-menu'); return [m.scrollHeight, m.clientHeight]; });
  info('menu scroll heights with many sections ' + mb.join('/'));
  await p4.context().close();
}
// 3. long title + sticky bar while scrolling
{
  const t = 'Which of these four pictures should we use at the very top of the home page where people see the pizza first?';
  const p = await open(700, 800, 'view=question&long=1&title=' + encodeURIComponent(t) + '&chip=' + encodeURIComponent('You answered · waiting for Claude to see it'));
  await shot(p, 'long-title-700x800');
  await p.evaluate(() => window.scrollTo(0, 600));
  await p.waitForTimeout(100);
  const r = await p.evaluate(() => { const b = document.querySelector('.qbar').getBoundingClientRect(); const t = document.querySelector('.topbar').getBoundingClientRect(); return { qtop: b.top, qh: b.height, tb: t.bottom, ty: t.top }; });
  ok('sticky: qbar stays right under the top bar after scrolling', Math.abs(r.qtop - r.tb) < 1.5 && r.ty === 0, JSON.stringify(r));
  info('qbar height (long title + long chip): ' + Math.round(r.qh));
  await shot(p, 'scrolled-700x800'); await noHScroll(p, 'long'); await p.context().close();
}
// 4. toasts, test connection, sound
{
  const p = await open(700, 800, 'view=home');
  await p.evaluate(() => QT.emit('writeerror', { error: 'x' }));
  ok('writeerror shows the friendly toast', (await p.locator('.toast').first().textContent()).includes('Not saved. Your words are still here. Please try again.'));
  await p.evaluate(() => QT.emit('writeerror', {}));
  ok('same toast is not stacked', (await p.locator('.toast').count()) === 1);
  await p.click('.test-btn'); ok('test button is busy while testing', await p.locator('.test-btn').isDisabled());
  await p.waitForSelector('.toast:has-text("Claude heard you")');
  ok('test result shown as a toast', true); await shot(p, 'toasts-700x800');
  ok('test button works again', await p.locator('.test-btn').isEnabled());
  ok('sound starts off', (await p.getAttribute('.sound-btn', 'aria-pressed')) === 'false');
  await p.click('.sound-btn');
  ok('sound toggle turns on and chimes once', (await p.getAttribute('.sound-btn', 'aria-pressed')) === 'true' && (await p.evaluate(() => window.__chimes)) === 1);
  await p.click('.sound-btn');
  ok('sound toggle turns off without a chime', (await p.getAttribute('.sound-btn', 'aria-pressed')) === 'false' && (await p.evaluate(() => window.__chimes)) === 1);
  await p.context().close();
}
// 5. routing: cleanup runs, views are not re-rendered on store events
{
  const p = await open(700, 800, 'view=home');
  await p.waitForTimeout(300);
  const res = await p.evaluate(async () => {
    let cleaned = 0, renders = 0;
    QT.views.home = (el) => { renders++; el.appendChild(Object.assign(document.createElement('h1'), { textContent: 'H' })); return () => { cleaned++; }; };
    QT.route.go('home');
    await new Promise((r) => setTimeout(r, 200));
    const a = renders;
    QT.emit('store', { collection: 'answers', ids: ['x'], initial: false });
    await new Promise((r) => setTimeout(r, 200));
    const b = renders;
    QT.route.go('done'); await new Promise((r) => setTimeout(r, 200));
    return { a, b, cleaned, title: document.querySelector('#qt-view h1').textContent };
  });
  ok('store events do not re-render the view', res.a === res.b, JSON.stringify(res));
  ok('previous view cleanup is called on route change', res.cleaned === 1 && res.title === 'Done', JSON.stringify(res));
  const bad = await p.evaluate(async () => { QT.views.question = () => { throw new Error('boom'); }; QT.route.go('question', { id: 'x' }); await new Promise((r) => setTimeout(r, 100)); return document.querySelector('#qt-view').textContent; });
  ok('a view that throws shows a friendly message', /Something went wrong/.test(bad), bad);
  await p.context().close();
}
await finish({ browser, site, errs });
