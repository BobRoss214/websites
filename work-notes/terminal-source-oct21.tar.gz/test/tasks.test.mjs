/* Tasks part test (SPEC2 section 6).   NODE_PATH=/opt/node22/lib/node_modules node T/test/tasks.test.mjs      Ports 9756+.
 * The how-to card, the summary and filters, search, the tree (roles, keys, folding finished branches, Open all / Close all), what a node says (state, progress,
 * workers, pending chips, links to questions), the detail panel, adding / changing / pausing / removing / asking (the exact writes and the chips that follow),
 * the map view when it exists, empty / offline / odd data.   It builds the page from T/src into its own snapshot.
 */
import { H, ok, info, seed, IDS, IDS2, sleep, partsDocs, openParts, tabsInfo, currentPart, textOf, unsafeReport } from './parts-lib.mjs';
import { okSoon } from './harness.mjs';
import { XSS } from './fixtures.mjs';

const h = await H.start(9756, { src: true });
const DOCS = partsDocs();
const NOW = Date.now();
const node = (id) => `li.tk-node[data-id="${id}"]`;
const nodeText = (page, id) => page.evaluate((s) => { const e = document.querySelector(s); const c = e && (e.querySelector(':scope > .tk-card') || e); return c ? c.innerText.replace(/\s+/g, ' ').trim() : null; }, node(id));
const goTasks = async (page, params = {}) => { await H.go(page, 'tasks', params); await H.settle(page, 400); };
const writesTo = async (page, prefix) => (await H.writes(page)).filter((w) => w.path.startsWith(prefix));
const lis = (page) => page.evaluate(() => [...document.querySelectorAll('li.tk-node')].map((l) => ({ id: l.dataset.id, level: +l.getAttribute('aria-level'), exp: l.getAttribute('aria-expanded'), sel: l.getAttribute('aria-selected'), tab: l.tabIndex })));
const SHOWN = `(e) => { if (!e || !e.getClientRects().length) return false; for (let p = e; p && p !== document.body; p = p.parentElement) { const cs = getComputedStyle(p); if (cs.display === 'none' || cs.visibility === 'hidden' || p.hidden || p.inert || p.getAttribute('aria-hidden') === 'true') return false; if (p !== e && p.getBoundingClientRect().height < 2 && /(hidden|clip)/.test(cs.overflow + cs.overflowY)) return false; if (p.classList && p.classList.contains('tk-wrap') && p.getAttribute('data-open') === 'false') return false; } const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }`;
const shownIds = (page) => page.evaluate((src) => { const shown = eval(src); return [...document.querySelectorAll('li.tk-node')].filter(shown).map((l) => l.dataset.id); }, SHOWN);
const click = async (page, sel) => { await page.click(sel, { timeout: 8000 }); await H.settle(page, 250); };
const key = (k) => `[data-key="${k}"]`;
const select = async (page, id) => { await page.evaluate((s) => { const l = document.querySelector(s); if (l && l.getAttribute('aria-selected') !== 'true') { const c = l.querySelector(':scope > .tk-card'); c && c.click(); } }, node(id)); await H.settle(page, 350); };
const openAll = async (page) => { await page.click(key('openall')); await H.settle(page, 450); };
const panel = (page) => page.evaluate(() => { const d = document.querySelector('.tk-detail'); return d ? d.innerText.replace(/\s+/g, ' ').trim() : null; });
const panelBtns = (page) => page.evaluate(() => [...document.querySelectorAll('.tk-detail [data-key^="a-"]')].map((b) => b.dataset.key + ':' + b.innerText.trim()));
const stored = (page, p) => H.get(page, p);

/* ---------- 1. how-to, strip, filters, search ---------- */
await H.block('1 top of the page', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'top: ' });
  await goTasks(page);
  let t = await textOf(page);
  ok('"Tasks" title and a friendly line', /Tasks/.test(t) && /Everything Claude and the crew are working on/.test(t), t.slice(0, 100));
  ok('"How to read this" is open the first time: big idea, jobs, smaller jobs, the little bar, colours, tap a job, add / change / ask', ['A big idea sits at the top', 'It breaks into tasks', 'Tasks break into smaller tasks', 'When the small ones are done, the big one is done', 'To do', 'Working', 'Waiting for you, Miss Cathy or Rob', 'Done', 'Paused', 'Tap a task to open it', 'add a smaller task, change a task, or ask'].every((x) => t.includes(x)), t.slice(0, 600));
  ok('it says that nothing here changes the real website', /Nothing here changes your real website/.test(t));
  ok('a tiny drawing shows three levels (Big idea, Task, Smaller task)', await page.evaluate(() => document.querySelectorAll('.tk-ex-row').length >= 3));
  await page.evaluate(() => [...document.querySelectorAll('#qt-view button')].find((b) => /^Hide$/.test(b.innerText.trim()) || /Hide/.test(b.innerText)).click());
  await H.settle(page, 300);
  ok('"Hide" closes it', !/A big idea sits at the top/.test(await textOf(page)));
  await page.reload({ waitUntil: 'load' }); await H.ready(page); await goTasks(page);
  ok('it stays closed after a reload', !/A big idea sits at the top/.test(await textOf(page)));
  const strip = await page.evaluate(() => [...document.querySelectorAll('.tk-strip button, .tk-strip [role=button], .tk-strip > *')].map((b) => b.innerText.replace(/\s+/g, ' ').trim()));
  ok('summary strip: "6 Working now", "3 Waiting for you", "11 Done"', strip.some((x) => /^6 Working now/.test(x)) && strip.some((x) => /^3 Waiting for you/.test(x)) && strip.some((x) => /^11 Done/.test(x)), JSON.stringify(strip));
  ok('the three counters are buttons at least 40 px high', await page.evaluate(() => { const b = [...document.querySelectorAll('.tk-strip button')]; return b.length === 3 && b.every((x) => x.getBoundingClientRect().height >= 39.5); }));
  const seg = await page.evaluate(() => [...document.querySelectorAll('.tk-seg button')].map((b) => b.innerText.trim() + '|' + b.getAttribute('aria-pressed')));
  ok('filters All / Working / Waiting (anyone) / Done / Paused with counts (All 43, Working 6, Waiting (anyone) 8 = for you, Miss Cathy or Rob, Done 11, Paused 2); All is pressed', JSON.stringify(seg) === JSON.stringify(['All 43|true', 'Working 6|false', 'Waiting (anyone) 8|false', 'Done 11|false', 'Paused 2|false']), JSON.stringify(seg));
  // filter
  await click(page, key('f:waiting'));
  let ids = await shownIds(page);
  ok('"Waiting": the waiting tasks show, with the main ideas above them; done tasks are gone', ['t-map-b', 't-photos-1', 't-qs-2'].every((i) => ids.includes(i)) && !ids.includes('t-map-c') && !ids.includes('t-winter-1'), ids.join());
  await click(page, key('f:done'));
  ids = await shownIds(page);
  ok('"Done": the finished tasks show (t-winter and its jobs, t-map-c)', ids.includes('t-map-c') && (ids.includes('t-winter-1') || ids.includes('t-winter')), ids.join());
  await click(page, key('f:paused'));
  ids = await shownIds(page);
  ok('"Paused": the two paused tasks show (t-photos-3, and t-term-3 that she paused)', ids.includes('t-photos-3') && ids.includes('t-term-3'), ids.join());
  await click(page, key('f:all'));
  await page.click('.tk-strip button:nth-child(2)'); await H.settle(page, 300);
  ids = await shownIds(page);
  ok('tapping the "Waiting for you" counter filters to the tasks waiting for HER (t-map-b, t-label, t-label-2)', ids.includes('t-map-b') && ids.includes('t-label-2') && !ids.includes('t-photos-1'), ids.join());
  ok('and the counter shows that it is pressed', await page.evaluate(() => document.querySelector('.tk-strip button:nth-child(2)').getAttribute('aria-pressed') === 'true'));
  await page.click('.tk-strip button:nth-child(2)'); await H.settle(page, 300);
  ok('tapping it again clears the filter', (await shownIds(page)).includes('t-map-c'));
  // search
  await page.fill('#tk-search', 'pond'); await H.settle(page, 400);
  ids = await shownIds(page);
  ok('search "pond" finds her new task and shows the branch above it', ids.includes('u-pend-1') && ids.includes('t-map') && !ids.includes('t-winter-1'), ids.join());
  await page.fill('#tk-search', 'cheerful'); await H.settle(page, 400);
  ok('search also looks in the plain words ("cheerful" is in her edit of t-photos-2)', (await shownIds(page)).includes('t-photos-2'), (await shownIds(page)).join());
  await page.fill('#tk-search', 'no such thing'); await H.settle(page, 400);
  ok('nothing found: friendly "Nothing matches that." and a button to clear the search', /Nothing matches that/.test(await textOf(page)) && (await page.evaluate(() => !!document.querySelector('[data-key="clearf"]'))));
  await click(page, key('clearf'));
  ok('clearing brings everything back and empties the search box', (await shownIds(page)).includes('t-map-c') && (await page.inputValue('#tk-search')) === '');
  await H.shot(page, 'tasks-top-1366');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 2. the tree: roles, levels, folding, keyboard ---------- */
await H.block('2 the tree', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'tree: ' });
  await goTasks(page);
  const tree = await page.evaluate(() => { const t = document.querySelector('[role=tree]'); return { has: !!t, label: t && t.getAttribute('aria-label'), items: t ? t.querySelectorAll('[role=treeitem]').length : 0 }; });
  ok('the list is a tree (role=tree with a name) of treeitems', tree.has && tree.label && tree.items >= 40, JSON.stringify(tree));
  const L = Object.fromEntries((await lis(page)).map((x) => [x.id, x]));
  ok('levels are right: main idea 1, job 2, smaller job 3, then 4 and 5 (aria-level)', L['t-map'].level === 1 && L['t-map-a'].level === 2 && L['t-map-a1'].level === 3 && L['t-map-a1a'].level === 4 && L['t-map-a1b1'].level === 5, JSON.stringify([L['t-map'], L['t-map-a1b1']]));
  ok('parents say if they are open (aria-expanded); leaves have no aria-expanded', L['t-map'].exp === 'true' && L['t-map-a2'].exp === null, JSON.stringify([L['t-map'].exp, L['t-map-a2'].exp]));
  ok('finished branches fold themselves: "Winter tree game" is closed, its jobs are not on screen', L['t-winter'].exp === 'false' && !(await shownIds(page)).includes('t-winter-1'), JSON.stringify(L['t-winter']));
  ok('exactly one item is in the Tab order (roving tabindex)', (await lis(page)).filter((x) => x.tab === 0).length === 1);
  const sizes = await page.evaluate(() => { const l = document.querySelector('li.tk-node[data-id="t-map-b"]'); return { size: l.getAttribute('aria-setsize'), pos: l.getAttribute('aria-posinset') }; });
  ok('aria-setsize and aria-posinset are there (t-map-b is 2nd of 5 under t-map)', sizes.size === '5' && sizes.pos === '2', JSON.stringify(sizes));
  // folding by the caret
  await page.evaluate(() => document.querySelector('li.tk-node[data-id="t-map"] > .tk-card .tk-caret').click()); await H.settle(page, 400);
  ok('tapping the caret closes "Redraw the farm map" (its jobs leave the screen)', !(await shownIds(page)).includes('t-map-a') && (await lis(page)).find((x) => x.id === 't-map').exp === 'false');
  await page.evaluate(() => document.querySelector('li.tk-node[data-id="t-map"] > .tk-card .tk-caret').click()); await H.settle(page, 400);
  ok('tapping again opens it', (await shownIds(page)).includes('t-map-a'));
  await page.click(key('openall')); await H.settle(page, 500);
  ok('"Open all" opens every parent (aria-expanded is true on all, the winter jobs show)', (await lis(page)).filter((x) => x.exp !== null).every((x) => x.exp === 'true') && (await shownIds(page)).includes('t-winter-1'));
  await page.click(key('closeall')); await H.settle(page, 500);
  ok('"Close all" closes every parent: only the main ideas are on screen', (await lis(page)).filter((x) => x.exp !== null).every((x) => x.exp === 'false') && (await shownIds(page)).every((i) => L[i] ? L[i].level === 1 || i.startsWith('u-') : true), (await shownIds(page)).join());
  // keyboard
  await page.focus(node('t-map'));
  const focused = () => page.evaluate(() => (document.activeElement.dataset || {}).id || null);
  await page.keyboard.press('ArrowRight'); await H.settle(page, 250);
  ok('ArrowRight on a closed parent opens it', (await lis(page)).find((x) => x.id === 't-map').exp === 'true' && (await focused()) === 't-map', await focused());
  await page.keyboard.press('ArrowRight'); await H.settle(page, 250);
  ok('ArrowRight on an open parent moves to its first child', (await focused()) === 't-map-a', await focused());
  await page.keyboard.press('ArrowDown'); await page.keyboard.press('ArrowDown'); await H.settle(page, 200);
  ok('ArrowDown goes to the next task ON SCREEN: from the closed t-map-a, two steps reach t-map-c (its hidden jobs are skipped)', (await focused()) === 't-map-c', await focused());
  await page.keyboard.press('ArrowUp'); await H.settle(page, 200);
  const af = await focused();
  await page.keyboard.press('ArrowLeft'); await H.settle(page, 250);
  ok('ArrowLeft on a leaf (or closed one) moves to its parent', ['t-map', 't-map-a'].includes(await focused()), af + ' -> ' + (await focused()));
  await page.keyboard.press('Home'); ok('Home goes to the first task', (await focused()) === 't-map', await focused());
  await page.keyboard.press('End'); const last = (await shownIds(page)).slice(-1)[0]; ok('End goes to the last task on screen', (await focused()) === last, `${await focused()} vs ${last}`);
  await page.keyboard.press('Home'); await page.keyboard.press('Enter'); await H.settle(page, 400);
  ok('Enter opens the details of the task in focus (a panel with its title)', /Redraw the farm map/.test((await panel(page)) || '') && (await lis(page)).find((x) => x.id === 't-map').sel === 'true', String(await panel(page)).slice(0, 80));
  await page.keyboard.press('Enter'); await H.settle(page, 300);
  ok('Enter again closes the details', (await panel(page)) === null || !/Details/.test('') );
  await page.keyboard.press('*'); await H.settle(page, 300);
  ok('"*" opens all the main ideas next to it', (await lis(page)).filter((x) => x.level === 1 && x.exp !== null).every((x) => x.exp === 'true'));
  // tab order
  await page.evaluate(() => { const st = document.createElement('span'); st.tabIndex = -1; document.getElementById('qt-view').insertBefore(st, document.getElementById('qt-view').firstChild); st.focus(); });
  const stops = [];
  for (let i = 0; i < 40; i++) { await page.keyboard.press('Tab'); const s = await page.evaluate(() => { const e = document.activeElement; if (!e || e === document.body) return null; const cs = getComputedStyle(e); return { tag: e.tagName.toLowerCase(), name: (e.getAttribute('aria-label') || e.innerText || e.value || '').replace(/\s+/g, ' ').trim().slice(0, 40), ring: (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) >= 2) || (cs.boxShadow && cs.boxShadow !== 'none') || (() => { const c = e.querySelector(':scope > .tk-card'); if (!c) return false; const k = getComputedStyle(c); return (k.outlineStyle !== 'none' && parseFloat(k.outlineWidth) >= 2) || (k.boxShadow && k.boxShadow !== 'none' && e.matches(':focus-visible')); })(), tree: !!e.closest('[role=tree]') }; }); if (!s) break; stops.push(s); }
  ok('Tab goes through the tools, then ONE stop in the tree, then on (it does not tab through 40 tasks)', stops.filter((s) => s.tree && s.tag === 'li').length === 1, JSON.stringify(stops.slice(0, 12).map((s) => s.name || s.tag)));
  ok('every stop has a name and a visible focus ring', stops.every((s) => s.name && s.ring), stops.filter((s) => !s.name || !s.ring).map((s) => s.tag + ' "' + s.name + '"').slice(0, 4).join(' | '));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 3. what a node says ---------- */
await H.block('3 what a node says', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'node: ' });
  await goTasks(page);
  await page.click(key('openall')); await H.settle(page, 500);
  const nt = (id) => nodeText(page, id);
  const WORDS = { todo: 'To do', working: 'Working', waiting: /Waiting for/, done: 'Done', paused: 'Paused' };
  const bad = [];
  for (const [p, d] of Object.entries(DOCS)) {
    if (!p.startsWith('tasks/') || d.id === 't-term-3' || d.id === 't-term-3a') continue;
    const t = await nt(d.id); if (!t) { bad.push(d.id + ': missing'); continue; }
    const label = (d.id === 't-label-1') ? 'Make four bigger looks (renamed)' : (d.id === 't-photos-2' ? 'Pick the best three photos' : d.title);
    if (!t.includes(label)) bad.push(d.id + ': title');
    const w = WORDS[d.state]; if (!(w instanceof RegExp ? w.test(t) : t.includes(w))) bad.push(d.id + ': state ' + d.state);
  }
  ok('every task node shows its title and its state in WORDS (To do / Working / Waiting for ... / Done / Paused) next to the colour', bad.length === 0, bad.slice(0, 5).join(' | '));
  ok('who is waited for is named: "Waiting for you" (owner), "Waiting for Miss Cathy", "Waiting for Rob"', /Waiting for you/.test(await nt('t-map-b')) && /Waiting for Miss Cathy/.test(await nt('t-photos-1')) && /Waiting for Rob/.test(await nt('t-qs-2')), `${(await nt('t-photos-1')).slice(0, 120)}`);
  ok('a main idea shows "3 of 8 done" and a bar with the same numbers; a done branch says "4 of 4 done"', /3 of 8 done/.test(await nt('t-map')) && /4 of 4 done/.test(await nt('t-winter')) && await page.evaluate(() => { const b = document.querySelector('li.tk-node[data-id="t-map"] > .tk-card [role=progressbar]'); return !!b && b.getAttribute('aria-valuenow') === '3' && b.getAttribute('aria-valuemax') === '8' && /t-map|Redraw/.test(b.getAttribute('aria-label')); }));
  ok('a task with no smaller jobs shows no bar', await page.evaluate(() => !document.querySelector('li.tk-node[data-id="t-map-c"] > .tk-card [role=progressbar]')));
  ok('the live note shows on working tasks ("Colouring the hills"), not on done ones', /Colouring the hills/.test(await nt('t-map-a')) && !/Tab strip is in/.test(await nt('t-term-1')));
  ok('worker badges: map-a shows on t-map-a, with the worker\'s name for screen readers ("Workers: ...")', await page.evaluate(() => { const c = document.querySelector('li.tk-node[data-id="t-map-a"] > .tk-card'); return /Workers: Map drawer A: Storybook Hills/.test(c.innerText + ' ' + [...c.querySelectorAll('.sr')].map((e) => e.textContent).join(' ')) && c.querySelectorAll('.tk-wk').length >= 1; }));
  ok('a main idea with many workers shows the first three and "+N"', await page.evaluate(() => { const c = document.querySelector('li.tk-node[data-id="t-terminal"] > .tk-card'); return c.querySelectorAll('.tk-wk').length === 2; }));
  // pending chips, in words
  ok('her new task (no task document yet) says "You added this · waiting for Claude to see it" and is "To do"', /You added this · waiting for Claude to see it/.test(await nt('u-pend-1')) && /To do/.test(await nt('u-pend-1')), await nt('u-pend-1'));
  ok('her edit not yet seen says "Your change · waiting for Claude to see it" and shows HER title', /Your change · waiting for Claude to see it/.test(await nt('t-photos-2')) && /Pick the best three photos/.test(await nt('t-photos-2')), await nt('t-photos-2'));
  ok('her edit that Claude has seen shows her title without a waiting chip (t-label-1)', /\(renamed\)/.test(await nt('t-label-1')) && !/waiting for Claude to see it/.test(await nt('t-label-1')), await nt('t-label-1'));
  ok('the task she added and Claude adopted (u-seen-1) is not marked waiting', !/waiting for Claude to see it/.test(await nt('u-seen-1')), await nt('u-seen-1'));
  const paused = await nt('t-term-3');
  ok('a task she paused says "You paused this" (in place of the state word) and the waiting chip, until Claude sees it', /You paused this/.test(paused) && /waiting for Claude to see it/.test(paused), paused);
  const removed = await nt('t-term-3a');
  ok('a task she asked to remove is crossed out and says "You asked to remove this"', /You asked to remove this/.test(removed) && (await page.evaluate(() => { const l = document.querySelector('li.tk-node[data-id="t-term-3a"]'); const t = l.querySelector('.tk-title'); return /removed/.test(l.className) || /line-through/.test(getComputedStyle(t).textDecorationLine); })), removed);
  ok('the page never says work has started for a pending task (u-pend-1 is not "Working")', !/Working/.test(await nt('u-pend-1')));
  // question links
  ok('a task that waits for her has an "Answer it →" button that goes straight to the question', await (async () => { const has = await page.evaluate(() => !!document.querySelector('li.tk-node[data-id="t-map-b"] .tk-flag')); if (!has) return false; await page.evaluate(() => document.querySelector('li.tk-node[data-id="t-map-b"] .tk-flag').click()); await H.settle(page, 500); return (await currentPart(page)) === 'questions' && /Book a visit/.test(await textOf(page)); })(), 'went to: ' + (await currentPart(page)));
  ok('after that the Questions tab is the selected one', (await tabsInfo(page)).tabs[0].selected === 'true');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 4. the detail panel ---------- */
await H.block('4 detail panel', async () => {
  for (const [w, label] of [[1366, 'wide: on the right'], [700, 'narrow: under the node']]) {
    const page = await openParts(h, { w, h: 900, label: 'panel ' + w + ': ' });
    await goTasks(page); await openAll(page);
    await select(page, 't-map-b');
    const p = await panel(page);
    ok(`[${w}] tapping a task opens its panel (${label})`, !!p && /Map look B: Sunset sky/.test(p), String(p).slice(0, 80));
    ok(`[${w}] ${w >= 1100 ? 'the panel is on the right of the tree' : 'the panel is inside the tapped node'}`, await page.evaluate((wide) => { const d = document.querySelector('.tk-detail'); const tree = document.querySelector('[role=tree]'); if (!d || !tree) return false; const dr = d.getBoundingClientRect(), tr = tree.getBoundingClientRect(); return wide ? dr.left >= tr.right - 20 : !!d.closest('li.tk-node'); }, w >= 1100));
    ok(`[${w}] the panel has the plain words, the state, who works on it and the related question`, /Needs your pick of the hill colours/.test(p) && /Waiting for you/.test(p) && /Who works on it/.test(p) && /Map drawer B/.test(p) && /Questions about it/.test(p) && /Where should the "Book a visit" button go/.test(p), p);
    ok(`[${w}] dates are in words ("Added 2 days ago")`, /Added \d+ (days?|hours?|min)/.test(p) || /Added/.test(p), p.slice(-120));
    const btns = await panelBtns(page);
    ok(`[${w}] buttons: Add a smaller task, Change this task, Pause, Ask about this task - and NO Remove on Claude's task`, ['a-add:Add a smaller task', 'a-pause:Pause', 'a-ask:Ask about this task'].every((b) => btns.includes(b)) && btns.some((b) => /^a-edit:/.test(b)) && !btns.some((b) => /^a-remove/.test(b)), JSON.stringify(btns));
    ok(`[${w}] every panel button is at least 40 px high`, await page.evaluate(() => [...document.querySelectorAll('.tk-detail button')].every((b) => b.getBoundingClientRect().height >= 39.5)), '');
    await page.evaluate(() => document.querySelector('.tk-detail .tk-wbtn').click()); await H.settle(page, 500);
    ok(`[${w}] tapping the worker in the panel opens the Workers part at that worker`, (await currentPart(page)) === 'workers' && await page.evaluate(() => { const c = document.querySelector('article.wk-card[data-wid="map-b"]'); const r = c && c.getBoundingClientRect(); return !!c && r.bottom > 0 && r.top < innerHeight; }));
    await H.go(page, 'tasks'); await H.settle(page, 400);
    await select(page, 't-map-b');
    await page.evaluate(() => document.querySelector('.tk-detail .tk-qbtn').click()); await H.settle(page, 500);
    ok(`[${w}] tapping the question in the panel opens that question`, (await currentPart(page)) === 'questions' && /Book a visit/.test(await textOf(page)));
    await H.go(page, 'tasks'); await H.settle(page, 400);
    await select(page, 't-map-b');
    await click(page, key('dclose'));
    ok(`[${w}] "Close" closes the panel`, (await panel(page)) === null);
    ok(`[${w}] a task of hers that has no smaller jobs has a Remove button (u-seen-1); one with jobs does not (t-gift)`, await (async () => { await select(page, 'u-seen-1'); const a = await panelBtns(page); await select(page, 't-gift'); const b = await panelBtns(page); return a.some((x) => /^a-remove/.test(x)) && !b.some((x) => /^a-remove/.test(x)); })());
    ok(`[${w}] no page errors`, page.__errs.length === 0, page.__errs.join(' | '));
    await page.context().close();
  }
});

/* ---------- 5. adding tasks ---------- */
await H.block('5 add a task', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'add: ' });
  await goTasks(page);
  await click(page, key('add-top'));
  const f = await page.evaluate(() => ({ title: document.getElementById('tk-new-title-top'), max: (document.getElementById('tk-new-title-top') || {}).maxLength, plainMax: (document.getElementById('tk-new-plain-top') || {}).maxLength, opts: [...(document.getElementById('tk-new-parent-top') || { options: [] }).options].map((o) => o.value + '|' + o.text), focused: document.activeElement === document.getElementById('tk-new-title-top'), labels: [...document.querySelectorAll('.tk-form label')].map((l) => l.innerText.trim()) }));
  ok('"+ Add a task" opens a form: Name of the task (at most 80 characters), What does it mean? (optional), Where does it go?', !!f.title && f.max === 80 && f.plainMax > 100 && f.labels.some((l) => /Name of the task/.test(l)) && f.labels.some((l) => /What does it mean\? \(optional\)/.test(l)) && f.labels.some((l) => /Where does it go\?/.test(l)), JSON.stringify(f));
  ok('"Where does it go?" starts with "A new big idea" and lists every task, kids indented with dashes', f.opts[0] === '|A new big idea' && f.opts.some((o) => /^t-map-a1\|– – – /.test(o) || /Colour the hills/.test(o)) && f.opts.length >= 40, JSON.stringify(f.opts.slice(0, 6)));
  ok('the cursor starts in the name box', f.focused);
  await H.clearWrites(page);
  await click(page, key('tkA:top:go'));
  ok('an empty name is not accepted: nothing is written and she is told', (await writesTo(page, 'taskAdds/')).length === 0 && /name|title|write/i.test(await textOf(page, '.tk-formcard')), (await textOf(page, '.tk-formcard')).slice(0, 160));
  await page.fill('#tk-new-title-top', 'Plant a pumpkin patch');
  await page.fill('#tk-new-plain-top', 'Orange ones, near the barn.');
  await page.selectOption('#tk-new-parent-top', 't-map-d');
  await click(page, key('tkA:top:go'));
  await H.settle(page, 500);
  const w = await writesTo(page, 'taskAdds/');
  ok('exactly ONE write to taskAdds/<id> {id "u-...", parentId "t-map-d", title, plain, createdAt}', w.length === 1 && w[0].data && /^u-[a-z0-9]+$/.test(w[0].data.id) && w[0].path === 'taskAdds/' + w[0].data.id && w[0].data.parentId === 't-map-d' && w[0].data.title === 'Plant a pumpkin patch' && w[0].data.plain === 'Orange ones, near the barn.' && !isNaN(Date.parse(w[0].data.createdAt)), JSON.stringify(w.map((x) => x.data)));
  ok('the page writes only her own collections (taskAdds, taskEdits, asks, meta)', (await H.writes(page)).every((x) => /^(taskAdds|taskEdits|asks|meta)\//.test(x.path)), (await H.writes(page)).map((x) => x.path).join());
  await okSoon('the first ping is a doorbell: Added a task: \u201cPlant a pumpkin patch\u201d (her words about it stay in the notebook)', () => H.pings(page), (x) => x.length >= 1 && x[0].text === 'Added a task: \u201cPlant a pumpkin patch\u201d' && !/Orange|barn/.test(x[0].text), 5000);
  const id = w[0] && w[0].data.id;
  ok('the new task is in the tree at once, under "Map look D", with the chip "You added this · waiting for Claude to see it"', await H.until(page, (i) => { const l = document.querySelector(`li.tk-node[data-id="${i}"]`); return !!l && /You added this · waiting for Claude to see it/.test(l.innerText) && !!l.parentElement.closest('li.tk-node[data-id="t-map-d"]'); }, id, 3000), (await nodeText(page, id)) || 'not on screen');
  ok('the form is closed or empty again afterwards', await page.evaluate(() => { const t = document.getElementById('tk-new-title-top'); return !t || t.value === ''; }));
  ok('Map look D now has one smaller job ("0 of 1 done") and the main idea still counts 8 leaves (D is no longer a leaf)', /0 of 1 done/.test(await nodeText(page, 't-map-d')) && /3 of 8 done/.test(await nodeText(page, 't-map')), (await nodeText(page, 't-map-d')).slice(0, 200));
  // Claude adopts it
  await H.put(page, 'tasks/' + id, { id, parentId: 't-map-d', title: 'Plant a pumpkin patch', plain: 'Orange ones, near the barn.', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 200, createdAt: w[0].data.createdAt, updatedAt: new Date().toISOString(), doneAt: null, createdBy: 'owner', seenAt: new Date().toISOString() });
  ok('when Claude adopts it (seenAt) the waiting chip goes away and "Claude saw it ✓" can show', await H.until(page, (i) => { const l = document.querySelector(`li.tk-node[data-id="${i}"]`); return !!l && !/waiting for Claude to see it/.test(l.innerText); }, id, 3000), (await nodeText(page, id)));
  await select(page, id);
  ok('its panel says "Claude saw it ✓" and "Added ... by you"', /Claude saw it ✓/.test(await panel(page)) && /by you/.test(await panel(page)), await panel(page));
  // a new big idea
  await click(page, key('add-top'));
  await page.fill('#tk-new-title-top', 'A brand new big idea');
  await H.clearWrites(page);
  await page.selectOption('#tk-new-parent-top', '');
  await page.keyboard.press('Enter').catch(() => {});
  await click(page, key('tkA:top:go')).catch(() => {});
  await H.settle(page, 500);
  const w2 = await writesTo(page, 'taskAdds/');
  ok('"A new big idea" is saved with parentId null (Enter in the form or the button: one write)', w2.length === 1 && w2[0].data.parentId === null && w2[0].data.title === 'A brand new big idea' && w2[0].data.plain === '', JSON.stringify(w2.map((x) => x.data)));
  // add from a panel
  await select(page, 't-photos-3');
  await click(page, key('a-add'));
  const prefill = await page.evaluate(() => { const s = document.querySelector('.tk-detail select, .tk-form select'); return s ? s.value : null; });
  ok('"Add a smaller task" in a panel puts the parent in already (t-photos-3)', prefill === 't-photos-3', String(prefill));
  await page.fill('.tk-detail .tk-form input[type=text]', 'Resize the first photo');
  await H.clearWrites(page);
  await click(page, key('tkA:panel:go'));
  await H.settle(page, 500);
  const w3 = await writesTo(page, 'taskAdds/');
  ok('it saves taskAdds with parentId t-photos-3', w3.length === 1 && w3[0].data.parentId === 't-photos-3' && w3[0].data.title === 'Resize the first photo', JSON.stringify(w3.map((x) => x.data)));
  // double submit
  await click(page, key('add-top'));
  await page.fill('#tk-new-title-top', 'Twice?');
  await H.clearWrites(page);
  await page.evaluate(() => { const b = document.querySelector('[data-key="tkA:top:go"]'); b.click(); b.click(); b.click(); });
  await H.settle(page, 600);
  ok('three quick taps on "Add task" make ONE task', (await writesTo(page, 'taskAdds/')).length === 1, String((await writesTo(page, 'taskAdds/')).length));
  // unsafe text she types
  await click(page, key('add-top'));
  await page.fill('#tk-new-title-top', XSS);
  await page.fill('#tk-new-plain-top', '"><script>window.__xss=1</script>');
  await click(page, key('tkA:top:go')); await H.settle(page, 500);
  const r = await unsafeReport(page);
  ok('html she types shows as plain words and runs nothing', r.img === 0 && r.scripts === 0 && !r.flag && r.alerts === 0 && (await textOf(page)).includes(XSS), JSON.stringify(r));
  // failure
  await page.evaluate(() => { window.__mock.failWrites = true; });
  await click(page, key('add-top'));
  await page.fill('#tk-new-title-top', 'Will not save');
  await H.clearWrites(page);
  await click(page, key('tkA:top:go')); await H.settle(page, 800);
  ok('a failed save tells her and keeps her words (the title is still in the box)', /could not|not saved|try again/i.test(await textOf(page, '.tk-formcard')) && (await page.inputValue('#tk-new-title-top')) === 'Will not save', (await textOf(page, '.tk-formcard')).slice(0, 200));
  ok('a failed add does not appear in the tree as if it were saved', !(await textOf(page)).includes('Will not save') || (await page.inputValue('#tk-new-title-top')) === 'Will not save');
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 6. changing, pausing, removing ---------- */
await H.block('6 change pause remove', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'change: ' });
  await goTasks(page); await openAll(page);
  await select(page, 't-map-c');
  await click(page, key('a-edit'));
  const f = await page.evaluate(() => { const form = document.querySelector('.tk-detail .tk-form'); return { has: !!form, title: form && form.querySelector('input[type=text]').value, plain: form && form.querySelector('textarea').value }; });
  ok('"Change this task" opens a form with the current title and words', f.has && f.title === 'Map look C: Simple' && /Plain words for Map look C/.test(f.plain), JSON.stringify(f));
  await H.clearWrites(page);
  await page.fill('.tk-detail .tk-form input[type=text]', '');
  await click(page, key('tkE:t-map-c:go')).catch(async () => { await page.evaluate(() => document.querySelector('.tk-detail .tk-form button[type=submit]').click()); });
  ok('an empty title is refused (nothing written)', (await writesTo(page, 'taskEdits/')).length === 0);
  await page.fill('.tk-detail .tk-form input[type=text]', 'Map look C: Very simple');
  await page.evaluate(() => document.querySelector('.tk-detail .tk-form button[type=submit]').click()); await H.settle(page, 500);
  const w = await writesTo(page, 'taskEdits/');
  ok('ONE write to taskEdits/t-map-c {id, title, updatedAt} (only what she changed, no "paused" or "removed")', w.length === 1 && w[0].path === 'taskEdits/t-map-c' && w[0].data.id === 't-map-c' && w[0].data.title === 'Map look C: Very simple' && !('paused' in w[0].data) && !('removed' in w[0].data) && !isNaN(Date.parse(w[0].data.updatedAt)), JSON.stringify(w.map((x) => x.data)));
  await okSoon('the first ping is a doorbell: Changed a task: \u201cMap look C: Very simple\u201d', () => H.pings(page), (x) => x.length >= 1 && x[0].text === 'Changed a task: \u201cMap look C: Very simple\u201d', 5000);
  ok('the node shows her new title and "Your change · waiting for Claude to see it" at once', await H.until(page, () => { const l = document.querySelector('li.tk-node[data-id="t-map-c"]'); return !!l && /Very simple/.test(l.innerText) && /Your change · waiting for Claude to see it/.test(l.innerText); }, null, 3000), (await nodeText(page, 't-map-c')));
  await H.put(page, 'tasks/t-map-c', { ...DOCS['tasks/t-map-c'], seenAt: new Date(Date.now() + 2000).toISOString(), updatedAt: new Date().toISOString() });
  ok('when Claude has seen it the waiting chip goes away and her title stays', await H.until(page, () => { const l = document.querySelector('li.tk-node[data-id="t-map-c"]'); return !!l && /Very simple/.test(l.innerText) && !/waiting for Claude to see it/.test(l.innerText); }, null, 3000), (await nodeText(page, 't-map-c')));
  // pause and resume
  await select(page, 't-map-d');
  await H.clearWrites(page);
  await click(page, key('a-pause')); await H.settle(page, 500);
  const w2 = await writesTo(page, 'taskEdits/');
  ok('"Pause" writes taskEdits/t-map-d {paused:true}', w2.length === 1 && w2[0].data.paused === true && w2[0].data.id === 't-map-d', JSON.stringify(w2.map((x) => x.data)));
  const pt = await nodeText(page, 't-map-d');
  ok('the node says "You paused this" and the panel now offers "Keep going"', /You paused this/.test(pt) && (await panelBtns(page)).some((b) => /^a-resume:Keep going/.test(b)), pt + ' ' + JSON.stringify(await panelBtns(page)));
  await H.clearWrites(page);
  await click(page, key('a-resume')); await H.settle(page, 500);
  const w3 = await writesTo(page, 'taskEdits/');
  ok('"Resume" writes {paused:false} (it does not delete her edit)', w3.length === 1 && w3[0].data.paused === false, JSON.stringify(w3.map((x) => x.data)));
  ok('the node is "To do" again', /To do/.test(await nodeText(page, 't-map-d')), await nodeText(page, 't-map-d'));
  // pause a task already paused by her before (t-term-3)
  await select(page, 't-term-3');
  ok('a task she paused earlier shows "Resume" (not "Pause")', (await panelBtns(page)).some((b) => /^a-resume/.test(b)) && !(await panelBtns(page)).some((b) => /^a-pause/.test(b)), JSON.stringify(await panelBtns(page)));
  // remove
  await select(page, 'u-seen-1');
  await H.clearWrites(page);
  await click(page, key('a-remove'));
  ok('"Remove" asks first: "Take this task off the list? Claude will remove it."', /Take this task off the list\? Claude will remove it\./.test(await panel(page)));
  await click(page, key('rm-no'));
  ok('"Keep it" writes nothing and the question goes away', (await writesTo(page, 'taskEdits/')).length === 0 && !/Take this task off the list/.test((await panel(page)) || ''));
  await click(page, key('a-remove')); await click(page, key('rm-yes')); await H.settle(page, 500);
  const w4 = await writesTo(page, 'taskEdits/');
  ok('"Remove it" writes taskEdits/u-seen-1 {removed:true}', w4.length === 1 && w4[0].data.removed === true && w4[0].data.id === 'u-seen-1', JSON.stringify(w4.map((x) => x.data)));
  const rt = await nodeText(page, 'u-seen-1');
  ok('the node is crossed out and says "You asked to remove this"; it is still in the list until Claude acts', /You asked to remove this/.test(rt), rt);
  ok('the panel offers "Keep it after all" and no other changes while it is removed', (await panelBtns(page)).join() === 'a-undo:Keep it after all', JSON.stringify(await panelBtns(page)));
  await H.clearWrites(page);
  await click(page, key('a-undo')); await H.settle(page, 500);
  const w5 = await writesTo(page, 'taskEdits/');
  ok('"Keep it after all" writes {removed:false}', w5.length === 1 && w5[0].data.removed === false, JSON.stringify(w5.map((x) => x.data)));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 7. asking about a task ---------- */
await H.block('7 ask about a task', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'taskask: ' });
  await goTasks(page);
  await select(page, 't-map');
  ok('the old answered question (ask-t-1) is in the panel: "Your questions (1)", her bubble and "Answer from Map drawer A: Storybook Hills"', /Your questions \(1\)/.test(await panel(page)) && /When will the map be ready\?/.test(await panel(page)) && /Answer from Map drawer A: Storybook Hills/.test(await panel(page)) && /About an hour/.test(await panel(page)), (await panel(page)).slice(-300));
  await select(page, 't-term-2');
  ok('an unanswered one shows "Sent · waiting for Claude to see it" (ask-t-2)', /Will the tabs work with the keyboard\?/.test(await panel(page)) && /Sent · waiting for Claude to see it/.test(await panel(page)), (await panel(page)).slice(-200));
  await select(page, 't-winter');
  await click(page, key('a-ask'));
  const ta = await page.evaluate(() => { const t = document.querySelector('.tk-detail textarea[id^="tk-ask-"]'); return t ? { max: t.maxLength, label: (document.querySelector(`label[for="${t.id}"]`) || {}).innerText, focused: document.activeElement === t } : null; });
  ok('"Ask about this task" opens a text box (at most 600 characters) with a label', !!ta && ta.max === 600 && /Ask about this task/.test(ta.label || ''), JSON.stringify(ta));
  await H.clearWrites(page);
  await click(page, '.tk-detail form button[type=submit], .tk-detail .tk-form button[type=submit]').catch(() => {});
  ok('an empty question is refused', (await writesTo(page, 'asks/')).length === 0);
  await page.fill('.tk-detail textarea[id^="tk-ask-"]', 'Can I see the winter game on my phone?');
  await page.evaluate(() => document.querySelector('.tk-detail form button[type=submit], .tk-detail .tk-form button[type=submit]').click()); await H.settle(page, 500);
  const w = await writesTo(page, 'asks/');
  ok('ONE write to asks/<id> {id, targetKind "task", targetId "t-winter", text, createdAt}', w.length === 1 && w[0].data.targetKind === 'task' && w[0].data.targetId === 't-winter' && w[0].data.text === 'Can I see the winter game on my phone?' && w[0].path === 'asks/' + w[0].data.id && !isNaN(Date.parse(w[0].data.createdAt)), JSON.stringify(w.map((x) => x.data)));
  ok('her message is a bubble with "Sent · waiting for Claude to see it"', /Can I see the winter game on my phone\?/.test(await panel(page)) && /Sent · waiting for Claude to see it/.test(await panel(page)), (await panel(page)).slice(-250));
  const id = w[0].data.id;
  await H.put(page, 'replies/' + id, { id, targetKind: 'task', targetId: 't-winter', state: 'seen', text: '', from: 'Claude', at: new Date().toISOString() });
  ok('seen: "Claude saw it ✓"', await H.until(page, () => /Claude saw it ✓/.test((document.querySelector('.tk-detail') || {}).innerText || ''), null, 3000));
  await H.put(page, 'replies/' + id, { id, targetKind: 'task', targetId: 't-winter', state: 'working', text: '', from: 'Claude', at: new Date().toISOString() });
  ok('working: "Claude is working on your answer"', await H.until(page, () => /Claude is working on your answer/.test((document.querySelector('.tk-detail') || {}).innerText || ''), null, 3000));
  await H.put(page, 'replies/' + id, { id, targetKind: 'task', targetId: 't-winter', state: 'answered', text: 'Yes, it works on phones.', from: 'Claude', at: new Date().toISOString() });
  ok('answered: a speech bubble "Answer from Claude" with the words', await H.until(page, () => /Answer from Claude/.test((document.querySelector('.tk-detail') || {}).innerText || '') && /Yes, it works on phones\./.test((document.querySelector('.tk-detail') || {}).innerText || ''), null, 3000));
  ok('the ping is a doorbell: Question for \u201cWinter tree game\u201d, open the Terminal to read it', (await H.pings(page)).some((p) => p.text === 'Question for \u201cWinter tree game\u201d, open the Terminal to read it'), JSON.stringify((await H.pings(page)).map((p) => p.text)));
  ok('the doorbell carries none of her words (no "winter game on my phone")', !(await H.pings(page)).some((p) => /on my phone|Can I see/.test(p.text)), JSON.stringify((await H.pings(page)).map((p) => p.text)));
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 8. the map view (second step) ---------- */
await H.block('8 map view', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'map: ' });
  await goTasks(page);
  const toggle = await page.evaluate(() => { const b = [...document.querySelectorAll('#qt-view button, #qt-view [role=tab], #qt-view [role=radio]')].filter((x) => /^\s*(map|list)\b/i.test(x.innerText.trim())); return b.map((x) => x.innerText.trim() + '|' + (x.getAttribute('aria-pressed') || x.getAttribute('aria-selected') || x.getAttribute('aria-checked'))); });
  if (!toggle.some((x) => /^map/i.test(x))) { info('NOTE: the "List | Map" toggle is not in the page yet (SPEC2 section 6: second step). Map checks skipped.'); await page.context().close(); return; }
  ok('a "List | Map" toggle with the current one marked', toggle.some((x) => /^list\|(true)/i.test(x)) && toggle.some((x) => /^map\|(false|null)/i.test(x)), JSON.stringify(toggle));
  await page.evaluate(() => [...document.querySelectorAll('#qt-view button, #qt-view [role=tab], #qt-view [role=radio]')].find((x) => /^\s*map\b/i.test(x.innerText.trim())).click());
  await H.settle(page, 700);
  const m = await page.evaluate(() => { const box = document.querySelector('.tk-mapbox'); const svgs = document.querySelectorAll('.tk-mapbox svg'); const nodes = document.querySelectorAll('.tk-mapbox li.tk-mn[data-id]'); return { box: !!box, scrolls: box ? box.scrollWidth > box.clientWidth : false, overflow: box ? getComputedStyle(box).overflowX : null, nodes: nodes.length, svg: svgs.length, docW: document.documentElement.scrollWidth, vw: innerWidth }; });
  ok('the map draws the open tasks (36 of the 44 nodes; the folded branches are shut) in its own scroll box, the page does not scroll sideways', m.box && m.nodes >= 30 && /(auto|scroll)/.test(m.overflow || '') && m.docW <= m.vw + 1, JSON.stringify(m));
  await page.evaluate(() => { const n = document.querySelector('.tk-mapbox li.tk-mn[data-id="t-map-b"] > .tk-mcard'); n && n.click(); }); await H.settle(page, 500);
  ok('tapping a map node opens the same detail panel', /Map look B: Sunset sky/.test((await panel(page)) || ''));
  ok('the map keeps working at 400 px wide (own scroll box, no page scroll)', await (async () => { await page.setViewportSize({ width: 400, height: 800 }); await H.settle(page, 400); return await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1); })());
  ok('no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 9. empty, offline, odd data, focus param ---------- */
await H.block('9 empty offline odd', async () => {
  const e = await openParts(h, { docs: partsDocs({ noTasks: true }), label: 'empty: ' });
  await goTasks(e);
  ok('no tasks yet: friendly "No tasks yet." and a way to add the first one', /No tasks yet/.test(await textOf(e)) && (await e.evaluate(() => !!document.querySelector('[data-key="add-top"]'))), (await textOf(e)).slice(0, 160));
  ok('empty: no tree, no errors', e.__errs.length === 0, e.__errs.join(' | '));
  await e.context().close();
  const o = await H.open(h, { w: 700, h: 800, docs: {}, mock: { db: null }, label: 'nodb: ' });
  await H.ready(o); await goTasks(o);
  const ot = await textOf(o, '#qt-main');
  ok('no notebook: friendly text, no add button, no errors', /No connection|Not connected|connection/i.test(ot) && !(await o.evaluate(() => !!document.querySelector('[data-key="add-top"]'))) && o.__errs.length === 0, ot.slice(0, 160) + ' ' + o.__errs.join('|'));
  await o.context().close();
  const page = await openParts(h, { w: 1366, h: 900, label: 'odd: ' });
  await goTasks(page, { focus: 't-map-b' });
  ok('route.go("tasks", {focus}) opens the branch, selects the task and brings it into view', await page.evaluate(() => { const l = document.querySelector('li.tk-node[data-id="t-map-b"]'); const r = l.getBoundingClientRect(); return l.getAttribute('aria-selected') === 'true' && r.bottom > 0 && r.top < innerHeight; }) && /Map look B: Sunset sky/.test((await panel(page)) || ''));
  await goTasks(page, { focus: 't-winter-2' });
  ok('focus on a task inside a folded finished branch opens the branch first', (await shownIds(page)).includes('t-winter-2'), (await shownIds(page)).join());
  await goTasks(page, { focus: 'no-such-task' });
  ok('focus on a task that does not exist is ignored (no error, the tree shows)', (await shownIds(page)).includes('t-map') && page.__errs.length === 0, page.__errs.join(' | '));
  // odd data
  const base = { workerIds: [], questionIds: [], note: '', plain: '', waitingFor: 'none', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), doneAt: null, createdBy: 'claude', seenAt: null, state: 'todo', order: 1 };
  await H.put(page, 'tasks/cyc-a', { ...base, id: 'cyc-a', parentId: 'cyc-b', title: 'Cycle A' });
  await H.put(page, 'tasks/cyc-b', { ...base, id: 'cyc-b', parentId: 'cyc-a', title: 'Cycle B' });
  await H.put(page, 'tasks/self', { ...base, id: 'self', parentId: 'self', title: 'Its own parent' });
  await H.put(page, 'tasks/orphan', { ...base, id: 'orphan', parentId: 'no-such-task', title: 'Lonely orphan', state: 'weird', waitingFor: 'nobody' });
  await H.put(page, 'tasks/odd-types', { ...base, id: 'odd-types', parentId: null, title: 5, plain: { a: 1 }, workerIds: 'x', questionIds: null, note: null, order: 'first', createdAt: 'yesterday', updatedAt: null });
  await H.put(page, 'tasks/ghost-links', { ...base, id: 'ghost-links', parentId: null, title: 'Links to nothing', workerIds: ['no-worker'], questionIds: ['no-question'] });
  const t0 = Date.now();
  await H.settle(page, 600);
  await page.click(key('openall'), { timeout: 8000 }).catch(() => {});
  await H.settle(page, 500);
  ok('odd data (a cycle, a task that is its own parent, an orphan, wrong value kinds, links to nothing) does not hang or throw', Date.now() - t0 < 8000 && page.__errs.filter((x) => /pageerror/.test(x)).length === 0, page.__errs.join(' | '));
  ok('the orphan is not lost: it shows as a main idea', (await shownIds(page)).includes('orphan'), (await shownIds(page)).slice(-8).join());
  ok('the page still draws the normal tasks after all that', /Redraw the farm map/.test(await textOf(page)));
  await select(page, 'ghost-links');
  ok('links to workers / questions that do not exist are left out (no empty buttons)', !/Who works on it/.test((await panel(page)) || '') && !/Questions about it/.test((await panel(page)) || ''), String(await panel(page)).slice(0, 160));
  ok('no page errors at all', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 10. live ---------- */
await H.block('10 live changes', async () => {
  const page = await openParts(h, { w: 1366, h: 900, label: 'live: ' });
  await goTasks(page);
  await page.click(key('openall')); await H.settle(page, 400);
  await H.put(page, 'tasks/t-map-a2', { ...DOCS['tasks/t-map-a2'], state: 'working', note: 'Drawing the silo', updatedAt: new Date().toISOString() });
  ok('a task that starts working shows "Working" and its note by itself', await H.until(page, () => { const l = document.querySelector('li.tk-node[data-id="t-map-a2"]'); return !!l && /Working/.test(l.innerText) && /Drawing the silo/.test(l.innerText); }, null, 3000));
  ok('the strip counters tick up (Working now 7)', await H.until(page, () => /\b7\b\s*Working now/.test(document.querySelector('.tk-strip').innerText.replace(/\s+/g, ' ')), null, 3000), (await textOf(page, '.tk-strip')));
  await H.put(page, 'tasks/t-map-a2', { ...DOCS['tasks/t-map-a2'], state: 'done', doneAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
  ok('and when it is done the parents\' bars move ("4 of 8 done" on the main idea)', await H.until(page, () => /4 of 8 done/.test(document.querySelector('li.tk-node[data-id="t-map"] > .tk-card').innerText.replace(/\s+/g, ' ')), null, 3000), (await nodeText(page, 't-map')).slice(0, 200));
  await select(page, 't-map-b');
  await H.put(page, 'tasks/t-map-b', { ...DOCS['tasks/t-map-b'], title: 'Map look B: Dusk sky', updatedAt: new Date().toISOString() });
  ok('a change to the task whose panel is open updates the panel too, and the panel stays open', await H.until(page, () => /Dusk sky/.test((document.querySelector('.tk-detail') || {}).innerText || ''), null, 3000));
  await H.del(page, 'tasks/t-map-b');
  ok('a task Claude removes disappears; an open panel for it closes or empties without errors', await H.until(page, () => !document.querySelector('li.tk-node[data-id="t-map-b"]'), null, 3000) && page.__errs.length === 0, page.__errs.join(' | '));
  await H.put(page, 'taskEdits/t-map-c', { id: 't-map-c', title: 'Typed in another window', updatedAt: new Date().toISOString() });
  ok('her edit made elsewhere (another window) shows here too, with the waiting chip', await H.until(page, () => { const l = document.querySelector('li.tk-node[data-id="t-map-c"]'); return !!l && /Typed in another window/.test(l.innerText) && /waiting for Claude to see it/.test(l.innerText); }, null, 3000));
  ok('live: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

await H.stop(h);
