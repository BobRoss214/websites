/* Layout with the REAL page (dist/index.html + mock + tester fixtures): screenshots at 3 sizes, no horizontal scroll, sticky bar.  Port 9202. */
import * as H from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';
const { ok, info } = H;
const h = await H.start(9202);
const hscroll = (p) => p.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth, document.documentElement.scrollHeight, window.innerHeight]);
const sizes = [[700, 800], [1366, 768], [1920, 1080], [400, 800]];
const views = [
  ['home', 'home', {}],
  ['look', 'section', { id: 'look' }],
  ['visual', 'question', { id: 'v-map-1' }],
  ['choice', 'question', { id: 'c-normal' }],
  ['long', 'question', { id: 'c-long' }],
  ['kathy', 'section', { id: 'kathy' }],
  ['kathyq', 'question', { id: 'k01' }],
  ['account', 'section', { id: 'account-features' }],
  ['done', 'done', {}],
  ['new', 'newsection', {}],
];
for (const [w, hh] of sizes) {
  const page = await H.open(h, { docs: seed(), w, h: hh });
  for (const [name, view, params] of views) {
    await H.go(page, view, params);
    await H.settle(page, 400);
    await H.shot(page, `layout-real-${name}-${w}x${hh}`);
    const [sw, cw, sh, ih] = await hscroll(page);
    ok(`${name} ${w}x${hh}: no horizontal scroll`, sw <= cw, `${sw}/${cw}`);
    info(`${name} ${w}x${hh}: page height ${sh} (window ${ih})`);
  }
  await page.context().close();
}
await H.stop(h);
