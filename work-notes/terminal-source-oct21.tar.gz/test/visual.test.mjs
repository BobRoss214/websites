/* Tests for the pictures (QT.visual) and the big viewer (QT.lightbox).     NODE_PATH=/opt/node22/lib/node_modules node T/test/visual.test.mjs
 *
 * The page under test is made fresh each run into T/dist-visual/index.html:
 *   default           base css + 21-visual.css + a tiny QT stand-in + 21-visual.js + 22-lightbox.js + test/visual-stub.js   (needs nothing from other helpers)
 *   VISUAL_BUILD=1    python3 T/build.py --only 21-visual.js,22-lightbox.js --extra T/test/visual-stub.js   (the real core, when it is ready)
 * Screenshots: T/shots/visual-*.png (look at them!).  Port 9400+.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { launch, startServer, ok, okSoon, info, finish, until } from './lib.mjs';

const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(T, 'dist-visual');
const SHOTS = path.join(T, 'shots');
fs.mkdirSync(DIST, { recursive: true });
fs.mkdirSync(SHOTS, { recursive: true });
const read = (p) => fs.readFileSync(path.join(T, p), 'utf8');

function assemble() {
  const out = path.join(DIST, 'index.html');
  if (process.env.VISUAL_BUILD) {
    const r = spawnSync('python3', [path.join(T, 'build.py'), '--out', out, '--only', '21-visual.js,22-lightbox.js', '--extra', path.join(T, 'test/visual-stub.js'), '--doctype'], { encoding: 'utf8' });
    if (r.status !== 0) throw new Error('build.py failed: ' + (r.stderr || r.stdout));
    return 'build.py';
  }
  const qt = 'window.QT={_h:{},on:function(e,f){(this._h[e]=this._h[e]||[]).push(f)},emit:function(e,d){(this._h[e]||[]).forEach(function(f){f(d)})}};';
  const html = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Visual test</title><style>' +
    read('src/css/00-base.css') + '\n' + read('src/css/21-visual.css') + '</style></head><body><script>' + qt + '</script><script>' + read('src/js/21-visual.js') +
    '</script><script>' + read('src/js/22-lightbox.js') + '</script><script>' + read('test/visual-stub.js') + '</script></body></html>';
  fs.writeFileSync(out, html);
  return 'stand-in';
}

const NOISE = /net::ERR|Failed to load resource|favicon/;
async function newPage(browser, base, { w = 700, h = 800, scheme = 'light', motion = 'no-preference', touch = false } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: scheme, reducedMotion: motion, hasTouch: touch, isMobile: touch, locale: 'en-US' });
  const page = await ctx.newPage();
  page.errs = [];
  page.on('pageerror', (e) => page.errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !NOISE.test(m.text())) page.errs.push('console: ' + m.text()); });
  await page.goto(base + 'index.html', { waitUntil: 'load' });
  await until(page, () => !!window.VS, null, 15000);
  return page;
}
const show = async (page, id, opts) => {
  await page.evaluate(([i, o]) => { window.VS.show(i, o); }, [id, opts || null]);
  await page.waitForSelector('.qtv', { state: 'attached' });
};
const text = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.textContent.trim().replace(/\s+/g, ' ') : null; }, sel);
const rect = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, r: r.right, b: r.bottom }; }, sel);
const isOpen = (page) => page.evaluate(() => !!document.querySelector('.qtl'));
const count = (page) => text(page, '.qtl-count');
const activeInfo = (page) => page.evaluate(() => { const a = document.activeElement; return a ? (a.className && a.className.baseVal === undefined ? a.className : a.tagName) + '|' + (a.getAttribute('data-vkey') || '') + '|' + (a.getAttribute('aria-label') || '') : 'none'; });
const shot = (page, name) => page.screenshot({ path: path.join(SHOTS, 'visual-' + name + '.png'), animations: 'disabled' });
const noSideScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1 && document.body.scrollWidth <= window.innerWidth + 1);
async function settleImages(page, sel = '.qtv-pic') {
  await until(page, (s) => { const ps = [...document.querySelectorAll(s)]; return ps.length > 0 && ps.every((p) => p.classList.contains('is-ok') || p.classList.contains('is-bad')); }, sel, 15000);
}
async function openCard(page, key) {
  await page.click(`.qtv-card[data-vkey="${key}"]`);
  await page.waitForSelector('.qtl', { state: 'attached' });
  await until(page, () => { const d = document.querySelector('.qtl'); return !!d && d.getAttribute('data-state') !== 'loading'; }, null, 10000);
}
async function imgReady(page) {
  return until(page, () => { const d = document.querySelector('.qtl'); return !!d && d.getAttribute('data-state') !== 'loading'; }, null, 10000);
}

const how = assemble();
info('page built with: ' + how);
const site = await startServer({ root: DIST, port: 9410 });
const browser = await launch();
const allErrs = [];

try {
  /* ================= 1. the grid of 4 versions at 700 x 800 ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q4');
    await settleImages(page);
    ok('4 versions: four cards', (await page.locator('.qtv-card').count()) === 4);
    ok('letter badges A B C D', (await page.locator('.qtv-badge').allTextContents()).join('') === 'ABCD');
    ok('cards are buttons with the spoken name (2 pictures)', (await page.getAttribute('.qtv-card[data-vkey="A"]', 'aria-label')) === 'Version A: Big photo on top, picture 1 of 2, open big view');
    ok('cards are buttons with the spoken name (1 picture)', (await page.getAttribute('.qtv-card[data-vkey="B"]', 'aria-label')) === 'Version B: Small photo, big words, open big view');
    ok('card B has 1 picture', (await page.locator('.qtv-card[data-vkey="B"] .qtv-more').count()) === 0);
    ok('+1 badge on A, +2 badge on C', (await text(page, '.qtv-card[data-vkey="A"] .qtv-more')) === '+1' && (await text(page, '.qtv-card[data-vkey="C"] .qtv-more')) === '+2');
    ok('every picture on the page sends no referrer (a picture from another website does not learn the page)', await page.evaluate(() => { const im = [...document.querySelectorAll('.qtv img')]; return im.length >= 3 && im.every((i) => i.referrerPolicy === 'no-referrer'); }));
    ok('all cards are real buttons', await page.evaluate(() => [...document.querySelectorAll('.qtv-card')].every((c) => c.tagName === 'BUTTON' && c.type === 'button')));
    const g = await rect(page, '.qtv-grid');
    ok('grid is 2 x 2: A,B in the first row and C,D in the second', await page.evaluate(() => { const r = (k) => document.querySelector(`.qtv-card[data-vkey="${k}"]`).getBoundingClientRect(); return Math.abs(r('A').top - r('B').top) < 2 && Math.abs(r('C').top - r('D').top) < 2 && r('C').top > r('A').bottom - 1 && r('B').left > r('A').right - 1; }));
    ok('grid at 700 wide: 5:2 pictures with a two-line caption strip, 300 to 360 px high', g.h <= 360 && g.h >= 300, 'height ' + Math.round(g.h));
    info('grid ' + Math.round(g.w) + ' x ' + Math.round(g.h));
    const pics = await page.evaluate(() => [...document.querySelectorAll('.qtv-card .qtv-pic')].map((p) => { const r = p.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)]; }));
    ok('each thumbnail picture box is 300 x 120 (5:2)', pics.every(([w, h]) => w <= 300 && w >= 280 && h >= 112 && h <= 122), JSON.stringify(pics));
    ok('no sideways scroll at 700', await noSideScroll(page));
    ok('no hint line any more', (await page.locator('.qtv-hint').count()) === 0);
    ok('the tip is in the tooltip of each picture', /Click to see it big\./.test((await page.getAttribute('.qtv-card[data-vkey="B"]', 'title')) || ''), await page.getAttribute('.qtv-card[data-vkey="B"]', 'title'));
    const blockH = await page.evaluate(() => document.querySelector('.qtv').getBoundingClientRect().height);
    ok('the whole pictures block (label row + grid) is at most 390 px', blockH <= 390, 'height ' + Math.round(blockH));
    ok('the row above the grid says "Pick your favorite"', (await text(page, '.qtv-head-label')) === 'Pick your favorite' && (await rect(page, '.qtv-head')).h < 32);
    const lt = await text(page, '.qtv-card[data-vkey="A"] .qtv-cap');
    ok('the caption gets up to TWO lines (item 5: not cut to one line "Soft gree..."): wraps, clamps at 2', await page.evaluate(() => { const c = document.querySelector('.qtv-card[data-vkey="A"] .qtv-text'); const st = getComputedStyle(c); const hh = c.getBoundingClientRect().height; return st.webkitLineClamp === '2' && st.whiteSpace === 'normal' && hh > 28 && hh < 44; }), lt && lt.slice(0, 30));
    ok('the strip under each picture is two lines high (52 px) when a version has a caption, the same for all four', await page.evaluate(() => [...document.querySelectorAll('.qtv-strip')].every((x) => Math.abs(x.getBoundingClientRect().height - 52) <= 2)));
    await okSoon('good pictures show (not blank)', () => page.evaluate(() => [...document.querySelectorAll('.qtv-card')].slice(0, 3).map((c) => { const i = c.querySelector('img'); return !!(i && i.complete && i.naturalWidth > 0 && getComputedStyle(i).opacity === '1'); })), (v) => v.every(Boolean));
    ok('the broken picture (D) shows the calm box, no broken icon', await page.evaluate(() => { const d = document.querySelector('.qtv-card[data-vkey="D"]'); const ph = d.querySelector('.qtv-ph'); return !!ph && !d.querySelector('img') && /Picture did not load/.test(ph.textContent) && /Plain page with the name/.test(ph.textContent); }));
    ok('the calm box keeps the size of the others', await page.evaluate(() => { const a = document.querySelector('.qtv-card[data-vkey="A"] .qtv-pic').getBoundingClientRect(), d = document.querySelector('.qtv-card[data-vkey="D"] .qtv-pic').getBoundingClientRect(); return Math.abs(a.width - d.width) < 1 && Math.abs(a.height - d.height) < 1; }));
    ok('pictures are never cropped: object-fit is contain on a neutral background', await page.evaluate(() => [...document.querySelectorAll('.qtv-card img')].every((i) => getComputedStyle(i).objectFit === 'contain') && getComputedStyle(document.querySelector('.qtv-card .qtv-pic')).backgroundColor !== 'rgba(0, 0, 0, 0)'));
    ok('the whole 1600x900 picture is inside its box (nothing cut off)', await page.evaluate(() => { const i = document.querySelector('.qtv-card[data-vkey="A"] img'); const k = Math.min(i.clientWidth / i.naturalWidth, i.clientHeight / i.naturalHeight); return k > 0 && i.naturalWidth * k <= i.clientWidth + 1 && i.naturalHeight * k <= i.clientHeight + 1; }));
    await shot(page, 'grid4-700x800');
    // the whole fake page: does it all fit?
    const full = await page.evaluate(() => ({ h: document.documentElement.scrollHeight, y: document.querySelector('.vs-answers').getBoundingClientRect().bottom }));
    info('fake page: answers end at y=' + Math.round(full.y) + ' (window 800)');
    ok('pictures + 6 answer buttons end inside 800 px', full.y <= 800, 'ends at ' + Math.round(full.y));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 2. 3 versions, 2 versions, tiny and wide windows ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q3'); await settleImages(page);
    ok('3 versions at 700: no sideways scroll, grid at most 360 px', (await noSideScroll(page)) && (await rect(page, '.qtv-grid')).h <= 360);
    await shot(page, 'grid3-700x800');
    await show(page, 'q2'); await settleImages(page);
    const g2 = await page.evaluate(() => { const r = (k) => document.querySelector(`.qtv-card[data-vkey="${k}"]`).getBoundingClientRect(); return { sameRow: Math.abs(r('A').top - r('B').top) < 2, h: document.querySelector('.qtv-grid').getBoundingClientRect().height }; });
    ok('2 versions sit in one row, grid is one row high', g2.sameRow && g2.h < 175, JSON.stringify(g2));
    await shot(page, 'grid2-700x800');
    await page.setViewportSize({ width: 1366, height: 768 });
    await show(page, 'q3'); await settleImages(page);
    ok('3 versions on a wide window sit in one row', await page.evaluate(() => { const r = (k) => document.querySelector(`.qtv-card[data-vkey="${k}"]`).getBoundingClientRect(); return Math.abs(r('A').top - r('C').top) < 2; }));
    await shot(page, 'grid3-1366x768');
    await show(page, 'q4', { split: true }); await settleImages(page);
    const sp = await rect(page, '.qtv-grid');
    ok('4 versions in the left column of the two-column page: 2 x 2, no sideways scroll', (await noSideScroll(page)) && sp.h < 400 && sp.h > 200, Math.round(sp.w) + 'x' + Math.round(sp.h));
    await shot(page, 'grid4-1366x768-split');
    await page.setViewportSize({ width: 1920, height: 1080 });
    await show(page, 'q4', { split: true }); await settleImages(page);
    await shot(page, 'grid4-1920x1080-split');
    await page.setViewportSize({ width: 400, height: 760 });
    await show(page, 'q4'); await settleImages(page);
    ok('4 versions at 400 wide: no sideways scroll', await noSideScroll(page));
    ok('4 versions at 400 wide: still 2 columns', await page.evaluate(() => { const r = (k) => document.querySelector(`.qtv-card[data-vkey="${k}"]`).getBoundingClientRect(); return Math.abs(r('A').top - r('B').top) < 2; }));
    ok('4 versions at 400 wide: all letters visible inside the window', await page.evaluate(() => [...document.querySelectorAll('.qtv-badge')].every((b) => { const r = b.getBoundingClientRect(); return r.left >= 0 && r.right <= window.innerWidth; })));
    await shot(page, 'grid4-400x760');
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 3. the big viewer ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q4'); await settleImages(page);
    await page.evaluate(() => { window.scrollTo(0, 0); });
    await openCard(page, 'A');
    ok('viewer opens', await isOpen(page));
    const dlg = await page.evaluate(() => { const d = document.querySelector('.qtl'); return { role: d.getAttribute('role'), modal: d.getAttribute('aria-modal'), label: d.getAttribute('aria-label') }; });
    ok('it is a modal dialog with a name', dlg.role === 'dialog' && dlg.modal === 'true' && !!dlg.label, JSON.stringify(dlg));
    ok('says "Version A · picture 1 of 2"', (await count(page)) === 'Version A · picture 1 of 2', await count(page));
    ok('the first picture is shown', await imgReady(page));
    ok('caption bar shows label and caption', /Big photo on top/.test(await text(page, '.qtl-title')) && /barn photo/.test(await text(page, '.qtl-text')));
    ok('four chips A B C D', (await page.locator('.qtl-chip').allTextContents()).join('') === 'ABCD');
    ok('chip A is current', (await page.getAttribute('.qtl-chip:nth-child(1)', 'aria-current')) === 'true');
    ok('focus is inside the viewer', await page.evaluate(() => !!document.activeElement.closest('.qtl')));
    ok('overlay colour comes from --overlay', await page.evaluate(() => { const d = document.querySelector('.qtl'); const probe = document.createElement('div'); probe.style.background = 'var(--overlay)'; document.body.appendChild(probe); const want = getComputedStyle(probe).backgroundColor; probe.remove(); return getComputedStyle(d).backgroundColor === want && want !== 'rgba(0, 0, 0, 0)'; }));
    ok('the picture in the big viewer sends no referrer', await page.evaluate(() => document.querySelector('.qtl-img').referrerPolicy === 'no-referrer'));
    ok('the picture is fitted inside the window (700 x 800)', await page.evaluate(() => { const i = document.querySelector('.qtl-img').getBoundingClientRect(), s = document.querySelector('.qtl-stage').getBoundingClientRect(); return i.left >= s.left - 1 && i.right <= s.right + 1 && i.top >= s.top - 1 && i.bottom <= s.bottom + 1; }));
    ok('no sideways scroll behind it', await noSideScroll(page));
    await shot(page, 'viewer-fit-700x800');

    // the page behind: no scrolling, no focus
    const y0 = await page.evaluate(() => window.scrollY);
    await page.mouse.wheel(0, 600);
    await page.keyboard.press('PageDown');
    await page.waitForTimeout(150);
    ok('the page behind cannot scroll', (await page.evaluate(() => window.scrollY)) === y0 && (await page.evaluate(() => getComputedStyle(document.body).overflow)) === 'hidden');
    ok('the page behind is switched off for the keyboard (inert)', await page.evaluate(() => document.getElementById('vs').inert === true));

    // arrows go through ALL pictures of ALL versions
    await page.keyboard.press('ArrowRight');
    ok('right arrow: A picture 2 of 2', (await count(page)) === 'Version A · picture 2 of 2', await count(page));
    ok('picture 2 is the phone view', await until(page, () => { const i = document.querySelector('.qtl-img'); return !!i && i.complete && i.naturalWidth === 600 && i.naturalHeight === 1200; }, null, 8000));
    await shot(page, 'viewer-tall-700x800');
    await page.keyboard.press('ArrowRight');
    ok('right arrow: on to Version B', (await count(page)) === 'Version B', await count(page));
    ok('chip B is current now', (await page.getAttribute('.qtl-chip:nth-child(2)', 'aria-current')) === 'true' && (await page.getAttribute('.qtl-chip:nth-child(1)', 'aria-current')) === null);
    await page.keyboard.press('ArrowRight');
    ok('then C picture 1 of 3', (await count(page)) === 'Version C · picture 1 of 3', await count(page));
    await page.keyboard.press('ArrowLeft'); await page.keyboard.press('ArrowLeft');
    ok('left arrow twice: back to A picture 2 of 2', (await count(page)) === 'Version A · picture 2 of 2', await count(page));
    await page.keyboard.press('Home');
    ok('Home: first picture', (await count(page)) === 'Version A · picture 1 of 2');
    await page.keyboard.press('ArrowLeft');
    ok('left arrow on the first picture wraps to the very last (D)', (await count(page)) === 'Version D', await count(page));
    await page.keyboard.press('End');
    ok('End: last picture', (await count(page)) === 'Version D');
    // broken picture in the viewer
    ok('broken picture: calm box, not a blank screen', await until(page, () => { const p = document.querySelector('.qtl-ph'); return !!p && /Picture did not load/.test(p.textContent) && /Plain page with the name/.test(p.textContent); }, null, 8000));
    ok('broken picture: "Try again" button', (await page.locator('.qtl-again').count()) === 1);
    ok('broken picture: the caption bar still says what it is', /Plain and simple/.test(await text(page, '.qtl-title')));
    ok('broken picture: full size is not offered', (await page.getAttribute('.qtl-mode', 'aria-disabled')) === 'true');
    await shot(page, 'viewer-broken-700x800');
    await page.keyboard.press('ArrowRight');
    ok('wrap-around works the other way (to A picture 1)', (await count(page)) === 'Version A · picture 1 of 2');

    // on-screen arrows + chips
    await page.click('.qtl-next');
    ok('on-screen next arrow', (await count(page)) === 'Version A · picture 2 of 2');
    await page.click('.qtl-prev');
    ok('on-screen previous arrow', (await count(page)) === 'Version A · picture 1 of 2');
    await page.click('.qtl-chip:nth-child(3)');
    ok('chip C jumps to Version C picture 1 of 3', (await count(page)) === 'Version C · picture 1 of 3', await count(page));
    await page.click('.qtl-chip:nth-child(2)');
    ok('chip B jumps to Version B', (await count(page)) === 'Version B');
    ok('arrows are real buttons with names', (await page.getAttribute('.qtl-next', 'aria-label')) === 'Next picture' && (await page.getAttribute('.qtl-prev', 'aria-label')) === 'Previous picture');

    // fit / full size
    await page.keyboard.press('Home'); await imgReady(page);
    ok('starts in "fit" mode', (await page.getAttribute('.qtl', 'data-mode')) === 'fit');
    const c = await rect(page, '.qtl-img');
    await page.mouse.click(c.x + c.w / 2, c.y + c.h / 2);
    ok('click on the picture: full size', await until(page, () => document.querySelector('.qtl').getAttribute('data-mode') === 'actual', null, 4000));
    const act = await page.evaluate(() => { const i = document.querySelector('.qtl-img').getBoundingClientRect(), s = document.querySelector('.qtl-scroll'); return { w: Math.round(i.width), h: Math.round(i.height), sw: s.scrollWidth, cw: s.clientWidth, sl: s.scrollLeft, st: s.scrollTop }; });
    ok('full size = the real pixels (1600 x 900) and it scrolls', act.w === 1600 && act.h === 900 && act.sw > act.cw, JSON.stringify(act));
    ok('it zoomed in where she clicked (centre of the picture)', act.sl > 300 && act.sl < 900, 'scrollLeft ' + act.sl);
    ok('the button now says "Fit to window"', /Fit to window/.test(await text(page, '.qtl-mode')));
    await shot(page, 'viewer-actual-700x800');
    // drag to move around
    const s0 = await page.evaluate(() => document.querySelector('.qtl-scroll').scrollLeft);
    await page.mouse.move(350, 300); await page.mouse.down(); await page.mouse.move(250, 280, { steps: 5 }); await page.mouse.up();
    const s1 = await page.evaluate(() => document.querySelector('.qtl-scroll').scrollLeft);
    ok('dragging moves the big picture', s1 > s0 + 50, s0 + ' -> ' + s1);
    ok('a drag does not flip the mode', (await page.getAttribute('.qtl', 'data-mode')) === 'actual');
    await page.keyboard.press('ArrowRight');
    ok('arrow keys still change picture while in full size, and it goes back to fit', (await count(page)) === 'Version A · picture 2 of 2' && (await page.getAttribute('.qtl', 'data-mode')) === 'fit');
    await page.keyboard.press('Home'); await imgReady(page);
    await page.keyboard.press('+');
    ok('"+" switches to full size', (await page.getAttribute('.qtl', 'data-mode')) === 'actual');
    await page.keyboard.press('+');
    ok('"+" again switches back to fit', (await page.getAttribute('.qtl', 'data-mode')) === 'fit');
    await page.click('.qtl-mode');
    ok('the button works too', (await page.getAttribute('.qtl', 'data-mode')) === 'actual');
    await page.keyboard.press('-');
    ok('"-" goes back to fit', (await page.getAttribute('.qtl', 'data-mode')) === 'fit');
    await page.keyboard.press('Enter');
    ok('Enter on the picture area toggles', (await page.getAttribute('.qtl', 'data-mode')) === 'actual');
    await page.keyboard.press('Enter');

    // the dark space round the picture closes the viewer
    await page.keyboard.press('Home'); await imgReady(page);
    const st = await rect(page, '.qtl-stage'), pc = await page.evaluate(() => { const i = document.querySelector('.qtl-img').getBoundingClientRect(); return { top: i.top, bottom: i.bottom }; });
    await page.mouse.click(st.x + st.w / 2, st.y + 12);
    ok('click on the dark space above the picture closes the viewer', !(await isOpen(page)));
    ok('and focus goes back to the thumbnail', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="A"]')));
    await openCard(page, 'A'); await imgReady(page);
    // letters must not reach the page behind (it has A-D answer shortcuts)
    await page.evaluate(() => { window.__keys = []; document.addEventListener('keydown', (e) => window.__keys.push(e.key)); });
    await page.keyboard.press('b'); await page.keyboard.press('C');
    ok('letter keys do not reach the page behind the viewer', (await page.evaluate(() => window.__keys.filter((k) => /^[a-d]$/i.test(k)).length)) === 0);
    // focus trap
    const seen = new Set(); let outside = 0;
    for (let n = 0; n < 16; n++) { await page.keyboard.press('Tab'); const inside = await page.evaluate(() => !!document.activeElement.closest('.qtl')); if (!inside) outside++; seen.add(await activeInfo(page)); }
    ok('Tab goes round inside the viewer (never leaves)', outside === 0 && seen.size >= 6, 'distinct stops: ' + seen.size);
    let outside2 = 0;
    for (let n = 0; n < 16; n++) { await page.keyboard.press('Shift+Tab'); if (!(await page.evaluate(() => !!document.activeElement.closest('.qtl')))) outside2++; }
    ok('Shift+Tab goes round inside the viewer too', outside2 === 0);

    // Esc closes, focus goes back to the thumbnail
    await page.keyboard.press('Escape');
    ok('Esc closes the viewer', !(await isOpen(page)));
    ok('focus is back on the thumbnail of Version A', await page.evaluate(() => document.activeElement && document.activeElement.matches('.qtv-card[data-vkey="A"]')), await activeInfo(page));
    ok('the page behind works again (not inert, scrolls)', await page.evaluate(() => document.getElementById('vs').inert === false && document.body.style.overflow === '' && document.documentElement.style.overflow === ''));
    await page.mouse.wheel(0, 300); await page.waitForTimeout(150);
    ok('the page can scroll again', (await page.evaluate(() => window.scrollY)) > 0);
    await page.evaluate(() => window.scrollTo(0, 0));

    // focus goes to the version she looked at LAST, not the one she opened
    await openCard(page, 'A'); await imgReady(page);
    await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight');
    ok('(setup) the viewer shows Version B', (await count(page)) === 'Version B');
    await page.keyboard.press('Escape');
    ok('after Esc, focus is on thumbnail B (the one she saw last), not A', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="B"]')), await activeInfo(page));
    await openCard(page, 'A'); await imgReady(page);
    await page.click('.qtl-chip:nth-child(3)');
    await page.click('.qtl-close');
    ok('after Close, focus is on thumbnail C when she was looking at C', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="C"]')), await activeInfo(page));
    await page.evaluate(() => window.scrollTo(0, 0));
    // close button + focus return for another card, from the keyboard
    await page.focus('.qtv-card[data-vkey="C"]');
    await page.keyboard.press('Enter');
    await page.waitForSelector('.qtl');
    ok('Enter on a thumbnail opens it (Version C)', (await count(page)) === 'Version C · picture 1 of 3');
    await page.click('.qtl-close');
    ok('Close button closes', !(await isOpen(page)));
    ok('focus back on thumbnail C', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="C"]')));
    await page.focus('.qtv-card[data-vkey="B"]'); await page.keyboard.press('Space');
    await page.waitForSelector('.qtl');
    ok('Space on a thumbnail opens it (Version B)', (await count(page)) === 'Version B');
    await page.keyboard.press('Escape');
    ok('focus back on thumbnail B', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="B"]')));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 4. a redraw while the viewer is open, a route change, a second render ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q4'); await settleImages(page);
    await page.evaluate(() => { window.__first = document.querySelector('.qtv-card[data-vkey="A"]'); window.VS.again('q4'); });
    ok('rendering the same question again changes nothing (same elements)', await page.evaluate(() => document.querySelector('.qtv-card[data-vkey="A"]') === window.__first && document.querySelectorAll('.qtv').length === 1));
    await page.evaluate(() => { const q = JSON.parse(JSON.stringify(window.VS.F.q4)); q.versions[0].label = 'Changed label'; window.QT.visual.render(window.VS.host(), q); });
    ok('a changed question is drawn again (still one picture area)', (await text(page, '.qtv-card[data-vkey="A"] .qtv-label')) === 'Changed label' && (await page.locator('.qtv').count()) === 1);
    await show(page, 'q4'); await settleImages(page);
    await openCard(page, 'B');
    // the page draws everything again behind the viewer (Claude updated something): the viewer stays, focus comes back to the NEW thumbnail
    await page.evaluate(() => { window.VS.show('q4'); });
    ok('viewer stays open when the page behind is redrawn', await isOpen(page));
    await page.keyboard.press('Escape');
    ok('viewer closed; focus lands on the new thumbnail B', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="B"]') && document.activeElement.isConnected));
    await openCard(page, 'C');
    await page.evaluate(() => { window.QT.emit('route', { view: 'home' }); });
    ok('a route change closes the viewer', !(await isOpen(page)));
    ok('and the page behind is usable again', await page.evaluate(() => document.getElementById('vs').inert === false && document.body.style.overflow === ''));
    // opening twice does not stack
    await page.evaluate(() => { const c = document.querySelector('.qtv-card[data-vkey="A"]'); c.click(); c.click(); });
    ok('opening twice shows one viewer', (await page.locator('.qtl').count()) === 1);
    await page.keyboard.press('Escape');
    ok('one Esc closes it for good', (await page.locator('.qtl').count()) === 0 && (await page.evaluate(() => document.getElementById('vs').inert === false)));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 5. "How it looks now" ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'qbefore');
    const tg = '.qtv-today-toggle';
    ok('with a grid: a small link above the grid, strip folded away', (await page.getAttribute(tg, 'aria-expanded')) === 'false' && !(await page.isVisible('.qtv-mini')) && (await text(page, tg)) === 'See how it looks now', await text(page, tg));
    const head = await page.evaluate(() => { const hd = document.querySelector('.qtv-head').getBoundingClientRect(), t = document.querySelector('.qtv-today-toggle').getBoundingClientRect(), g = document.querySelector('.qtv-grid').getBoundingClientRect(), r = document.querySelector('.qtv').getBoundingClientRect(); return { rowH: hd.height, btnH: t.height, btnRight: t.right, boxRight: r.right, gridTop: g.top, rowBottom: hd.bottom, total: g.bottom - hd.top }; });
    ok('the link row is 40 px high and the button (40 px) stays inside it, never touching the pictures', head.rowH <= 41 && head.btnH >= 40 && head.btnH <= head.rowH + 0.5 && head.gridTop >= head.rowBottom - 0.5, JSON.stringify(head));
    ok('the link is right-aligned', Math.abs(head.btnRight - head.boxRight) < 12, JSON.stringify(head));
    ok('link row + grid is at most 400 px at 700 wide', head.total <= 400 && head.total >= 330, Math.round(head.total) + ' px');
    ok('the label is on the LEFT of the same row, the link on the RIGHT', await page.evaluate(() => { const l = document.querySelector('.qtv-head-label').getBoundingClientRect(), t = document.querySelector('.qtv-today-toggle').getBoundingClientRect(), r = document.querySelector('.qtv').getBoundingClientRect(); return Math.abs(l.left - r.left) < 12 && Math.abs(t.right - r.right) < 12 && Math.abs((l.top + l.height / 2) - (t.top + t.height / 2)) < 6 && l.right < t.left; }));
    await page.click(tg);
    ok('click opens it and the words change', (await page.getAttribute(tg, 'aria-expanded')) === 'true' && (await page.isVisible('.qtv-mini')) && (await text(page, tg)) === 'Hide how it looks now');
    ok('the strip opens BELOW the grid', await page.evaluate(() => document.querySelector('.qtv-today-below').getBoundingClientRect().top >= document.querySelector('.qtv-grid').getBoundingClientRect().bottom - 1));
    await settleImages(page, '.qtv-today-below .qtv-pic');
    ok('two small thumbnails with captions', (await page.locator('.qtv-mini').count()) === 2 && /Home page today/.test(await text(page, '.qtv-mini .qtv-mini-cap')));
    ok('the opened strip shows the pictures at a sensible size (about 220 px wide)', await page.evaluate(() => [...document.querySelectorAll('.qtv-today-below .qtv-mini .qtv-pic')].every((p) => { const w = p.getBoundingClientRect().width; return w >= 200 && w <= 230; })));
    await shot(page, 'today-open-700x800');
    await page.evaluate(() => { window.VS.show('qbefore'); });
    ok('her choice (open) is kept when the page is redrawn', (await page.getAttribute(tg, 'aria-expanded')) === 'true');
    await page.click('.qtv-mini:nth-child(2)');
    await page.waitForSelector('.qtl');
    ok('viewer starts at the second "now" picture', (await count(page)) === 'How it looks now · picture 2 of 2', await count(page));
    ok('"Now" chip looks different (dashed) from the version letters', await page.evaluate(() => getComputedStyle(document.querySelector('.qtl-chip')).borderTopStyle === 'dashed' && getComputedStyle(document.querySelectorAll('.qtl-chip')[1]).borderTopStyle === 'solid'));
    ok('chips: Now, A, B, C, D', (await page.locator('.qtl-chip').allTextContents()).join(',') === 'Now,A,B,C,D');
    ok('no pick button on a "now" picture', await page.evaluate(() => document.querySelector('.qtl-pick').hidden));
    await page.keyboard.press('ArrowRight');
    ok('next goes on to Version A', (await count(page)) === 'Version A · picture 1 of 2');
    ok('...and now the pick button shows', await page.evaluate(() => !document.querySelector('.qtl-pick').hidden));
    await page.click('.qtl-chip:nth-child(1)');
    ok('chip Now goes back', (await count(page)) === 'How it looks now · picture 1 of 2');
    await page.keyboard.press('Escape');
    ok('focus returns to the small thumbnail of the picture she saw last (the first one)', await page.evaluate(() => document.activeElement.matches('.qtv-mini[data-idx="0"]')));
    await page.click(tg);
    ok('folds away again', !(await page.isVisible('.qtv-mini')) && (await text(page, tg)) === 'See how it looks now');
    await show(page, 'qsolo');
    ok('with no versions grid the strip starts open, in its own box', (await page.getAttribute(tg, 'aria-expanded')) === 'true' && (await page.isVisible('.qtv-mini')) && (await page.locator('.qtv-today.is-solo').count()) === 1 && (await text(page, tg)).startsWith('How it looks now'));
    await settleImages(page);
    await shot(page, 'today-solo-700x800');
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 5b. the "Pick" buttons on the pictures ================= */
  {
    const page = await newPage(browser, site.url);
    await page.evaluate(() => window.VS.show('q4', { pick: false }));
    await settleImages(page);
    const noPickH = (await rect(page, '.qtv-grid')).h;
    ok('without onPick there are no Pick buttons', (await page.locator('.qtv-pick').count()) === 0);
    await show(page, 'q4'); await settleImages(page);
    ok('with onPick: a Pick button on every version that has a picture (4, also the one whose picture did not load)', (await page.locator('.qtv-pick').count()) === 4);
    ok('Pick button text "Pick A" and the spoken name', (await text(page, '.qtv-pick[data-pick="A"]')) === 'Pick A' && (await page.getAttribute('.qtv-pick[data-pick="A"]', 'aria-label')) === 'Pick version A: Big photo on top');
    ok('the Pick buttons need no extra height (grid same as without them)', Math.abs((await rect(page, '.qtv-grid')).h - noPickH) < 1, noPickH + ' vs ' + (await rect(page, '.qtv-grid')).h);
    ok('each Pick button sits INSIDE the picture box, bottom right', await page.evaluate(() => ['A', 'B', 'C', 'D'].every((k) => { const p = document.querySelector(`.qtv-card[data-vkey="${k}"] .qtv-pic`).getBoundingClientRect(), b = document.querySelector(`.qtv-pick-in`).ownerDocument.querySelector(`.qtv-pick[data-pick="${k}"] .qtv-pick-in`).getBoundingClientRect(); return b.left >= p.left && b.right <= p.right + 1 && b.top >= p.top && b.bottom <= p.bottom + 1 && b.right > p.right - 20 && b.bottom > p.bottom - 14; })));
    ok('every Pick button has a 40 px hit area', await page.evaluate(() => [...document.querySelectorAll('.qtv-pick')].every((b) => { const r = b.getBoundingClientRect(); return r.height >= 40 && r.width >= 40; })));
    ok('the Pick button is not inside the picture button (no nested buttons)', await page.evaluate(() => !document.querySelector('button button') && [...document.querySelectorAll('.qtv-pick')].every((b) => b.parentElement.classList.contains('qtv-cell'))));
    // keyboard order: picture, its Pick, next picture
    await page.focus('.qtv-card[data-vkey="A"]');
    await page.keyboard.press('Tab');
    ok('Tab: from picture A to Pick A', await page.evaluate(() => document.activeElement.matches('.qtv-pick[data-pick="A"]')));
    await page.keyboard.press('Tab');
    ok('Tab: then picture B', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="B"]')));
    await shot(page, 'pick-grid-700x800');
    // clicking Pick does not open the viewer; clicking the picture does
    await page.evaluate(() => { window.__picks.length = 0; });
    await page.click('.qtv-pick[data-pick="B"]');
    ok('click on "Pick B" calls onPick("B") and does not open the viewer', JSON.stringify(await page.evaluate(() => window.__picks)) === '["B"]' && !(await isOpen(page)));
    await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab');
    await page.focus('.qtv-pick[data-pick="C"]'); await page.keyboard.press('Enter');
    ok('keyboard Enter on "Pick C" picks C', JSON.stringify(await page.evaluate(() => window.__picks)) === '["B","C"]' && !(await isOpen(page)));
    // what she picked is shown
    await page.evaluate(() => window.VS.setAnswer('q4', 'B'));
    const mark = await page.evaluate(() => { const c = (k) => document.querySelector(`.qtv-cell[data-cell="${k}"]`); return { b: c('B').classList.contains('is-picked'), a: c('A').classList.contains('is-picked'), text: document.querySelector('.qtv-pick[data-pick="B"]').textContent, other: document.querySelector('.qtv-pick[data-pick="A"]').textContent, pressed: document.querySelector('.qtv-pick[data-pick="B"]').getAttribute('aria-pressed'), border: getComputedStyle(c('B').querySelector('.qtv-card')).borderTopColor, borderA: getComputedStyle(c('A').querySelector('.qtv-card')).borderTopColor }; });
    ok('her pick (B) shows "✓ Your pick" with a green border', mark.b && !mark.a && mark.text === '✓ Your pick' && mark.other === 'Pick A' && mark.pressed === 'true' && mark.border !== mark.borderA, JSON.stringify(mark));
    await shot(page, 'picked-grid-700x800');
    await page.evaluate(() => window.VS.setAnswer('q4', 'C'));
    ok('a new answer moves the mark', await page.evaluate(() => document.querySelector('.qtv-cell[data-cell="C"]').classList.contains('is-picked') && !document.querySelector('.qtv-cell[data-cell="B"]').classList.contains('is-picked')));
    await page.evaluate(() => window.VS.setAnswer('q4', 'unsure'));
    ok('"not sure" or "own answer" marks nothing', (await page.locator('.qtv-cell.is-picked').count()) === 0);
    await page.evaluate(() => window.VS.setAnswer('q4', 'D'));
    await page.evaluate(() => window.VS.setAnswer('q4', null));
    ok('undo (answer removed) clears the mark', (await page.locator('.qtv-cell.is-picked').count()) === 0);
    await page.evaluate(() => window.VS.setAnswer('q4', 'A'));
    await page.evaluate(() => { window.VS.show('q4'); });
    ok('the mark is there at once when the pictures are drawn again', await page.evaluate(() => document.querySelector('.qtv-cell[data-cell="A"]').classList.contains('is-picked')));
    // a redraw with a new onPick function must call the NEW one
    await page.evaluate(() => { window.__picks.length = 0; window.VS.again('q4', { onPick: (k) => window.__picks.push('new:' + k) }); });
    await page.click('.qtv-pick[data-pick="D"]');
    ok('drawing again with a new onPick: the new one is used', JSON.stringify(await page.evaluate(() => window.__picks)) === '["new:D"]');
    // the viewer
    await page.evaluate(() => { window.__picks.length = 0; window.VS.show('q4'); window.VS.setAnswer('q4', null); });
    await openCard(page, 'C'); await imgReady(page);
    ok('viewer: "Pick this version" button for Version C', (await text(page, '.qtl-pick')) === 'Pick this version' && (await page.getAttribute('.qtl-pick', 'aria-label')) === 'Pick this version: Version C, Three pictures in a row');
    await shot(page, 'viewer-pick-700x800');
    await page.click('.qtl-pick');
    ok('viewer: clicking it picks C (same onPick) and the viewer stays open', JSON.stringify(await page.evaluate(() => window.__picks)) === '["C"]' && (await isOpen(page)));
    await page.evaluate(() => window.VS.setAnswer('q4', 'C'));
    ok('viewer: the button now says "✓ Your pick"', (await text(page, '.qtl-pick')) === '✓ Your pick' && (await page.getAttribute('.qtl-pick', 'aria-pressed')) === 'true');
    await page.keyboard.press('ArrowLeft');   // Version B
    ok('viewer: on another version it offers to pick that one', (await text(page, '.qtl-pick')) === 'Pick this version' && /Version B/.test(await page.getAttribute('.qtl-pick', 'aria-label')));
    await page.keyboard.press('Escape');
    ok('after closing, the grid shows C as picked', await page.evaluate(() => document.querySelector('.qtv-cell[data-cell="C"]').classList.contains('is-picked')));
    // viewer without onPick
    await page.evaluate(() => window.VS.show('q4', { pick: false }));
    await openCard(page, 'A');
    ok('viewer without onPick has no pick button', await page.evaluate(() => document.querySelector('.qtl-pick').hidden));
    await page.keyboard.press('Escape');
    // clean-up of the "something changed" listeners
    const subs = await page.evaluate(() => { const a = window.__subs; window.VS.cleanup(); const b = window.__subs; window.VS.show('q4'); const c = window.__subs; window.VS.show('q4'); const d = window.__subs; return [a, b, c, d]; });
    ok('the pictures stop listening when they are cleaned up (and never listen twice)', subs[1] === subs[0] - 1 && subs[2] === subs[1] + 1 && subs[3] === subs[2], JSON.stringify(subs));
    const subs2 = await page.evaluate(() => { const a = window.__subs; document.querySelector('.qtv-card[data-vkey="A"]').click(); const b = window.__subs; window.QT.lightbox.close(); const c = window.__subs; return [a, b, c]; });
    ok('the viewer listens only while it is open', subs2[1] === subs2[0] + 1 && subs2[2] === subs2[0], JSON.stringify(subs2));
    // the two-column wide page and the narrow page
    await page.setViewportSize({ width: 400, height: 760 });
    await show(page, 'q4'); await settleImages(page);
    ok('400 wide: Pick buttons stay inside their pictures, no sideways scroll', (await noSideScroll(page)) && (await page.evaluate(() => ['A', 'B', 'C', 'D'].every((k) => { const p = document.querySelector(`.qtv-card[data-vkey="${k}"] .qtv-pic`).getBoundingClientRect(), b = document.querySelector(`.qtv-pick[data-pick="${k}"] .qtv-pick-in`).getBoundingClientRect(); return b.left >= p.left && b.right <= p.right + 1 && b.top >= p.top && b.bottom <= p.bottom + 1; }))));
    await page.evaluate(() => window.VS.setAnswer('q4', 'B'));
    await shot(page, 'picked-grid-400x760');
    // very big text (root font 32 px): the Pick button must not sit on the picture and steal its click
    await page.setViewportSize({ width: 700, height: 800 });
    await page.addStyleTag({ content: 'html{font-size:32px}' });
    await show(page, 'q4'); await settleImages(page);
    ok('32 px text: each Pick button is UNDER its picture, not on it', await page.evaluate(() => ['A', 'B', 'C', 'D'].every((k) => { const c = document.querySelector(`.qtv-card[data-vkey="${k}"]`).getBoundingClientRect(), b = document.querySelector(`.qtv-pick[data-pick="${k}"]`).getBoundingClientRect(); return b.top >= c.bottom - 1 && b.width > 80; })));
    await page.click('.qtv-card[data-vkey="B"]');
    ok('32 px text: a click in the middle of a picture opens the viewer', await isOpen(page));
    await page.keyboard.press('Escape');
    await shot(page, 'picked-grid-700-text32');
    ok('32 px text: no sideways scroll', await noSideScroll(page));
    await page.evaluate(() => { document.querySelectorAll('style').forEach((st) => { if (st.textContent === 'html{font-size:32px}') st.remove(); }); });
    await page.setViewportSize({ width: 1366, height: 768 });
    await show(page, 'q4', { split: true }); await settleImages(page);
    await shot(page, 'picked-grid-1366x768');
    await page.evaluate(() => window.VS.setAnswer('q4', null));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 6. results row (Done) ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q2');
    await page.evaluate(() => window.VS.results());
    await settleImages(page, '#vs-results .qtv-pic');
    ok('thumbRow: three thumbnails', (await page.locator('#vs-results .qtv-mini').count()) === 3);
    ok('thumbRow: named for screen readers', (await page.getAttribute('#vs-results .qtv-mini:nth-child(2)', 'aria-label')) === 'Result, picture 2 of 3: Second result on a phone, open big view', await page.getAttribute('#vs-results .qtv-mini:nth-child(2)', 'aria-label'));
    ok('thumbRow: the broken one is a calm box', (await page.locator('#vs-results .qtv-mini:nth-child(3) .qtv-ph').count()) === 1);
    await shot(page, 'results-row-700x800');
    await page.click('#vs-results .qtv-mini:nth-child(2)');
    await page.waitForSelector('.qtl');
    ok('opens at the second picture: "Picture 2 of 3"', (await count(page)) === 'Picture 2 of 3', await count(page));
    ok('no chips for a plain set', await page.evaluate(() => document.querySelector('.qtl-chips').hidden));
    await page.keyboard.press('ArrowRight');
    ok('third picture (broken) shows the calm box', await until(page, () => !!document.querySelector('.qtl-ph'), null, 8000));
    await page.keyboard.press('Escape');
    ok('focus goes to the thumbnail of the picture she saw last (the third)', await page.evaluate(() => document.activeElement.matches('#vs-results .qtv-mini:nth-child(3)')));
    ok('thumbRow with nothing gives an empty hidden row', await page.evaluate(() => { const r = window.QT.visual.thumbRow([]); const r2 = window.QT.visual.thumbRow(null); return r.hidden && r2.hidden && r.childNodes.length === 0; }));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 7. odd and unsafe input ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'qweird'); await settleImages(page);
    ok('no document text was run as page code', await page.evaluate(() => window.__pwned === undefined && !document.querySelector('img[src="x"]') && !document.querySelector('.qtv script, .qtv b')));
    ok('the label is shown as plain text', /<img src=x onerror/.test(await text(page, '.qtv-card[data-vkey="A"] .qtv-label')));
    ok('javascript: address -> calm box', await page.evaluate(() => { const c = document.querySelector('.qtv-card[data-vkey="A"]'); return !c.querySelector('img') && !!c.querySelector('.qtv-ph'); }));
    ok('no <img> anywhere has a javascript:, file: or http: address', await page.evaluate(() => [...document.querySelectorAll('img')].every((i) => /^(https:|data:image\/)/i.test(i.getAttribute('src') || ''))));
    ok('a version with no pictures: shown, not clickable, says so', await page.evaluate(() => { const c = document.querySelector('.qtv-card[data-vkey="C"]'); return c && c.tagName !== 'BUTTON' && /No picture/.test(c.textContent); }));
    ok('a very long label and caption are cut after two lines, the grid still fits', await page.evaluate(() => { const l = document.querySelector('.qtv-card[data-vkey="B"] .qtv-text'); return getComputedStyle(l).webkitLineClamp === '2' && l.getBoundingClientRect().height < 44 && document.documentElement.scrollWidth <= innerWidth; }));
    ok('long caption has a full-text tooltip', /very long label/.test((await page.getAttribute('.qtv-card[data-vkey="B"]', 'title')) || ''));
    await shot(page, 'weird-700x800');
    await openCard(page, 'A');
    ok('viewer: unsafe address shows the calm box', await until(page, () => !!document.querySelector('.qtl-ph'), null, 5000));
    ok('viewer: no "Try again" for a refused address', (await page.locator('.qtl-again').count()) === 0);
    ok('viewer: label with HTML is plain text', /<img src=x onerror/.test(await text(page, '.qtl-title')) && (await page.evaluate(() => window.__pwned === undefined)));
    await page.keyboard.press('ArrowRight'); await page.keyboard.press('ArrowRight');
    ok('versions without pictures are skipped by the arrows (A, B, D...)', (await count(page)) === 'Version D · picture 1 of 2', await count(page));
    ok('chips only for versions that have pictures (A B D)', (await page.locator('.qtl-chip').allTextContents()).join('') === 'ABD');
    await page.keyboard.press('Escape');
    // empty / strange questions never crash
    const res = await page.evaluate(() => {
      const out = [], h = document.createElement('div');
      [null, undefined, {}, { versions: 'x' }, { versions: [null, 5, { images: 'no' }] }, { beforeImages: [null, { url: 5 }], versions: [] }, { versions: [{ key: 'a', images: [{}] }] }].forEach((q) => { try { window.QT.visual.render(h, q); out.push('ok'); } catch (e) { out.push('ERR ' + e.message); } });
      try { window.QT.visual.render(null, {}); window.QT.lightbox.open([], 0); window.QT.lightbox.open(null); window.QT.lightbox.close(); out.push('ok'); } catch (e) { out.push('ERR ' + e.message); }
      return out;
    });
    ok('odd or empty questions never crash', res.every((r) => r === 'ok'), res.join(','));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 8. small pictures ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'qsmall'); await settleImages(page);
    await openCard(page, 'A'); await imgReady(page);
    const r = await rect(page, '.qtl-img');
    ok('a small picture is not blown up (320 x 200)', Math.round(r.w) <= 320 && Math.round(r.h) <= 200, Math.round(r.w) + 'x' + Math.round(r.h));
    ok('so "Full size" is dimmed and does nothing', (await page.getAttribute('.qtl-mode', 'aria-disabled')) === 'true');
    await page.mouse.click(r.x + r.w / 2, r.y + r.h / 2);
    await page.keyboard.press('+');
    ok('click and "+" leave it alone', (await page.getAttribute('.qtl', 'data-mode')) === 'fit');
    await shot(page, 'viewer-small-700x800');
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 9. laptop 1366 x 768 ================= */
  {
    const page = await newPage(browser, site.url, { w: 1366, h: 768 });
    await show(page, 'q4', { split: true }); await settleImages(page);
    await openCard(page, 'C'); await imgReady(page);
    ok('1366: picture fits inside the stage', await page.evaluate(() => { const i = document.querySelector('.qtl-img').getBoundingClientRect(), s = document.querySelector('.qtl-stage').getBoundingClientRect(); return i.left >= s.left - 1 && i.right <= s.right + 1 && i.top >= s.top - 1 && i.bottom <= s.bottom + 1; }));
    ok('1366: top bar, caption and arrows all visible', await page.evaluate(() => ['.qtl-top', '.qtl-foot', '.qtl-prev', '.qtl-next', '.qtl-close'].every((s) => { const r = document.querySelector(s).getBoundingClientRect(); return r.width > 0 && r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight; })));
    await shot(page, 'viewer-fit-1366x768');
    await page.keyboard.press('ArrowRight'); await imgReady(page);
    ok('1366: 1600x900 can be shown full size', (await page.getAttribute('.qtl-mode', 'aria-disabled')) === 'false');
    await page.keyboard.press('+');
    await shot(page, 'viewer-actual-1366x768');
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 10. narrow (400 px) ================= */
  {
    const page = await newPage(browser, site.url, { w: 400, h: 760 });
    await show(page, 'q4'); await settleImages(page);
    await openCard(page, 'A'); await imgReady(page);
    const fit = await page.evaluate(() => {
      const w = innerWidth, h = innerHeight;
      const inside = (s) => { const e = document.querySelector(s); if (!e) return 'missing ' + s; const r = e.getBoundingClientRect(); return (r.left >= -0.5 && r.right <= w + 0.5 && r.top >= -0.5 && r.bottom <= h + 0.5 && r.width > 0) ? true : s + ' ' + [r.left, r.right, r.top, r.bottom].map(Math.round).join(','); };
      const bad = ['.qtl-close', '.qtl-mode', '.qtl-count', '.qtl-prev', '.qtl-next', '.qtl-foot', '.qtl-chip:nth-child(4)'].map(inside).filter((x) => x !== true);
      return { bad, scrollW: document.querySelector('.qtl').scrollWidth, w };
    });
    ok('400 wide: every button and the caption fit inside the window', fit.bad.length === 0, fit.bad.join(' | '));
    ok('400 wide: viewer has no sideways scroll', fit.scrollW <= fit.w);
    ok('400 wide: buttons are at least 40 px tall', await page.evaluate(() => ['.qtl-close', '.qtl-mode', '.qtl-chip', '.qtl-prev', '.qtl-next'].every((s) => document.querySelector(s).getBoundingClientRect().height >= 40)));
    ok('400 wide: the picture uses the width', (await rect(page, '.qtl-img')).w >= 380);
    await shot(page, 'viewer-fit-400x760');
    await page.keyboard.press('+');
    await shot(page, 'viewer-actual-400x760');
    // swipe with a finger (synthetic touch pointer events)
    await page.keyboard.press('-');
    const swiped = await page.evaluate(() => {
      const s = document.querySelector('.qtl-scroll');
      const fire = (type, x, y) => s.dispatchEvent(new PointerEvent(type, { pointerType: 'touch', pointerId: 7, isPrimary: true, bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, buttons: type === 'pointerup' ? 0 : 1 }));
      fire('pointerdown', 300, 300); fire('pointermove', 200, 305); fire('pointerup', 120, 310);
      return document.querySelector('.qtl-count').textContent;
    });
    ok('a swipe to the left shows the next picture', swiped === 'Version A · picture 2 of 2', swiped);
    const swiped2 = await page.evaluate(() => {
      const s = document.querySelector('.qtl-scroll');
      const fire = (type, x, y) => s.dispatchEvent(new PointerEvent(type, { pointerType: 'touch', pointerId: 8, isPrimary: true, bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, buttons: type === 'pointerup' ? 0 : 1 }));
      fire('pointerdown', 100, 300); fire('pointermove', 200, 305); fire('pointerup', 300, 310);
      return document.querySelector('.qtl-count').textContent;
    });
    ok('a swipe to the right goes back', swiped2 === 'Version A · picture 1 of 2', swiped2);
    await page.keyboard.press('Escape');
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 10b. a touch screen: tap to open, tap picture, tap dark space ================= */
  {
    const page = await newPage(browser, site.url, { w: 420, h: 800, touch: true });
    await show(page, 'q4'); await settleImages(page);
    ok('touch: the tip says Tap', /Tap to see it big\./.test((await page.getAttribute('.qtv-card[data-vkey="C"]', 'title')) || ''));
    await page.tap('.qtv-card[data-vkey="C"]');
    await page.waitForSelector('.qtl');
    await imgReady(page);
    ok('touch: tap opens Version C', (await count(page)) === 'Version C · picture 1 of 3');
    ok('touch: help talks about swiping', /Swipe/.test(await text(page, '.qtl-help')), await text(page, '.qtl-help'));
    await page.tap('.qtl-next');
    ok('touch: tap on the arrow goes on', (await count(page)) === 'Version C · picture 2 of 3');
    const r = await rect(page, '.qtl-img');
    await page.touchscreen.tap(r.x + r.w / 2, r.y + r.h / 2);
    ok('touch: tap on the picture switches to full size', await until(page, () => document.querySelector('.qtl').getAttribute('data-mode') === 'actual', null, 4000));
    await page.touchscreen.tap(210, 400);
    ok('touch: tap again goes back to fit', await until(page, () => document.querySelector('.qtl').getAttribute('data-mode') === 'fit', null, 4000));
    await page.touchscreen.tap(210, 80);
    ok('touch: a tap on the dark space closes', await until(page, () => !document.querySelector('.qtl'), null, 4000));
    ok('touch: focus back on the thumbnail', await page.evaluate(() => document.activeElement.matches('.qtv-card[data-vkey="C"]')));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 10c. names for screen readers ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'qbefore'); await page.click('.qtv-today-toggle'); await settleImages(page);
    await openCard(page, 'A'); await imgReady(page);
    const bad = await page.evaluate(() => [...document.querySelectorAll('button, [role="group"], [role="dialog"]')].filter((b) => !(b.getAttribute('aria-label') || '').trim() && !b.textContent.trim()).map((b) => b.className));
    ok('every button and group has a name', bad.length === 0, bad.join(','));
    ok('images inside buttons are hidden from screen readers (the button has the name)', await page.evaluate(() => [...document.querySelectorAll('.qtv-card img, .qtv-mini img')].every((i) => i.getAttribute('alt') === '')));
    ok('the viewer picture has its description', await page.evaluate(() => !!document.querySelector('.qtl-img').alt));
    ok('there is a polite announcement for each picture', /Version A/.test(await text(page, '.qtl-live')), await text(page, '.qtl-live'));
    allErrs.push(...page.errs);
    await page.context().close();
  }

  /* ================= 11. reduced motion, dark mode ================= */
  {
    const page = await newPage(browser, site.url, { motion: 'reduce' });
    await show(page, 'q4'); await settleImages(page);
    await openCard(page, 'A');
    ok('reduced motion: no animation on the viewer, no fade on pictures', await page.evaluate(() => getComputedStyle(document.querySelector('.qtl')).animationName === 'none' && parseFloat(getComputedStyle(document.querySelector('.qtv-card img') || document.querySelector('.qtl-img')).transitionDuration) < 0.001));
    allErrs.push(...page.errs);
    await page.context().close();
    const page2 = await newPage(browser, site.url, { scheme: 'dark' });
    await show(page2, 'qbefore'); await page2.click('.qtv-today-toggle'); await settleImages(page2);
    await shot(page2, 'dark-grid-700x800');
    ok('dark mode: text on thumbnails is readable (card text is light on dark)', await page2.evaluate(() => { const c = getComputedStyle(document.querySelector('.qtv-card')); const l = (s) => s.match(/\d+/g).slice(0, 3).map(Number); const bg = l(c.backgroundColor), fg = l(c.color); return (fg[0] + fg[1] + fg[2]) > (bg[0] + bg[1] + bg[2]) + 200; }));
    await openCard(page2, 'B'); await imgReady(page2);
    await shot(page2, 'dark-viewer-700x800');
    allErrs.push(...page2.errs);
    await page2.context().close();
  }

  /* ================= 12. no lingering things ================= */
  {
    const page = await newPage(browser, site.url);
    await show(page, 'q4'); await settleImages(page);
    for (let n = 0; n < 5; n++) { await openCard(page, 'A'); await page.keyboard.press('ArrowRight'); await page.keyboard.press('Escape'); }
    ok('after opening and closing 5 times nothing is left behind', await page.evaluate(() => document.querySelectorAll('.qtl').length === 0 && document.body.style.overflow === '' && document.documentElement.style.overflow === '' && [...document.body.children].every((n) => !n.inert)));
    allErrs.push(...page.errs);
    await page.context().close();
  }
} catch (e) {
  ok('the test ran to the end', false, String(e && e.stack ? e.stack.split('\n').slice(0, 4).join(' / ') : e));
}
await finish({ browser, site, errs: allErrs });
