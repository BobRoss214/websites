/* question-shots.mjs (owner: question) - takes the pictures I look at: T/shots/question-state-*.png  (port 9302) */
import path from 'node:path';
import { startServer, launch } from './lib.mjs';
import { newPage, waitReady } from './mockfix.mjs';
import { seed } from './fixtures.mjs';
import { T } from './harness.mjs';
const site = await startServer({ root: T, port: 9302 });
const browser = await launch();
const errs = [];
const sleep = (n) => new Promise((r) => setTimeout(r, n));
async function open(id, w, h, scheme = 'light') {
  const page = await newPage(browser, { seed: seed(), viewport: { width: w, height: h }, errs, colorScheme: scheme });
  await page.goto(site.url + 'dist-question/full/index.html');
  await waitReady(page);
  await page.evaluate((id) => window.QT.route.go('question', { id }), id);
  await sleep(400);
  return page;
}
const shot = (page, name) => page.screenshot({ path: path.join(T, 'shots', 'question-state-' + name + '.png') });
{
  const p = await open('v-map-1', 700, 800);
  await p.evaluate(() => window.QT.answerUI.pick('v-map-1', 'B')); await sleep(900);
  await shot(p, 'visual-saved-700x800');
  await p.click('.qa-x[data-key="change"]'); await sleep(300);
  await p.keyboard.type('Make the sky bluer');
  await sleep(200); await shot(p, 'visual-change-700x800');
  await p.context().close();
}
{
  const a = await open('c-done', 700, 800);
  await shot(a, 'answered-700x800');
  await a.context().close();
  const c = await open('c-normal', 1366, 768);
  await shot(c, 'choice-1366x768');
  await c.context().close();
  const p = await open('c-short', 700, 800);
  await p.click('.qa-x[data-key="own"]'); await p.keyboard.type('Only on the contact page, please.'); await sleep(200);
  await shot(p, 'own-open-700x800');
  await p.evaluate(() => { window.__mock.failWrites = true; });
  await p.click('[data-fid="own-save"]'); await sleep(1800);
  await shot(p, 'error-700x800');
  await p.context().close();
}
{
  const p = await open('v-hero-1', 1366, 768);
  await shot(p, 'visual-answered-1366x768');
  await p.context().close();
  const k = await open('k05', 1366, 768);
  await shot(k, 'readonly-1366x768');
  await k.context().close();
  const d = await open('v-map-1', 700, 800, 'dark');
  await shot(d, 'visual-dark-700x800');
  await d.context().close();
}
console.log('errors', errs);
await browser.close(); await site.close();
