/* A rich test notebook for the Tasks part (made-up test data, not content for the owner).
 *   import { tasksDocs, TID } from './tasks.fixture.mjs';
 *   const D = tasksDocs();   // { 'tasks/map': {...}, 'workers/w-claude': {...}, 'taskAdds/u-1': {...}, 'taskEdits/...': ..., 'asks/...': ..., 'replies/...': ... }
 * About 44 tasks, 4 levels, every state, a finished branch, tasks that wait for her / Miss Cathy / Rob, and her own pending adds, edits, pause and removal. */
const MIN = 60e3, HOUR = 60 * MIN, DAY = 24 * HOUR;
export const TID = { map: 'map', winter: 'winter', photos: 'photos', terminal: 'terminal', cathy: 'cathy', oldmac: 'oldmac', trans: 'trans', mine: 'u-gift', mineKid: 'u-prices', paused: 'tasks-map-view', removed: 'u-old', edited: 'win-msg' };

export function tasksDocs(now = Date.now()) {
  const iso = (ago) => new Date(now - ago).toISOString();
  const D = {};
  let order = 0;
  const T = (id, parentId, title, state, o = {}) => {
    D['tasks/' + id] = Object.assign({
      id, parentId, title, plain: '', state, waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: ++order, createdAt: iso(5 * DAY - order * MIN),
      updatedAt: iso(3 * HOUR), doneAt: state === 'done' ? iso(6 * HOUR) : null, createdBy: 'claude', seenAt: null,
    }, o);
    return id;
  };

  /* ---- workers (for the badges) ---- */
  const W = (id, name, icon, state, o = {}) => { D['workers/' + id] = Object.assign({ id, name, parentId: null, kind: 'helper', icon, role: 'Helps with the farm site', state, now: '', waitingFor: 'none', startedAt: iso(HOUR), updatedAt: iso(2 * MIN), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 1 }, o); };
  W('w-claude', 'Claude', '🧑‍🌾', 'working', { kind: 'lead', role: 'The boss of the crew' });
  W('w-map-a', 'Map drawer A', '🗺️', 'working', { now: 'Drawing the fall map' });
  W('w-map-b', 'Map drawer B', '🖍️', 'done', { finishedAt: iso(2 * HOUR) });
  W('w-photos', 'Photo helper', '📷', 'waiting', { waitingFor: 'owner' });
  W('w-words', 'Words helper', '✏️', 'resting');
  W('w-tree', 'Tree game helper', '🎄', 'working', { now: 'Writing the all-22 message' });
  W('w-check', 'Site checker', '🔍', 'working', { now: 'Reading the translations' });
  W('w-term', 'Terminal builder', '🖥️', 'working', { now: 'Building the task tree' });

  /* ---- 1. Redraw the farm map ---- */
  T('map', null, 'Redraw the farm map', 'working', { plain: 'Make the map on the home page look like the farm, one map for each season.', workerIds: ['w-claude'], note: 'Spring and summer are done. Fall is being drawn.' });
  T('map-seasons', 'map', 'Draw the four seasons', 'working', { plain: 'One picture for spring, summer, fall and winter.' });
  T('map-spring', 'map-seasons', 'Spring map', 'done', { plain: 'Strawberry rows, the barn and the pond.', workerIds: ['w-map-b'] });
  T('map-summer', 'map-seasons', 'Summer map', 'done', { plain: 'Blueberries and sunflowers.', workerIds: ['w-map-b'] });
  T('map-fall', 'map-seasons', 'Fall map', 'working', { plain: 'Pumpkins, the wagon and the corn.', workerIds: ['w-map-a'], note: 'Drawing the pumpkin patch.' });
  T('map-fall-pump', 'map-fall', 'Pumpkin patch', 'working', { plain: 'Rows of pumpkins with a little path.', workerIds: ['w-map-a'] });
  T('map-fall-corn', 'map-fall', 'Corn and wagon', 'todo', { plain: 'A hay wagon next to the corn.' });
  T('map-winter', 'map-seasons', 'Winter map', 'todo', { plain: 'Snow, the trees and the GreenHouse.' });
  T('map-words', 'map', 'Check the map words', 'waiting', { plain: 'The names on the map must be the real names. Claude needs your OK on two of them.', waitingFor: 'owner', questionIds: ['v-map-1'], workerIds: ['w-words'] });
  T('map-words-old', 'map-words', 'Compare old and new names', 'done', { plain: 'A list of every name on the old map.' });
  T('map-words-pond', 'map-words', 'What is the pond called?', 'waiting', { plain: 'Miss Cathy knows the real name.', waitingFor: 'cathy' });
  T('map-phone', 'map', 'Make it work on phones', 'todo', { plain: 'The map must be easy to tap on a small screen.' });

  /* ---- 2. Winter tree game ---- */
  T('winter', null, 'Winter tree game', 'working', { plain: 'The game of lighting trees on the home page in winter.', workerIds: ['w-tree'] });
  T('win-btn', 'winter', 'Button says "Light the trees"', 'done', { plain: 'The new button words.' });
  T('win-msg', 'winter', 'Message when all 22 trees are lit', 'working', { plain: 'The farm message only shows when the last tree lights up.', workerIds: ['w-tree'], note: 'Writing the words in four languages.' });
  T('win-six', 'winter', 'A true message at the 6th light', 'waiting', { plain: 'Four wordings are ready. Which one do you like?', waitingFor: 'owner', questionIds: ['c-short'] });
  T('win-trans', 'winter', 'Translations', 'todo', { plain: 'Spanish, Hindi, Chinese and Vietnamese.' });
  T('win-es', 'win-trans', 'Spanish', 'done');
  T('win-hi', 'win-trans', 'Hindi', 'working', { workerIds: ['w-check'] });
  T('win-zh', 'win-trans', 'Chinese', 'todo');
  T('win-vi', 'win-trans', 'Vietnamese', 'todo');

  /* ---- 3. Holiday photos ---- */
  T('photos', null, 'Holiday photos on the home page', 'waiting', { plain: 'Show real holiday photos at the top of the page.', waitingFor: 'owner', questionIds: ['c-normal'], workerIds: ['w-photos'] });
  T('ph-pick', 'photos', 'Pick the photos', 'waiting', { plain: 'You pick the ones you like best.', waitingFor: 'owner', questionIds: ['c-normal'], workerIds: ['w-photos'] });
  T('ph-small', 'photos', 'Make them small and fast', 'todo');
  T('ph-put', 'photos', 'Put them on the page', 'todo');

  /* ---- 4. The Terminal itself ---- */
  T('terminal', null, 'The Terminal itself', 'working', { plain: 'This page: questions, workers and tasks.', workerIds: ['w-claude', 'w-term'] });
  T('tm-q', 'terminal', 'Questions part', 'done', { plain: 'Questions you answer, with chips that show Claude saw them.' });
  T('tm-q-sec', 'tm-q', 'Sections and lists', 'done');
  T('tm-q-chip', 'tm-q', 'Status chips', 'done');
  T('tm-w', 'terminal', 'Workers part', 'working', { workerIds: ['w-term'] });
  T('tm-t', 'terminal', 'Tasks part', 'working', { plain: 'The tree you are looking at.', workerIds: ['w-term'], note: 'The tree is working. The map comes next.' });
  T('tasks-tree', 'tm-t', 'Tree view', 'working', { workerIds: ['w-term'] });
  T('tasks-map-view', 'tm-t', 'Map view', 'todo', { plain: 'The same tasks drawn left to right.' });
  T('tasks-forms', 'tm-t', 'Add and change forms', 'todo');

  /* ---- 5. Questions for Miss Cathy and Rob ---- */
  T('cathy', null, 'Questions for Miss Cathy and Rob', 'waiting', { plain: 'Questions only they can answer.', waitingFor: 'cathy' });
  T('ca-first', 'cathy', 'The first 90 questions', 'done');
  T('ca-more', 'cathy', 'Extra questions', 'working');

  /* ---- 6. Old Mac photo copies (a finished branch) ---- */
  T('oldmac', null, 'Old Mac photo copies', 'done', { plain: 'Copies of the Old Mac photos, all finished.' });
  T('om-1', 'oldmac', 'Copy the photos', 'done');
  T('om-2', 'oldmac', 'Check the copies', 'done');
  T('om-2a', 'om-2', 'Count the files', 'done');
  T('om-2b', 'om-2', 'Open three at random', 'done');

  /* ---- 7. Website translations check (paused by Claude) ---- */
  T('trans', null, 'Website translations check', 'paused', { plain: 'Read every translated page once. Paused until the winter words are final.' });
  T('tr-es', 'trans', 'Spanish pages', 'paused');
  T('tr-hi', 'trans', 'Hindi pages', 'paused');

  /* ---- her own tasks ---- */
  D['taskAdds/u-gift'] = { id: 'u-gift', parentId: null, title: 'Add a gift shop page', plain: 'A page with a few things people can buy at the farm.', createdAt: iso(4 * MIN) };            // pending: Claude has not seen it
  D['taskAdds/u-prices'] = { id: 'u-prices', parentId: 'winter', title: 'Ask about the tree prices', plain: '', createdAt: iso(2 * MIN) };                                                             // pending, under a Claude task
  D['taskAdds/u-seen'] = { id: 'u-seen', parentId: 'photos', title: 'Photos of the new barn door', plain: 'Please add these too.', createdAt: iso(2 * DAY) };
  T('u-seen', 'photos', 'Photos of the new barn door', 'todo', { plain: 'Please add these too.', createdBy: 'owner', createdAt: iso(2 * DAY), seenAt: iso(2 * DAY - 5 * MIN) });   // adopted by Claude
  D['taskAdds/u-old'] = { id: 'u-old', parentId: 'map-phone', title: 'Draw a pony on the map', plain: 'Just for fun.', createdAt: iso(3 * DAY) };
  T('u-old', 'map-phone', 'Draw a pony on the map', 'todo', { plain: 'Just for fun.', createdBy: 'owner', createdAt: iso(3 * DAY), seenAt: iso(3 * DAY - MIN) });
  D['taskEdits/u-old'] = { id: 'u-old', removed: true, updatedAt: iso(MIN) };                                                     // she asked to remove it: pending
  D['taskEdits/win-msg'] = { id: 'win-msg', title: 'Message when all 22 trees are lit (final words)', updatedAt: iso(3 * MIN) };     // her pending rename of a Claude task
  D['taskEdits/tasks-map-view'] = { id: 'tasks-map-view', paused: true, updatedAt: iso(20 * MIN) };                                   // she paused it, Claude has not seen it yet

  /* ---- her questions and the answers ---- */
  D['asks/ask-1'] = { id: 'ask-1', targetKind: 'task', targetId: 'map', text: 'How many seasons are done?', createdAt: iso(HOUR) };
  D['replies/ask-1'] = { id: 'ask-1', targetKind: 'task', targetId: 'map', state: 'answered', text: 'Two of four: spring and summer. Fall is being drawn now and winter comes after it.', from: 'Claude', at: iso(50 * MIN) };
  D['asks/ask-2'] = { id: 'ask-2', targetKind: 'task', targetId: 'map', text: 'Can the pond be bigger?', createdAt: iso(10 * MIN) };
  D['replies/ask-2'] = { id: 'ask-2', targetKind: 'task', targetId: 'map', state: 'seen', text: '', from: 'Claude', at: iso(8 * MIN) };
  D['asks/ask-3'] = { id: 'ask-3', targetKind: 'task', targetId: 'map', text: 'And can the barn be red?', createdAt: iso(MIN) };

  return D;
}

/** Splits { 'coll/id': doc } into { coll: { id: doc } }. */
export function byCollection(docs) {
  const out = {};
  for (const [p, d] of Object.entries(docs)) { const i = p.indexOf('/'); (out[p.slice(0, i)] = out[p.slice(0, i)] || {})[p.slice(i + 1)] = d; }
  return out;
}
