/* Test stub for the visual helper (NOT part of the page that is published).
   Runs after 21-visual.js and 22-lightbox.js are loaded. Makes fixture questions whose pictures are generated placeholders
   (data:image/svg+xml, different colours and sizes, one broken address) and a tiny fake question page around them.
   window.VS.show(id, {split}) draws a fixture; window.VS.F holds the fixtures. */
(function () {
  var QT = window.QT = window.QT || {};
  if (!QT.on) { QT._h = {}; QT.on = function (e, f) { (QT._h[e] = QT._h[e] || []).push(f); }; QT.emit = function (e, d) { (QT._h[e] || []).forEach(function (f) { f(d); }); }; }
  if (!QT.emit) QT.emit = function () {};
  if (!QT.off) QT.off = function (e, f) { var l = QT._h && QT._h[e]; if (l) { var i = l.indexOf(f); if (i >= 0) l.splice(i, 1); } };
  QT.store = QT.store || {};
  QT.store.answers = QT.store.answers || {};
  window.__picks = [];
  window.__subs = 0;   // how many 'store' listeners are alive (visual + viewer must clean up after themselves)
  (function () { var on = QT.on, off = QT.off; QT.on = function (e, f) { if (e === 'store') window.__subs++; return on.apply(QT, arguments); }; QT.off = function (e, f) { if (e === 'store') window.__subs--; return off.apply(QT, arguments); }; })();

  /* a fake web page as a picture: colour bar, big headline, blocks, and its size written in the corner */
  function svg(w, h, o) {
    o = o || {};
    var bg = o.bg || '#f4ead5', bar = o.bar || '#5c3a1e', hero = o.hero || '#b8232f', fg = o.fg || '#fff';
    var fs = Math.round(Math.min(w, h * 1.4) * 0.06), tall = h > w * 1.15;
    var parts = [
      '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">',
      '<rect width="' + w + '" height="' + h + '" fill="' + bg + '"/>',
      '<rect width="' + w + '" height="' + Math.round(h * (tall ? 0.05 : 0.09)) + '" fill="' + bar + '"/>',
      '<text x="' + Math.round(w * 0.03) + '" y="' + Math.round(h * (tall ? 0.034 : 0.06)) + '" font-family="Arial" font-weight="bold" font-size="' + Math.round(fs * 0.8) + '" fill="#fff">FARM  Home  Menu  Visit</text>',
      '<rect x="' + Math.round(w * 0.03) + '" y="' + Math.round(h * (tall ? 0.08 : 0.14)) + '" width="' + Math.round(w * 0.94) + '" height="' + Math.round(h * (tall ? 0.3 : 0.5)) + '" rx="' + Math.round(w * 0.015) + '" fill="' + hero + '"/>',
      '<text x="' + Math.round(w * 0.06) + '" y="' + Math.round(h * (tall ? 0.15 : 0.3)) + '" font-family="Arial" font-weight="bold" font-size="' + fs + '" fill="' + fg + '">' + (o.title || 'Welcome') + '</text>',
      '<text x="' + Math.round(w * 0.06) + '" y="' + Math.round(h * (tall ? 0.19 : 0.4)) + '" font-family="Arial" font-size="' + Math.round(fs * 0.55) + '" fill="' + fg + '">' + (o.sub || 'fresh and local') + '</text>'
    ];
    for (var i = 0; i < 3; i++) {
      parts.push('<rect x="' + Math.round(w * (0.03 + i * 0.32)) + '" y="' + Math.round(h * (tall ? 0.42 : 0.7)) + '" width="' + Math.round(w * 0.3) + '" height="' + Math.round(h * (tall ? 0.15 : 0.2)) + '" rx="8" fill="' + bar + '" opacity="' + (0.9 - i * 0.2) + '"/>');
    }
    parts.push('<text x="' + Math.round(w * 0.97) + '" y="' + Math.round(h * 0.97) + '" text-anchor="end" font-family="Arial" font-size="' + Math.round(fs * 0.5) + '" fill="#333">' + w + ' x ' + h + '</text>');
    parts.push('</svg>');
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(parts.join(''));
  }
  var C = { A: ['#f7efe0', '#7a3b12', '#b8232f'], B: ['#e3f0e6', '#1c4d2d', '#2e7d4b'], C: ['#e4eefa', '#1d3f73', '#3a6fc4'], D: ['#fbe9c8', '#6b4400', '#d68a00'] };
  function pic(k, w, h, title, alt) { return { url: svg(w, h, { bg: C[k][0], bar: C[k][1], hero: C[k][2], title: title }), alt: alt || ('Home page, version ' + k + ', ' + w + ' by ' + h), w: w, h: h }; }

  var LONG = 'The big barn photo fills the whole top of the page, the opening hours sit right under it, and the menu is a row of round buttons that stay on screen when you scroll down.';
  var F = {};
  F.q4 = { id: 'q4', kind: 'visual', title: 'Which home page do you like best?', versions: [
    { key: 'A', label: 'Big photo on top', caption: LONG, images: [pic('A', 1600, 900, 'Big photo on top', 'Top of the home page, version A'), pic('A', 600, 1200, 'Phone', 'Version A on a phone')] },
    { key: 'B', label: 'Small photo, big words', caption: 'Words first, the photo is small and sits on the right.', images: [pic('B', 1200, 800, 'Small photo')] },
    { key: 'C', label: 'Three pictures in a row', caption: 'Three smaller pictures side by side.', images: [pic('C', 800, 600, 'Three in a row'), pic('C', 1600, 900, 'Wide'), pic('C', 600, 1200, 'Phone')] },
    { key: 'D', label: 'Plain and simple', caption: 'No photo at all. Just the name and the opening hours.', images: [{ url: 'https://localhost:9/does-not-exist.png', alt: 'Plain page with the name and the opening hours', w: 1600, h: 900 }] }
  ] };
  F.q3 = { id: 'q3', kind: 'visual', title: 'Three versions', versions: F.q4.versions.slice(0, 3).map(function (v, i) { return i === 3 ? v : { key: v.key, label: v.label, caption: v.caption, images: v.images.slice(0, 1) }; }) };
  F.q2 = { id: 'q2', kind: 'visual', title: 'Two versions', versions: [
    { key: 'A', label: 'Photo on top', caption: 'The photo is the first thing you see.', images: [pic('A', 1600, 900, 'Photo on top')] },
    { key: 'B', label: 'Words on top', caption: 'The words are the first thing you see.', images: [pic('B', 1600, 900, 'Words on top')] }
  ] };
  F.qbefore = { id: 'qbefore', kind: 'visual', title: 'With a "today" row', beforeImages: [
    { url: svg(1600, 900, { bg: '#eee', bar: '#444', hero: '#888', title: 'Today' }), alt: 'The home page today', w: 1600, h: 900, caption: 'Home page today' },
    { url: svg(600, 1200, { bg: '#eee', bar: '#444', hero: '#888', title: 'Today (phone)' }), alt: 'The home page today on a phone', w: 600, h: 1200, caption: 'Today, on a phone' }
  ], versions: F.q4.versions };
  F.qsolo = { id: 'qsolo', kind: 'visual', title: 'Only a "today" row', beforeImages: F.qbefore.beforeImages, versions: [] };
  F.qsmall = { id: 'qsmall', kind: 'visual', title: 'A small picture', versions: [
    { key: 'A', label: 'Small', caption: 'Only 320 by 200.', images: [pic('A', 320, 200, 'Small')] },
    { key: 'B', label: 'Other', caption: '', images: [pic('B', 1600, 900, 'Other')] }
  ] };
  F.qweird = { id: 'qweird', kind: 'visual', title: 'Odd text', versions: [
    { key: 'A', label: '<img src=x onerror="window.__pwned=1">Bad label', caption: '<script>window.__pwned=2<\/script> ' + LONG, images: [{ url: 'javascript:window.__pwned=3', alt: '<b>bold</b> alt text', w: 100, h: 50 }] },
    { key: 'B', label: 'A very long label that goes on and on and on and on and on and on and on', caption: LONG + ' ' + LONG, images: [pic('B', 1600, 900, 'Long text')] },
    { key: 'C', label: 'No pictures at all', caption: 'This version has no pictures.', images: [] },
    { key: 'D', label: 'Not a picture address', caption: 'ftp and file addresses are refused.', images: [{ url: 'file:///etc/passwd', alt: 'Refused address', w: 100, h: 100 }, { url: 'http://example.com/a.png', alt: 'Plain http is refused too' }] }
  ] };
  F.qlast = { id: 'qlast', kind: 'visual', title: 'Four, a different set', versions: F.q4.versions.map(function (v) { return v; }) };

  /* the fake page around the pictures: sticky question bar, the pictures, some answer buttons */
  var root = document.createElement('div');
  root.id = 'vs';
  root.innerHTML = '<div class="vs-bar"><b id="vs-title">Question</b></div><div class="vs-split" id="vs-split"><div id="vs-host"></div><div id="vs-text"></div></div><div id="vs-results"></div>' +
    '<div class="vs-answers"><button type="button" class="btn">I pick A</button><button type="button" class="btn">I pick B</button><button type="button" class="btn">I pick C</button><button type="button" class="btn">I pick D</button>' +
    '<button type="button" class="btn quiet">I am not sure yet</button><button type="button" class="btn quiet">Explain another way</button></div><div id="vs-tall"></div>';
  var st = document.createElement('style');
  st.textContent = '#vs{max-width:1000px;margin:0 auto;padding:0 14px}.vs-bar{position:sticky;top:0;z-index:20;background:var(--bg);padding:8px 0;border-bottom:1px solid var(--line);margin-bottom:8px}' +
    '.vs-answers{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}#vs-tall{height:1800px}@media (min-width:1100px){.vs-split.is-split{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:18px}}' +
    '#vs-text{display:none}.is-split #vs-text{display:block}';
  document.head.appendChild(st);
  document.body.appendChild(root);

  window.VS = {
    F: F,
    host: function () { return document.getElementById('vs-host'); },
    show: function (id, opts) {
      opts = opts || {};
      var host = document.getElementById('vs-host');
      host.textContent = '';
      document.getElementById('vs-split').classList.toggle('is-split', !!opts.split);
      document.getElementById('vs-title').textContent = F[id].title;
      document.getElementById('vs-text').textContent = 'The question text and the answer buttons would be in this column.';
      return window.VS.cleanup = QT.visual.render(host, F[id], opts.pick === false ? undefined : { onPick: function (k) { window.__picks.push(k); } });
    },
    again: function (id, o) { return QT.visual.render(document.getElementById('vs-host'), F[id], o || { onPick: function (k) { window.__picks.push(k); } }); },
    setAnswer: function (qid, key, status) {
      if (key == null) delete QT.store.answers[qid]; else QT.store.answers[qid] = { id: qid, status: status || 'answered', key: key };
      QT.emit('store', { collection: 'answers', ids: [qid], initial: false });
    },
    results: function () {
      var box = document.getElementById('vs-results');
      box.textContent = '';
      box.appendChild(QT.visual.thumbRow([
        { url: svg(1600, 900, { title: 'Result 1' }), alt: 'First result', w: 1600, h: 900, caption: 'Home page now' },
        { url: svg(600, 1200, { title: 'Result 2' }), alt: 'Second result on a phone', w: 600, h: 1200 },
        { url: 'https://localhost:9/missing.png', alt: 'Third result', w: 800, h: 600 }
      ], { label: 'Result' }));
    }
  };
})();
