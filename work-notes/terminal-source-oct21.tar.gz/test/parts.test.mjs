/* parts.test.mjs  (owner: question)
 * Tests for T/src/js/50-parts.js + 50-parts.css: the tab strip (Questions | Workers | Tasks) and QT.parts (selectors + shared helpers).
 *   NODE_PATH=/opt/node22/lib/node_modules AXE_PATH=/tmp/claude-0/axe-core/axe.min.js node T/test/parts.test.mjs
 * Builds dist-question2/index.html (everything in src) first (QT_NOBUILD=1 skips that). Port 9340 (QT_PORT=n changes it).
 * Data = the tester's fixtures (test/fixtures.mjs: seed({parts:true}), EXPECT2), so the numbers below are the ones the other helpers test too.
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { startServer, launch, ok, info, finish, okSoon, axeSource } from './lib.mjs';
import { newPage, waitReady } from './mockfix.mjs';
import { seed, IDS, IDS2, EXPECT2, XSS, iso } from './fixtures.mjs';
import { T } from './harness.mjs';

const SHOTS = path.join(T, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const sleep = (n) => new Promise((r) => setTimeout(r, n));
const OUT = 'dist-question2/index.html';

if (!process.env.QT_NOBUILD) {
  let built = true;
  try { execFileSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, OUT)], { cwd: T, stdio: 'pipe' }); } catch (e) { built = false; console.log('FAIL build.py: ' + String(e.stderr || e.message).split('\n').slice(0, 3).join(' | ')); }
  ok('build to dist-question2', built);
}

const site = await startServer({ root: T, port: Number(process.env.QT_PORT) || 9340 });
const browser = await launch();
const errs = [];

async function open(o = {}) {
  const page = await newPage(browser, { seed: o.seed || seed({ parts: true }), options: o.options || {}, viewport: { width: o.w || 700, height: o.h || 800 }, errs, colorScheme: o.scheme || 'light', init: o.init });
  await page.goto(site.url + OUT);
  await waitReady(page);
  if (o.route) { await page.evaluate((r) => window.QT.route.go(r[0], r[1] || {}), o.route); await sleep(300); }
  return page;
}
const go = async (page, view, params = {}) => { await page.evaluate(([v, p]) => window.QT.route.go(v, p), [view, params]); await sleep(350); };
const P = (page, fn, arg) => page.evaluate(fn, arg);
const visible = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); if (!e || e.hidden) return false; const cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden') return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }, sel);
const ids = (list) => list.map((x) => x.id);

try {
  /* ======================================================================= 1. QT.parts: the API is there */
  {
    const page = await open();
    const api = await P(page, () => Object.keys(window.QT.parts || {}).sort());
    const must = ['current', 'go', 'workers', 'workerKids', 'workerRoots', 'tasks', 'taskKids', 'taskRoots', 'progress', 'seen', 'counts', 'seenChip', 'bubble', 'ago', 'asksFor', 'watch', 'initials', 'label', 'partOf', 'task', 'askState'];
    ok('1.1 QT.parts has every selector and helper of SPEC2 section 4 (and the shared ones)', must.every((k) => api.includes(k)), 'missing: ' + must.filter((k) => !api.includes(k)).join(','));

    /* ---- workers */
    const w = await P(page, () => { const Q = window.QT.parts; const all = Q.workers(); const roots = Q.workerRoots(); const seen = new Set(); let dup = 0; const walk = (x) => { if (seen.has(x.id)) dup++; seen.add(x.id); Q.workerKids(x.id).forEach(walk); }; roots.forEach(walk);
      return { n: all.length, working: all.filter((x) => x.state === 'working').length, roots: roots.map((x) => x.id), kids: Q.workerKids('claude').map((x) => x.id), mapKids: Q.workerKids('team-maps').map((x) => x.id), reach: seen.size, dup, leafKids: Q.workerKids('map-a').length, none: Q.workerKids('nope').length, order: all.map((x) => x.order) }; });
    ok('1.2 workers(): all ' + EXPECT2.workers.total + ' workers', w.n === EXPECT2.workers.total, String(w.n));
    ok('1.3 workerRoots(): only Claude (the lead); workerKids("claude") = the 3 teams and the site checker, in order', JSON.stringify(w.roots) === '["claude"]' && JSON.stringify(w.kids) === '["team-maps","team-build","team-qs","site-1"]', JSON.stringify([w.roots, w.kids]));
    ok('1.4 workerKids("team-maps") = map-a, map-b, map-c, map-d in order; a helper and an unknown id have none', JSON.stringify(w.mapKids) === '["map-a","map-b","map-c","map-d"]' && w.leafKids === 0 && w.none === 0, JSON.stringify(w.mapKids));
    ok('1.5 walking roots -> kids reaches every worker exactly once', w.reach === EXPECT2.workers.total && w.dup === 0, JSON.stringify({ reach: w.reach, dup: w.dup }));
    ok('1.6 workers() is sorted by `order`', w.order.every((v, i) => i === 0 || w.order[i - 1] <= v), JSON.stringify(w.order));

    /* ---- effective tasks */
    const t = await P(page, () => {
      const Q = window.QT.parts, all = Q.tasks(), by = (id) => all.find((x) => x.id === id) || null;
      return {
        n: all.length, roots: Q.taskRoots().map((x) => x.id), pend: all.filter((x) => x.pending).map((x) => x.id), editPend: all.filter((x) => x.editPending).map((x) => x.id).sort(),
        paused: all.filter((x) => x.state === 'paused').map((x) => x.id).sort(), youPaused: all.filter((x) => x.youPaused).map((x) => x.id), removed: all.filter((x) => x.removed).map((x) => x.id),
        mine: all.filter((x) => x.mine).map((x) => x.id).sort(),
        photos2: by('t-photos-2') && { title: by('t-photos-2').title, plain: by('t-photos-2').plain }, label1: by('t-label-1') && { title: by('t-label-1').title, editPending: by('t-label-1').editPending },
        add1: by('u-pend-1') && { state: by('u-pend-1').state, parentId: by('u-pend-1').parentId, createdBy: by('u-pend-1').createdBy, pending: by('u-pend-1').pending, waitingFor: by('u-pend-1').waitingFor },
        seen1: by('u-seen-1') && { pending: by('u-seen-1').pending, mine: by('u-seen-1').mine },
        mapKids: Q.taskKids('t-map').map((x) => x.id), none: Q.taskKids('nope').length, one: Q.task('t-map') && Q.task('t-map').title, noOne: Q.task('nope'),
        defaults: all.every((x) => Array.isArray(x.workerIds) && Array.isArray(x.questionIds) && typeof x.note === 'string' && typeof x.plain === 'string' && typeof x.title === 'string'),
      };
    });
    ok('1.7 tasks(): ' + EXPECT2.tasks.effective + ' effective tasks (42 stored + her 2 pending adds)', t.n === EXPECT2.tasks.effective, String(t.n));
    ok('1.8 taskRoots(): the 7 big ideas + her pending new big idea', t.roots.length === EXPECT2.tasks.roots && t.roots.includes('u-pend-2') && IDS2.mainIdeas.every((i) => t.roots.includes(i)), JSON.stringify(t.roots));
    ok('1.9 her adds: a task that exists only as taskAdds is "todo", createdBy owner, pending; an adopted one is not pending', JSON.stringify(t.pend.sort()) === '["u-pend-1","u-pend-2"]' && t.add1.state === 'todo' && t.add1.createdBy === 'owner' && t.add1.pending === true && t.add1.parentId === 't-map' && t.add1.waitingFor === 'none' && t.seen1.pending === false && t.seen1.mine === true, JSON.stringify([t.pend, t.add1, t.seen1]));
    ok('1.10 her edits are laid on top: new title / plain words shown; a seen edit is not pending, an unseen one is', t.photos2.title === 'Pick the best three photos' && t.photos2.plain === 'Choose three that look cheerful.' && t.label1.title === 'Make four bigger looks (renamed)' && t.label1.editPending === false && JSON.stringify(t.editPend) === JSON.stringify(['t-photos-2', 't-term-3', 't-term-3a']), JSON.stringify([t.photos2, t.label1, t.editPend]));
    ok('1.11 paused:true shows state "paused" (youPaused); removed:true is flagged but still listed', JSON.stringify(t.paused) === '["t-photos-3","t-term-3"]' && JSON.stringify(t.youPaused) === '["t-term-3"]' && JSON.stringify(t.removed) === '["t-term-3a"]', JSON.stringify([t.paused, t.youPaused, t.removed]));
    ok('1.12 taskKids("t-map") = A, B, C, D and her pending pond (last); unknown id has none; task(id)', JSON.stringify(t.mapKids) === '["t-map-a","t-map-b","t-map-c","t-map-d","u-pend-1"]' && t.none === 0 && t.one === 'Redraw the farm map' && t.noOne === null, JSON.stringify(t.mapKids));
    ok('1.13 every effective task has safe defaults (lists, note, plain, title)', t.defaults);

    /* ---- progress: counts leaves */
    const pr = await P(page, () => { const Q = window.QT.parts; return { map: Q.progress('t-map'), term3: Q.progress('t-term-3'), winter: Q.progress('t-winter'), leaf: Q.progress('t-map-c'), leaf2: Q.progress('t-map-d'), a1: Q.progress('t-map-a1'), nope: Q.progress('nope') }; });
    ok('1.14 progress("t-map") counts the LEAVES below it: 3 of 8 (her pending pond counts)', pr.map.done === 3 && pr.map.total === 8, JSON.stringify(pr.map));
    ok('1.15 progress of a leaf counts itself (1 of 1 done / 0 of 1); of a branch only its leaves; unknown id is 0 of 0', pr.leaf.done === 1 && pr.leaf.total === 1 && pr.leaf2.done === 0 && pr.leaf2.total === 1 && pr.a1.total === 2 && pr.a1.done === 1 && pr.nope.total === 0, JSON.stringify(pr));
    ok('1.16 progress does not count a leaf she asked to remove ("t-term-3": 0 of 2, not 0 of 3); a finished idea is all done', pr.term3.done === 0 && pr.term3.total === 2 && pr.winter.done === 4 && pr.winter.total === 4, JSON.stringify([pr.term3, pr.winter]));

    /* ---- seen(): Claude has seen her adds, edits and asks */
    const sn = await P(page, () => { const Q = window.QT.parts, st = window.QT.store; const g = (c, id) => st[c][id];
      return { addPend: Q.seen(g('taskAdds', 'u-pend-1')), addSeen: Q.seen(g('taskAdds', 'u-seen-1')), editPend: Q.seen(g('taskEdits', 't-photos-2')), editSeen: Q.seen(g('taskEdits', 't-label-1')), editPaused: Q.seen(g('taskEdits', 't-term-3')),
        ask1: Q.seen(g('asks', 'ask-w-1')), ask2: Q.seen(g('asks', 'ask-w-2')), ask3: Q.seen(g('asks', 'ask-w-3')), askT1: Q.seen(g('asks', 'ask-t-1')), askT2: Q.seen(g('asks', 'ask-t-2')),
        guess: Q.seen({ id: 'u-pend-1', createdAt: new Date().toISOString() }), kind: Q.seen({ id: 'ask-w-2' }, 'ask'), nothing: Q.seen(null), empty: Q.seen({}) }; });
    ok('1.17 seen(): adds, edits and asks - exactly the ones the fixtures say Claude has not seen are false', !sn.addPend && sn.addSeen && !sn.editPend && sn.editSeen && !sn.editPaused && !sn.ask1 && sn.ask2 && sn.ask3 && sn.askT1 && !sn.askT2, JSON.stringify(sn));
    ok('1.18 seen(): needs a document; the kind is guessed (and can be given)', sn.guess === false && sn.kind === true && sn.nothing === false && sn.empty === false);

    /* ---- asks and answers */
    const ak = await P(page, () => { const Q = window.QT.parts; const f = (k, i) => Q.asksFor(k, i).map((x) => [x.ask.id, x.state, x.seen, x.reply ? x.reply.state : null]);
      return { claude: f('worker', 'claude'), mapB: f('worker', 'map-b'), mapA: f('worker', 'map-a'), taskMap: f('task', 't-map'), none: f('worker', 'map-c'), wrongKind: f('task', 'map-a') }; });
    ok('1.19 asksFor(): answered / seen / sent per ask, oldest first, only for that worker or task', JSON.stringify(ak.claude) === '[["ask-w-3","answered",true,"answered"]]' && JSON.stringify(ak.mapB) === '[["ask-w-2","seen",true,"seen"]]' && JSON.stringify(ak.mapA) === '[["ask-w-1","sent",false,null]]' && JSON.stringify(ak.taskMap) === '[["ask-t-1","answered",true,"answered"]]' && !ak.none.length && !ak.wrongKind.length, JSON.stringify(ak));

    /* ---- numbers */
    const c = await P(page, () => ({ c: window.QT.parts.counts(), badge: window.QT.status && window.QT.status.badgeCount ? window.QT.status.badgeCount() : null }));
    ok('1.20 counts(): workers working ' + EXPECT2.workers.working + ', tasks waiting for her ' + EXPECT2.tasks.waitingForOwner + ', working ' + EXPECT2.tasks.working + ', done ' + EXPECT2.tasks.done + ', questions = the number the menu shows',
      c.c.workersWorking === EXPECT2.workers.working && c.c.tasksWaitingForYou === EXPECT2.tasks.waitingForOwner && c.c.tasksWorking === EXPECT2.tasks.working && c.c.tasksDone === EXPECT2.tasks.done && c.c.questionsWaiting === c.badge, JSON.stringify(c));

    /* ---- small things */
    const sm = await P(page, () => { const Q = window.QT.parts; return { ini: [Q.initials('Map drawer A: Storybook Hills'), Q.initials('Claude'), Q.initials(''), Q.initials('  odd   <img>  '), Q.initials(null)], label: [Q.label('workers'), Q.label('tasks'), Q.label('questions'), Q.label('x')], partOf: ['home', 'section', 'question', 'done', 'newsection', 'workers', 'tasks'].map(Q.partOf), ago: [Q.ago(new Date().toISOString()), Q.ago('rubbish'), Q.ago(null)] }; });
    ok('1.21 initials(), label(), partOf(), ago()', JSON.stringify(sm.ini) === '["MD","CL","?","OI","?"]' && sm.label.join() === 'Workers,Tasks,Questions,Questions' && sm.partOf.join() === 'questions,questions,questions,questions,questions,workers,tasks' && sm.ago[0] === 'just now' && sm.ago[1] === '' && sm.ago[2] === '', JSON.stringify(sm));
    await page.context().close();
  }

  /* ======================================================================= 2. selectors survive bad data (loops, orphans, junk) */
  {
    const page = await open({ seed: seed({ parts: false }) });
    const r = await P(page, () => {
      const st = window.QT.store, Q = window.QT.parts, mk = (id, parentId, o = {}) => Object.assign({ id, parentId, title: id, plain: '', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 1, createdAt: '2026-10-01T10:00:00Z', updatedAt: '2026-10-01T10:00:00Z', doneAt: null, createdBy: 'claude', seenAt: null }, o);
      st.tasks = { a: mk('a', 'b'), b: mk('b', 'a'), c: mk('c', 'zzz'), d: mk('d', 'd'), e: mk('e', null, { state: 'weird', waitingFor: 'x', order: 'x' }), bad: null, arr: [1] };
      st.workers = { x: { id: 'x', name: 'X', parentId: 'y', kind: 'helper', order: 1 }, y: { id: 'y', name: 'Y', parentId: 'x', kind: 'team', order: 2 }, z: { id: 'z', name: 'Z', parentId: 'nope', kind: 'helper' } };
      delete st.taskAdds; delete st.taskEdits; delete st.asks; delete st.replies;
      const seen = new Set(); const walk = (x, n) => { if (n > 50) return 'LOOP'; if (seen.has(x.id)) return 'DUP'; seen.add(x.id); for (const k of Q.taskKids(x.id)) { const o = walk(k, n + 1); if (o) return o; } return ''; };
      let bad = ''; for (const x of Q.taskRoots()) bad = bad || walk(x, 0);
      const wseen = new Set(); const ww = (x, n) => { if (n > 50) return 'LOOP'; if (wseen.has(x.id)) return 'DUP'; wseen.add(x.id); for (const k of Q.workerKids(x.id)) { const o = ww(k, n + 1); if (o) return o; } return ''; };
      let wbad = ''; for (const x of Q.workerRoots()) wbad = wbad || ww(x, 0);
      return { roots: Q.taskRoots().map((x) => x.id).sort(), n: Q.tasks().length, bad, reach: seen.size, e: Q.task('e'), wroots: Q.workerRoots().map((x) => x.id).sort(), wbad, wreach: wseen.size, prog: Q.progress('a'), counts: Q.counts(), asks: Q.asksFor('worker', 'x'), adds: Q.tasks().filter((t) => t.pending).length };
    });
    ok('2.1 a loop (a<->b), a missing parent (c), a self parent (d): every task is reachable exactly once, nothing loops, junk entries are skipped', r.bad === '' && r.reach === 5 && r.n === 5 && JSON.stringify(r.roots) === '["a","c","d","e"]', JSON.stringify(r));
    ok('2.2 a task with a strange state / waiting / order gets safe values', r.e.state === 'todo' && r.e.waitingFor === 'none' && r.e.order > 1e9, JSON.stringify(r.e));
    ok('2.3 workers: a loop and a missing parent do not hide or repeat anyone', r.wbad === '' && r.wreach === 3 && JSON.stringify(r.wroots) === '["x","z"]', JSON.stringify([r.wbad, r.wreach, r.wroots]));
    ok('2.4 progress of a loop member and counts() work without the other collections (no throw)', r.prog.total >= 1 && typeof r.counts.tasksDone === 'number' && Array.isArray(r.asks) && r.adds === 0, JSON.stringify([r.prog, r.counts]));
    await page.context().close();
  }

  /* ======================================================================= 3. the tab strip */
  {
    const page = await open();
    const s = await P(page, () => { const l = document.querySelector('[role="tablist"]'), tabs = [...document.querySelectorAll('[role="tab"]')], strip = document.querySelector('.pt-strip'); const r = strip.getBoundingClientRect(), tb = document.querySelector('.topbar').getBoundingClientRect();
      return { has: !!l, label: l && l.getAttribute('aria-label'), n: tabs.length, names: tabs.map((b) => b.querySelector('.pt-tab-t').textContent), sel: tabs.map((b) => b.getAttribute('aria-selected')), tabindex: tabs.map((b) => b.tabIndex), navRole: strip.getAttribute('role'), firstNav: (document.querySelector('nav') || {}).id, under: Math.abs(r.top - tb.bottom) < 1.5, h: r.height, tabH: tabs.map((b) => Math.round(b.getBoundingClientRect().height)), pos: getComputedStyle(strip).position, root: document.getElementById('app').getAttribute('data-part'), brand: document.querySelector('.brand-t').textContent, title: document.title, ctrl: tabs.map((b) => b.getAttribute('aria-controls')), ctrlOk: !!document.getElementById('qt-main') }; });
    ok('3.1 a proper tab list with 3 tabs: Questions | Workers | Tasks, Questions selected (roving tabindex)', s.has && s.n === 3 && s.names.join() === 'Questions,Workers,Tasks' && s.sel.join() === 'true,false,false' && s.tabindex.join() === '0,-1,-1', JSON.stringify(s));
    ok('3.2 the strip sits right under the top bar, is sticky, and each tab is at least 40 px high', s.under && s.pos === 'sticky' && s.tabH.every((h) => h >= 40) && s.h >= 40, JSON.stringify([s.under, s.pos, s.tabH, s.h]));
    ok('3.3 the tab strip is a named navigation landmark but NOT a <nav> element (the first <nav> of the page is still the left menu); tabs point at the main area that exists', s.navRole === 'navigation' && s.firstNav === 'qt-menu' && s.label === 'Parts of the Terminal' && s.ctrl.every((c) => c === 'qt-main') && s.ctrlOk);
    ok('3.4 brand text and tab title say "Terminal" (the number of waiting questions stays in front)', s.brand === 'Terminal' && /^(\(\d+\) )?Terminal$/.test(s.title), s.title);
    ok('3.5 the app root says which part is open (data-part="questions")', s.root === 'questions');

    // count badges
    const b = await P(page, () => [...document.querySelectorAll('.pt-tab')].map((x) => ({ part: x.getAttribute('data-part'), label: x.getAttribute('aria-label'), count: x.querySelector('.count').hidden ? null : x.querySelector('.count').textContent, calm: x.querySelector('.count').classList.contains('calm') })));
    const waitingQ = await P(page, () => window.QT.status.badgeCount());
    ok('3.6 count badges: Questions = waiting for her, Workers = working now, Tasks = waiting for her', b[0].count === String(waitingQ) && b[1].count === String(EXPECT2.workers.working) && b[2].count === String(EXPECT2.tasks.waitingForOwner), JSON.stringify(b));
    ok('3.7 each tab has a spoken name with the number in words; the Workers badge is the calm grey one', /question/.test(b[0].label) && /working/.test(b[1].label) && /waiting for you/.test(b[2].label) && b[1].calm && !b[0].calm, JSON.stringify(b.map((x) => x.label)));

    // badges follow live changes
    await P(page, () => { window.__mock.db.merge('workers/map-b', { state: 'working', waitingFor: 'none', now: 'Back at it' }); window.__mock.db.merge('tasks/t-label-2', { state: 'done', waitingFor: 'none' }); });
    await okSoon('3.8 badges follow live changes (a worker starts: 7; a task no longer waits: 2)', () => P(page, () => [...document.querySelectorAll('.pt-tab .count')].map((x) => x.hidden ? '' : x.textContent).join()), (v) => v.endsWith(',' + (EXPECT2.workers.working + 1) + ',' + (EXPECT2.tasks.waitingForOwner - 1)), 6000);
    await P(page, () => { ['claude', 'team-maps', 'map-a', 'team-build', 'b-question', 'w-xss', 'map-b'].forEach((id) => window.__mock.db.merge('workers/' + id, { state: 'resting', now: '' })); });
    await okSoon('3.9 a badge with 0 hides itself', () => visible(page, '.pt-tab[data-part="workers"] .count'), (v) => v === false, 6000);

    // switching parts
    await go(page, 'question', { id: IDS.choiceNormal });
    await page.click('.pt-tab[data-part="workers"]'); await sleep(400);
    let st = await P(page, () => ({ part: window.QT.parts.current(), view: window.QT.route.current().view, root: document.getElementById('app').getAttribute('data-part'), sel: [...document.querySelectorAll('.pt-tab')].map((x) => x.getAttribute('aria-selected')).join(), menu: getComputedStyle(document.getElementById('qt-menu')).display, mbtn: getComputedStyle(document.querySelector('.menu-btn')).display }));
    ok('3.10 clicking Workers opens the Workers part: route, tab, data-part; the menu and the menu button are gone (700 px wide)', st.part === 'workers' && st.view === 'workers' && st.root === 'workers' && st.sel === 'false,true,false' && st.menu === 'none' && st.mbtn === 'none', JSON.stringify(st));
    await page.click('.pt-tab[data-part="tasks"]'); await sleep(400);
    st = await P(page, () => ({ part: window.QT.parts.current(), view: window.QT.route.current().view, root: document.getElementById('app').getAttribute('data-part'), mbtn: getComputedStyle(document.querySelector('.menu-btn')).display }));
    ok('3.11 Tasks: same (no menu button)', st.part === 'tasks' && st.view === 'tasks' && st.root === 'tasks' && st.mbtn === 'none', JSON.stringify(st));
    await page.click('.pt-tab[data-part="questions"]'); await sleep(400);
    st = await P(page, () => ({ route: window.QT.route.current(), root: document.getElementById('app').getAttribute('data-part'), mbtn: getComputedStyle(document.querySelector('.menu-btn')).display }));
    ok('3.12 Questions brings her back to the question she was on (not just the home page); the menu button is back', st.route.view === 'question' && st.route.params.id === IDS.choiceNormal && st.root === 'questions' && st.mbtn !== 'none', JSON.stringify(st));
    await page.click('.pt-tab[data-part="questions"]'); await sleep(300);
    ok('3.13 clicking the open Questions tab again goes to the questions home', (await P(page, () => window.QT.route.current().view)) === 'home');
    await P(page, () => window.QT.parts.go('tasks', { focus: 't-map' })); await sleep(300);
    ok('3.14 QT.parts.go("tasks", {focus}) passes the focus on; go("workers") and go("questions") work from code', await P(page, () => { const r = window.QT.route.current(); return r.view === 'tasks' && r.params.focus === 't-map'; }));
    await P(page, () => window.QT.parts.go('workers')); await sleep(250);
    const wv = await P(page, () => window.QT.route.current().view);
    await P(page, () => window.QT.parts.go('nonsense')); await sleep(250);
    ok('3.15 go() with an unknown part falls back to the questions', wv === 'workers' && (await P(page, () => window.QT.parts.current())) === 'questions');

    // Workers/Tasks use the whole width
    await go(page, 'workers');
    const wd = await P(page, () => { const m = document.getElementById('qt-main').getBoundingClientRect(), v = document.getElementById('qt-view').getBoundingClientRect(); return { main: Math.round(m.width), vw: innerWidth, view: Math.round(v.width) }; });
    ok('3.16 Workers: the main area has the whole window width (700 px)', wd.main >= wd.vw - 20, JSON.stringify(wd));
    await page.context().close();
  }

  /* ======================================================================= 4. keyboard, focus, a11y */
  {
    const page = await open();
    await page.focus('.pt-tab[aria-selected="true"]');
    await page.keyboard.press('ArrowRight');
    let f = await P(page, () => ({ active: document.activeElement.getAttribute('data-part'), part: window.QT.parts.current(), ti: [...document.querySelectorAll('.pt-tab')].map((b) => b.tabIndex).join() }));
    ok('4.1 ArrowRight moves the focus to Workers but does not open it yet; the roving tabindex follows', f.active === 'workers' && f.part === 'questions' && f.ti === '-1,0,-1', JSON.stringify(f));
    await page.keyboard.press('Enter'); await sleep(350);
    f = await P(page, () => ({ part: window.QT.parts.current(), active: document.activeElement && document.activeElement.getAttribute('data-part') }));
    ok('4.2 Enter opens the part', f.part === 'workers');
    await page.focus('.pt-tab[data-part="workers"]'); await page.keyboard.press('End');
    const e1 = await P(page, () => document.activeElement.getAttribute('data-part'));
    await page.keyboard.press('ArrowRight');
    const e2 = await P(page, () => document.activeElement.getAttribute('data-part'));
    await page.keyboard.press('Home');
    const e3 = await P(page, () => document.activeElement.getAttribute('data-part'));
    await page.keyboard.press('ArrowLeft');
    const e4 = await P(page, () => document.activeElement.getAttribute('data-part'));
    ok('4.3 End = Tasks, ArrowRight wraps to Questions, Home = Questions, ArrowLeft wraps to Tasks', e1 === 'tasks' && e2 === 'questions' && e3 === 'questions' && e4 === 'tasks', [e1, e2, e3, e4].join());
    await page.keyboard.press('Space'); await sleep(350);
    ok('4.4 Space opens the focused tab', (await P(page, () => window.QT.parts.current())) === 'tasks');
    // Tab order: top bar controls, then the tab strip (one stop), then the page
    await page.evaluate(() => { window.scrollTo(0, 0); const f = document.querySelector('.sound-btn:not([hidden])') || document.querySelector('.topbar .btn:not([hidden])'); f.focus(); });
    const order = [];
    for (let i = 0; i < 4; i++) { await page.keyboard.press('Tab'); order.push(await P(page, () => { const a = document.activeElement; return a.getAttribute('data-part') ? 'tab:' + a.getAttribute('data-part') : (a.className || a.tagName).toString().split(' ')[0]; })); }
    const iTab = order.findIndex((x) => x.startsWith('tab:'));
    ok('4.5 Tab goes from the top bar buttons (Voice, Check Claude) to exactly one tab stop in the strip (the open tab), then into the page', iTab >= 0 && iTab <= 2 && order.filter((x) => x.startsWith('tab:')).length === 1 && order[iTab] === 'tab:tasks' && order.length > iTab + 1, JSON.stringify(order));
    const focusRing = await P(page, () => { document.querySelector('.pt-tab[data-part="tasks"]').focus(); return getComputedStyle(document.querySelector('.pt-tab[data-part="tasks"]')).outlineStyle; });
    await page.keyboard.press('Shift+Tab'); await page.keyboard.press('Tab');
    ok('4.6 the focused tab shows a focus ring', focusRing !== 'none' || (await P(page, () => getComputedStyle(document.activeElement).outlineWidth)) !== '0px');
    await page.context().close();
  }

  if (axeSource()) {
    for (const scheme of ['light', 'dark']) {
      for (const part of [['home', {}], ['workers', {}], ['tasks', {}], ['question', { id: IDS.choiceNormal }]]) {
        const page = await open({ scheme, route: part });
        await page.addScriptTag({ content: axeSource() });
        const res = await page.evaluate(async () => { const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'best-practice'] } }); return r.violations.map((v) => v.id + ' x' + v.nodes.length + ' ' + (v.nodes[0] && v.nodes[0].target ? v.nodes[0].target.join(' ') : '')); });
        const mine = res.filter((v) => /pt-|tablist|tab\b|\[role="tab"\]|aria-(controls|selected)|aria-required|landmark|region|nav/.test(v));
        ok(`4.7 axe on "${part[0]}" (${scheme}): nothing about the tab strip or the landmarks`, mine.length === 0, mine.join(' | '));
        if (res.length) info(`(axe also says, not mine: ${res.slice(0, 3).join(' | ')})`);
        await page.context().close();
      }
    }
  } else info('no AXE_PATH: axe checks skipped');

  /* ======================================================================= 5. remember the part */
  {
    const page = await open();
    await P(page, () => window.QT.parts.go('tasks', { focus: 't-label' })); await sleep(300);
    const keys = await P(page, () => ({ part: window.localStorage.getItem('qt.part'), route: window.localStorage.getItem('qt.route') }));
    ok('5.1 the part is remembered in localStorage', keys.part === 'tasks' && /tasks/.test(keys.route || ''), JSON.stringify(keys));
    await page.reload(); await waitReady(page); await sleep(500);
    const r = await P(page, () => ({ part: window.QT.parts.current(), sel: [...document.querySelectorAll('.pt-tab')].map((x) => x.getAttribute('aria-selected')).join(), root: document.getElementById('app').getAttribute('data-part') }));
    ok('5.2 after a reload the Tasks part is open again (tab, data-part)', r.part === 'tasks' && r.sel === 'false,false,true' && r.root === 'tasks', JSON.stringify(r));
    await P(page, () => window.QT.parts.go('questions')); await sleep(300);
    await page.reload(); await waitReady(page); await sleep(500);
    ok('5.3 ... and the Questions part again after that', (await P(page, () => window.QT.parts.current())) === 'questions');
    // localStorage blocked: the page still works
    const blocked = await open({ init: 'Object.defineProperty(window, "localStorage", { get() { throw new Error("blocked"); } });' });
    const bl = await P(blocked, () => ({ strip: !!document.querySelector('.pt-strip'), part: window.QT.parts.current() }));
    await P(blocked, () => window.QT.parts.go('workers')); await sleep(300);
    ok('5.4 with localStorage blocked the strip and the parts still work', bl.strip && bl.part === 'questions' && (await P(blocked, () => window.QT.parts.current())) === 'workers');
    await blocked.context().close();
    await page.context().close();
  }

  /* ======================================================================= 6. sticky bars at 700x800, fit, zoom */
  {
    const page = await open({ route: ['question', { id: IDS.choiceNormal }] });
    const fit = await P(page, () => ({ doc: document.documentElement.scrollHeight, vh: innerHeight }));
    ok('6.1 the Questions part still fits 700x800 with the strip: a normal choice question needs no scroll', fit.doc <= fit.vh, JSON.stringify(fit));
    await go(page, 'question', { id: IDS.visual });
    const fit2 = await P(page, () => ({ doc: document.documentElement.scrollHeight, vh: innerHeight }));
    ok('6.2 ... and the picture question too', fit2.doc <= fit2.vh, JSON.stringify(fit2));
    await go(page, 'section', { id: IDS.sections.other });
    await P(page, () => window.scrollTo(0, 400)); await sleep(150);
    const sticky = await P(page, () => { const tb = document.querySelector('.topbar').getBoundingClientRect(), s = document.querySelector('.pt-strip').getBoundingClientRect(); return { tbBottom: Math.round(tb.bottom), stripTop: Math.round(s.top), stripBottom: Math.round(s.bottom), scrolled: scrollY }; });
    ok('6.3 scrolling a long page: top bar and strip stay at the top, one under the other', sticky.scrolled > 100 && sticky.stripTop === sticky.tbBottom && sticky.stripBottom - sticky.stripTop >= 40, JSON.stringify(sticky));
    await go(page, 'section', { id: 'kathy' });
    await P(page, () => window.scrollTo(0, 600)); await sleep(200);
    const fd = await P(page, () => { const f = document.querySelector('.sx-find'), s = document.querySelector('.pt-strip'); if (!f) return null; return { findTop: Math.round(f.getBoundingClientRect().top), stripBottom: Math.round(s.getBoundingClientRect().bottom), scrolled: scrollY }; });
    ok('6.3b the "Find a question" box of a long section sticks UNDER the strip, not behind it', !fd || fd.scrolled < 100 || fd.findTop >= fd.stripBottom, JSON.stringify(fd));
    await go(page, 'question', { id: IDS.choiceNormal });
    await P(page, () => window.scrollTo(0, 300)); await sleep(150);
    const qb = await P(page, () => { const s = document.querySelector('.pt-strip').getBoundingClientRect(), q = document.querySelector('#qt-view .qbar'); const r = q.getBoundingClientRect(); return { stripBottom: Math.round(s.bottom), qTop: Math.round(r.top), pos: getComputedStyle(q).position, scrolled: scrollY, free: q.classList.contains('qbar-free') }; });
    ok('6.4 a question: its sticky bar sits right under the strip (not behind it) when the page is scrolled', qb.pos !== 'sticky' || (qb.qTop === qb.stripBottom) || qb.scrolled === 0, JSON.stringify(qb));
    await page.context().close();

    // a short window and big text: the strip scrolls away before the question bar has to (the sticky bars cover at most 35% of the window)
    for (const cfg of [{ name: 'zoom 200% (683x384)', w: 683, h: 384 }, { name: 'zoom 300% (455x256)', w: 455, h: 256 }, { name: 'text 32px (700x800)', w: 700, h: 800, fs: 32 }, { name: 'text 24px (1366x768)', w: 1366, h: 768, fs: 24 }]) {
      const pg = await open({ w: cfg.w, h: cfg.h, route: ['question', { id: IDS.choiceNormal }] });
      if (cfg.fs) { await pg.addStyleTag({ content: `html{font-size:${cfg.fs}px!important}` }); await sleep(400); await pg.evaluate(() => window.dispatchEvent(new Event('resize'))); await sleep(300); }
      await P(pg, () => window.scrollTo(0, 400)); await sleep(150);
      const c = await P(pg, () => { const tb = document.querySelector('.topbar').getBoundingClientRect(), s = document.querySelector('.pt-strip'), sr = s.getBoundingClientRect(), q = document.querySelector('#qt-view .qbar'); let bottom = tb.bottom; if (getComputedStyle(s).position === 'sticky') bottom = Math.max(bottom, sr.bottom); if (q && getComputedStyle(q).position === 'sticky') bottom = Math.max(bottom, q.getBoundingClientRect().bottom); return { cover: bottom / innerHeight, free: s.classList.contains('is-free'), vh: innerHeight }; });
      ok(`6.5 ${cfg.name}: the sticky bars cover at most 35% of the window (the strip steps aside when needed)`, c.cover <= 0.355, JSON.stringify(c));
      await pg.context().close();
    }
  }

  /* ======================================================================= 7. narrow, wide, dark */
  {
    const narrow = await open({ w: 400, h: 800, route: ['workers', {}] });
    const n = await P(narrow, () => { const l = document.querySelector('.pt-tablist'), tabs = [...document.querySelectorAll('.pt-tab')].map((b) => { const r = b.getBoundingClientRect(); const t = b.querySelector('.pt-tab-t'); return { l: Math.round(r.left), r: Math.round(r.right), w: Math.round(r.width), clip: b.scrollWidth > b.clientWidth + 1, ellipsis: t.scrollWidth > t.clientWidth + 1 }; }); return { tabs, sideways: document.documentElement.scrollWidth > innerWidth + 1, lw: l.scrollWidth, cw: l.clientWidth }; });
    ok('7.1 400 px wide: three tabs side by side, none cut (no word ends in "…"), no sideways scroll', !n.sideways && n.tabs.length === 3 && n.tabs.every((t) => !t.clip && !t.ellipsis && t.l >= 0 && t.r <= 400) && n.lw <= n.cw + 1, JSON.stringify(n));
    await narrow.screenshot({ path: path.join(SHOTS, 'parts-workers-400x800.png') });
    await narrow.context().close();
    const wide = await open({ w: 1366, h: 768, route: ['question', { id: IDS.choiceNormal }] });
    const wd = await P(wide, () => { const s = document.querySelector('.pt-strip').getBoundingClientRect(), m = document.getElementById('qt-menu').getBoundingClientRect(), tb = document.querySelector('.topbar').getBoundingClientRect(); return { stripW: Math.round(s.width), vw: innerWidth, menuTop: Math.round(m.top), tbBottom: Math.round(tb.bottom), stripBottom: Math.round(s.bottom), menuH: Math.round(m.height) }; });
    ok('7.2 1366 wide: the strip spans the whole window; the left menu starts under the strip and fills the rest of the window height', wd.stripW >= wd.vw - 20 && wd.menuTop >= wd.stripBottom - 1 && wd.menuTop + wd.menuH <= 768 + 1, JSON.stringify(wd));
    await wide.screenshot({ path: path.join(SHOTS, 'parts-questions-1366x768.png') });
    await go(wide, 'tasks');
    const wt = await P(wide, () => { const m = document.getElementById('qt-main').getBoundingClientRect(); return { x: Math.round(m.left), w: Math.round(m.width), vw: innerWidth, menu: getComputedStyle(document.getElementById('qt-menu')).display }; });
    ok('7.3 1366 wide, Tasks: no menu, the main area starts at the left edge and uses the whole width', wt.menu === 'none' && wt.x === 0 && wt.w >= wt.vw - 20, JSON.stringify(wt));
    await wide.screenshot({ path: path.join(SHOTS, 'parts-tasks-1366x768.png') });
    await wide.context().close();
    // the narrow drop-down menu still opens under the strip
    const dd = await open({ w: 700, h: 800, route: ['home', {}] });
    await dd.click('.menu-btn'); await sleep(250);
    const m = await P(dd, () => { const m = document.getElementById('qt-menu').getBoundingClientRect(), s = document.querySelector('.pt-strip').getBoundingClientRect(); return { open: document.getElementById('qt-menu').classList.contains('open'), top: Math.round(m.top), stripBottom: Math.round(s.bottom), bottom: Math.round(m.bottom), vh: innerHeight }; });
    ok('7.4 700 wide: the Menu button opens the drop-down; it starts under the strip and stays inside the window', m.open && m.top >= m.stripBottom - 1 && m.bottom <= m.vh, JSON.stringify(m));
    await dd.keyboard.press('Escape');
    await dd.context().close();
  }

  /* ======================================================================= 8. the shared look: chip + speech bubble */
  {
    for (const scheme of ['light', 'dark']) {
      const page = await open({ scheme });
      const r = await P(page, (xss) => {
        const Q = window.QT.parts, host = document.createElement('div'); host.id = 'pt-host'; host.style.cssText = 'position:fixed;left:0;top:90px;width:640px;z-index:5000;padding:8px;background:var(--bg)';
        const pend = Q.seenChip({ what: 'add', seen: false }), seen = Q.seenChip({ what: 'ask', seen: true, at: new Date(Date.now() - 120000).toISOString() });
        const bubY = Q.bubble({ side: 'you', text: xss + '\nsecond line', at: new Date(Date.now() - 60000).toISOString(), chip: Q.seenChip({ what: 'ask', seen: false }) });
        const bubC = Q.bubble({ side: 'claude', name: 'Map drawer A', text: 'About an hour.', at: new Date().toISOString(), chip: seen });
        [pend, bubY, bubC].forEach((e) => host.appendChild(e)); document.body.appendChild(host);
        const lum = (c) => { const m = c.match(/[\d.]+/g).map(Number); const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(m[0]) + 0.7152 * f(m[1]) + 0.0722 * f(m[2]); };
        const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
        const cs = (e) => getComputedStyle(e);
        const rows = [[bubY, bubY.querySelector('.pt-bub-text')], [bubC, bubC.querySelector('.pt-bub-text')], [bubY, bubY.querySelector('.pt-bub-name')], [bubC, bubC.querySelector('.pt-bub-name')], [bubY, bubY.querySelector('.pt-bub-foot')], [pend, pend]];
        const contrast = rows.map(([bg, fg]) => Math.round(ratio(cs(fg).color, cs(bg).backgroundColor) * 10) / 10);
        return { pend: pend.textContent, seen: seen.textContent, pendCls: pend.className, bubYAria: bubY.getAttribute('aria-label'), bubCAria: bubC.getAttribute('aria-label'), imgs: host.querySelectorAll('img').length, text: bubY.querySelector('.pt-bub-text').textContent, nameY: bubY.querySelector('.pt-bub-name').textContent, nameC: bubC.querySelector('.pt-bub-name').textContent,
          youRight: Math.round(bubY.getBoundingClientRect().right), claudeLeft: Math.round(bubC.getBoundingClientRect().left), hostW: host.getBoundingClientRect().width, contrast, border: cs(pend).borderTopStyle, bg: [cs(bubY).backgroundColor, cs(bubC).backgroundColor], tailY: cs(bubY, '::after').content, white: cs(bubY).whiteSpace, wrap: cs(bubY.querySelector('.pt-bub-text')).whiteSpace };
      }, XSS);
      ok(`8.1 (${scheme}) the pending chip says "You added this · waiting for Claude to see it", dashed grey (the same look as the question chips)`, r.pend.replace(/\s+/g, ' ').trim() === 'You added this · waiting for Claude to see it' && r.border === 'dashed' && /qt-unseen/.test(r.pendCls), JSON.stringify([r.pend, r.border, r.pendCls]));
      ok(`8.2 (${scheme}) the seen chip says "Claude saw it ✓ · 2 min ago"`, r.seen.trim() === 'Claude saw it ✓ · 2 min ago', r.seen);
      const words = await P(page, () => ['add', 'edit', 'ask', 'pause', 'resume', 'remove'].map((w) => window.QT.parts.seenChip({ what: w }).textContent.replace(/\s+/g, ' ').trim()));
      ok(`8.2b (${scheme}) the pending chips use plain words (no "resume", "job" or "helper"): "You asked to start it again · waiting for Claude to see it"`, words.length === 6 && words[4] === 'You asked to start it again · waiting for Claude to see it' && !/resum|\bjobs?\b|helper/i.test(words.join(' ')), words.join(' | '));
      ok(`8.3 (${scheme}) a bubble shows text as plain text (a pasted <img> tag is words, not a picture), keeps line breaks, has a spoken name`, r.imgs === 0 && r.text.includes('<img') && r.wrap === 'pre-line' && r.bubYAria === 'Your question' && r.bubCAria === 'Answer from Map drawer A' && r.nameY === 'You' && r.nameC === 'Map drawer A', JSON.stringify([r.imgs, r.bubYAria, r.bubCAria]));
      ok(`8.4 (${scheme}) her bubble sits on the right, Claude's on the left; two different colours; the tail is drawn`, r.youRight > r.claudeLeft + 200 && r.bg[0] !== r.bg[1] && r.tailY !== 'none', JSON.stringify([r.youRight, r.claudeLeft, r.bg, r.tailY]));
      ok(`8.5 (${scheme}) text in bubbles and the pending chip has contrast >= 4.5:1`, r.contrast.every((c) => c >= 4.5), JSON.stringify(r.contrast));
      if (scheme === 'light') { const el = await page.$('#pt-host'); if (el) await el.screenshot({ path: path.join(SHOTS, 'parts-bubbles.png') }); }
      await page.context().close();
    }
    // reduced motion: nothing moves
    const rm = await open({ init: '' });
    await rm.emulateMedia({ reducedMotion: 'reduce' });
    const an = await P(rm, () => { const Q = window.QT.parts, b = Q.bubble({ side: 'you', text: 'x' }); document.body.appendChild(b); return { bub: getComputedStyle(b).animationName, tab: getComputedStyle(document.querySelector('.pt-tab')).transitionDuration }; });
    ok('8.6 with "reduce motion" the bubble pop and the tab fade are off', an.bub === 'none' && parseFloat(an.tab) <= 0.001, JSON.stringify(an));
    await rm.context().close();
  }

  /* ======================================================================= 9. no notebook, no data: the page still draws */
  {
    const page = await open({ seed: seed({ parts: false }) });
    const r = await P(page, () => ({ strip: !!document.querySelector('.pt-strip'), counts: window.QT.parts.counts(), workers: window.QT.parts.workers().length, tasks: window.QT.parts.tasks().length }));
    ok('9.1 without workers and tasks the strip is there, the counts are 0 and the lists are empty', r.strip && r.counts.workersWorking === 0 && r.counts.tasksWaitingForYou === 0 && r.workers === 0 && r.tasks === 0, JSON.stringify(r));
    await go(page, 'workers'); await go(page, 'tasks');
    ok('9.2 Workers and Tasks open without data (no error)', (await P(page, () => window.QT.parts.current())) === 'tasks');
    await page.context().close();
    const off = await open({ options: { dbNull: true } });
    const o = await P(off, () => ({ strip: !!document.querySelector('.pt-strip'), part: window.QT.parts.current(), counts: window.QT.parts.counts() }));
    ok('9.3 with no notebook at all (offline) the strip is still there and nothing throws', o.strip && o.part === 'questions' && o.counts.workersWorking === 0, JSON.stringify(o));
    await go(off, 'workers');
    ok('9.4 ... and the Workers part opens', (await P(off, () => window.QT.parts.current())) === 'workers');
    await off.context().close();
  }

  /* ======================================================================= 10. watch() and the page never writes */
  {
    const page = await open();
    await P(page, () => { window.__w = 0; window.__off = window.QT.parts.watch(() => { window.__w++; }); });
    await P(page, () => { window.__mock.db.merge('workers/map-a', { now: 'Another line' }); window.__mock.db.merge('workers/map-c', { now: '' }); window.__mock.db.merge('questions/' + 'zzz', { title: 'x' }); });
    await okSoon('10.1 watch(fn) is called once (not per document) when workers change', () => P(page, () => window.__w), (n) => n === 1, 4000);
    await P(page, () => { window.__w = 0; window.__mock.db.merge('answers/zzz', { key: 'A' }); });
    await sleep(300);
    ok('10.2 watch(fn) ignores collections it does not care about (answers)', (await P(page, () => window.__w)) === 0);
    await P(page, () => { window.__off(); window.__w = 0; window.__mock.db.merge('workers/map-a', { now: 'Third' }); });
    await sleep(300);
    ok('10.3 the function that watch() returns stops it', (await P(page, () => window.__w)) === 0);
    await go(page, 'workers'); await go(page, 'tasks'); await go(page, 'home');
    const writes = await P(page, () => window.__mock.db.writes.filter((w) => /^(workers|tasks|replies|taskAdds|taskEdits|asks)\//.test(w.path)));
    ok('10.4 switching parts and reading never writes anything to the notebook', writes.length === 0, JSON.stringify(writes));
    await page.context().close();
  }
} catch (e) {
  ok('the test ran to the end', false, String(e && e.stack ? e.stack.split('\n').slice(0, 4).join(' / ') : e));
}

await finish({ browser, site, errs });
