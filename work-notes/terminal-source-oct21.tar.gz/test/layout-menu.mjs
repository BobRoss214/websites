/* Left menu labels stay on ONE line from 1100px up (real page, Cathy count 90); logo is not a button; test button shows "Test" at 640-899.  Port 9210. */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const { ok, info } = H;
const h = await H.start(9210);
const p = await H.open(h, { docs: seed({ count: 90 }), w: 1366, h: 768 });
for (const w of [1100, 1366, 1920]) {
  await p.setViewportSize({ width: w, height: 768 }); await H.settle(p, 150);
  const r = await p.evaluate(() => [...document.querySelectorAll('#qt-menu .mi')].map((e) => [e.querySelector('.mi-t').textContent, Math.round(e.getBoundingClientRect().height)]));
  const multi = r.filter(([t, hh]) => hh > 46 && !/Account|Gift/.test(t));
  ok(`[${w}px] every menu label is on one line`, multi.length === 0, JSON.stringify(multi));
  info(`[${w}px] ` + r.map(([t, hh]) => t + ':' + hh).join(' | '));
}
await p.setViewportSize({ width: 1366, height: 768 }); await H.settle(p, 150); await H.shot(p, 'layout-menu-1366');
const lg = await p.evaluate(() => { const b = document.querySelector('.brand'); return { aria: b.getAttribute('aria-hidden'), tag: b.tagName, interactive: !!b.closest('a,button,[role=button]') || getComputedStyle(b).cursor === 'pointer', svg: !!b.querySelector('svg.mark'), text: b.textContent.trim() }; });
ok('logo is a plain aria-hidden picture, not a control', lg.aria === 'true' && lg.tag === 'SPAN' && !lg.interactive && lg.svg && lg.text === '', JSON.stringify(lg));
for (const w of [900, 899, 820, 819, 700, 400]) {
  await p.setViewportSize({ width: w, height: 800 }); await H.settle(p, 100);
  const t = await p.evaluate(() => { const b = document.querySelector('.test-btn'), r = b.getBoundingClientRect(); return { vis: b.innerText.trim(), name: b.getAttribute('aria-label'), title: b.title, w: Math.round(r.width), h: Math.round(r.height) }; });
  const want = w >= 900 ? 'Check Claude hears me' : w >= 820 ? 'Check Claude' : '';
  ok(`[${w}px] test button shows "${want}" (hit area >= 40px, name + tooltip kept)`, t.vis === want && t.h >= 40 && t.w >= 40 && /^Check Claude hears me/.test(t.name) && /test note/.test(t.title), JSON.stringify(t));
}
for (const w of [900, 700, 640, 639, 400]) {
  await p.setViewportSize({ width: w, height: 800 }); await H.settle(p, 100);
  const t = await p.evaluate(() => { const b = document.querySelector('.sound-btn'), r = b.getBoundingClientRect(); return { vis: b.innerText.trim(), name: b.getAttribute('aria-label'), title: b.title, pressed: b.getAttribute('aria-pressed'), w: Math.round(r.width), h: Math.round(r.height) }; });
  const want = w >= 640 ? 'Sound: off' : '';
  ok(`[${w}px] sound button shows "${want}" (name + tooltip kept, >= 40px)`, t.vis === want && t.h >= 40 && t.w >= 40 && /Play a happy sound when something new arrives/.test(t.name) && /Play a happy sound when something new arrives/.test(t.title) && t.pressed === 'false', JSON.stringify(t));
}
await p.setViewportSize({ width: 700, height: 800 }); await H.settle(p, 100);
await p.click('.sound-btn'); await H.settle(p, 100);
const on = await p.evaluate(() => { const b = document.querySelector('.sound-btn'); return { vis: b.innerText.trim(), pressed: b.getAttribute('aria-pressed'), name: b.getAttribute('aria-label'), bg: getComputedStyle(b).backgroundColor }; });
ok('sound on: the words say "Sound: on", pressed, name starts with the visible words', on.vis === 'Sound: on' && on.pressed === 'true' && /^Sound: on/.test(on.name) && true, JSON.stringify(on));
// the "Downloads and skills" built-in section: in the built-in group after "Other questions", only when its document exists; her own sections stay under MY SECTIONS
{
  const p2 = await H.open(h, { docs: seed(), w: 1366, h: 768 });
  const keys = () => p2.evaluate(() => [...document.querySelectorAll('#qt-menu [data-key], #qt-menu .mi-label')].map((e) => e.classList.contains('mi-label') ? 'LABEL:' + e.textContent : e.getAttribute('data-key') + '=' + e.querySelector('.mi-t').textContent));
  let k = await keys();
  ok('no downloads row while its section document does not exist', !k.some((x) => /^s:downloads/.test(x)), k.join(' | '));
  const base = { kind: 'builtin', size: 'small', hold: false, archived: false, createdAt: new Date().toISOString(), createdBy: 'claude' };
  await H.put(p2, 'sections/downloads', { ...base, id: 'downloads', title: 'Downloads and skills', order: 3, readOnly: false, blurb: 'Files and skills Claude made for you.' });
  await H.put(p2, 'sections/terminal', { ...base, id: 'terminal', title: 'Terminal', kind: 'custom', order: 30, createdBy: 'owner' });
  await H.put(p2, 'sections/website-control-pannle', { ...base, id: 'website-control-pannle', title: 'Website control panel', kind: 'custom', order: 31, createdBy: 'owner' });
  await H.settle(p2, 400);
  k = await keys();
  const at = (pre) => k.findIndex((x) => x.startsWith(pre));
  ok('downloads sits right after "Other questions", before "Ideas for later"', at('s:downloads=') === at('s:other=') + 1 && at('s:later=') === at('s:downloads=') + 1, k.join(' | '));
  ok('downloads has the title "Downloads and skills" and a download icon (not the folder icon)', k[at('s:downloads=')] === 's:downloads=Downloads and skills' && (await p2.evaluate(() => document.querySelector('#qt-menu [data-key="s:downloads"] svg path').getAttribute('d'))) !== (await p2.evaluate(() => document.querySelector('#qt-menu [data-key="s:terminal"] svg path').getAttribute('d'))), k.join(' | '));
  const lab = at('LABEL:');
  ok('her own sections (terminal, website-control-pannle) are under MY SECTIONS, downloads is above it', lab > at('s:kathy=') && at('s:terminal=') > lab && at('s:website-control-pannle=') > lab && at('s:downloads=') < lab, k.join(' | '));
  await p2.click('#qt-menu [data-key="s:downloads"]'); await H.settle(p2, 300);
  ok('the downloads row opens the section and is marked as the current page', (await p2.evaluate(() => (document.querySelector('#qt-menu [aria-current="page"]') || {}).getAttribute && document.querySelector('#qt-menu [aria-current="page"]').getAttribute('data-key'))) === 's:downloads');
  await p2.context().close();
}
// one shared look for the two toggles: same colours on and off; the little switch shows the state; "Sound: on/off", "Voice: on/off"
{
  const p3 = await H.open(h, { docs: seed(), w: 1366, h: 768 });
  const look = () => p3.evaluate(() => { const out = {}; for (const sel of ['.sound-btn', '.qt-voice-btn']) { const b = document.querySelector(sel); if (!b) continue; const cs = getComputedStyle(b), af = getComputedStyle(b, '::after'); out[sel] = { text: b.innerText.trim(), pressed: b.getAttribute('aria-pressed'), bg: cs.backgroundColor, border: cs.borderColor, color: cs.color, sw: af.backgroundColor, swW: af.width, h: Math.round(b.getBoundingClientRect().height) }; } return out; });
  let a = await look();
  ok('sound toggle: label "Sound: off", little switch drawn (grey), button not coloured', a['.sound-btn'] && a['.sound-btn'].text === 'Sound: off' && parseFloat(a['.sound-btn'].swW) > 20, JSON.stringify(a));
  await p3.click('.sound-btn'); await H.settle(p3, 150);
  const b = await look();
  ok('sound toggle: "Sound: on" has the SAME button colours as off, only the little switch changes (green)', b['.sound-btn'].text === 'Sound: on' && b['.sound-btn'].bg === a['.sound-btn'].bg && b['.sound-btn'].border === a['.sound-btn'].border && b['.sound-btn'].color === a['.sound-btn'].color && b['.sound-btn'].sw !== a['.sound-btn'].sw, JSON.stringify([a['.sound-btn'], b['.sound-btn']]));
  if (a['.qt-voice-btn']) {
    ok('voice toggle: label "Voice: on/off", same button colours as the sound toggle, a little switch', /^Voice: (on|off)$/.test(a['.qt-voice-btn'].text) && a['.qt-voice-btn'].bg === a['.sound-btn'].bg && a['.qt-voice-btn'].border === a['.sound-btn'].border && a['.qt-voice-btn'].h === a['.sound-btn'].h && parseFloat(a['.qt-voice-btn'].swW) > 20, JSON.stringify(a));
  } else info('no voice switch in this browser (no speech): only the sound toggle was checked');
  await p3.context().close();
}
await H.stop(h);
