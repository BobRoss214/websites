/* speak-mock.mjs  (owner: layout)  A pretend speechSynthesis for the browser tests of the "read it out loud" buttons (src/js/60-speak.js).
 *
 *   import { MOCK, VOICES } from './speak-mock.mjs';
 *   await page.addInitScript(MOCK(opts));        // BEFORE page.goto
 *   await page.evaluate(() => window.__speech.spoken)           // [{text, voice, lang, rate, pitch, volume}]
 *
 * opts:  voices   list of voices (default VOICES.local); [] = the list is empty
 *        late     ms: the voice list arrives (with a "voiceschanged") this long after the page started; before that getVoices() answers []
 *        auto     ms an utterance "takes" before it ends by itself (default 25); 0 = it never ends until the test says so (window.__speech.finish())
 *        none     true = there is no speechSynthesis at all
 *        throws   true = window.speechSynthesis throws when touched
 *        noUtter  true = SpeechSynthesisUtterance is missing
 *        failSpeak true = speak() throws
 *        eventAtStart true = a "voiceschanged" is sent right at the start (headless Chromium does that, with an empty list)
 *
 * window.__speech:  spoken[] cancels calls current queue speaking pending
 *                   finish()            the utterance being said ends (onend)
 *                   fail(error)         the utterance being said fails (onerror {error})
 *                   setVoices(list, fire=true)   replaces the voice list (and sends "voiceschanged")
 *                   log                 every call in order: 'speak:<text>' 'cancel'
 */
export const VOICES = {
  local: [
    { name: 'Microsoft David - English (United States)', lang: 'en-US', localService: true, default: true },
    { name: 'Microsoft Zira - English (United States)', lang: 'en-US', localService: true, default: false },
    { name: 'Microsoft George - English (United Kingdom)', lang: 'en-GB', localService: true, default: false },
    { name: 'Microsoft Helena - Spanish (Spain)', lang: 'es-ES', localService: true, default: false },
  ],
  googleOnly: [
    { name: 'Google US English', lang: 'en-US', localService: false, default: true },
    { name: 'Google UK English Female', lang: 'en-GB', localService: false, default: false },
    { name: 'Google español', lang: 'es-ES', localService: false, default: false },
  ],
  onlineOnly: [
    { name: 'Microsoft Aria Online (Natural) - English (United States)', lang: 'en-US', localService: false, default: true },
    { name: 'Microsoft Guy Online (Natural) - English (United States)', lang: 'en-US', localService: false, default: false },
  ],
  mixed: [
    { name: 'Google US English', lang: 'en-US', localService: false, default: true },
    { name: 'Microsoft Aria Online (Natural) - English (United States)', lang: 'en-US', localService: false, default: false },
    { name: 'Odd local voice that says it is remote', lang: 'en-US', localService: false, default: false },
    { name: 'Google Local Pretender', lang: 'en-US', localService: true, default: false },          // a local flag but a Google name: not used
    { name: 'Some Online Local Pretender', lang: 'en-US', localService: true, default: false },      // "Online" in the name: not used
    { name: 'Alex', lang: 'en-US', localService: true, default: false },
    { name: 'Samantha', lang: 'en-US', localService: true, default: false },
    { name: 'Daniel', lang: 'en-GB', localService: true, default: false },
    { name: 'Albert', lang: 'en-US', localService: true, default: false },                          // a novelty voice
  ],
  noFlag: [{ name: 'Mystery', lang: 'en-US', default: true }],      // no localService property at all: not private for sure
};

export function MOCK(opts = {}) {
  return `(() => {
    const O = ${JSON.stringify({ voices: opts.voices || VOICES.local, late: opts.late || 0, auto: opts.auto === undefined ? 25 : opts.auto, none: !!opts.none, throws: !!opts.throws, noUtter: !!opts.noUtter, failSpeak: !!opts.failSpeak, eventAtStart: !!opts.eventAtStart })};
    const S = window.__speech = { spoken: [], cancels: 0, calls: 0, log: [], current: null, queue: [], voices: O.late ? [] : O.voices.map((v, i) => Object.assign({ voiceURI: v.name }, v)) };
    S.speaking = false; S.pending = false;
    const upd = () => { S.speaking = !!S.current; S.pending = S.queue.length > 0; };
    const et = new EventTarget();
    class Utter { constructor(text) { this.text = String(text); this.lang = ''; this.voice = null; this.rate = 1; this.pitch = 1; this.volume = 1; this.onend = null; this.onerror = null; this.onstart = null; } }
    const fire = (u, kind, extra) => { const fn = u['on' + kind]; if (typeof fn === 'function') try { fn.call(u, Object.assign({ type: kind, utterance: u }, extra || {})); } catch (e) { setTimeout(() => { throw e; }); } };
    let timer = 0;
    const startNext = () => {
      if (S.current || !S.queue.length) { upd(); return; }
      S.current = S.queue.shift(); upd();
      fire(S.current, 'start');
      if (O.auto) timer = setTimeout(() => S.finish(), O.auto);
    };
    S.finish = () => { clearTimeout(timer); const u = S.current; S.current = null; upd(); if (u) fire(u, 'end'); startNext(); };
    S.fail = (error) => { clearTimeout(timer); const u = S.current; S.current = null; upd(); if (u) fire(u, 'error', { error: error || 'synthesis-failed' }); startNext(); };
    S.setVoices = (list, doFire = true) => { S.arrivedAt = performance.now(); S.voices = list.map((v) => Object.assign({ voiceURI: v.name }, v)); if (doFire) et.dispatchEvent(new Event('voiceschanged')); };
    const synth = {
      speak(u) {
        S.calls++;
        if (O.failSpeak) throw new Error('speak failed');
        S.log.push('speak:' + u.text);
        S.spoken.push({ text: u.text, voice: u.voice ? u.voice.name : null, voiceLocal: u.voice ? u.voice.localService : null, lang: u.lang, rate: u.rate, pitch: u.pitch, volume: u.volume, at: Date.now() });
        S.queue.push(u); upd();
        setTimeout(startNext, 0);
      },
      cancel() {
        S.cancels++; S.log.push('cancel');
        clearTimeout(timer);
        const cur = S.current, q = S.queue.splice(0);
        S.current = null; upd();
        // like Chrome: the one being said (and the waiting ones) hear "interrupted", a moment later
        setTimeout(() => { if (cur) fire(cur, 'error', { error: 'interrupted' }); q.forEach((u) => fire(u, 'error', { error: 'canceled' })); }, 0);
      },
      getVoices() { return S.voices.slice(); },
      pause() {}, resume() {},
      addEventListener: (...a) => { et.addEventListener(...a); if (O.eventAtStart && a[0] === 'voiceschanged') setTimeout(() => et.dispatchEvent(new Event('voiceschanged')), 0); },   // like Chrome: a listener hears the list change that follows the start
      removeEventListener: (...a) => et.removeEventListener(...a),
      get speaking() { return S.speaking; }, get pending() { return S.pending; }, get paused() { return false; },
      onvoiceschanged: null,
    };
    if (!O.none) {
      if (O.throws) Object.defineProperty(window, 'speechSynthesis', { configurable: true, get() { throw new Error('speechSynthesis is blocked here'); } });
      else Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: synth });
    } else { try { Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: undefined }); } catch (e) {} }
    if (!O.noUtter) window.SpeechSynthesisUtterance = Utter; else { try { Object.defineProperty(window, 'SpeechSynthesisUtterance', { configurable: true, value: undefined }); } catch (e) {} }
    if (O.late) setTimeout(() => S.setVoices(O.voices), O.late);
    if (O.eventAtStart) setTimeout(() => et.dispatchEvent(new Event('voiceschanged')), 0);
  })();`;
}
