/* Test stub for the sections helper (NOT part of the page). Stands in for 40-status.js and 20-question.js when 30-sections.js is built alone:
   QT.status (state / chip / badgeCount / isNew / heartbeatLabel) and a tiny QT.views.question. */
(function () {
  var QT = window.QT;
  function coll(n) { return QT.store[n] || {}; }
  var STATES = { seen: 1, working: 1, done: 1, followup: 1, held: 1 };
  function state(qid) {
    var a = coll('answers')[qid], s = coll('status')[qid];
    var named = s && STATES[s.state] ? s.state : null;
    if (a) { if (!s || (a.answeredAt > (s.seenAt || s.at || ''))) return 'answeredUnseen'; return named || 'seen'; }
    if (named && named !== 'seen') return named;
    return 'waiting';
  }
  var TXT = { waiting: 'Waiting for you', answeredUnseen: 'You answered · waiting for Claude to see it', seen: 'Claude saw it ✓', working: 'Working on it…', done: 'Done ✓', followup: 'Claude has a follow-up question', held: 'Paused (you asked me to wait)' };
  QT.status = {
    state: state,
    chip: function (qid) { var s = state(qid); var e = document.createElement('span'); e.className = 'chip ' + (s === 'done' ? 'good' : s === 'working' ? 'info' : ''); e.setAttribute('data-state', s); e.textContent = TXT[s] + (s === 'working' && (coll('status')[qid] || {}).note ? ' ' + coll('status')[qid].note : ''); return e; },
    badgeCount: function (id) { return QT.sections.waiting(id).length; },
    isNew: function (qid) { return !!(window.__new && window.__new[qid]); },
    heartbeatLabel: function () { return { text: 'Claude last looked: 2 min ago', stale: false }; },
    testConnection: function () { return Promise.resolve('ok'); }
  };
  QT.sound = { enabled: function () { return false; }, set: function () {}, chime: function () {} };
  QT.views = QT.views || {};
  QT.views.question = function (el, p) {
    var q = coll('questions')[p.id] || {};
    el.appendChild(QT.el('h1', { class: 'stub-q-title', text: q.title || p.id }));
    el.appendChild(QT.el('p', { class: 'stub-q-kind', text: 'kind=' + q.kind }));
    el.appendChild(QT.el('button', { type: 'button', class: 'btn', on: { click: function () { QT.route.go('section', { id: q.sectionId }); } } }, 'Back to the section'));
  };
})();
