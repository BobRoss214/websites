/* Odd data in the notebook: loops and ids like "__proto__".   NODE_PATH=/opt/node22/lib/node_modules node T/test/security.test.mjs     Ports 9776+.   (owner: tester)
 * Claude (or a mistake) can write documents that are shaped badly. The page must never freeze or break because of them:
 *   1. A LOOP of parents: worker A under B under A, a worker under itself, a loop of three, kids hanging off a loop; the same for tasks.
 *      The Workers and Tasks views must still draw every worker / task once (nobody vanishes), the page stays quick and clickable, also when the loop
 *      appears while the view is open, and QT.parts answers at once.
 *   2. IDS that are the names of things every object has: a document called __proto__ / constructor / toString (also as the id inside a document, as a
 *      parent, as a task or worker link, as the target of a question), and a document with a "__proto__" key. Nothing may be polluted, nothing may
 *      vanish, nothing may break; the page's own writes refuse such ids.
 * Everything else about the page is checked in the other tests; this file only looks at "odd data does no harm".
 */
import { H, ok, info, sleep, partsDocs, openParts, textOf } from './parts-lib.mjs';
import { okSoon } from './harness.mjs';

const h = await H.start(9776, { src: true });
const NOW = Date.now();
const iso = (msAgo) => new Date(NOW - msAgo).toISOString();
const MIN = 60 * 1000;

const worker = (id, name, parentId, o = {}) => ({ id, name, parentId, kind: 'helper', icon: '🐝', role: 'A made-up job for the odd-data test.', state: 'working', now: 'Busy', waitingFor: 'none', startedAt: iso(30 * MIN), updatedAt: iso(2 * MIN), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 50, ...o });
const task = (id, parentId, title, o = {}) => ({ id, parentId, title, plain: 'A made-up job: ' + title + '.', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 50, createdAt: iso(120 * MIN), updatedAt: iso(5 * MIN), doneAt: null, createdBy: 'claude', seenAt: null, ...o });

/** The page is alive: it answers a plain question within `limit` ms (a frozen page never does). */
/** page.evaluate that never throws: a page that throws gives {error}. */
const tryEv = (page, fn, arg) => page.evaluate(fn, arg).catch((e) => ({ error: String(e && e.message).split('\n')[0].slice(0, 200) }));
const alive = (page, limit = 6000) => Promise.race([page.evaluate(() => 1 + 1).then((v) => v === 2), sleep(limit).then(() => false)]);

/* the odd ids must not make the page less safe: read what the page itself says about them */
const probe = (page) => page.evaluate(() => {
  const P = Object.prototype;
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const stores = {};
  for (const c of ['workers', 'tasks', 'taskAdds', 'taskEdits', 'asks', 'replies']) {
    const s = (window.QT.store || {})[c] || {};
    stores[c] = { n: Object.keys(s).length, bad: ['__proto__', 'constructor', 'toString', 'hasOwnProperty', 'valueOf', 'prototype'].filter((k) => own(s, k)) };
  }
  return {
    protoNames: Object.getOwnPropertyNames(P).sort().join(',') === window.__protoNames ? 'same' : 'CHANGED: ' + Object.getOwnPropertyNames(P).sort().join(','),
    polluted: ({}).polluted === undefined ? null : ({}).polluted,
    nameLeak: ({}).name === undefined ? null : ({}).name,
    idLeak: ({}).id === undefined ? null : ({}).id,
    stateLeak: ({}).state === undefined ? null : ({}).state,
    arrayPolluted: [].polluted === undefined ? null : [].polluted,
    stores,
    skipped: window.QT.skippedIds || null,
  };
});
const INIT_BASE = 'window.__protoNames = Object.getOwnPropertyNames(Object.prototype).sort().join(",");';   // what Object.prototype holds BEFORE the page runs

/* ===================================================================== 1. loops of parents */
const LOOPS = { w: ['w-loop-a', 'w-loop-b', 'w-self', 'w-tri-1', 'w-tri-2', 'w-tri-3', 'w-loop-kid', 'w-loop-kid2', 'w-ok-under-loop'], t: ['t-loop-a', 't-loop-b', 't-self', 't-tri-1', 't-tri-2', 't-tri-3', 't-loop-kid', 't-loop-kid2', 't-ok-under-loop'] };
function loopDocs() {
  const D = partsDocs();
  const W = (id, name, parentId, o) => { D['workers/' + id] = worker(id, name, parentId, o); };
  W('w-loop-a', 'Loop worker A', 'w-loop-b');           // A under B ...
  W('w-loop-b', 'Loop worker B', 'w-loop-a');           // ... and B under A
  W('w-self', 'Self worker', 'w-self');                 // a worker under itself
  W('w-tri-1', 'Triangle one', 'w-tri-3');              // 1 under 3 under 2 under 1
  W('w-tri-2', 'Triangle two', 'w-tri-1');
  W('w-tri-3', 'Triangle three', 'w-tri-2');
  W('w-loop-kid', 'Kid of the loop', 'w-loop-a');
  W('w-loop-kid2', 'Kid of the kid', 'w-loop-kid');
  W('w-ok-under-loop', 'Fine helper', 'claude', { order: 99 });
  const T = (id, parentId, title, o) => { D['tasks/' + id] = task(id, parentId, title, o); };
  T('t-loop-a', 't-loop-b', 'Loop task A');
  T('t-loop-b', 't-loop-a', 'Loop task B');
  T('t-self', 't-self', 'Self task');
  T('t-tri-1', 't-tri-3', 'Triangle task one');
  T('t-tri-2', 't-tri-1', 'Triangle task two');
  T('t-tri-3', 't-tri-2', 'Triangle task three');
  T('t-loop-kid', 't-loop-a', 'Kid of the loop task');
  T('t-loop-kid2', 't-loop-kid', 'Kid of the kid task');
  T('t-ok-under-loop', 't-map', 'Fine task', { order: 99 });
  return D;
}
const waitCards = (page, ids) => H.until(page, (x) => x.every((id) => !!document.querySelector(`article.wk-card[data-wid="${id}"]`)), ids, 8000);

await H.block('1 worker loops', async () => {
  const t0 = Date.now();
  const page = await openParts(h, { docs: loopDocs(), label: 'loop-w: ' });
  ok('the page opens with loops in the crew (it did not freeze: ready in under 12 s)', (await alive(page)) && Date.now() - t0 < 12000, (Date.now() - t0) + ' ms');
  const api = await Promise.race([page.evaluate(() => {
    const t = performance.now(); const P = window.QT.parts;
    const all = P.workers().map((w) => w.id), roots = P.workerRoots().map((w) => w.id);
    const seen = new Set(); let steps = 0;
    const walk = (w) => { if (seen.has(w.id) || steps++ > 5000) return; seen.add(w.id); P.workerKids(w.id).forEach(walk); };
    P.workerRoots().forEach(walk);
    return { ms: Math.round(performance.now() - t), all: all.length, roots, reached: seen.size, steps };
  }), sleep(8000).then(() => null)]);
  ok('QT.parts.workers / workerRoots / workerKids answer at once (a loop is cut, not followed for ever)', !!api && api.ms < 500, JSON.stringify(api));
  ok('every worker is reachable from a root: nobody vanishes (15 + 9 = 24)', !!api && api.all === 24 && api.reached === 24, JSON.stringify(api && { all: api.all, reached: api.reached, steps: api.steps }));
  ok('every loop has a top one (a loop member is a root)', !!api && ['w-loop-a', 'w-loop-b'].some((i) => api.roots.includes(i)) && api.roots.includes('w-self') && ['w-tri-1', 'w-tri-2', 'w-tri-3'].some((i) => api.roots.includes(i)), JSON.stringify(api && api.roots));
  await H.go(page, 'workers'); await H.settle(page, 500);
  ok('the Workers view is drawn and the page answers', (await alive(page)) && (await textOf(page)).length > 100, (await textOf(page)).slice(0, 80));
  // folded branches have no cards in the page: open every fold, as she would
  await page.evaluate(() => { document.querySelectorAll('[data-fid^="fold-"]').forEach((b) => { if (b.getAttribute('aria-expanded') === 'false') b.click(); }); });
  await H.settle(page, 500);
  await page.evaluate(() => { const b = document.querySelector('[data-fid="showfin"]'); if (b && !/hide/i.test(b.innerText)) b.click(); });   // finished workers are folded away at first
  await H.settle(page, 400);
  ok('the page still answers after unfolding everything', await alive(page));
  const cards = await page.evaluate((ids) => Object.fromEntries(ids.map((id) => [id, document.querySelectorAll(`article.wk-card[data-wid="${id}"]`).length])), LOOPS.w);
  ok('every loop worker has exactly ONE card (none missing, none twice)', Object.values(cards).every((n) => n === 1), JSON.stringify(cards));
  const total = await page.evaluate(() => document.querySelectorAll('article.wk-card[data-wid]').length);
  ok('all 24 workers have a card (nobody is drawn twice)', total === 24, String(total));
  ok('the names are on the cards (a loop does not hide text)', /Loop worker A/.test(await textOf(page)) && /Loop worker B/.test(await textOf(page)) && /Self worker/.test(await textOf(page)) && /Kid of the kid/.test(await textOf(page)));
  // the page works: tabs, filters, folding
  await H.go(page, 'tasks'); await H.settle(page, 300);
  await H.go(page, 'workers'); await H.settle(page, 300);
  ok('Workers - Tasks - Workers again: the page answers each time', await alive(page));
  const flt = await page.evaluate(() => { const b = document.querySelector('[data-fid="flt-working"]'); if (!b) return false; b.click(); return true; });
  await H.settle(page, 300);
  ok('a filter button still works (' + (flt ? 'clicked' : 'no filter button found') + ')', flt && (await alive(page)));
  // a loop made while the view is open
  const dyn = await page.evaluate(async () => {
    const M = window.__mock.db; const t0 = performance.now();
    M.put('workers/w-live-1', { id: 'w-live-1', name: 'Live loop one', parentId: 'w-live-2', kind: 'helper', icon: '', role: 'x', state: 'working', now: '', waitingFor: 'none', startedAt: null, updatedAt: new Date().toISOString(), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 60 });
    M.put('workers/w-live-2', { id: 'w-live-2', name: 'Live loop two', parentId: 'w-live-1', kind: 'helper', icon: '', role: 'x', state: 'working', now: '', waitingFor: 'none', startedAt: null, updatedAt: new Date().toISOString(), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 61 });
    await new Promise((r) => setTimeout(r, 600));
    return { ms: Math.round(performance.now() - t0), a: !!document.querySelector('article.wk-card[data-wid="w-live-1"]'), b: !!document.querySelector('article.wk-card[data-wid="w-live-2"]') };
  });
  ok('a loop that appears while the Workers view is open is drawn (both workers) and does not freeze it', (await alive(page)) && dyn.a && dyn.b, JSON.stringify(dyn));
  // a very long loop (60 workers in a ring)
  const ring = await page.evaluate(async () => {
    const M = window.__mock.db; const t0 = performance.now();
    for (let i = 0; i < 60; i++) M.put('workers/w-ring-' + i, { id: 'w-ring-' + i, name: 'Ring ' + i, parentId: 'w-ring-' + ((i + 1) % 60), kind: 'helper', icon: '', role: 'x', state: 'resting', now: '', waitingFor: 'none', startedAt: null, updatedAt: new Date().toISOString(), finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 70 + i });
    await new Promise((r) => setTimeout(r, 900));
    const P = window.QT.parts;
    return { ms: Math.round(performance.now() - t0), n: P.workers().length, reached: (() => { const s = new Set(); let st = 0; const walk = (w) => { if (s.has(w.id) || st++ > 9000) return; s.add(w.id); P.workerKids(w.id).forEach(walk); }; P.workerRoots().forEach(walk); return s.size; })() };
  });
  ok('a ring of 60 workers (longer than a 50-step walk) is cut too: all 86 reachable, no freeze', (await alive(page)) && ring.n === 86 && ring.reached === 86, JSON.stringify(ring));
  ok('loops: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

await H.block('2 task loops', async () => {
  const page = await openParts(h, { docs: loopDocs(), label: 'loop-t: ' });
  ok('the page opens with loops among the tasks', await alive(page));
  const api = await Promise.race([page.evaluate(() => {
    const t = performance.now(); const P = window.QT.parts;
    const all = P.tasks().map((x) => x.id), roots = P.taskRoots().map((x) => x.id);
    const seen = new Set(); let steps = 0;
    const walk = (x) => { if (seen.has(x.id) || steps++ > 5000) return; seen.add(x.id); P.taskKids(x.id).forEach(walk); };
    P.taskRoots().forEach(walk);
    const pr = ['t-loop-a', 't-loop-b', 't-self', 't-tri-1', 't-loop-kid', 't-map'].map((id) => { try { const r = P.progress(id); return r && typeof r === 'object' ? 'ok' : String(r); } catch (e) { return 'threw ' + e.message; } });
    return { ms: Math.round(performance.now() - t), all: all.length, roots, reached: seen.size, steps, pr };
  }), sleep(8000).then(() => null)]);
  ok('QT.parts.tasks / taskRoots / taskKids / progress answer at once with loops', !!api && api.ms < 500 && api.pr.every((x) => x === 'ok'), JSON.stringify(api && { ms: api.ms, pr: api.pr }));
  ok('every task is reachable from a root (44 effective + 9 = 53): nobody vanishes', !!api && api.reached === api.all && api.all >= 53, JSON.stringify(api && { all: api.all, reached: api.reached }));
  ok('every loop has a top task (a loop member is a root)', !!api && ['t-loop-a', 't-loop-b'].some((i) => api.roots.includes(i)) && api.roots.includes('t-self') && ['t-tri-1', 't-tri-2', 't-tri-3'].some((i) => api.roots.includes(i)), JSON.stringify(api && api.roots));
  await H.go(page, 'tasks'); await H.settle(page, 500);
  ok('the Tasks view is drawn and the page answers', (await alive(page)) && (await textOf(page)).length > 100);
  const opened = await Promise.race([page.evaluate(() => { const b = document.querySelector('[data-key="openall"]'); if (!b) return 'no button'; const t = performance.now(); b.click(); return Math.round(performance.now() - t); }), sleep(8000).then(() => 'froze')]);
  await H.settle(page, 600);
  ok('"Open all" with loops is quick and the page answers (' + opened + ' ms)', typeof opened === 'number' && opened < 3000 && (await alive(page)), String(opened));
  const nodes = await page.evaluate((ids) => Object.fromEntries(ids.map((id) => [id, document.querySelectorAll(`li.tk-node[data-id="${id}"]`).length])), LOOPS.t);
  ok('every loop task has exactly ONE row (none missing, none twice)', Object.values(nodes).every((n) => n === 1), JSON.stringify(nodes));
  const rows = await page.evaluate(() => document.querySelectorAll('li.tk-node').length);
  const ids = await page.evaluate(() => [...document.querySelectorAll('li.tk-node')].map((l) => l.dataset.id));
  ok('no task is drawn twice (' + rows + ' rows)', new Set(ids).size === ids.length && rows >= 53, ids.length + ' rows, ' + new Set(ids).size + ' different');
  // click a loop node, open its panel, search, close all
  const sel = await page.evaluate(() => { const l = document.querySelector('li.tk-node[data-id="t-loop-a"]'); const c = l && l.querySelector(':scope > .tk-card'); if (!c) return false; c.click(); return true; });
  await H.settle(page, 500);
  ok('clicking a loop task opens its panel and the page answers', sel && (await alive(page)) && /Loop task A/.test(await textOf(page, '.tk-detail')), (await textOf(page, '.tk-detail')).slice(0, 100));
  const closed = await page.evaluate(() => { const b = document.querySelector('[data-key="closeall"]'); if (!b) return false; b.click(); return true; });
  await H.settle(page, 400);
  ok('"Close all" works with loops', closed && (await alive(page)));
  const found = await page.evaluate(async () => { const s = document.getElementById('tk-search'); if (!s) return null; s.focus(); s.value = 'loop task'; s.dispatchEvent(new Event('input', { bubbles: true })); await new Promise((r) => setTimeout(r, 700)); return document.querySelectorAll('li.tk-node').length; });
  ok('the search finds loop tasks and does not freeze (' + found + ' rows)', found !== null && (await alive(page)), String(found));
  // adding below a loop task still works
  await page.evaluate(() => { const s = document.getElementById('tk-search'); if (s) { s.value = ''; s.dispatchEvent(new Event('input', { bubbles: true })); } });
  const add = await page.evaluate(() => window.QT.write.taskAdd({ title: 'Under a loop', parentId: 't-loop-a' }).then((id) => ({ ok: true, id }), (e) => ({ ok: false, e: String(e && e.message) })));
  await H.settle(page, 500);
  ok('adding a task under a loop task works and the page answers', add.ok && (await alive(page)), JSON.stringify(add));
  // a loop made while the view is open
  const dyn = await page.evaluate(async () => {
    const M = window.__mock.db; const t0 = performance.now();
    const mk = (id, parentId) => ({ id, parentId, title: 'Live ' + id, plain: 'x', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 90, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), doneAt: null, createdBy: 'claude', seenAt: null });
    M.put('tasks/t-live-1', mk('t-live-1', 't-live-2')); M.put('tasks/t-live-2', mk('t-live-2', 't-live-1'));
    await new Promise((r) => setTimeout(r, 700));
    return { ms: Math.round(performance.now() - t0), a: !!document.querySelector('li.tk-node[data-id="t-live-1"]'), b: !!document.querySelector('li.tk-node[data-id="t-live-2"]') };
  });
  ok('a task loop that appears while the Tasks view is open does not freeze it (and both tasks are drawn)', (await alive(page)) && dyn.a && dyn.b, JSON.stringify(dyn));
  ok('task loops: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

await H.block('3 loops and links together (worker <-> task, ask on a loop member)', async () => {
  const D = loopDocs();
  D['workers/w-loop-a'] = worker('w-loop-a', 'Loop worker A', 'w-loop-b', { taskIds: ['t-loop-a', 't-self'] });
  D['tasks/t-loop-a'] = task('t-loop-a', 't-loop-b', 'Loop task A', { workerIds: ['w-loop-a', 'w-loop-b'] });
  const page = await openParts(h, { docs: D, label: 'loop-link: ' });
  await H.go(page, 'workers'); await H.settle(page, 400);
  const link = await page.evaluate(() => { const c = document.querySelector('article.wk-card[data-wid="w-loop-a"]'); return c ? [...c.querySelectorAll('a.wk-task, [data-key^="task:"]')].length : -1; });
  ok('a loop worker with task links draws and the page answers', (await alive(page)) && link >= 0, String(link));
  const asked = await page.evaluate(() => window.QT.write.ask({ targetKind: 'worker', targetId: 'w-loop-a', text: 'Are you in a loop?' }).then((id) => ({ ok: true, id }), (e) => ({ ok: false, e: String(e && e.message) })));
  ok('asking a worker that sits in a loop works', asked.ok, JSON.stringify(asked));
  ok('links and loops: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ===================================================================== 2. odd ids */
const ODDS = ['__proto__', 'constructor', 'toString', 'hasOwnProperty', 'valueOf', 'prototype', '__defineGetter__'];
function oddDocs() {
  const D = partsDocs();
  // documents whose OWN ID is odd (the page leaves them out)
  for (const odd of ODDS) {
    D['workers/' + odd] = worker(odd, 'Worker named ' + odd, null);
    D['tasks/' + odd] = task(odd, null, 'Task named ' + odd);
    D['taskAdds/' + odd] = { id: odd, parentId: null, title: 'Add named ' + odd, plain: '', createdAt: iso(MIN) };
    D['taskEdits/' + odd] = { id: odd, title: 'Edit named ' + odd, updatedAt: iso(MIN) };
    D['asks/' + odd] = { id: odd, targetKind: 'worker', targetId: 'claude', text: 'Ask named ' + odd, createdAt: iso(MIN) };
    D['replies/' + odd] = { id: odd, targetKind: 'worker', targetId: 'claude', state: 'answered', text: 'Reply named ' + odd, from: 'Claude', at: iso(MIN) };
  }
  // good documents that POINT at odd ids (as a parent, as links, as the target of a reply)
  D['workers/w-odd-parent'] = worker('w-odd-parent', 'Parent is proto', '__proto__');
  D['workers/w-odd-parent2'] = worker('w-odd-parent2', 'Parent is constructor', 'constructor');
  D['workers/w-odd-links'] = worker('w-odd-links', 'Odd links worker', 'claude', { taskIds: ['__proto__', 'constructor', 'toString', 't-map'] });
  D['tasks/t-odd-parent'] = task('t-odd-parent', '__proto__', 'Task parent is proto');
  D['tasks/t-odd-parent2'] = task('t-odd-parent2', 'constructor', 'Task parent is constructor');
  D['tasks/t-odd-links'] = task('t-odd-links', 't-map', 'Odd links task', { workerIds: ['__proto__', 'constructor', 'claude'], questionIds: ['__proto__', 'constructor', 'toString'] });
  D['replies/ask-odd-target'] = { id: 'ask-odd-target', targetKind: 'task', targetId: '__proto__', state: 'answered', text: 'A reply about proto', from: 'Claude', at: iso(MIN) };
  D['asks/ask-odd-target'] = { id: 'ask-odd-target', targetKind: 'task', targetId: '__proto__', text: 'A question about proto', createdAt: iso(2 * MIN) };
  D['taskAdds/u-odd-parent'] = { id: 'u-odd-parent', parentId: '__proto__', title: 'Her add under proto', plain: '', createdAt: iso(MIN) };
  D['taskEdits/t-odd-parent'] = { id: 't-odd-parent', title: 'Task parent is proto (renamed)', updatedAt: iso(MIN) };
  // a good document whose "id" INSIDE says something odd (the document's own name is fine)
  D['workers/w-odd-idfield'] = worker('__proto__', 'Id inside is proto', null);
  D['tasks/t-odd-idfield'] = task('__proto__', null, 'Id inside is proto (task)');
  D['workers/w-odd-idfield2'] = worker('constructor', 'Id inside is constructor', null);
  D['tasks/t-odd-idfield2'] = task('constructor', null, 'Id inside is constructor (task)');
  return D;
}
/* documents with a "__proto__" KEY: they must be made as text, because an object written in code cannot hold an own "__proto__" */
const KEYED = {
  'workers/w-odd-key': '{"__proto__":{"polluted":"yes","name":"HACKED","state":"HACKED"},"id":"w-odd-key","name":"Worker with a proto key","parentId":null,"kind":"helper","icon":"","role":"x","state":"working","now":"","waitingFor":"none","startedAt":null,"updatedAt":"' + new Date(NOW - 2 * MIN).toISOString() + '","finishedAt":null,"activity":[],"result":"","taskIds":[],"brain":"","progress":null,"order":77}',
  'tasks/t-odd-key': '{"__proto__":{"polluted":"yes","title":"HACKED","state":"HACKED"},"id":"t-odd-key","parentId":null,"title":"Task with a proto key","plain":"x","state":"todo","waitingFor":"none","workerIds":[],"questionIds":[],"note":"","order":77,"createdAt":"' + new Date(NOW - 20 * MIN).toISOString() + '","updatedAt":"' + new Date(NOW - 2 * MIN).toISOString() + '","doneAt":null,"createdBy":"claude","seenAt":null}',
  'taskEdits/t-map': '{"__proto__":{"polluted":"yes"},"id":"t-map","title":"Map task renamed by a proto key","updatedAt":"' + new Date(NOW - MIN).toISOString() + '"}',
  'questions/q-odd-key': '{"__proto__":{"polluted":"yes","title":"HACKED"},"id":"q-odd-key","sectionId":"other","kind":"choice","order":900,"title":"A question with a proto key","story":["Plain words."],"why":"","ownTip":"","choices":[{"key":"A","label":"Yes","explain":"Fine."},{"key":"B","label":"No","explain":"Fine."}],"required":false,"round":1,"parentId":null,"who":"owner","needs":"","createdAt":"' + new Date(NOW - 3600e3).toISOString() + '"}',
};
const initKeyed = `(function () { var K = ${JSON.stringify(KEYED)}; Object.keys(K).forEach(function (p) { window.__mock.db.put(p, JSON.parse(K[p])); }); })();`;

await H.block('4 odd ids in the notebook', async () => {
  const page = await openParts(h, { docs: oddDocs(), init: INIT_BASE, initAfter: initKeyed, label: 'odd: ' });
  ok('the page opens with odd ids in the notebook', await alive(page));
  const p = await probe(page);
  ok('nothing was added to Object.prototype / Array.prototype ("polluted", name, id, state all stay undefined)', p.protoNames === 'same' && p.polluted === null && p.nameLeak === null && p.idLeak === null && p.stateLeak === null && p.arrayPolluted === null, JSON.stringify(p));
  ok('the stores hold no document called __proto__ / constructor / toString / hasOwnProperty / valueOf / prototype', Object.values(p.stores).every((s) => s.bad.length === 0), JSON.stringify(p.stores));
  info('left out by the page (QT.skippedIds): ' + JSON.stringify(p.skipped));
  ok('the page says (in QT.skippedIds) which odd documents it left out', !!p.skipped && Object.keys(p.skipped).length > 0, JSON.stringify(p.skipped));
  const api0 = await tryEv(page, () => {
    const P = window.QT.parts, S = window.QT.store;
    const ids = (a) => a.map((x) => x.id);
    return { workers: ids(P.workers()), tasks: ids(P.tasks()), wRoots: ids(P.workerRoots()), tRoots: ids(P.taskRoots()), stored: Object.keys(S.workers).length, storedT: Object.keys(S.tasks).length };
  });
  ok('QT.parts.workers / tasks / workerRoots / taskRoots still answer when a worker or task has a parent called "__proto__" or "constructor"', !api0.error, api0.error);
  const api = api0.error ? { workers: [], tasks: [], wRoots: [], tRoots: [] } : api0;
  const goodW = ['w-odd-parent', 'w-odd-parent2', 'w-odd-links', 'w-odd-key'];
  const goodT = ['t-odd-parent', 't-odd-parent2', 't-odd-links', 't-odd-key'];
  ok('the good workers around the odd ones are all there (parent is proto / constructor, odd links, proto key)', goodW.every((i) => api.workers.includes(i)), JSON.stringify(api.workers.filter((i) => /odd/.test(i))));
  ok('the good tasks around the odd ones are all there', goodT.every((i) => api.tasks.includes(i)), JSON.stringify(api.tasks.filter((i) => /odd/.test(i))));
  ok('a worker / task whose parent is "__proto__" or "constructor" stands at the top (a parent that does not exist makes it a root)', ['w-odd-parent', 'w-odd-parent2'].every((i) => api.wRoots.includes(i)) && ['t-odd-parent', 't-odd-parent2'].every((i) => api.tRoots.includes(i)), JSON.stringify({ w: api.wRoots, t: api.tRoots }));
  ok('the original 15 workers and 42 + 2 tasks are all still there (nothing vanished: at least 15 + 4, 44 + 4)', api.workers.length >= 19 && api.tasks.length >= 48, JSON.stringify({ w: api.workers.length, t: api.tasks.length }));
  ok('no worker or task is listed under an odd id', !api.workers.some((i) => ODDS.includes(i)) && !api.tasks.some((i) => ODDS.includes(i)), JSON.stringify([...api.workers, ...api.tasks].filter((i) => ODDS.includes(i))));
  // the views
  await H.go(page, 'workers'); await H.settle(page, 600);
  await page.evaluate(() => { document.querySelectorAll('[data-fid^="fold-"]').forEach((b) => { if (b.getAttribute('aria-expanded') === 'false') b.click(); }); });
  await H.settle(page, 400);
  const wt = await textOf(page);
  ok('the Workers view still draws: the good workers with odd links are on it, and so is the crew', (await alive(page)) && /Parent is proto/.test(wt) && /Parent is constructor/.test(wt) && /Odd links worker/.test(wt) && /Worker with a proto key/.test(wt) && /Storybook Hills/.test(wt), wt.slice(0, 120));
  ok('no text from an odd document leaks onto the view ("HACKED" is nowhere)', !/HACKED/.test(wt));
  const wcards = await page.evaluate(() => document.querySelectorAll('article.wk-card[data-wid]').length);
  ok('every worker has a card (' + wcards + ')', wcards === api.workers.length, wcards + ' cards, ' + api.workers.length + ' workers');
  await H.go(page, 'tasks'); await H.settle(page, 600);
  await page.evaluate(() => { const b = document.querySelector('[data-key="openall"]'); b && b.click(); });
  await H.settle(page, 500);
  const tt = await textOf(page);
  ok('the Tasks view still draws: the good tasks with odd parents / links are on it', (await alive(page)) && /Task parent is proto/.test(tt) && /Task parent is constructor/.test(tt) && /Odd links task/.test(tt) && /Task with a proto key/.test(tt), tt.slice(0, 120));
  ok('no text from an odd document leaks onto the Tasks view', !/HACKED/.test(tt));
  ok('the Map task (which has an edit with a "__proto__" key) still has its row', await page.evaluate(() => !!document.querySelector('li.tk-node[data-id="t-map"]')), tt.slice(0, 100));
  const trows = await page.evaluate(() => { const ids = [...document.querySelectorAll('li.tk-node')].map((l) => l.dataset.id); return { n: ids.length, uniq: new Set(ids).size }; });
  ok('no task is drawn twice (' + trows.n + ' rows)', trows.n === trows.uniq && trows.n >= 48, JSON.stringify(trows));
  // the panels of the odd-linked ones open
  const open = await page.evaluate(() => { const l = document.querySelector('li.tk-node[data-id="t-odd-links"]'); const c = l && l.querySelector(':scope > .tk-card'); if (!c) return false; c.click(); return true; });
  await H.settle(page, 500);
  ok('the panel of a task with odd links opens and the page answers', open && (await alive(page)) && /Odd links task/.test(await textOf(page, '.tk-detail')), (await textOf(page, '.tk-detail')).slice(0, 100));
  // the questions side
  await H.go(page, 'home'); await H.settle(page, 400);
  ok('the home (questions) view still draws', (await alive(page)) && (await textOf(page)).length > 100, (await textOf(page)).slice(0, 80));
  await H.go(page, 'section', { id: 'other' }); await H.settle(page, 400);
  const qt = await textOf(page);
  ok('a question with a "__proto__" key is a normal question (its own words show, not the polluted ones)', (await alive(page)) && !/HACKED/.test(qt), qt.slice(0, 100));
  // the page's own writes refuse odd ids
  await H.clearWrites(page);
  const refused = await page.evaluate(async (odds) => {
    const W = window.QT.write, out = [];
    const attempt = async (name, fn) => { try { await fn(); out.push([name, 'accepted']); } catch (e) { out.push([name, 'refused']); } };
    for (const odd of odds) {
      await attempt('taskEdit ' + odd, () => W.taskEdit(odd, { title: 'x' }));
      await attempt('taskAdd parent ' + odd, () => W.taskAdd({ title: 'Under ' + odd, parentId: odd }));
      await attempt('ask worker ' + odd, () => W.ask({ targetKind: 'worker', targetId: odd, text: 'hello' }));
      await attempt('ask task ' + odd, () => W.ask({ targetKind: 'task', targetId: odd, text: 'hello' }));
    }
    return out;
  }, ['__proto__', 'constructor', 'prototype', 'toString', 'hasOwnProperty']);
  const accepted = refused.filter((r) => r[1] === 'accepted');
  // lowercase-start words that are fine as ids by the letter rule (toString has a capital, so it fails ID_RE) are listed as accepted here; only the ones that can hurt matter
  const harmful = accepted.filter((r) => /__proto__|constructor|prototype/.test(r[0]));
  ok('the page refuses to write anything about __proto__ / constructor / prototype (edit, add under it, ask about it)', harmful.length === 0, JSON.stringify(harmful));
  ok('...and about toString / hasOwnProperty (capital letters are not allowed in an id)', !accepted.some((r) => /toString|hasOwnProperty/.test(r[0])), JSON.stringify(accepted.filter((r) => /toString|hasOwnProperty/.test(r[0]))));
  ok('a refused write wrote nothing into the notebook', (await H.writes(page)).length === 0, (await H.writes(page)).map((w) => w.path).join());
  const p2 = await probe(page);
  ok('after all of that, still nothing polluted', p2.protoNames === 'same' && p2.polluted === null && p2.nameLeak === null && p2.stateLeak === null, JSON.stringify(p2));
  ok('odd ids: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* one odd parent at a time, so a failure names exactly the word and the part that breaks */
await H.block('4b one odd parent at a time', async () => {
  for (const odd of ['__proto__', 'constructor', 'toString', 'hasOwnProperty', 'valueOf']) {
    for (const kind of ['worker', 'task']) {
      const D = partsDocs();
      if (kind === 'worker') D['workers/w-one-odd'] = worker('w-one-odd', 'One odd worker', odd);
      else D['tasks/t-one-odd'] = task('t-one-odd', odd, 'One odd task');
      const page = await openParts(h, { docs: D, label: `odd-${kind}-${odd}: ` });
      const r = await tryEv(page, (k) => { const P = window.QT.parts; const list = k === 'worker' ? P.workers() : P.tasks(); const roots = k === 'worker' ? P.workerRoots() : P.taskRoots(); const id = k === 'worker' ? 'w-one-odd' : 't-one-odd'; return { n: list.length, root: roots.some((x) => x.id === id) }; }, kind);
      ok(`a ${kind} whose parent is called "${odd}": QT.parts answers and lists it as a top one`, !r.error && r.root && r.n === (kind === 'worker' ? 16 : 45), JSON.stringify(r));
      await H.go(page, kind === 'worker' ? 'workers' : 'tasks'); await H.settle(page, 500);
      if (kind === 'task') { await page.evaluate(() => { const b = document.querySelector('[data-key="openall"]'); b && b.click(); }); await H.settle(page, 300); }
      const shown = kind === 'worker' ? await page.evaluate(() => !!document.querySelector('article.wk-card[data-wid="w-one-odd"]')) : await page.evaluate(() => !!document.querySelector('li.tk-node[data-id="t-one-odd"]'));
      ok(`...and the ${kind === 'worker' ? 'Workers' : 'Tasks'} view draws it (and the rest of the page, ${(await textOf(page)).length} characters)`, shown && (await alive(page)) && (await textOf(page)).length > 200, (await textOf(page)).slice(0, 100));
      ok(`...without a page error (${odd}, ${kind})`, page.__errs.length === 0, page.__errs.join(' | ').slice(0, 300));
      await page.context().close();
    }
  }
});

await H.block('5 odd ids arriving while the page is open', async () => {
  const page = await openParts(h, { init: INIT_BASE, label: 'odd-live: ' });
  await H.go(page, 'workers'); await H.settle(page, 400);
  const before = await page.evaluate(() => ({ w: window.QT.parts.workers().length, t: window.QT.parts.tasks().length }));
  // Claude writes odd documents now (the notebook accepts them as letters and digits)
  await page.evaluate(() => {
    const M = window.__mock.db, now = new Date().toISOString();
    for (const odd of ['__proto__', 'constructor', 'toString']) {
      M.put('workers/' + odd, { id: odd, name: 'Live worker ' + odd, parentId: null, kind: 'helper', icon: '', role: 'x', state: 'working', now: '', waitingFor: 'none', startedAt: null, updatedAt: now, finishedAt: null, activity: [], result: '', taskIds: [], brain: '', progress: null, order: 80 });
      M.put('tasks/' + odd, { id: odd, parentId: null, title: 'Live task ' + odd, plain: 'x', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 80, createdAt: now, updatedAt: now, doneAt: null, createdBy: 'claude', seenAt: null });
      M.put('replies/' + odd, { id: odd, targetKind: 'worker', targetId: 'claude', state: 'answered', text: 'Live reply ' + odd, from: 'Claude', at: now });
    }
    M.put('workers/w-live-odd', { id: 'w-live-odd', name: 'Live odd parent', parentId: '__proto__', kind: 'helper', icon: '', role: 'x', state: 'working', now: '', waitingFor: 'none', startedAt: null, updatedAt: now, finishedAt: null, activity: [], result: '', taskIds: ['__proto__'], brain: '', progress: null, order: 81 });
  });
  await H.settle(page, 800);
  ok('the page answers after odd documents arrive', await alive(page));
  const after = await page.evaluate(() => ({ w: window.QT.parts.workers().length, t: window.QT.parts.tasks().length, shown: !!document.querySelector('article.wk-card[data-wid="w-live-odd"]') }));
  ok('the one good document among them is drawn (+1 worker), the odd ones are left out', after.w === before.w + 1 && after.t === before.t && after.shown, JSON.stringify({ before, after }));
  const p = await probe(page);
  ok('nothing polluted, nothing stored under an odd id', p.protoNames === 'same' && p.polluted === null && p.nameLeak === null && Object.values(p.stores).every((s) => s.bad.length === 0), JSON.stringify(p));
  // the same with one odd doc removed again (a delete of a document the page never took in)
  await page.evaluate(() => window.__mock.db.remove('workers/__proto__'));
  await H.settle(page, 400);
  ok('removing an odd document that was never taken in does nothing bad', await alive(page));
  // switching around still works
  for (const v of ['tasks', 'workers', 'home']) { await H.go(page, v); await H.settle(page, 250); }
  ok('Tasks - Workers - Home: the page answers each time', await alive(page));
  ok('live odd ids: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

await H.stop(h);
