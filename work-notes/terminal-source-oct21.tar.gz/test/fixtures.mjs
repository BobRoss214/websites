/* Shared test fixtures for the Question Terminal (SPEC.md section 4).
 *
 *   import { seed, IDS, split, svg, iso } from './fixtures.mjs';
 *   const docs = seed();                       // { 'sections/look': {...}, 'questions/v-map-1': {...}, 'answers/c-done': {...}, 'meta/heartbeat': {...}, ... }
 *   const docs2 = seed({ stale: true });       // heartbeat is 45 minutes old
 *   const docs3 = seed({ count: 12 });         // 12 read-only "Kathy" questions instead of 30
 *   const docs4 = seed({ empty: true });       // only the 4 built-in sections + heartbeat (the friendly empty home)
 *   split(docs)                                // { sections:{look:{...}}, questions:{...}, answers:{...}, ... }  (grouped by collection)
 *
 * Options of seed():
 *   stale      Boolean  heartbeat 45 min old (amber "Claude may be busy") instead of 2 min old          (default false)
 *   count      Number   how many read-only questions in the "kathy" section                               (default 30)
 *   empty      Boolean  only the built-in sections (+ heartbeat). No questions, no answers.               (default false)
 *   noHeart    Boolean  no meta/heartbeat document at all                                                 (default false)
 *   extra      Number   N more plain unanswered questions in "other" (for long-list tests)                (default 0)
 *   draftIdea  Boolean  also an unsent draft idea in account-features                                     (default false)
 *   now        Number   the "now" (ms) every time stamp is counted back from                              (default Date.now())
 *   parts      Boolean  also the Workers and Tasks parts (SPEC2): 15 workers, 41 tasks, her pending adds / edits / asks, replies   (default false)
 *   bigTasks   Number   N more tasks (a 4-level tree of mixed states) for speed tests                              (default 0)
 *   noCrew     Boolean  with parts: no workers (empty Workers part);  noTasks: no tasks (empty Tasks part)
 *   downloads  Boolean  also the built-in section "downloads" (Downloads and skills) with 4 questions that carry a `safety` check (IDS.safety*): F3 of SPEC3
 *   cathy      Boolean  also 3 answers with key "cathy" ("This is a question for Miss Cathy and Rob"): c-short (with a note), c-normal, gs-2 (Claude already moved it: status done)
 *
 * Everything here is TEST DATA ONLY. The farm facts are made up on purpose (this is not content for the owner).
 */

export const XSS = '<img src=x onerror=alert(1)>';
export const XSS2 = '"><script>window.__xss=1</script>';
export const LONGWORD = 'Supercalifragilisticexpialidocious'.repeat(5) + 'https://example.com/' + 'a'.repeat(120);

/* ---------- ids used by the tests (keep in sync with the data below) ---------- */
export const IDS = {
  sections: { look: 'look', other: 'other', later: 'later', kathy: 'kathy', big: 'account-features', small: 'gift-shop' },
  visual: 'v-map-1',            // the 4-version picture question, unanswered, with "how it looks now" pictures
  visualAnswered: 'v-hero-1',   // answered B, Claude saw it
  visualChange: 'v-menu-1',     // answered "change", Claude is working on it
  choiceShort: 'c-short',       // short text, unanswered
  choiceNormal: 'c-normal',     // normal text, unanswered
  choiceLong: 'c-long',         // VERY long story (5 paragraphs) and long option texts, unanswered
  choiceXss: 'c-xss',           // html in every text field, unanswered
  answeredUnseen: 'c-unseen',   // answered A, no status doc
  done: 'c-done',               // answered A, status done + doneNote + doneImages
  followup: 'c-followup',       // answered own text, status followup -> c-followup-2
  followupChild: 'c-followup-2',
  held: 'c-held',               // answered "unsure", status held
  help: 'c-help',               // answered "help", status seen
  readonly: 'k01',              // first Miss Cathy question (id k01, section id "kathy")
  readonlyLast: 'k30',          // last Kathy question when count is the default 30
  later: ['l-1', 'l-2', 'l-3'],
  big: ['af-1', 'af-2', 'af-3', 'af-4', 'af-5', 'af-6'],   // af-1..af-4 required
  bigRequired: ['af-1', 'af-2', 'af-3', 'af-4'],
  small: ['gs-1', 'gs-2'],
  ideas: ['idea-1', 'idea-2'],
  draftIdea: 'idea-draft',
  downloads: 'downloads',                       // the built-in section "Downloads and skills" (seed({ downloads: true }))
  safety: 'd-sample-safety',                    // verdict "mixed", canRecheck, 5 checks (ok warn fail unknown ok), 3 limits, 4 sources, runs on her computer
  safetyClean: 'd-sample-clean',                // verdict "looks_safe", canRecheck, 2 checks ok, runs only inside Claude's workspace
  safetyBad: 'd-sample-notsafe',                // verdict "not_safe", no canRecheck
  safetyNone: 'd-sample-unchecked',             // verdict "unchecked", canRecheck, nothing else
  cathy: ['c-short', 'c-normal', 'gs-2'],       // seed({ cathy: true }): answered with "This is a question for Miss Cathy and Rob"
};

/* ---------- small helpers ---------- */
export const iso = (msAgo, now = Date.now()) => new Date(now - msAgo).toISOString();
const MIN = 60 * 1000, HOUR = 60 * MIN, DAY = 24 * HOUR;

/* ---------- pictures: real PNG files inside data: addresses (no network, no svg) ----------
 * The page only accepts https, /_blob/<id>, #anchors and data:image png / jpeg / gif / webp / avif (QT.safeUrl, 8 Oct): svg is NOT allowed.
 * So the test pictures are small real PNGs drawn here (plain colours, a few shapes, and the label in a built-in 5x7 letter font). */
import zlib from 'node:zlib';
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (buf) => { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (type, data) => { const out = Buffer.alloc(12 + data.length); out.writeUInt32BE(data.length, 0); out.write(type, 4, 'latin1'); data.copy(out, 8); out.writeUInt32BE(crc32(out.subarray(4, 8 + data.length)), 8 + data.length); return out; };
const FONT = { A: '01110 10001 10001 11111 10001 10001 10001', B: '11110 10001 10001 11110 10001 10001 11110', C: '01110 10001 10000 10000 10000 10001 01110', D: '11110 10001 10001 10001 10001 10001 11110', E: '11111 10000 10000 11110 10000 10000 11111', F: '11111 10000 10000 11110 10000 10000 10000', G: '01110 10001 10000 10111 10001 10001 01111', H: '10001 10001 10001 11111 10001 10001 10001', I: '01110 00100 00100 00100 00100 00100 01110', J: '00111 00010 00010 00010 00010 10010 01100', K: '10001 10010 10100 11000 10100 10010 10001', L: '10000 10000 10000 10000 10000 10000 11111', M: '10001 11011 10101 10101 10001 10001 10001', N: '10001 11001 10101 10011 10001 10001 10001', O: '01110 10001 10001 10001 10001 10001 01110', P: '11110 10001 10001 11110 10000 10000 10000', Q: '01110 10001 10001 10001 10101 10010 01101', R: '11110 10001 10001 11110 10100 10010 10001', S: '01111 10000 10000 01110 00001 00001 11110', T: '11111 00100 00100 00100 00100 00100 00100', U: '10001 10001 10001 10001 10001 10001 01110', V: '10001 10001 10001 10001 10001 01010 00100', W: '10001 10001 10001 10101 10101 11011 10001', X: '10001 10001 01010 00100 01010 10001 10001', Y: '10001 10001 01010 00100 00100 00100 00100', Z: '11111 00001 00010 00100 01000 10000 11111', 0: '01110 10001 10011 10101 11001 10001 01110', 1: '00100 01100 00100 00100 00100 00100 01110', 2: '01110 10001 00001 00010 00100 01000 11111', 3: '11110 00001 00001 01110 00001 00001 11110', 4: '00010 00110 01010 10010 11111 00010 00010', 5: '11111 10000 11110 00001 00001 10001 01110', 6: '00110 01000 10000 11110 10001 10001 01110', 7: '11111 00001 00010 00100 01000 01000 01000', 8: '01110 10001 10001 01110 10001 10001 01110', 9: '01110 10001 10001 01111 00001 00010 01100' };
const hex = (c) => { const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(c || ''); if (!m) return [200, 200, 200]; let h = m[1]; if (h.length === 3) h = h.replace(/./g, '$&$&'); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; };
const PNG_CACHE = new Map();
/** A picture as a PNG data: URL, w x h pixels. `label` is written in the middle (letters and digits only). */
export function png(w, h, color, label = '', dark = '#222') {
  const key = [w, h, color, label, dark].join('|');
  if (PNG_CACHE.has(key)) return PNG_CACHE.get(key);
  w = Math.max(1, Math.min(4000, Math.round(w))); h = Math.max(1, Math.min(4000, Math.round(h)));
  const px = Buffer.alloc(h * (1 + w * 3));            // each row: filter byte 0, then r g b ...
  const bg = hex(color), fg = hex(dark);
  const mix = (c, to, a) => c.map((v, i) => Math.round(v * (1 - a) + to[i] * a));
  const rect = (x0, y0, ww, hh, rgb) => { x0 = Math.max(0, Math.round(x0)); y0 = Math.max(0, Math.round(y0)); const x1 = Math.min(w, Math.round(x0 + ww)), y1 = Math.min(h, Math.round(y0 + hh)); for (let y = y0; y < y1; y++) { let o = y * (1 + w * 3) + 1 + x0 * 3; for (let x = x0; x < x1; x++) { px[o++] = rgb[0]; px[o++] = rgb[1]; px[o++] = rgb[2]; } } };
  rect(0, 0, w, h, bg);
  rect(w * 0.08, h * 0.12, w * 0.84, h * 0.16, mix(bg, [255, 255, 255], 0.55));
  const r = Math.min(w, h) * 0.18, cx = w * 0.22, cy = h * 0.62, dk = mix(bg, [0, 0, 0], 0.18);
  for (let y = Math.max(0, Math.floor(cy - r)); y < Math.min(h, Math.ceil(cy + r)); y++) { const dx = Math.sqrt(Math.max(0, r * r - (y - cy) * (y - cy))); rect(cx - dx, y, 2 * dx, 1, dk); }
  rect(w * 0.45, h * 0.5, w * 0.45, h * 0.3, mix(bg, [255, 255, 255], 0.4));
  const text = String(label || '').toUpperCase().replace(/[^A-Z0-9 ]/g, '') + (label ? ' ' : '') + w + 'X' + h;
  const fs = Math.max(18, Math.round(Math.min(w, h) / 6));
  const scale = Math.max(1, Math.floor(Math.min(fs / 7, (w * 0.9) / (text.length * 6))));
  const tw = text.length * 6 * scale - scale, tx = Math.round((w - tw) / 2), ty = Math.round((h - 7 * scale) / 2);
  [...text].forEach((ch, i) => { const g = FONT[ch]; if (!g) return; g.split(' ').forEach((row, ry) => { for (let rx = 0; rx < 5; rx++) if (row[rx] === '1') rect(tx + (i * 6 + rx) * scale, ty + ry * scale, scale, scale, fg); }); });
  const head = Buffer.alloc(13); head.writeUInt32BE(w, 0); head.writeUInt32BE(h, 4); head[8] = 8; head[9] = 2; head[10] = 0; head[11] = 0; head[12] = 0;
  const file = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', head), chunk('IDAT', zlib.deflateSync(px, { level: 6 })), chunk('IEND', Buffer.alloc(0))]);
  const url = 'data:image/png;base64,' + file.toString('base64');
  PNG_CACHE.set(key, url);
  return url;
}
/** Old name, kept so nothing breaks: it now makes a PNG (svg pictures are no longer allowed by the page). */
export const svg = png;
const img = (w, h, color, label, alt) => ({ url: png(w, h, color, label), alt: alt || ('Picture ' + label), w, h });
export const BROKEN_URL = 'https://broken.invalid/this-picture-does-not-exist.png';

const CHOICE_KEYS = ['A', 'B', 'C', 'D'];

/** A choice question. `opts` can override anything. */
function choiceQ(id, sectionId, order, title, o = {}) {
  const labels = o.labels || ['Yes, do it', 'No, leave it as it is', 'Make it smaller', 'Explain this to me another way'];
  const explains = o.explains || ['Claude will change it.', 'Claude will not touch it.', 'Claude will try a smaller version.', 'Claude will explain it again in other words.'];
  return Object.assign({
    id, sectionId, kind: 'choice', order, createdAt: o.createdAt || iso(3 * DAY + order * MIN, o.now),
    title,
    story: o.story || ['On the home page there is a line under the main picture. Some people may not see it.'],
    why: o.why === undefined ? 'This helps me choose the right thing to build first.' : o.why,
    ownTip: o.ownTip === undefined ? 'Not happy with these? Type your own answer below.' : o.ownTip,
    choices: CHOICE_KEYS.map((k, i) => ({ key: k, label: labels[i], explain: explains[i] })),
    required: !!o.required, round: o.round || 1, parentId: o.parentId || null,
    who: 'owner', needs: '', previouslyNotSure: !!o.previouslyNotSure, topic: o.topic || '', oldId: o.oldId || null,
  }, o.over || {});
}

function readonlyQ(i, now) {
  const whos = ['kathy', 'rob', 'adviser', 'unknown'];
  const topics = ['Prices and menu', 'Hours and seasons', 'Events and tours', 'Photos and people', 'Contact and money', 'Rules and safety'];
  const id = 'k' + String(i).padStart(2, '0');
  const who = whos[i % whos.length], topic = topics[i % topics.length];
  return {
    id, sectionId: 'kathy', kind: 'readonly', order: i, createdAt: iso(2 * DAY + i * MIN, now),
    title: `What is the right answer for item ${i} about ${topic.toLowerCase()}?` + (i % 7 === 0 ? ' ' + 'This one has a longer title so that the list has to wrap it onto a second line nicely.' : ''),
    story: ['The site shows a line about this, but nobody has told Claude the real answer.', ...(i % 3 === 0 ? ['A second short paragraph that gives a bit more detail about the question.'] : [])],
    why: 'Visitors ask about this a lot, so the site should say the right thing.',
    ownTip: '', choices: [], required: false, round: 1, parentId: null,
    who, needs: i % 2 ? 'The exact wording to put on the site.' : 'A yes or no, and a number if it is yes.',
    previouslyNotSure: i % 5 === 0, topic, oldId: 'd' + String(i).padStart(2, '0'),
  };
}


/* ===================================================================== SPEC2: workers, tasks, her adds / edits / asks ===================================================================== */
export const IDS2 = {
  lead: 'claude', teams: ['team-maps', 'team-build', 'team-qs'],
  working: ['claude', 'team-maps', 'map-a', 'team-build', 'b-question', 'w-xss'], waiting: ['map-b'], resting: ['map-d', 'team-qs', 'q-cathy'], done: ['map-c', 'b-core', 'q-other', 'site-1'], stopped: ['b-sections'],
  withProgress: 'map-a',            // the only worker with a progress number (40)
  xssWorker: 'w-xss',
  mainIdeas: ['t-map', 't-winter', 't-photos', 't-label', 't-terminal', 't-qs', 't-gift'],
  waitingForYou: ['t-map-b', 't-label-2', 't-label'],       // tasks with waitingFor "owner" (see EXPECT2.tasks)
  pendingAdd: 'u-pend-1', pendingAddRoot: 'u-pend-2', adoptedAdd: 'u-seen-1',
  pendingEdit: 't-photos-2', seenEdit: 't-label-1', pausedEdit: 't-term-3', removedEdit: 't-term-3a',
  asks: { workerPending: 'ask-w-1', workerSeen: 'ask-w-2', workerAnswered: 'ask-w-3', taskAnswered: 'ask-t-1', taskPending: 'ask-t-2' },
  xssTask: 'u-pend-2',
};
export const EXPECT2 = {
  workers: { total: 15, working: 6, waiting: 1, resting: 3, done: 4, stopped: 1 },
  /* tasks: 42 stored documents (7 main ideas, 4 levels) + 2 adds she made that Claude has not adopted yet = 44 effective tasks.
     Effective states (her pending edits laid on top): paused = t-photos-3 and t-term-3 (she paused it); t-term-3a is "removed" (crossed out). */
  tasks: { stored: 42, effective: 44, working: 6, done: 11, waiting: 8, waitingForOwner: 3, paused: 2, pendingAdds: 2, roots: 8 },
  /* roots: the 7 main ideas + her pending "new big idea" u-pend-2 */
  pendingCount: { adds: 2, edits: 3, asks: 2 },     // not seen by Claude yet: u-pend-1, u-pend-2 | t-photos-2, t-term-3, t-term-3a | ask-w-1, ask-t-2
};

/** The crew: 15 workers in 4 levels (Claude -> 3 teams -> helpers), every state, one with a progress number, one with unsafe text. */
export function crew(now = Date.now()) {
  const W = {};
  const act = (list) => list.map(([m, t]) => ({ at: iso(m * MIN, now), text: t }));
  const w = (id, name, parentId, kind, icon, role, state, o = {}) => {
    W['workers/' + id] = Object.assign({
      id, name, parentId, kind, icon, role, state, now: '', waitingFor: 'none', startedAt: state === 'resting' ? null : iso(95 * MIN, now), updatedAt: iso(2 * MIN, now), finishedAt: state === 'done' || state === 'stopped' ? iso(20 * MIN, now) : null,
      activity: [], result: '', taskIds: [], brain: 'Sonnet', progress: null, order: Object.keys(W).length + 1,
    }, o);
  };
  w('claude', 'Claude', null, 'lead', '🧑‍🌾', 'The boss of the crew. Plans the work, checks it, and answers your questions.', 'working', { now: 'Checking the new answers from the owner', brain: 'Opus', taskIds: ['t-terminal'], startedAt: iso(300 * MIN, now), activity: act([[2, 'Read the owner\'s answers'], [9, 'Handed the map job to Map drawer A'], [31, 'Checked the Terminal pictures'], [64, 'Wrote the plan for the crew']]) });
  w('team-maps', 'Map drawers', 'claude', 'team', '🗺️', 'Draws the pictures of the farm map.', 'working', { now: 'Drawing four looks of the map', brain: '', taskIds: ['t-map'], order: 2 });
  w('map-a', 'Map drawer A: Storybook Hills', 'team-maps', 'helper', '🎨', 'Draws map look A with soft green hills.', 'working', { now: 'Colouring the hills and the barn', progress: 40, taskIds: ['t-map-a', 't-map-a1'], startedAt: iso(25 * MIN, now), activity: act([[2, 'Coloured the first hill'], [6, 'Drew the barn'], [11, 'Started the picture'], [15, 'Read the map notes'], [19, 'Got the farm places list'], [22, 'Looked at the old map'], [24, 'Opened the drawing tools'], [25, 'Joined the crew']]) });
  w('map-b', 'Map drawer B', 'team-maps', 'helper', '🖌️', 'Draws map look B with a sunset sky.', 'waiting', { now: 'Needs your pick of the hill colours', waitingFor: 'owner', taskIds: ['t-map-b'], brain: 'Opus', activity: act([[4, 'Asked which hill colours you like']]) });
  w('map-c', 'Map drawer C', 'team-maps', 'helper', '🏞️', 'Draws map look C, the simple one.', 'done', { result: 'Handed back a finished map with the five farm places and soft colours.', taskIds: ['t-map-c'], activity: act([[20, 'Handed back the finished map']]) });
  w('map-d', 'Map drawer D', 'team-maps', 'helper', '', 'Draws map look D when there is time.', 'resting', { taskIds: ['t-map-d'], updatedAt: iso(50 * MIN, now) });
  w('team-build', 'Terminal builders', 'claude', 'team', '🛠️', 'Builds the Terminal page you are looking at.', 'working', { now: 'Putting the Workers and Tasks parts together', brain: '', taskIds: ['t-terminal'], order: 7 });
  w('b-core', 'Core builder', 'team-build', 'helper', '⚙️', 'Makes the part of the page that talks to Claude.', 'done', { result: 'The page now remembers workers and tasks and can send her questions.', taskIds: ['t-term-1'], activity: act([[30, 'Finished the notebook code']]) });
  w('b-question', 'Question builder', 'team-build', 'helper', '❓', 'Makes the tab strip and the question pages.', 'working', { now: 'Adding the three tabs at the top', taskIds: ['t-term-2'], startedAt: iso(40 * MIN, now) });
  w('b-sections', 'Sections builder', 'team-build', 'helper', '📋', 'Makes the Tasks tree.', 'stopped', { result: 'Stopped early: the plan changed, so a new builder took over.', taskIds: ['t-term-3'], activity: act([[45, 'Stopped when the plan changed']]) });
  w('team-qs', 'Questions crew', 'claude', 'team', '💬', 'Writes the questions for you, Miss Cathy and Rob.', 'resting', { brain: '', taskIds: ['t-qs'], updatedAt: iso(70 * MIN, now), order: 12 });
  w('q-cathy', 'Question writer: Miss Cathy and Rob', 'team-qs', 'helper', '📝', 'Writes the pile of questions only Miss Cathy and Rob can answer.', 'resting', { taskIds: ['t-qs-1', 't-qs-2'] });
  w('q-other', 'Question writer: other questions', 'team-qs', 'helper', '📬', 'Writes the first regular questions.', 'done', { result: 'Wrote 9 questions about the home page and the visit page.', taskIds: ['t-qs-3'] });
  w('w-xss', 'Odd <img src=x onerror=alert(1)> crew', 'team-qs', 'helper', '🐝', 'A role with a very long word: ' + LONGWORD.slice(0, 120), 'working', { now: XSS + ' ' + LONGWORD.slice(0, 100), taskIds: [], activity: act([[1, XSS], [3, LONGWORD.slice(0, 90)]]) });
  w('site-1', 'Site checker', 'claude', 'helper', '🔍', 'Checks the real website pages for mistakes (reads only).', 'done', { result: 'Checked 25 pages. Nothing is broken.', taskIds: [] });
  return W;
}

/** The task tree: 7 main ideas, 3-4 levels deep, 41 tasks, every state, links to workers and to questions in the default seed(). */
export function taskTree(now = Date.now()) {
  const Tk = {};
  let n = 0;
  const t = (id, parentId, title, state, o = {}) => {
    n++;
    Tk['tasks/' + id] = Object.assign({
      id, parentId, title, plain: 'Plain words for ' + title + '.', state, waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: n, createdAt: iso(2 * DAY, now), updatedAt: iso((10 + n) * MIN, now), doneAt: state === 'done' ? iso((40 + n) * MIN, now) : null, createdBy: 'claude', seenAt: null,
    }, o);
  };
  t('t-map', null, 'Redraw the farm map', 'working', { plain: 'Claude is drawing four new looks of the farm map so you can pick the one you like.', workerIds: ['team-maps'], note: 'Three of four looks are on the way' });
  t('t-map-a', 't-map', 'Map look A: Storybook Hills', 'working', { workerIds: ['map-a'], note: 'Colouring the hills' });
  t('t-map-a1', 't-map-a', 'Colour the hills', 'working', { workerIds: ['map-a'] });
  t('t-map-a2', 't-map-a', 'Add the barn and the silo', 'todo');
  t('t-map-a3', 't-map-a', 'Draw the paths', 'done');
  t('t-map-b', 't-map', 'Map look B: Sunset sky', 'waiting', { waitingFor: 'owner', workerIds: ['map-b'], questionIds: ['c-normal'], plain: 'Needs your pick of the hill colours before it goes on.' });
  t('t-map-c', 't-map', 'Map look C: Simple', 'done', { workerIds: ['map-c'] });
  t('t-map-d', 't-map', 'Map look D: Plain', 'todo', { workerIds: ['map-d'] });
  t('t-winter', null, 'Winter tree game', 'done', { plain: 'A small game on the home page in winter: tap the tree and presents pop out.' });
  t('t-winter-1', 't-winter', 'Draw the tree', 'done'); t('t-winter-2', 't-winter', 'Make the presents pop', 'done'); t('t-winter-3', 't-winter', 'Check it on a phone', 'done');
  t('t-photos', null, 'Holiday photos on the home page', 'waiting', { waitingFor: 'cathy', plain: 'Show real holiday photos from the farm. Miss Cathy has the photos.' });
  t('t-photos-1', 't-photos', 'Get the photos from Miss Cathy', 'waiting', { waitingFor: 'cathy', questionIds: ['k01'] });
  t('t-photos-2', 't-photos', 'Pick the best three', 'todo'); t('t-photos-3', 't-photos', 'Make them small enough', 'paused');
  t('t-label', null, 'The "See the farm in" words', 'waiting', { waitingFor: 'owner', questionIds: ['v-map-1'] });
  t('t-label-1', 't-label', 'Make four bigger looks', 'done', { seenAt: iso(1 * MIN, now) }); t('t-label-2', 't-label', 'Pick one of the four looks', 'waiting', { waitingFor: 'owner', questionIds: ['v-map-1', 'c-normal'] });
  t('t-terminal', null, 'The Terminal itself', 'working', { workerIds: ['team-build', 'claude'], plain: 'This page: questions, workers and tasks in one place.' });
  t('t-term-1', 't-terminal', 'Teach the page about workers and tasks', 'done', { workerIds: ['b-core'] });
  t('t-term-2', 't-terminal', 'Add the tabs at the top', 'working', { workerIds: ['b-question'], note: 'Tab strip is in' });
  t('t-term-3', 't-terminal', 'Make the Tasks tree', 'todo', { workerIds: ['b-sections'] });
  t('t-term-3a', 't-term-3', 'Draw the branches', 'todo'); t('t-term-3b', 't-term-3', 'Make it work with the keyboard', 'todo'); t('t-term-3c', 't-term-3b', 'Arrow keys', 'todo'); t('t-term-3d', 't-term-3b', 'Enter to open', 'todo');
  t('t-qs', null, 'Questions for Miss Cathy and Rob', 'waiting', { waitingFor: 'rob', workerIds: ['team-qs'] });
  t('t-qs-1', 't-qs', 'Prices and menu questions', 'waiting', { waitingFor: 'cathy', workerIds: ['q-cathy'], questionIds: ['k01', 'k02'] });
  t('t-qs-2', 't-qs', 'Tour and event questions', 'waiting', { waitingFor: 'rob', workerIds: ['q-cathy'] }); t('t-qs-3', 't-qs', 'The first regular questions', 'done', { workerIds: ['q-other'] });
  t('t-gift', null, 'Gift page idea', 'todo', { createdBy: 'owner', seenAt: iso(1 * HOUR, now), createdAt: iso(3 * HOUR, now), plain: 'Her own idea, added earlier.' });
  t('t-gift-1', 't-gift', 'Say what the gift page needs', 'todo', { createdBy: 'owner', seenAt: iso(1 * HOUR, now), createdAt: iso(3 * HOUR, now) });
  // an extra deep branch (4 levels under a main idea) and a few more leaves so there are 41 tasks
  t('t-map-a1a', 't-map-a1', 'Pick the green for the near hills', 'done'); t('t-map-a1b', 't-map-a1', 'Pick the green for the far hills', 'working'); t('t-map-a1b1', 't-map-a1b', 'Mix three greens', 'todo');
  t('t-label-3', 't-label', 'Check the words on a big screen', 'todo'); t('t-label-4', 't-label', 'Check the words in other languages', 'todo');
  t('t-winter-4', 't-winter', 'Add sound (turned off at first)', 'done');
  t('t-photos-4', 't-photos', 'Write short words for each photo', 'todo');
  t('t-term-4', 't-terminal', 'Test it on a phone', 'todo');
  return Tk;
}

/** Her adds, edits and asks, and Claude's replies (some seen, some not). */
export function pendingParts(now = Date.now()) {
  const D = {};
  const put = (c, id, doc) => { D[c + '/' + id] = doc; };
  // adds
  put('taskAdds', 'u-pend-1', { id: 'u-pend-1', parentId: 't-map', title: 'Add a pond to the map', plain: 'A little pond near the barn, please.', createdAt: iso(3 * MIN, now) });
  put('taskAdds', 'u-pend-2', { id: 'u-pend-2', parentId: null, title: 'Odd idea ' + XSS + ' ' + LONGWORD.slice(0, 70), plain: XSS2 + ' ' + LONGWORD.slice(0, 100), createdAt: iso(2 * MIN, now) });
  put('taskAdds', 'u-seen-1', { id: 'u-seen-1', parentId: 't-gift', title: 'Ask about gift cards', plain: 'Can people buy gift cards?', createdAt: iso(50 * MIN, now) });
  D['tasks/u-seen-1'] = { id: 'u-seen-1', parentId: 't-gift', title: 'Ask about gift cards', plain: 'Can people buy gift cards?', state: 'todo', waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: 99, createdAt: iso(50 * MIN, now), updatedAt: iso(20 * MIN, now), doneAt: null, createdBy: 'owner', seenAt: iso(20 * MIN, now) };
  // edits (t-photos-2: pending; t-label-1: seen (tasks seenAt is 1 min ago, edit 30 min ago); t-term-3: paused pending; t-term-3a: removed pending)
  put('taskEdits', 't-photos-2', { id: 't-photos-2', title: 'Pick the best three photos', plain: 'Choose three that look cheerful.', updatedAt: iso(5 * MIN, now) });
  put('taskEdits', 't-label-1', { id: 't-label-1', title: 'Make four bigger looks (renamed)', updatedAt: iso(30 * MIN, now) });
  put('taskEdits', 't-term-3', { id: 't-term-3', paused: true, updatedAt: iso(4 * MIN, now) });
  put('taskEdits', 't-term-3a', { id: 't-term-3a', removed: true, updatedAt: iso(3 * MIN, now) });
  // asks and replies
  const ask = (id, kind, target, text, minAgo) => put('asks', id, { id, targetKind: kind, targetId: target, text, createdAt: iso(minAgo * MIN, now) });
  ask('ask-w-1', 'worker', 'map-a', 'How many hills are you drawing?', 1);
  ask('ask-w-2', 'worker', 'map-b', 'Why are you waiting for me?', 12);
  ask('ask-w-3', 'worker', 'claude', 'What is the crew doing right now?', 40);
  ask('ask-t-1', 'task', 't-map', 'When will the map be ready?', 45);
  ask('ask-t-2', 'task', 't-term-2', 'Will the tabs work with the keyboard?', 2);
  put('replies', 'ask-w-2', { id: 'ask-w-2', targetKind: 'worker', targetId: 'map-b', state: 'seen', text: '', from: 'Claude', at: iso(10 * MIN, now) });
  put('replies', 'ask-w-3', { id: 'ask-w-3', targetKind: 'worker', targetId: 'claude', state: 'answered', text: 'Six workers are busy. Two are drawing maps and three are building this page.', from: 'Claude', at: iso(35 * MIN, now) });
  put('replies', 'ask-t-1', { id: 'ask-t-1', targetKind: 'task', targetId: 't-map', state: 'answered', text: 'About an hour, if you pick the hill colours soon.', from: 'Map drawer A: Storybook Hills', at: iso(40 * MIN, now) });
  return D;
}

/** N more tasks in a tree 4 levels deep (for speed tests). Ids b-0, b-0-1, b-0-1-2 ... */
export function bigTasks(n, now = Date.now()) {
  const Tk = {};
  const states = ['todo', 'working', 'waiting', 'done', 'paused'];
  let made = 0, i = 0;
  while (made < n) {
    const root = 'b-' + (i++);
    Tk['tasks/' + root] = { id: root, parentId: null, title: 'Big idea number ' + i, plain: 'A big idea made for the speed test.', state: states[i % 5], waitingFor: states[i % 5] === 'waiting' ? 'owner' : 'none', workerIds: [], questionIds: [], note: '', order: made, createdAt: iso(DAY, now), updatedAt: iso(MIN * (i % 50), now), doneAt: null, createdBy: 'claude', seenAt: null };
    made++;
    for (let a = 0; a < 4 && made < n; a++) {
      const A = root + '-' + a;
      Tk['tasks/' + A] = { id: A, parentId: root, title: `Job ${i}.${a}`, plain: 'A job.', state: states[(i + a) % 5], waitingFor: states[(i + a) % 5] === 'waiting' ? 'cathy' : 'none', workerIds: [], questionIds: [], note: '', order: a, createdAt: iso(DAY, now), updatedAt: iso(MIN * a, now), doneAt: null, createdBy: 'claude', seenAt: null }; made++;
      for (let b = 0; b < 4 && made < n; b++) {
        const B = A + '-' + b;
        Tk['tasks/' + B] = { id: B, parentId: A, title: `Small job ${i}.${a}.${b}`, plain: 'A small job.', state: states[(i + a + b) % 5], waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: b, createdAt: iso(DAY, now), updatedAt: iso(MIN * b, now), doneAt: null, createdBy: 'claude', seenAt: null }; made++;
        for (let c = 0; c < 2 && made < n; c++) {
          const C = B + '-' + c;
          Tk['tasks/' + C] = { id: C, parentId: B, title: `Tiny job ${i}.${a}.${b}.${c}`, plain: 'A tiny job.', state: states[(i + a + b + c) % 5], waitingFor: 'none', workerIds: [], questionIds: [], note: '', order: c, createdAt: iso(DAY, now), updatedAt: iso(MIN * c, now), doneAt: null, createdBy: 'claude', seenAt: null }; made++;
        }
      }
    }
  }
  return Tk;
}

/* ---------- the big builder ---------- */
export function seed(opts = {}) {
  const now = opts.now == null ? Date.now() : opts.now;
  const count = opts.count == null ? 30 : opts.count;
  const D = {};   // 'collection/id' -> doc
  const put = (coll, id, doc) => { D[coll + '/' + id] = doc; return doc; };
  const sec = (id, title, order, o = {}) => put('sections', id, Object.assign({
    id, title, kind: 'builtin', order, size: 'small', hold: false, readOnly: false, blurb: '', archived: false, createdAt: iso(10 * DAY, now), createdBy: 'claude',
  }, o));

  /* sections */
  sec('look', 'Look and feel', 1, { blurb: 'Pictures Claude made. Pick the version you like best.' });
  sec('other', 'Other questions', 2, { blurb: 'Questions that do not fit anywhere else.' });
  sec('later', 'Ideas for later', 3, { blurb: 'Parked ideas. No hurry.' });
  sec('kathy', 'Questions for Miss Cathy and Rob', 4, { readOnly: true, blurb: 'You can read these. Miss Cathy and Rob will answer them.' });

  /* heartbeat */
  if (!opts.noHeart) put('meta', 'heartbeat', { at: iso(opts.stale ? 45 * MIN : 2 * MIN, now), note: opts.stale ? 'Waiting for the next check' : 'Working on the map pictures' });
  if (opts.empty) return D;

  /* ---- look: visual questions ---- */
  const q = (doc) => put('questions', doc.id, doc);
  q({
    id: 'v-map-1', sectionId: 'look', kind: 'visual', order: 1, createdAt: iso(1 * DAY, now),
    title: 'Which map picture do you like best for the home page?',
    story: ['Claude made four versions of the map. Click a picture to see it big.'],
    why: 'The map is the first thing visitors look at, so it should feel right.',
    ownTip: 'Want something different? Say what you want in the box.',
    choices: [],
    versions: [
      { key: 'A', label: 'Wide and calm', caption: 'Soft green fields, wide view.', images: [img(1600, 900, '#9bc78d', 'A', 'Wide map with green fields')] },
      { key: 'B', label: 'Tall for phones', caption: 'Made for a phone screen, tall and narrow.', images: [img(600, 1200, '#8db7d6', 'B', 'Tall map for phones')] },
      { key: 'C', label: 'Warm sunset', caption: 'Orange evening colours. Two pictures: wide and small.', images: [img(1200, 800, '#e9a86b', 'C1', 'Sunset map'), img(400, 400, '#d98a45', 'C2', 'Sunset map close up')] },
      { key: 'D', label: 'Plain and simple', caption: 'This picture could not be loaded (test).', images: [{ url: BROKEN_URL, alt: 'Plain map (broken on purpose)', w: 1000, h: 600 }] },
    ],
    beforeImages: [
      { url: svg(1280, 720, '#cfc6b4', 'Now 1'), alt: 'The map now', w: 1280, h: 720, caption: 'How the map looks now' },
      { url: svg(640, 640, '#bdb29a', 'Now 2'), alt: 'The map now, square crop', w: 640, h: 640, caption: 'Now on a phone' },
    ],
    required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null,
  });
  q({
    id: 'v-hero-1', sectionId: 'look', kind: 'visual', order: 2, createdAt: iso(2 * DAY, now),
    title: 'Which top picture do you like for the home page?',
    story: ['Two versions of the big picture at the very top.'], why: 'It is the first thing people see.', ownTip: '', choices: [],
    versions: [
      { key: 'A', label: 'Barn at sunrise', caption: 'Warm light.', images: [img(1200, 600, '#f0c987', 'A')] },
      { key: 'B', label: 'Field of flowers', caption: 'Bright and busy.', images: [img(1200, 600, '#e58fb0', 'B')] },
    ],
    beforeImages: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null,
  });
  q({
    id: 'v-menu-1', sectionId: 'look', kind: 'visual', order: 3, createdAt: iso(2 * DAY, now),
    title: 'Which menu picture do you like?',
    story: ['Three ideas for how the menu page looks.'], why: 'People read the menu on their phones.', ownTip: '', choices: [],
    versions: [
      { key: 'A', label: 'Big photos', caption: 'Photo first.', images: [img(900, 700, '#c9d6a3', 'A')] },
      { key: 'B', label: 'Just words', caption: 'Easy to read.', images: [img(900, 700, '#e2d5ef', 'B')] },
      { key: 'C', label: 'Mixed', caption: 'A bit of both.', images: [img(900, 700, '#bfe0e0', 'C')] },
    ],
    beforeImages: [{ url: svg(900, 700, '#cfc6b4', 'Now'), alt: 'Menu now', w: 900, h: 700, caption: 'Now' }],
    required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null,
  });

  /* ---- other: choice questions of different length ---- */
  q(choiceQ('c-short', 'other', 1, 'Show the farm phone number on every page?', {
    story: ['Short and simple.'], why: 'Easy to find.', ownTip: '',
    labels: ['Yes', 'No', 'Only on one page', 'Explain this to me another way'], explains: ['Show it.', 'Hide it.', 'Show it in one place.', 'Claude will explain.'],
  }));
  q(choiceQ('c-normal', 'other', 2, 'Where should the "Book a visit" button go on the home page?', {
    story: ['Right now the button is at the bottom of the home page. Many people never scroll that far.', 'Claude can move it up, so it is the first thing people see after the main picture.'],
    why: 'More people will find the button and book a visit.',
    ownTip: 'Have another place in mind? Type it below.',
    labels: ['At the very top, in the menu bar', 'Under the main picture', 'Stay at the bottom', 'Explain this to me another way'],
    explains: ['The button is always visible, even when you scroll.', 'The button shows right after the main picture.', 'Nothing changes.', 'Claude will explain it with a small drawing.'],
    required: false,
  }));
  const longPara = (n) => `Paragraph ${n}. When a visitor opens the site on a small phone, the menu, the opening times, the picture of the barn, and the button to book a visit all fight for the same small space, and today the order is the one the first builder chose, not the one that fits how people really look at a page. Claude wants to be sure to move things the way you would want it.`;
  q(choiceQ('c-long', 'other', 3, 'How should the whole visit page be set out for people on small phones who only have a minute?', {
    story: [1, 2, 3, 4, 5].map(longPara),
    why: 'This is the most visited page on the site and a small change here helps almost every visitor, so Claude would like to get it right the first time and not move things again later.',
    ownTip: 'Have your own idea? Type it below, in your own words. It is fine to write a lot.',
    labels: [
      'Put the opening times first, then the picture of the barn, then the button to book a visit, then the long text about the farm and what to bring with you',
      'Put the picture of the barn first, then a short line about the farm, then the button to book a visit, then the opening times at the very bottom of the page',
      'Keep everything where it is today and only make the letters bigger and the buttons easier to press with a thumb on a small phone',
      'Explain this to me another way, with a small drawing of each of the ways to set out the page, so I can see them side by side',
    ],
    explains: [
      'People who just want to know when you are open see that first. The button to book moves down a bit, so a few people may not find it as quickly as today.',
      'The page feels warm and friendly at first sight. People who only want the hours must scroll down to find them, which some people will not do.',
      'Nothing moves. This is the safest choice, but the page stays as crowded as it is today and some people may still not find the button.',
      'Claude will draw the three ways and put them next to each other so you can compare them. Then you can come back and pick one.',
    ],
  }));
  q(choiceQ('c-xss', 'other', 4, 'Test: ' + XSS + ' what do you think?', {
    story: [XSS, 'Second paragraph with ' + XSS2 + ' and a very long word: ' + LONGWORD],
    why: XSS + ' ' + LONGWORD, ownTip: XSS,
    labels: [XSS, 'B ' + LONGWORD, XSS2, 'Explain this to me another way'], explains: [XSS, LONGWORD, XSS2, XSS],
    over: { topic: XSS },
  }));
  q(choiceQ('c-unseen', 'other', 5, 'Should the news box say "News" or "What is new"?', { labels: ['News', 'What is new', 'Latest', 'Explain this to me another way'] }));
  q(choiceQ('c-done', 'other', 6, 'Make the opening hours bigger?', { labels: ['Yes, bigger', 'Keep it', 'A little bigger', 'Explain this to me another way'] }));
  q(choiceQ('c-followup', 'other', 7, 'What should the gift page be called?', { labels: ['Gifts', 'Shop', 'Farm shop', 'Explain this to me another way'] }));
  q(choiceQ('c-followup-2', 'other', 8, 'You wrote your own name. Should it also show in the menu?', { parentId: 'c-followup', round: 2, labels: ['Yes', 'No', 'Only on big screens', 'Explain this to me another way'] }));
  q(choiceQ('c-held', 'other', 9, 'Add a picture of the pond?', { labels: ['Yes', 'No', 'Later', 'Explain this to me another way'], previouslyNotSure: true }));
  q(choiceQ('c-help', 'other', 10, 'Use two columns on the visit page?', { labels: ['Yes', 'No', 'Only on wide screens', 'Explain this to me another way'] }));
  for (let i = 0; i < (opts.extra || 0); i++) q(choiceQ('x-' + (i + 1), 'other', 20 + i, `Extra question number ${i + 1}: which color is better?`, { labels: ['Green', 'Brown', 'Red', 'Explain this to me another way'] }));

  /* ---- later ---- */
  q(choiceQ('l-1', 'later', 1, 'Add a newsletter sign-up some day?', { topic: 'Newsletter', labels: ['Yes, later', 'No', 'Not sure', 'Explain this to me another way'] }));
  q(choiceQ('l-2', 'later', 2, 'Sell gift cards online some day?', { topic: 'Shop', labels: ['Yes, later', 'No', 'Not sure', 'Explain this to me another way'] }));
  q(choiceQ('l-3', 'later', 3, 'Add a blog with farm stories?', { topic: 'Stories', labels: ['Yes, later', 'No', 'Not sure', 'Explain this to me another way'] }));

  /* ---- kathy: readonly pile ---- */
  for (let i = 1; i <= count; i++) q(readonlyQ(i, now));

  /* ---- big custom section: account-features ---- */
  sec('account-features', 'Account features', 10, { kind: 'custom', size: 'big', createdBy: 'owner', createdAt: iso(3 * DAY, now), blurb: '' });
  const af = (n, title, req, o = {}) => q(choiceQ('af-' + n, 'account-features', n, title, Object.assign({
    required: req, labels: ['Yes, add it', 'No, skip it', 'Make it simple', 'Explain this to me another way'],
    explains: ['Claude will add it.', 'Claude will not add it.', 'Claude will add a simple version.', 'Claude will explain it again.'], topic: 'Accounts',
  }, o)));
  af(1, 'Should visitors be able to make an account?', true);
  af(2, 'What should an account be used for first?', true);
  af(3, 'Should visitors log in with their email?', true);
  af(4, 'Should I send a "welcome" email after sign-up?', true);
  af(5, 'Should the account page show past visits?', false);
  af(6, 'Should there be a "favourites" list?', false);
  put('plans', 'account-features', { sectionId: 'account-features', version: 1, summary: 'Claude will add a simple sign-up and a page where people see their visits.', steps: ['Make a sign-up form with just a name and an email.', 'Make a page that shows each person\'s visits.', 'Send a short welcome email.', 'Test it on a phone and on a laptop.'], needs: ['Your OK on the steps above.', 'The name to use in the welcome email.'], at: iso(30 * MIN, now) });
  put('ideas', 'idea-1', { id: 'idea-1', sectionId: 'account-features', text: 'I want people to be able to keep a list of the visits they booked.', createdAt: iso(2 * DAY, now), sentAt: iso(2 * DAY - MIN, now) });
  put('ideas', 'idea-2', { id: 'idea-2', sectionId: 'account-features', text: 'Maybe a way to say thank you after a visit.', createdAt: iso(1 * DAY, now), sentAt: iso(1 * DAY - MIN, now) });
  put('ideaStatus', 'idea-1', { id: 'idea-1', state: 'questionsReady', at: iso(2 * DAY - 10 * MIN, now), note: 'Claude wrote questions for this.' });
  put('ideaStatus', 'idea-2', { id: 'idea-2', state: 'read', at: iso(1 * DAY - 5 * MIN, now), note: '' });
  if (opts.draftIdea) put('ideas', 'idea-draft', { id: 'idea-draft', sectionId: 'account-features', text: 'A draft idea that is not sent yet.', createdAt: iso(5 * MIN, now), sentAt: null });

  /* ---- small custom section ---- */
  sec('gift-shop', 'Gift shop', 11, { kind: 'custom', size: 'small', createdBy: 'owner', createdAt: iso(2 * DAY, now) });
  q(choiceQ('gs-1', 'gift-shop', 1, 'Should the gift shop show prices?', { labels: ['Yes', 'No', 'Only on request', 'Explain this to me another way'] }));
  q(choiceQ('gs-2', 'gift-shop', 2, 'Should gift shop items have photos?', { labels: ['Yes', 'No', 'Some of them', 'Explain this to me another way'] }));

  /* ---- answers (various states) ---- */
  const ans = (qid, a, ago) => put('answers', qid, Object.assign({ id: qid, status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: '', answeredAt: iso(ago, now), round: 1 }, a));
  ans('c-unseen', { key: 'A', label: 'News' }, 20 * MIN);
  ans('c-done', { key: 'A', label: 'Yes, bigger' }, 1 * DAY);
  ans('c-followup', { key: 'own', ownText: 'Call it Farm Gifts and More.', label: 'Farm Gifts and More', note: 'I like short names.' }, 1 * DAY);
  ans('c-held', { status: 'answered', key: 'unsure', label: "I'm not sure yet" }, 1 * DAY);
  ans('c-help', { key: 'help', label: 'Explain another way' }, 3 * HOUR);
  ans('v-hero-1', { key: 'B', label: 'Field of flowers' }, 1 * DAY);
  ans('v-menu-1', { key: 'change', changeText: 'Make the photos smaller and the words bigger.', label: 'I do not like any of them' }, 2 * HOUR);
  ans('l-3', { key: 'B', label: 'No' }, 2 * DAY);
  ans('af-1', { key: 'A', label: 'Yes, add it' }, 2 * DAY);
  ans('af-2', { key: 'own', ownText: 'First, to see the visits they booked.', label: 'First, to see the visits they booked.' }, 1 * DAY);
  ans('af-6', { key: 'unsure', label: "I'm not sure yet" }, 1 * DAY);
  ans('gs-1', { key: 'A', label: 'Yes' }, 1 * HOUR);

  /* ---- statuses (every state) ---- */
  const st = (qid, s) => put('status', qid, Object.assign({ id: qid, state: 'seen', seenAt: iso(10 * MIN, now), note: '', doneNote: '', doneImages: [], followupId: null, at: iso(10 * MIN, now) }, s));
  st('v-hero-1', { state: 'seen', seenAt: iso(23 * HOUR, now), at: iso(23 * HOUR, now) });
  st('v-menu-1', { state: 'working', seenAt: iso(1 * HOUR, now), note: 'Making version B bigger', at: iso(5 * MIN, now) });
  st('c-help', { state: 'seen', seenAt: iso(2 * HOUR, now), at: iso(2 * HOUR, now) });
  st('c-done', { state: 'done', seenAt: iso(20 * HOUR, now), doneNote: 'The opening hours are now bigger on every page.', doneImages: [{ url: svg(800, 450, '#b7e0b0', 'Result'), alt: 'The result', w: 800, h: 450 }, { url: svg(400, 800, '#a9d0ea', 'Phone'), alt: 'The result on a phone', w: 400, h: 800 }], at: iso(6 * HOUR, now) });
  st('c-followup', { state: 'followup', seenAt: iso(20 * HOUR, now), followupId: 'c-followup-2', note: 'Claude has one more question.', at: iso(19 * HOUR, now) });
  st('c-held', { state: 'held', seenAt: iso(20 * HOUR, now), note: 'Paused', at: iso(20 * HOUR, now) });
  st('af-1', { state: 'seen', seenAt: iso(1 * DAY, now), at: iso(1 * DAY, now) });
  st('af-2', { state: 'working', seenAt: iso(5 * HOUR, now), note: 'Thinking about what the sign-up needs', at: iso(2 * HOUR, now) });
  st('gs-1', { state: 'seen', seenAt: iso(30 * 1000, now), at: iso(30 * 1000, now) });
  // (c-unseen has NO status doc: "answered, Claude has not looked yet")

  /* ---- F3: the built-in section "Downloads and skills" and four sample questions with a safety check (TEST DATA ONLY; the live seed has none) ---- */
  if (opts.downloads) {
    sec('downloads', 'Downloads and skills', 5, { blurb: 'Free tools and skills that could save time. Claude checks each one for safety first.' });
    const checkedAt = iso(3 * HOUR, now);
    q(choiceQ('d-sample-safety', 'downloads', 1, 'Add the free "Tidy Photos" tool to speed up the picture work?', {
      story: ['Tidy Photos is a free program that makes big photos smaller, so the pages load faster.', 'Claude would run it on your photos only. It would not touch anything else.'],
      why: 'Faster pages help visitors on slow phone connections.',
      labels: ['Yes, add it', 'No, skip it', 'Only try it on three photos', 'Explain this to me another way'],
      explains: ['Claude will set it up.', 'Claude will not use it.', 'Claude will test it on three photos first.', 'Claude will explain it again.'],
      over: {
        canRecheck: true,
        safety: {
          verdict: 'mixed', checkedAt, round: 2,
          summary: 'The tool is open and well known. One part sends a small usage note to its makers, which I could not turn off.',
          whatItDoes: 'Makes photos smaller without changing how they look.',
          whereItRuns: 'your_computer',
          checks: [
            { label: 'The code is public and can be read', result: 'ok', note: 'Anyone can read it on GitHub.' },
            { label: 'Many people use it and trust it', result: 'warn', note: 'About 40 people reported a slow-down after an update.' },
            { label: 'It does not ask for passwords', result: 'fail', note: 'It asks to sign in to a cloud account. Skip that part.' },
            { label: 'Last update was recent', result: 'unknown', note: 'The page does not say when it was last changed.' },
            { label: 'No known security problems listed', result: 'ok', note: '' },
          ],
          limits: ['I could not run the program to watch what it does.', 'I could not read the paid add-ons.', 'I did not check the makers of the cloud account.'],
          sources: [
            { label: 'The tool on GitHub', url: 'https://github.com/example/tidy-photos' },
            { label: 'Its security page', url: 'https://www.example.org/security/tidy' },
            { label: 'A plain web address', url: 'http://example.com/old' },
            { label: 'Bad address', url: 'javascript:alert(1)' },
          ],
        },
      },
    }));
    q(choiceQ('d-sample-clean', 'downloads', 2, 'Use the "Alt Text Helper" skill for picture descriptions?', {
      story: ['A skill is a small set of instructions for Claude. This one helps write short picture descriptions.'],
      why: 'Descriptions help people who use screen readers.',
      labels: ['Yes, use it', 'No', 'Try it once first', 'Explain this to me another way'],
      over: {
        canRecheck: true,
        safety: {
          verdict: 'looks_safe', checkedAt: iso(20 * 60 * 1000, now), round: 1,
          summary: 'It is only text instructions. It cannot install anything.',
          whatItDoes: 'Helps Claude write short descriptions for pictures.', whereItRuns: 'claude_only',
          checks: [{ label: 'It is only text', result: 'ok', note: '' }, { label: 'It does not use the internet', result: 'ok', note: '' }],
          limits: [], sources: [{ label: 'The skill page', url: 'https://example.com/skills/alt-text' }],
        },
      },
    }));
    q(choiceQ('d-sample-notsafe', 'downloads', 3, 'Try the "Speed Booster" program from a download site?', {
      story: ['A program from a website that promises to make every page faster.'], why: 'Maybe a quick win.',
      labels: ['Yes', 'No', 'Not sure', 'Explain this to me another way'],
      over: {
        safety: {
          verdict: 'not_safe', checkedAt: iso(2 * DAY, now), round: 1,
          summary: 'Several reports say it installs extra programs. Please do not download it.',
          whatItDoes: 'Says it speeds up websites.', whereItRuns: 'your_computer',
          checks: [{ label: 'Makers can be found', result: 'fail', note: 'No real name or address.' }],
          limits: ['I could not open the installer safely.'], sources: [],
        },
      },
    }));
    q(choiceQ('d-sample-unchecked', 'downloads', 4, 'Look at the "Map Maker" add-on?', {
      story: ['Claude has not looked at this one yet.'], why: 'It might help with the map.',
      labels: ['Yes, look at it', 'No', 'Later', 'Explain this to me another way'],
      over: { canRecheck: true, safety: { verdict: 'unchecked' } },
    }));
  }
  /* ---- F1: questions she sent to the Miss Cathy and Rob list ---- */
  if (opts.cathy) {
    const CL = 'This is a question for Miss Cathy and Rob';
    ans('c-short', { key: 'cathy', label: CL, note: 'Cathy knows the number.' }, 30 * MIN);
    ans('c-normal', { key: 'cathy', label: CL }, 10 * MIN);
    ans('gs-2', { key: 'cathy', label: CL }, 1 * DAY);
    st('c-short', { state: 'seen', seenAt: iso(5 * MIN, now), at: iso(5 * MIN, now) });
    st('gs-2', { state: 'done', seenAt: iso(20 * HOUR, now), doneNote: 'Moved to the Miss Cathy and Rob list', at: iso(19 * HOUR, now) });
  }

  if (opts.parts) {
    if (!opts.noCrew) Object.assign(D, crew(now));
    if (!opts.noTasks) { Object.assign(D, taskTree(now)); Object.assign(D, pendingParts(now)); }
    else { for (const k of Object.keys(D)) if (/^(taskAdds|taskEdits|asks|replies)\//.test(k)) delete D[k]; }
  }
  if (opts.bigTasks) Object.assign(D, bigTasks(opts.bigTasks, now));
  return D;
}

/** Splits { 'coll/id': doc } into { coll: { id: doc } }. */
export function split(docs) {
  const out = { sections: {}, questions: {}, answers: {}, status: {}, ideas: {}, ideaStatus: {}, plans: {}, planReplies: {}, meta: {} };
  for (const [path, doc] of Object.entries(docs)) {
    const i = path.indexOf('/');
    const c = path.slice(0, i), id = path.slice(i + 1);
    (out[c] = out[c] || {})[id] = doc;
  }
  return out;
}

/** Deep copy (the tests change fixtures). */
export const clone = (o) => JSON.parse(JSON.stringify(o));

/** Ids of questions in a section that she can answer and has not answered (what the tab-title count shows). */
export function waitingCount(docs) {
  const secs = split(docs);
  return Object.values(secs.questions).filter((qq) => qq.kind !== 'readonly' && !secs.answers[qq.id] && !(secs.sections[qq.sectionId] || {}).readOnly && !(secs.sections[qq.sectionId] || {}).archived).length;
}

export default seed;
