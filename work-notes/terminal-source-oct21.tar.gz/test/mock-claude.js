/* mock-claude.js  (owner: core)  -  an in-memory fake of window.claude for tests. NOT part of the page.
 *
 * Load it BEFORE the page runs (Playwright: see test/mockfix.mjs  injectMock(page, seed, options)).
 *
 * Before the page:   window.__MOCK_SEED__   = { "questions/q1": {...}, "sections/look": {...} }      (or an array of docs with _collection + id)
 *                    window.__MOCK_CONFIG__ = { dbNull:true, comments:'writers_only'|{can,...}|null, silent:['plans'], writeDelay:0, persist:false }
 * While the page runs, window.__mock is the remote control:
 *   __mock.db.put(path, data)        Claude writes a whole document (fires snapshots)       alias: set
 *   __mock.db.merge(path, patch)     Claude merges fields into a document
 *   __mock.db.remove(path)           Claude deletes a document                              alias: delete
 *   __mock.db.get(path)              the document as it is now (plain copy) or undefined
 *   __mock.db.list(collection)       [{id, ...data}] sorted by id
 *   __mock.db.writes                 everything the PAGE wrote and the notebook accepted: [{op:'set'|'update'|'delete', path, data, at}]
 *   __mock.writes                    the very same array (short name)
 *   __mock.db.attempts               every write call the page made, also the refused ones (failed:true)
 *   __mock.db.overlaps               paths where the page started a write while another to the same document was still running (must stay empty)
 *   __mock.db.failNext(n, code)      the next n write calls are refused with {code} (default 'unavailable')
 *   __mock.failWrites = true         every write is refused until set back to false (code in __mock.failCode, default 'unavailable')
 *   __mock.db.writeDelay = ms        each write takes this long (default 0: finishes in a microtask)
 *   __mock.db.setNull(true|false)    use('db') resolves null from now on (the page in "no notebook" mode)
 *   __mock.db.silent = ['plans']     those collections never deliver a snapshot (until release(name))
 *   __mock.db.release(name)          let a silent collection deliver
 *   __mock.db.failSubscribe(name, code)  the next onSnapshot on that collection ends at once with an error   (config: failSubscribe:{plans:'invalid_argument'})
 *   __mock.db.revoke()               every listener gets {code:'revoked'}, later writes are refused
 *   __mock.db.subs                   [{path, kind, active}]   every onSnapshot the page made;  __mock.db.listenerCount() = active ones
 *   __mock.db.reset(seed)            wipe everything and load a new seed
 *   __mock.comments.can              'available' (default) | 'writers_only' | 'no_session' | 'off'   what canSendToClaude() answers
 *   __mock.comments.failNext         a code such as 'rate_limited': the next sendToClaude is refused with it
 *   __mock.pings                     everything sent with sendToClaude: [{target, at}]
 *   __mock.user.owner / .edit / .write / .id   what the user capability answers
 * The mock holds any collection: workers, tasks, replies, taskAdds, taskEdits, asks work like the others (seed them with partsSeed() from mockfix.mjs; Claude's side: __mock.db.put('replies/<askId>', {...}))
 */
(function () {
  'use strict';
  if (window.__mock) return;

  var CFG = window.__MOCK_CONFIG__ || {};
  var SEED = window.__MOCK_SEED__ || {};

  /* ---------------------------------------------------------------- helpers */
  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  function freeze(o) {
    if (o && typeof o === 'object' && !Object.isFrozen(o)) {
      Object.freeze(o);
      Object.keys(o).forEach(function (k) { freeze(o[k]); });
    }
    return o;
  }
  function eq(a, b) {
    if (a === b) return true;
    if (typeof a !== typeof b || a === null || b === null || typeof a !== 'object') return false;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    for (var i = 0; i < ka.length; i++) if (!Object.prototype.hasOwnProperty.call(b, ka[i]) || !eq(a[ka[i]], b[ka[i]])) return false;
    return true;
  }
  function merge(base, patch) {
    var out = Object.assign({}, base);
    Object.keys(patch).forEach(function (k) { out[k] = (isObj(patch[k]) && isObj(out[k])) ? merge(out[k], patch[k]) : patch[k]; });
    return out;
  }
  function dbError(code, message) { return { code: code, message: message || ('mock: ' + code) }; }
  var SEG = /^[A-Za-z0-9_\-.~:@+]+$/;
  function checkPath(path, wantDoc) {
    if (typeof path !== 'string' || !path) throw new TypeError('mock db: empty path');
    var parts = path.split('/');
    if (parts.length > 16 || path.length > 1000) throw new TypeError('mock db: path too long: ' + path);
    parts.forEach(function (s) { if (!SEG.test(s) || s === '.' || s === '..') throw new TypeError('mock db: bad segment "' + s + '" in ' + path); });
    if (wantDoc && parts.length % 2 !== 0) throw new TypeError('mock db: a document path needs an even number of segments: ' + path);
    if (!wantDoc && parts.length % 2 !== 1) throw new TypeError('mock db: a collection path needs an odd number of segments: ' + path);
    return parts;
  }
  var later = function (fn) { Promise.resolve().then(fn); };
  function delay(ms) { return ms > 0 ? new Promise(function (r) { setTimeout(r, ms); }) : Promise.resolve(); }

  /* ---------------------------------------------------------------- the data */
  var docs = {};            // path -> { data (frozen), version, snap }
  var listeners = [];       // active + dead listeners
  var writes = [], attempts = [], overlaps = [], subs = [];
  var inflight = {};
  var failN = 0, failCode = 'unavailable';
  var revoked = false;
  var nullDb = !!CFG.dbNull || CFG.db === null;
  var pendingSubFail = Object.assign({}, CFG.failSubscribe || {});   // collection -> error code for its next onSnapshot
  var M = { version: 1 };

  var META = Object.freeze({ fromCache: false, hasPendingWrites: false });

  function snapOf(path) {
    var d = docs[path];
    if (!d) return freeze({ id: path.split('/').pop(), exists: false, data: function () { return undefined; }, metadata: META });
    if (!d.snap) {
      var data = d.data;
      d.snap = freeze({ id: path.split('/').pop(), exists: true, data: function () { return data; }, metadata: META });
    }
    return d.snap;
  }

  function persist() {
    if (!CFG.persist) return;
    try {
      var o = {};
      Object.keys(docs).forEach(function (p) { o[p] = docs[p].data; });
      window.sessionStorage.setItem('__mock_db', JSON.stringify(o));
    } catch (e) { /* no storage */ }
  }

  function applyDoc(path, data) {
    var prev = docs[path];
    if (data === null) {
      if (!prev) return false;
      delete docs[path];
    } else {
      var c = freeze(clone(data));
      if (prev && eq(prev.data, c)) return false;
      docs[path] = { data: c, version: (prev ? prev.version : 0) + 1 };
    }
    persist();
    notify();
    return true;
  }

  function load(seed) {
    docs = {};
    var list = [];
    if (Array.isArray(seed)) {
      seed.forEach(function (d) { if (d && d._collection && d.id) { var c = clone(d); delete c._collection; list.push([d._collection + '/' + d.id, c]); } });
    } else if (isObj(seed)) {
      Object.keys(seed).forEach(function (p) { list.push([p, seed[p]]); });
    }
    list.forEach(function (e) { docs[e[0]] = { data: freeze(clone(e[1])), version: 1 }; });
  }
  load(SEED);
  if (CFG.persist) {
    try {
      var saved = window.sessionStorage.getItem('__mock_db');
      if (saved) load(JSON.parse(saved));
    } catch (e) { /* none */ }
  }

  /* ---------------------------------------------------------------- queries */
  function inCollection(path, coll) {
    if (path.indexOf(coll + '/') !== 0) return false;
    return path.slice(coll.length + 1).indexOf('/') < 0;
  }
  function cmp(a, b) { return a < b ? -1 : a > b ? 1 : 0; }
  function passes(data, f) {
    var v = data[f.field], t = f.value;
    switch (f.op) {
      case '==': return eq(v, t);
      case '!=': return !eq(v, t);
      case '<': return v !== undefined && v < t;
      case '<=': return v !== undefined && v <= t;
      case '>': return v !== undefined && v > t;
      case '>=': return v !== undefined && v >= t;
      case 'in': return Array.isArray(t) && t.some(function (x) { return eq(x, v); });
      case 'not-in': return Array.isArray(t) && !t.some(function (x) { return eq(x, v); });
      case 'array-contains': return Array.isArray(v) && v.some(function (x) { return eq(x, t); });
    }
    return false;
  }
  function run(q) {
    var out = Object.keys(docs).filter(function (p) { return inCollection(p, q.path); }).filter(function (p) {
      return q.filters.every(function (f) { return passes(docs[p].data, f); });
    });
    out.sort(function (a, b) {
      if (q.order) {
        var va = docs[a].data[q.order.field], vb = docs[b].data[q.order.field];
        var ma = va === undefined, mb = vb === undefined;
        if (ma !== mb) return ma ? 1 : -1;
        var c = cmp(va, vb);
        if (c) return q.order.dir === 'desc' ? -c : c;
      }
      return cmp(a, b);
    });
    if (q.lim) out = out.slice(0, q.lim);
    return out;
  }
  function querySnap(q, last) {
    var paths = run(q);
    var snaps = paths.map(snapOf);
    var prev = last ? last.paths : [];
    var changes = [];
    paths.forEach(function (p, i) {
      var j = prev.indexOf(p);
      if (j < 0) changes.push({ type: 'added', doc: snaps[i], oldIndex: -1, newIndex: i });
      else if (last.snaps[j] !== snaps[i]) changes.push({ type: 'modified', doc: snaps[i], oldIndex: j, newIndex: i });
    });
    prev.forEach(function (p, j) { if (paths.indexOf(p) < 0) changes.push({ type: 'removed', doc: last.snaps[j], oldIndex: j, newIndex: -1 }); });
    var snap = freeze({ docs: snaps, size: snaps.length, empty: snaps.length === 0, docChanges: function () { return changes; }, metadata: META });
    return { snap: snap, paths: paths, snaps: snaps, changes: changes };
  }
  function sameSet(a, b) {
    if (!a) return false;
    if (a.paths.length !== b.paths.length) return false;
    for (var i = 0; i < a.paths.length; i++) if (a.paths[i] !== b.paths[i] || a.snaps[i] !== b.snaps[i]) return false;
    return true;
  }

  function silent(path) {
    var s = M.db && M.db.silent;
    return !!(s && s.length && s.indexOf(path.split('/')[0]) >= 0);
  }

  function deliverTo(l, force, always) {
    if (!l.active || l.muted) return;
    if (silent(l.path) && !force) { l.muted = true; return; }
    var res;
    if (l.kind === 'doc') {
      var s = snapOf(l.path);
      if (!always && l.last && l.last.snap === s) return;
      res = { snap: s };
    } else {
      res = querySnap(l.query, l.last);
      if (!always && sameSet(l.last, res)) return;
    }
    l.last = res;
    var fn = l.next;
    later(function () { if (l.active) { try { fn(res.snap); } catch (e) { setTimeout(function () { throw e; }); } } });
  }
  function notify() { listeners.slice().forEach(function (l) { deliverTo(l); }); }

  function listen(kind, path, query, next, error) {
    var l = { kind: kind, path: path, query: query, next: next, error: error, active: true, muted: false, last: null };
    var rec = { path: path, kind: kind, active: true };
    subs.push(rec);
    var coll = kind === 'collection' ? path : path.split('/').slice(0, -1).join('/');
    if (pendingSubFail[coll]) {
      var code = pendingSubFail[coll]; delete pendingSubFail[coll];
      l.active = false; rec.active = false;
      later(function () { if (typeof error === 'function') error(dbError(code)); });
      return function () {};
    }
    if (revoked) { l.active = false; rec.active = false; later(function () { if (typeof error === 'function') error(dbError('revoked')); }); return function () {}; }
    listeners.push(l);
    l.rec = rec;
    if (CFG.cacheFirst && kind === 'collection') {
      // like the real notebook can: first a snapshot marked fromCache with only the first pages, then the complete one
      later(function () {
        if (!l.active || l.muted || silent(l.path)) { deliverTo(l); return; }
        var res = querySnap(query, null), k = Math.floor(res.paths.length / 2);
        var paths = res.paths.slice(0, k), snaps = res.snaps.slice(0, k);
        var snap = freeze({ docs: snaps, size: k, empty: k === 0, metadata: { fromCache: true, hasPendingWrites: false },
          docChanges: function () { return paths.map(function (p, i) { return { type: 'added', doc: snaps[i], oldIndex: -1, newIndex: i }; }); } });
        l.last = { snap: snap, paths: paths, snaps: snaps };
        try { next(snap); } catch (e) { setTimeout(function () { throw e; }); }
        setTimeout(function () { deliverTo(l, false, true); }, CFG.cacheFirst > 1 ? CFG.cacheFirst : 40);
      });
      return function () { l.active = false; rec.active = false; var i = listeners.indexOf(l); if (i >= 0) listeners.splice(i, 1); };
    }
    later(function () { deliverTo(l); });
    return function () { l.active = false; rec.active = false; var i = listeners.indexOf(l); if (i >= 0) listeners.splice(i, 1); };
  }

  /* ---------------------------------------------------------------- writes by the page */
  function pageWrite(op, path, data) {
    var rec = { op: op, path: path, data: data === undefined ? undefined : clone(data), at: Date.now() };
    attempts.push(rec);
    if (inflight[path]) overlaps.push({ path: path, op: op, at: Date.now() });
    inflight[path] = (inflight[path] || 0) + 1;
    return delay(M.db.writeDelay).then(function () {
      inflight[path]--;
      if (revoked) { rec.failed = true; throw dbError('revoked'); }
      if (M.failWrites) { rec.failed = true; throw dbError(M.failCode || 'unavailable'); }
      if (failN > 0) { failN--; rec.failed = true; throw dbError(failCode); }
      if (op !== 'delete') {
        if (!isObj(data)) { rec.failed = true; throw dbError('invalid_argument', 'mock: a document must be a plain object'); }
        if (JSON.stringify(data).length > 256 * 1024) { rec.failed = true; throw dbError('invalid_argument', 'mock: document over 256 KiB'); }
      }
      if (op === 'update' && !docs[path]) { rec.failed = true; throw dbError('invalid_argument', 'mock: update needs an existing document'); }
      if (op === 'set') applyDoc(path, data);
      else if (op === 'update') applyDoc(path, merge(docs[path].data, clone(data)));
      else applyDoc(path, null);
      writes.push({ op: op, path: path, data: rec.data, at: rec.at });
    });
  }

  /* ---------------------------------------------------------------- the db namespace the page sees */
  function makeQuery(path, st) {
    var q = {
      where: function (field, op, value) { return makeQuery(path, { filters: st.filters.concat([{ field: field, op: op, value: value }]), order: st.order, lim: st.lim }); },
      orderBy: function (field, dir) { return makeQuery(path, { filters: st.filters, order: { field: field, dir: dir === 'desc' ? 'desc' : 'asc' }, lim: st.lim }); },
      limit: function (n) { return makeQuery(path, { filters: st.filters, order: st.order, lim: n }); },
      get: function () { return Promise.resolve(querySnap({ path: path, filters: st.filters, order: st.order, lim: st.lim }, null).snap); },
      onSnapshot: function (next, error) { return listen('collection', path, { path: path, filters: st.filters, order: st.order, lim: st.lim }, next, error); },
      path: path
    };
    return q;
  }
  function collectionRef(path) {
    checkPath(path, false);
    var q = makeQuery(path, { filters: [], order: null, lim: null });
    q.doc = function (id) { return docRef(path + '/' + (id || ('auto' + Math.random().toString(36).slice(2, 10)))); };
    q.add = function (data) { var r = q.doc(); return r.set(data).then(function () { return r; }); };
    return q;
  }
  function docRef(path) {
    checkPath(path, true);
    return {
      id: path.split('/').pop(),
      path: path,
      get: function () { return Promise.resolve(snapOf(path)); },
      set: function (data) { return pageWrite('set', path, data); },
      update: function (data) { return pageWrite('update', path, data); },
      delete: function () { return pageWrite('delete', path); },
      acquire: function (o) { return Promise.resolve({ acquired: true, holder: o && o.holder, version: 1, expiresAt: new Date(Date.now() + 30000).toISOString() }); },
      onSnapshot: function (next, error) { return listen('doc', path, null, next, error); },
      collection: function (sub) { return collectionRef(path + '/' + sub); }
    };
  }
  var dbNs = Object.freeze({ doc: docRef, collection: collectionRef });

  /* ---------------------------------------------------------------- the remote control */
  M.db = {
    put: function (path, data) { checkPath(path, true); return applyDoc(path, data); },
    merge: function (path, patch) { checkPath(path, true); return applyDoc(path, merge(docs[path] ? docs[path].data : {}, clone(patch))); },
    remove: function (path) { checkPath(path, true); return applyDoc(path, null); },
    get: function (path) { return docs[path] ? clone(docs[path].data) : undefined; },
    list: function (coll) {
      return Object.keys(docs).filter(function (p) { return inCollection(p, coll); }).sort().map(function (p) { return clone(docs[p].data); });
    },
    writes: writes,
    attempts: attempts,
    overlaps: overlaps,
    subs: subs,
    listenerCount: function () { return listeners.filter(function (l) { return l.active; }).length; },
    failNext: function (n, code) { failN = n == null ? 1 : n; failCode = code || 'unavailable'; },
    writeDelay: Number(CFG.writeDelay) || 0,
    setNull: function (on) { nullDb = on === undefined ? true : !!on; },
    silent: Array.isArray(CFG.silent) ? CFG.silent.slice() : [],
    release: function (name) {
      M.db.silent = M.db.silent.filter(function (n) { return n !== name; });
      listeners.forEach(function (l) { if (l.muted && !silent(l.path)) { l.muted = false; deliverTo(l, true); } });
    },
    failSubscribe: function (name, code) { pendingSubFail[name] = code || 'unavailable'; },
    revoke: function () {
      revoked = true;
      listeners.slice().forEach(function (l) { l.active = false; if (l.rec) l.rec.active = false; var fn = l.error; if (typeof fn === 'function') later(function () { fn(dbError('revoked')); }); });
      listeners.length = 0;
    },
    reset: function (seed) { load(seed || {}); listeners.forEach(function (l) { l.last = null; }); notify(); persist(); },
    clearWrites: function () { writes.length = 0; attempts.length = 0; overlaps.length = 0; }
  };
  M.db.set = M.db.put;
  M.db.delete = M.db.remove;
  M.writes = writes;
  M.failWrites = false;
  M.failCode = 'unavailable';

  /* ---------------------------------------------------------------- comments */
  var commentsCfg = CFG.comments;
  M.pings = [];
  M.comments = {
    can: typeof commentsCfg === 'string' ? commentsCfg : (isObj(commentsCfg) && commentsCfg.can) || 'available',
    failNext: null,
    created: [],
    replied: []
  };
  var commentsNs = {
    canSendToClaude: function () { return Promise.resolve(M.comments.can); },
    anchorFor: function (el) {
      if (!el || !el.isConnected) return Promise.reject({ code: 'invalid', message: 'mock: element is not on the page' });
      return Promise.resolve({ path: 'x', x: 0, y: 0 });
    },
    sendToClaude: function (target) {
      if (M.comments.can !== 'available') return Promise.reject({ code: 'claude_unavailable', message: 'mock: cannot send to Claude (' + M.comments.can + ')' });
      if (M.comments.failNext) { var c = M.comments.failNext; M.comments.failNext = null; return Promise.reject({ code: c, message: 'mock: ' + c }); }
      if (!target || typeof target.text !== 'string' || !target.text || (!target.anchor && !target.threadId)) return Promise.reject({ code: 'invalid', message: 'mock: bad target' });
      M.pings.push({ target: clone(target), at: Date.now() });
      return Promise.resolve({ threadId: target.threadId || 't1', commentId: 'c' + M.pings.length });
    },
    create: function (o) { M.comments.created.push(clone(o)); return Promise.resolve({ threadId: 't1', commentId: 'c' + M.comments.created.length }); },
    reply: function (threadId, text) { M.comments.replied.push({ threadId: threadId, text: text }); return Promise.resolve({ commentId: 'r' + M.comments.replied.length }); }
  };

  /* ---------------------------------------------------------------- user, permissions */
  M.user = { owner: true, edit: true, write: true, id: 'u_test', name: 'Test Owner' };
  var userNs = {
    isOwner: function () { return Promise.resolve(!!M.user.owner); },
    canEdit: function () { return Promise.resolve(!!M.user.edit); },
    can: function (what) { return Promise.resolve(what === 'data.write' ? (M.user.write === null ? null : !!M.user.write) : false); },
    id: function () { return Promise.resolve(M.user.id); },
    me: function () { return Promise.resolve({ id: M.user.id, name: M.user.name, avatarUrl: '', color: '#888888', email: null, isOwner: !!M.user.owner, canEdit: !!M.user.edit }); }
  };
  var permNs = {
    state: function (name) {
      var all = { db: nullDb ? 'unavailable' : 'granted', comments: commentsCfg === null ? 'unavailable' : 'granted', user: 'granted' };
      return Promise.resolve(name === undefined ? all : (all[name] || 'unavailable'));
    },
    request: function () { return Promise.resolve({}); }
  };

  /* ---------------------------------------------------------------- window.claude */
  M.useLog = [];
  window.claude = {
    use: function (name) {
      M.useLog.push(name);
      if (CFG.useThrow) throw new Error('mock: use() exploded');
      if (CFG.useReject || (name === 'db' && CFG.dbReject)) return Promise.reject(dbError('not_granted', 'mock: ' + name + ' refused'));
      if (name === 'db' && CFG.dbHang) return new Promise(function () { /* never answers */ });
      var ns = null;
      if (name === 'db') ns = nullDb ? null : dbNs;
      else if (name === 'comments') ns = commentsCfg === null ? null : commentsNs;
      else if (name === 'user') ns = CFG.user === null ? null : userNs;
      else if (name === 'permissions') ns = permNs;
      return CFG.useDelay ? delay(CFG.useDelay).then(function () { return ns; }) : Promise.resolve(ns);
    }
  };
  window.__mock = M;
})();
