/* Screenshots of the Tasks part at 700x800, 1366x768, 1920x1080 (light and dark): node T/test/tasks-shots.mjs  ->  T/shots/tasks/*.png */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { startServer, launch } from './lib.mjs';
import { injectMock } from './mockfix.mjs';
import { seed } from './fixtures.mjs';
import { tasksDocs } from './tasks.fixture.mjs';
const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.join(T, 'shots', 'tasks'); fs.mkdirSync(OUT, { recursive: true });
execFileSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, 'dist-sections2', 'index.html')], { cwd: T, stdio: 'pipe' });
let site; for (let p = 9540; p < 9599 && !site; p++) { try { site = await startServer({ root: T, port: p }); } catch (e) { /* next */ } }
const browser = await launch();
async function open(w, h, o = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage(); page.errs = [];
  page.on('pageerror', (e) => page.errs.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') page.errs.push(m.text()); });
  await page.addInitScript((how) => { try { if (how) localStorage.setItem('qt.tasks.howto', 'closed'); localStorage.setItem('qt.route', JSON.stringify({ view: 'tasks', params: {} })); } catch (e) {} }, !!o.closed);
  await injectMock(page, { ...seed(), ...tasksDocs() }, {});
  await page.goto(site.url + 'dist-sections2/index.html');
  await page.waitForSelector('.tk-tree', { timeout: 20000});
  await page.waitForTimeout(500);
  return page;
}
const shot = (p, n, full) => p.screenshot({ path: path.join(OUT, n + '.png'), fullPage: !!full });
const sizes = [[700, 800], [1366, 768], [1920, 1080]];
for (const [w, h] of sizes) {
  let p = await open(w, h);
  await shot(p, `a-${w}x${h}-first-visit`);
  await p.context().close();
  p = await open(w, h, { closed: true });
  await shot(p, `b-${w}x${h}`);
  await p.locator('li[data-id="map-words"] > .tk-card').click(); await p.waitForTimeout(400);
  await shot(p, `c-${w}x${h}-detail`);
  await p.getByRole('button', { name: 'Ask about this task' }).click(); await p.waitForTimeout(300);
  await shot(p, `d-${w}x${h}-ask`);
  await p.locator('li[data-id="map"] > .tk-card').click(); await p.waitForTimeout(400);
  await shot(p, `e-${w}x${h}-asks-and-answers`);
  await p.getByRole('button', { name: '+ Add a task' }).click(); await p.waitForTimeout(300);
  await shot(p, `f-${w}x${h}-add`);
  console.log(w, 'errors:', p.errs.slice(0, 3).join(' | ') || 'none');
  await p.context().close();
}
for (const [w, h] of [[700, 800], [1366, 768]]) {
  const p = await open(w, h, { scheme: 'dark', closed: true });
  await shot(p, `g-${w}x${h}-dark`);
  await p.locator('li[data-id="win-msg"] > .tk-card').click(); await p.waitForTimeout(300);
  await shot(p, `h-${w}x${h}-dark-detail`);
  await p.context().close();
}
const p = await open(400, 800, { closed: true });
await shot(p, 'i-400x800');
await p.context().close();
await browser.close(); await site.close();
