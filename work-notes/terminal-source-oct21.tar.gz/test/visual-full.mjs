/* Integration check of the pictures inside the whole page (real layout + question + status, mock notebook).
   NODE_PATH=/opt/node22/lib/node_modules node T/test/visual-full.mjs   (builds T/dist-visual/full/index.html first) */
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { startServer, launch, ok, until, finish } from './lib.mjs';
import { newPage, waitReady } from './mockfix.mjs';
import { seed } from './fixtures.mjs';
import { T } from './harness.mjs';

const r = spawnSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, 'dist-visual/full/index.html'), '--doctype'], { encoding: 'utf8' });
if (r.status !== 0) { console.log(r.stderr || r.stdout); process.exit(1); }
const site = await startServer({ root: T, port: 9420 });
const browser = await launch();
const errs = [];
const shot = (page, n) => page.screenshot({ path: path.join(T, 'shots', 'visual-full-' + n + '.png'), animations: 'disabled' });
for (const [w, h] of [[700, 800], [1366, 768], [1920, 1080], [400, 800]]) {
  const page = await newPage(browser, { seed: seed(), viewport: { width: w, height: h }, errs });
  await page.goto(site.url + 'dist-visual/full/index.html');
  ok(`${w}: page ready`, await waitReady(page));
  await page.evaluate(() => window.QT.route.go('question', { id: 'v-map-1' }));
  await page.waitForSelector('.qtv-card');
  await until(page, () => [...document.querySelectorAll('.qtv-pic')].every((p) => p.classList.contains('is-ok') || p.classList.contains('is-bad')), null, 15000);
  const m = await page.evaluate(() => {
    const g = document.querySelector('.qtv-grid').getBoundingClientRect(), ans = document.querySelector('.qv-answer');
    const last = [...document.querySelectorAll('.qv-answer button, .qv-answer textarea')].pop();
    return { gridH: Math.round(g.height), gridW: Math.round(g.width), cards: document.querySelectorAll('.qtv-card').length, viewBottom: Math.round(document.getElementById('qt-view').getBoundingClientRect().bottom + scrollY), picsH: Math.round(document.querySelector('.qtv').getBoundingClientRect().height), sideScroll: document.documentElement.scrollWidth - innerWidth, pageH: document.documentElement.scrollHeight, today: !!document.querySelector('.qtv-today-toggle') };
  });
  console.log(w + 'x' + h, JSON.stringify(m));
  ok(`${w}: four cards, no sideways scroll`, m.cards === 4 && m.sideScroll <= 0);
  await shot(page, `${w}x${h}`);
  await page.click('.qtv-card >> nth=0');
  await page.waitForSelector('.qtl');
  ok(`${w}: viewer opens from the real page`, await until(page, () => document.querySelector('.qtl')?.getAttribute('data-state') !== 'loading', null, 10000));
  await shot(page, `${w}x${h}-viewer`);
  if (w === 700) {
    const before = await page.evaluate(() => JSON.stringify(window.QT.store.answers['v-map-1'] || null));
    await page.keyboard.press('b'); await page.keyboard.press('D');
    await page.waitForTimeout(300);
    ok('700: letters pressed in the viewer do not answer the question behind it', (await page.evaluate(() => JSON.stringify(window.QT.store.answers['v-map-1'] || null))) === before && (await page.locator('.qtl').count()) === 1);
    // Claude changes something behind the viewer (a status note): the question is drawn again, the viewer must stay and focus must come back to a card
    await page.evaluate(() => window.__mock.db.put('status/v-map-1', { id: 'v-map-1', state: 'working', note: 'Making version B bigger', at: new Date().toISOString() }));
    await page.waitForTimeout(500);
    ok('700: a note from Claude behind the viewer does not close it', (await page.locator('.qtl').count()) === 1);
  }
  await page.keyboard.press('Escape');
  ok(`${w}: Esc closes and focus is back on the card`, await page.evaluate(() => !document.querySelector('.qtl') && document.activeElement.matches('.qtv-card[data-vkey="A"]')));
  await page.context().close();
}
await finish({ browser, site, errs });
