import sys
def lum(h):
    h=h.lstrip('#'); r,g,b=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    f=lambda c: c/12.92 if c<=0.03928 else ((c+0.055)/1.055)**2.4
    return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b)
def cr(a,b):
    la,lb=lum(a),lum(b)
    if la<lb: la,lb=lb,la
    return (la+0.05)/(lb+0.05)
L=dict(bg='#fbf6ea',card='#ffffff',ink='#2f1d10',soft='#5c4838',line='#e0d3b8',ls='#8a7458',accent='#b8232f',aink='#ffffff',asoft='#fbe4e4',good='#17663a',gbg='#e1f2e6',warn='#7a4300',wbg='#fdebc8',info='#1d4f91',ibg='#e4eefa',panel='#f3ebd9',focus='#1a4fd6')
D=dict(bg='#1b1410',card='#261c15',ink='#f6ecdc',soft='#d3c0a6',line='#4f3e2f',ls='#a38a6c',accent='#ff8a93',aink='#2b0f12',asoft='#4a2328',good='#9fe0b5',gbg='#1e3d29',warn='#ffd596',wbg='#4d3410',info='#a9ccff',ibg='#1f3350',panel='#2f2319',focus='#8fb4ff')
pairs=[('ink','bg',4.5),('ink','card',4.5),('ink','panel',4.5),('soft','bg',4.5),('soft','card',4.5),('soft','panel',4.5),('aink','accent',4.5),('accent','bg',4.5),('accent','card',4.5),('accent','asoft',4.5),('ink','asoft',4.5),('good','gbg',4.5),('good','bg',4.5),('good','card',4.5),('warn','wbg',4.5),('warn','bg',4.5),('warn','card',4.5),('info','ibg',4.5),('info','bg',4.5),('info','card',4.5),('ink','gbg',4.5),('ink','wbg',4.5),('ink','ibg',4.5),('soft','gbg',4.5),('soft','wbg',4.5),('soft','ibg',4.5),('ls','bg',3),('ls','card',3),('focus','bg',3),('focus','card',3),('focus','accent',3)]
bad=0
for name,t in (('light',L),('dark',D)):
    for a,b,m in pairs:
        r=cr(t[a],t[b]); flag='' if r>=m else '  <-- LOW'
        if flag: bad+=1
        if flag or '-v' in sys.argv: print(f'{name:5} {a:7} on {b:7} {r:5.2f} (need {m}){flag}')
print('low pairs:',bad)
