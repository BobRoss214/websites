/* Real page: offline, write error toast, stale heartbeat, dropdown menu, tab order.  Port 9204. */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const { ok, info } = H;
const h = await H.start(9204);
{
  const p = await H.open(h, { docs: {}, w: 700, h: 800, mock: { dbNull: true } });
  await H.settle(p, 300); await H.shot(p, 'layout-real-offline-700x800');
  ok('offline: banner visible', await p.locator('#qt-offline').isVisible());
  ok('offline: Offline label', (await p.locator('.live').innerText()).trim() === 'Not connected');
  info('offline view text: ' + (await H.viewText(p)).slice(0, 160));
  await p.context().close();
}
{
  const p = await H.open(h, { docs: seed({ stale: true }), w: 700, h: 800 });
  await H.go(p, 'question', { id: 'c-normal' }); await H.settle(p, 300); await H.shot(p, 'layout-real-stale-700x800');
  info('heartbeat text: ' + (await p.locator('.hb').innerText()) + ' | stale=' + (await p.locator('.hb').evaluate((e) => e.classList.contains('stale'))));
  await p.setViewportSize({ width: 1366, height: 768 }); await H.settle(p, 200); await H.shot(p, 'layout-real-stale-1366x768');
  info('heartbeat text at 1366: ' + (await p.locator('.hb').innerText()));
  // write error toast
  await p.evaluate(() => { window.__mock.failWrites = true; });
  const clicked = await H.clickText(p, /^Pick|^A\b|Option|First/i, { within: '#qt-view' });
  info('clicked an answer button: ' + clicked);
  await H.settle(p, 1500);
  info('toast text: ' + (await p.locator('.toasts .toast').allInnerTexts()).join(' | '));
  await H.shot(p, 'layout-real-writeerror-1366x768');
  await p.context().close();
}
{
  const p = await H.open(h, { docs: seed(), w: 700, h: 800 });
  await p.click('.menu-btn'); await H.settle(p, 100); await H.shot(p, 'layout-real-menu-700x800');
  const labels = await p.locator('#qt-menu .mi').allInnerTexts();
  info('menu items: ' + labels.map((s) => s.replace(/\s+/g, ' ')).join(' / '));
  await p.keyboard.press('Tab'); await p.keyboard.press('Tab');
  info('active after 2 tabs: ' + (await p.evaluate(() => document.activeElement.textContent.trim().replace(/\s+/g, ' ').slice(0, 30))));
  await p.context().close();
}
await H.stop(h);
