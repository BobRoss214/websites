/* Tests for the Workers part (QT.views.workers).   NODE_PATH=/opt/node22/lib/node_modules node T/test/workers.visual.test.mjs      port 9402
 * Builds T/dist-visual2/index.html (core + 51-workers.js + test/workers-stub.js, all css) and loads it with the REAL core and the mock notebook, seeded from test/workers.fixture.mjs.
 * (The stub only mounts the view; it fills QT.store itself and stubs QT.write.ask only when the core has none.)
 * Screenshots: T/shots/workers/wk-*.png  (look at them!)  AXE_PATH=/tmp/claude-0/axe-core/axe.min.js turns the axe check on. */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { startServer, launch, ok, info, finish, until, axeSource } from './lib.mjs';
import { newPage, waitReady } from './mockfix.mjs';
import { fixture } from './workers.fixture.mjs';
import { T } from './harness.mjs';

const r = spawnSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, 'dist-visual2/index.html'), '--only', '51-workers.js', '--extra', path.join(T, 'test/workers-stub.js'), '--doctype'], { encoding: 'utf8' });
if (r.status !== 0) { console.log(r.stderr || r.stdout); process.exit(1); }
fs.mkdirSync(path.join(T, 'shots/workers'), { recursive: true });
const site = await startServer({ root: T, port: 9402 });
const browser = await launch();
const errs = [];
const AXE = process.env.AXE_PATH && fs.existsSync(process.env.AXE_PATH) ? fs.readFileSync(process.env.AXE_PATH, 'utf8') : axeSource();

const toSeed = (fix) => { const o = {}; for (const c of Object.keys(fix)) for (const id of Object.keys(fix[c])) o[c + '/' + id] = fix[c][id]; return o; };
async function open({ w = 700, h = 800, scheme = 'light', q = '', fix, opts, motion, viaStub } = {}) {
  const f = fix === undefined ? fixture() : fix;
  const page = await newPage(browser, { seed: viaStub ? {} : toSeed(f), viewport: { width: w, height: h }, colorScheme: scheme, errs, options: opts || {}, init: `window.__WK__ = ${JSON.stringify(viaStub ? f : {})};` });
  page.setDefaultTimeout(60000);
  if (motion) await page.emulateMedia({ reducedMotion: motion });
  await page.goto(site.url + 'dist-visual2/index.html' + q);
  await waitReady(page);
  await page.waitForFunction(() => window.__wkMounted, null, { timeout: 10000 });
  await page.waitForSelector('.wk-in');
  await page.waitForTimeout(300);
  return page;
}
const shot = (page, name) => page.screenshot({ path: path.join(T, 'shots/workers', 'wk-' + name + '.png'), animations: 'disabled' });
const text = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.textContent.trim().replace(/\s+/g, ' ') : null; }, sel);
const count = (page, sel) => page.locator(sel).count();
const card = (id) => `.wk-card[data-wid="${id}"]`;
const noSide = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
const closeHelp = async (page) => { if (await count(page, '[data-fid="help-close"]')) { await page.click('[data-fid="help-close"]'); await page.waitForTimeout(100); } };

try {
  /* ============ 1. the picture of the crew ============ */
  {
    const page = await open();
    ok('the crew came from the notebook (19 workers)', await page.evaluate(() => Object.keys(QT.store.workers || {}).length === 19));
    ok('title and one friendly line', (await text(page, '.wk-title')) === '🚜 The crew' || /The crew/.test(await text(page, '.wk-title')));
    ok('the "how to read this" card is open the first time', (await count(page, '.wk-help')) === 1 && /farm crew/.test(await text(page, '.wk-help')));
    ok('counters count EVERY worker (Claude and the teams too): 8 working, 2 waiting, 3 resting, 5 finished, 1 stopped = 19', (await page.locator('.wk-count').allTextContents()).map((s) => s.replace(/\s+/g, ' ').trim()).join(',') === '8 working,2 waiting,3 resting,5 finished,1 stopped', (await page.locator('.wk-count').allTextContents()).join(','));
    ok('one lead card, 4 team cards', (await count(page, '.wk-card.is-lead')) === 1 && (await count(page, '.wk-card.is-team')) === 4);
    ok('finished helpers are folded away (9 helper cards shown, "Finished (5)" at the bottom)', (await count(page, '.wk-card.is-helper')) === 9 && /Finished \(5\)/.test(await text(page, '.wk-fin')));
    ok('the crew is a tree: helpers sit inside their team', await page.evaluate(() => { const t = document.querySelector('.wk-card[data-wid="team-map"]').closest('li'); return !!t.querySelector('.wk-card[data-wid="map-a"]') && !t.querySelector('.wk-card[data-wid="winter-a"]'); }));
    ok('state chips have WORDS, not only colours', await page.evaluate(() => [...document.querySelectorAll('.wk-card .wk-chip')].every((c) => c.textContent.trim().length > 3)));
    ok('"Waiting for you" is a red chip, "Waiting for Claude" an amber one', await page.evaluate(() => { const a = document.querySelector('.wk-card[data-wid="map-d"] .wk-chip'), b = document.querySelector('.wk-card[data-wid="build-tasks"] .wk-chip'); return /Waiting for you/.test(a.textContent) && a.classList.contains('accent') && /Waiting for Claude/.test(b.textContent) && b.classList.contains('warn'); }));
    ok('"Right now" only for working and waiting workers', await page.evaluate(() => [...document.querySelectorAll('.wk-card.is-helper')].every((c) => { const st = c.getAttribute('data-state'), has = !!c.querySelector('.wk-now'); return (st === 'working' || st === 'waiting') ? has : !has; })));
    ok('a progress bar only where progress is a number (map-a 60%, nobody else)', (await count(page, '.wk-bar')) === 1 && (await page.getAttribute(`${card('map-a')} .wk-bar`, 'aria-valuenow')) === '60');
    ok('times: "Started 48 min ago · last update 2 min ago"', /Started 48 min ago/.test(await text(page, `${card('map-a')} .wk-times`)) && /last update 2 min ago/.test(await text(page, `${card('map-a')} .wk-times`)));
    ok('strength label: standard / extra strong', /Strength: standard/.test(await text(page, `${card('map-a')} .wk-line`)) && /Strength: extra strong/.test(await text(page, `${card('winter-a')} .wk-line`)));
    ok('task chips open the task (QT.route.go tasks {focus})', await (async () => {
      await page.evaluate(() => { window.__go = []; const g = QT.route.go; QT.route.go = function (v, p) { window.__go.push([v, p]); }; window.__goOrig = g; });
      await page.click(`${card('map-a')} .wk-task >> nth=0`);
      return JSON.stringify(await page.evaluate(() => window.__go)) === '[["tasks",{"focus":"t-map-hills"}]]';
    })());
    ok('the badge is a round face: icon, or initials when there is no emoji', (await text(page, `${card('map-a')} .wk-face`)) === '🏰');
    ok('no sideways scroll at 700', await noSide(page));
    await closeHelp(page);
    await shot(page, '700-first-screen');
    const lead = await page.evaluate(() => document.querySelector('.wk-card.is-lead').getBoundingClientRect().bottom);
    ok('with the help card closed, Claude\'s card and the first team are on the first screen (700x800)', lead < 560 && (await page.evaluate(() => document.querySelector('.wk-card.is-team').getBoundingClientRect().top < 800)), 'lead bottom ' + Math.round(lead));
    await page.context().close();
  }

  /* ============ 2. the help card is remembered ============ */
  {
    const page = await open();
    await page.click('[data-fid="help-close"]');
    ok('"Got it" closes the card and leaves a small "How to read this" button', (await count(page, '.wk-help')) === 0 && (await count(page, '[data-fid="help"]')) === 1);
    await page.reload(); await page.waitForSelector('.wk-in');
    ok('...and it stays closed after a reload', (await count(page, '.wk-help')) === 0);
    await page.click('[data-fid="help"]');
    ok('the small button opens it again', (await count(page, '.wk-help')) === 1);
    await page.context().close();
  }

  /* ============ 3. counters filter, finished toggle, folds ============ */
  {
    const page = await open();
    await closeHelp(page);
    await page.click('[data-fid="flt-waiting"]');
    ok('tap "2 waiting": only the two waiting helpers (+ lead and their teams)', (await count(page, '.wk-card.is-helper')) === 2 && (await page.getAttribute('[data-fid="flt-waiting"]', 'aria-pressed')) === 'true');
    await shot(page, '700-filter-waiting');
    await page.click('[data-fid="flt-waiting"]');
    ok('tap again: everybody is back', (await count(page, '.wk-card.is-helper')) === 9);
    await page.click('[data-fid="flt-done"]');
    ok('tap "5 finished": the 5 finished helpers (no fold)', (await count(page, '.wk-card.is-helper')) === 5 && (await count(page, '.wk-fin')) === 0);
    await page.click('[data-fid="flt-done"]');
    await page.click('label.wk-showfin');
    ok('"Show finished" brings the 5 finished helpers into their teams', (await count(page, '.wk-card.is-helper')) === 14 && (await count(page, '.wk-fin')) === 0 && (await page.isChecked('[data-fid="showfin"]')));
    await shot(page, '700-with-finished');
    await page.reload(); await page.waitForSelector('.wk-in');
    ok('...and the choice is remembered', (await count(page, '.wk-card.is-helper')) === 14);
    await page.click('label.wk-showfin');
    // finished list
    await page.click('[data-fid="fin"]');
    ok('"Finished (5)" opens a list of cards with what they handed back', (await count(page, '.wk-fin .wk-card')) === 5 && /handed back/.test(await text(page, '.wk-fin')));
    ok('each finished card says which team it came from', /Part of /.test(await text(page, '.wk-fin .wk-from')));
    await shot(page, '700-finished-list');
    // folds
    await page.click('[data-fid="fold-team-map"]');
    ok('fold a team: its helpers are hidden and cannot be tabbed to', (await page.getAttribute('[data-fid="fold-team-map"]', 'aria-expanded')) === 'false' && (await page.evaluate(() => document.querySelector('.wk-card[data-wid="map-a"]').closest('.wk-fold-wrap').inert === true)));
    await page.reload(); await page.waitForSelector('.wk-in');
    ok('...the fold is remembered', (await page.getAttribute('[data-fid="fold-team-map"]', 'aria-expanded')) === 'false');
    await page.focus('[data-fid="fold-team-map"]'); await page.keyboard.press('Enter');
    ok('keyboard: Enter opens it again', (await page.getAttribute('[data-fid="fold-team-map"]', 'aria-expanded')) === 'true' && (await page.evaluate(() => document.querySelector('.wk-card[data-wid="map-a"]').closest('.wk-fold-wrap').inert === false)));
    await page.click('[data-fid="fold-claude"]');
    ok('the lead folds the whole crew', (await page.evaluate(() => document.querySelector('.wk-card.is-lead').closest('li').querySelector(':scope > .wk-fold-wrap').inert === true)));
    await page.context().close();
  }

  /* ============ 4. asking a worker ============ */
  {
    const page = await open();
    await closeHelp(page);
    ok('every card has an "Ask this worker" button', (await count(page, '[data-fid^="ask-"]')) === 14);
    ok('map-a: the answered question opens by itself (first time)', (await page.getAttribute('[data-fid="qs-map-a"]', 'aria-expanded')) === 'true' && /It uses your photos of the red barn/.test(await text(page, `${card('map-a')} .wk-them`)));
    ok('...with "Answer from <name>" and the other question as "Sent · waiting for Claude to see it"', /Answer from Map drawer A/.test(await text(page, `${card('map-a')} .wk-them`)) && /Sent · waiting for Claude to see it/.test(await text(page, `${card('map-a')} .wk-thread`)));
    ok('winter-a: a "seen" question shows "Claude saw it ✓"', (await page.getAttribute('[data-fid="qs-winter-a"]', 'aria-expanded')) === 'false');
    await page.click('[data-fid="qs-winter-a"]');
    ok('...when opened', /Claude saw it ✓/.test(await text(page, `${card('winter-a')} .wk-thread`)));
    await page.click('[data-fid="ask-map-c"]');
    ok('Ask opens a text box with the focus in it, Send is off while it is empty', (await page.evaluate(() => document.activeElement.matches('[data-fid="ta-map-c"]'))) && (await page.isDisabled('[data-fid="send-map-c"]')));
    ok('it says the question goes to Claude first', /goes to Claude first/.test(await text(page, `${card('map-c')} .wk-form`)));
    await page.fill('[data-fid="ta-map-c"]', 'How many pumpkin rows will there be?');
    ok('typing turns Send on and counts the letters', (await page.isEnabled('[data-fid="send-map-c"]')) && /36 \/ 600/.test(await text(page, `${card('map-c')} .wk-count-chars`)));
    ok('the box takes at most 600 letters', (await page.getAttribute('[data-fid="ta-map-c"]', 'maxlength')) === '600');
    // a live redraw while she types must not lose her words or the focus
    await page.evaluate(() => { const d = JSON.parse(JSON.stringify(QT.store.workers['map-a'])); d.now = 'Drawing the oak tree'; window.__mock.db.put('workers/map-a', d); });
    await page.waitForTimeout(200);
    ok('a live update does not lose what she was typing, nor the focus', (await page.inputValue('[data-fid="ta-map-c"]')) === 'How many pumpkin rows will there be?' && (await page.evaluate(() => document.activeElement.matches('[data-fid="ta-map-c"]'))));
    ok('...and the new words show', /Drawing the oak tree/.test(await text(page, `${card('map-a')} .wk-now`)));
    await page.evaluate(() => { window.__mock.db.failNext(1, 'not_granted'); });
    await page.click('[data-fid="send-map-c"]');
    await page.waitForSelector('.wk-msg:not(:empty)');
    ok('a failed send keeps her words and says so in plain words', (await page.inputValue('[data-fid="ta-map-c"]')).length === 36 && /Not saved\. Your words are still here/.test(await text(page, `${card('map-c')} .wk-msg`)));
    await page.click('[data-fid="send-map-c"]');
    await page.waitForSelector(`${card('map-c')} .wk-ask`);
    const asked = (await page.evaluate(() => window.__mock.writes.filter((x) => x.path.startsWith('asks/')))).map((x) => ({ id: x.path.split('/')[1], ...x.data }));
    ok('Send calls QT.write.ask({targetKind:"worker", targetId, text})', asked.length === 1 && asked[0].targetKind === 'worker' && asked[0].targetId === 'map-c' && asked[0].text === 'How many pumpkin rows will there be?');
    ok('her message appears as a bubble with "Sent · waiting for Claude to see it"', /How many pumpkin rows/.test(await text(page, `${card('map-c')} .wk-me`)) && /Sent · waiting for Claude to see it/.test(await text(page, `${card('map-c')} .wk-st`)));
    ok('the form closed and "Your questions (1)" is open', (await count(page, `${card('map-c')} .wk-form`)) === 0 && (await page.getAttribute('[data-fid="qs-map-c"]', 'aria-expanded')) === 'true');
    await shot(page, '700-asked');
    const id = asked[0].id;
    await page.evaluate((i) => window.__mock.db.put('replies/' + i, { id: i, targetKind: 'worker', targetId: 'map-c', state: 'seen', text: '', from: 'Claude', at: new Date().toISOString() }), id);
    await page.waitForTimeout(150);
    ok('then "Claude saw it ✓"', /Claude saw it ✓/.test(await text(page, `${card('map-c')} .wk-st`)));
    await page.evaluate((i) => window.__mock.db.put('replies/' + i, { id: i, targetKind: 'worker', targetId: 'map-c', state: 'answered', text: 'Twelve rows, in three groups.', from: 'Claude', at: new Date().toISOString() }), id);
    await page.waitForTimeout(150);
    ok('then the answer in a speech bubble: "Answer from Claude"', /Answer from Claude/.test(await text(page, `${card('map-c')} .wk-them`)) && /Twelve rows/.test(await text(page, `${card('map-c')} .wk-them`)));
    await shot(page, '700-answered');
    // a finished worker can still be asked
    await page.click('label.wk-showfin');
    await page.click('[data-fid="ask-map-b"]');
    ok('a finished worker: the placeholder says Claude answers from their notes', /This worker has finished\. Claude will answer from their notes\./.test((await page.getAttribute('[data-fid="ta-map-b"]', 'placeholder')) || ''));
    // the answer that opened by itself does not open again next time
    await page.reload(); await page.waitForSelector('.wk-in');
    ok('an answer opens by itself only once (map-a is closed after a reload)', (await page.getAttribute('[data-fid="qs-map-a"]', 'aria-expanded')) === 'false');
    await page.context().close();
  }

  /* ============ 5. offline, empty, hostile text, focus link ============ */
  {
    const page = await open({ opts: { db: null }, viaStub: true });
    await closeHelp(page);
    await page.click('[data-fid="ask-map-c"]');
    await page.fill('[data-fid="ta-map-c"]', 'Hello?');
    await page.click('[data-fid="send-map-c"]');
    ok('offline: a plain message, her words stay, nothing is sent', /No connection/.test(await text(page, `${card('map-c')} .wk-msg`)) && (await page.evaluate(() => (window.__mock && window.__mock.writes ? window.__mock.writes.filter((x) => x.path.startsWith('asks/')).length : 0))) === 0 && (await page.inputValue('[data-fid="ta-map-c"]')) === 'Hello?');
    await page.context().close();

    const e = await open({ fix: {} });
    ok('no workers yet: a friendly "No crew yet"', /No crew yet/.test(await text(e, '.wk-empty')) && /Claude has workers/.test(await text(e, '.wk-empty')));
    await shot(e, '700-empty');
    await e.context().close();

    const bad = fixture();
    bad.workers['map-a'].name = '<img src=x onerror="window.__pwned=1">Evil';
    bad.workers['map-a'].icon = '<b>x</b>';
    bad.workers['map-a'].role = '<script>window.__pwned=2<\/script> role';
    bad.workers['map-a'].now = '<u>underlined</u> now';
    bad.workers['map-c'].progress = 'lots';
    bad.workers['map-d'].state = 'exploding';
    const h = await open({ fix: bad });
    ok('document text never becomes page code', await h.evaluate(() => window.__pwned === undefined && !document.querySelector('.wk img[src="x"], .wk script, .wk-card u, .wk-card b')));
    ok('the strange name is shown as plain text and the bad icon becomes initials', /<img src=x/.test(await text(h, `${card('map-a')} .wk-name`)) && (await text(h, `${card('map-a')} .wk-face`)) === 'IE');
    ok('a progress that is not a number draws no bar; an unknown state counts as resting', (await count(h, `${card('map-c')} .wk-bar`)) === 0 && (await h.getAttribute(`${card('map-d')}`, 'data-state')) === 'resting');
    await h.context().close();

    const f = await open({ q: '?focus=map-d' });
    await f.waitForTimeout(500);
    ok('focus link: the card is shown, flashed and has the focus', (await f.evaluate(() => document.activeElement.matches('.wk-card[data-wid="map-d"]'))) && (await f.evaluate(() => document.querySelector('.wk-card[data-wid="map-d"]').classList.contains('is-focus'))));
    await f.context().close();
    const g = await open({ q: '?focus=map-b' });
    await g.waitForTimeout(500);
    ok('focus link to a finished worker shows the finished workers first', (await count(g, '.wk-card[data-wid="map-b"]')) === 1);
    await g.context().close();
  }

  /* ============ 6. sizes, themes, sizes of things, axe ============ */
  for (const [w, h, scheme, q] of [[700, 800, 'light', ''], [700, 800, 'dark', ''], [400, 800, 'light', ''], [1366, 768, 'light', '?full=1'], [1366, 768, 'dark', '?full=1'], [1920, 1080, 'light', '?full=1']]) {
    const page = await open({ w, h, scheme, q });
    const tag = `${w}x${h}${scheme === 'dark' ? ' dark' : ''}`;
    ok(`[${tag}] no sideways scroll`, await noSide(page));
    ok(`[${tag}] every button is at least 40 px high and wide`, await page.evaluate(() => [...document.querySelectorAll('.wk button')].filter((b) => b.getClientRects().length).every((b) => { const r = b.getBoundingClientRect(); return r.height >= 39.5 && r.width >= 39.5; })), await page.evaluate(() => [...document.querySelectorAll('.wk button')].filter((b) => b.getClientRects().length).map((b) => { const r = b.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height), b.textContent.trim().slice(0, 14)]; }).filter((x) => x[0] < 39.5 || x[1] < 39.5).slice(0, 4).join(' | ')));
    ok(`[${tag}] no text smaller than 13 px`, await page.evaluate(() => [...document.querySelectorAll('.wk *')].filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())).every((e) => parseFloat(getComputedStyle(e).fontSize) >= 12.9)));
    ok(`[${tag}] nothing sticks out of its card (no text cut off)`, await page.evaluate(() => [...document.querySelectorAll('.wk-card')].every((c) => c.scrollWidth <= c.clientWidth + 1)));
    if (AXE) {
      await page.evaluate(AXE);
      const res = await page.evaluate(() => window.axe.run(document.querySelector('.wk'), { resultTypes: ['violations'] }));
      ok(`[${tag}] axe finds no problems`, res.violations.length === 0, res.violations.map((v) => `${v.id}: ${v.nodes.slice(0, 2).map((n) => n.target.join(' ')).join(' | ')}`).join(' || ').slice(0, 500));
    }
    if (w !== 400) await closeHelp(page);
    await shot(page, `${w}x${h}-${scheme}`);
    await page.context().close();
  }

  /* ============ 7. keyboard and reduced motion ============ */
  {
    const page = await open({ motion: 'reduce' });
    await closeHelp(page);
    ok('reduced motion: the working badge does not pulse, cards do not fade in', await page.evaluate(() => getComputedStyle(document.querySelector('.wk-badge[data-state="working"]')).animationName === 'none' && getComputedStyle(document.querySelector('.wk-card')).animationName === 'none'));
    // keyboard walk: Tab reaches every control inside the visible tree, in order, and every stop has a visible name
    const names = [];
    await page.focus('[data-fid="flt-working"]');
    for (let n = 0; n < 30; n++) {
      await page.keyboard.press('Tab');
      const d = await page.evaluate(() => { const a = document.activeElement; if (!a || !a.closest('.wk')) return null; const r = a.getBoundingClientRect(); return { name: (a.getAttribute('aria-label') || a.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40), ring: getComputedStyle(a).outlineStyle !== 'none' || getComputedStyle(a).boxShadow !== 'none', vis: r.width > 0 && r.height > 0 }; });
      if (!d) break;
      names.push(d);
    }
    ok('Tab visits controls and every one has a name', names.length >= 12 && names.every((d) => d.name && d.vis), names.slice(0, 4).map((d) => d.name).join(' > '));
    ok('every focused control shows a focus ring', names.every((d) => d.ring));
    await page.context().close();
  }
} catch (e) {
  ok('the test ran to the end', false, String(e && e.stack ? e.stack.split('\n').slice(0, 4).join(' / ') : e));
}
await finish({ browser, site, errs });
