/* Live test: the page follows the shared notebook (the mock) WITHOUT a reload.
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/live.test.mjs        Port range 9720-9739.
 * Covers: empty notebook, new question (list, tab title, menu badge, NEW badge, ONE chime, none at first load), status chip walk
 * waiting -> answeredUnseen -> seen -> working -> done (+ followup, held), heartbeat label + stale, plan arrives (card + chime),
 * notebook missing (offline banner, no exceptions), write failure (toast).
 */
import * as H from './harness.mjs';
import { ok, info } from './harness.mjs';
import { seed, IDS, waitingCount, XSS, png } from './fixtures.mjs';

const h = await H.start(9721);
const MIN = 60000;
const sleep = H.sleep;
const newQ = (id, extra = {}) => Object.assign({
  id, sectionId: 'other', kind: 'choice', order: 90, createdAt: new Date().toISOString(), title: 'A brand new question from Claude?',
  story: ['Hello, this one just arrived.'], why: 'Just a test.', ownTip: '',
  choices: ['A', 'B', 'C', 'D'].map((k, i) => ({ key: k, label: ['Yes', 'No', 'Maybe', 'Explain this to me another way'][i], explain: 'Test.' })),
  required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null,
}, extra);
const count = (page) => page.title().then((t) => { const m = /^\((\d+)\)\s/.exec(t); return m ? Number(m[1]) : 0; });
const chip = (page) => H.text(page, '#qt-view .qbar .chip, #qt-view .qbar [class*=chip]');
const badgeOf = (page, id) => page.evaluate((i) => window.QT.status.badgeCount(i), id);
const state = (page, id) => page.evaluate((i) => window.QT.status.state(i), id);

/* ---------- 1. an empty notebook: friendly home, no errors ---------- */
for (const [label, docs] of [['no sections at all', {}], ['only the 4 built-in sections', seed({ empty: true })]]) {
  const page = await H.open(h, { docs, label: label + ': ' });
  ok(`empty (${label}): the app draws`, await H.ready(page));
  const t = await H.viewText(page);
  ok(`empty (${label}): home says something friendly (${t.length} characters)`, t.length > 20 && !/undefined|null|NaN|\[object|Error/.test(t), t.slice(0, 200));
  ok(`empty (${label}): tab title has no count`, (await count(page)) === 0, await page.title());
  const bar = await H.text(page, 'header, .topbar');
  ok(`empty (${label}): top bar shows the name`, /Terminal/.test(bar || ''), bar);
  ok(`empty (${label}): no errors`, page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
}

/* ---------- 2. a new question arrives ---------- */
await H.block('2 a new question arrives', async () => {
  const DOCS = seed();
  const N0 = waitingCount(DOCS);
  // sound is switched on, then the page is loaded again: the chime must not play for what is already there
  let page = await H.open(h, { docs: DOCS, label: 'new-question: ' });
  await page.evaluate(() => window.QT.sound.set(true));
  await page.reload({ waitUntil: 'load' }); await H.ready(page);
  ok('sound setting is remembered after a reload', await page.evaluate(() => window.QT.sound.enabled()));
  await H.settle(page, 600);
  ok('NO chime at first load', (await H.chimes(page)) === 0, 'chimes: ' + (await H.chimes(page)));
  ok(`tab title shows how many she can answer: "(${N0}) Terminal"`, (await count(page)) === N0, await page.title());
  await H.go(page, 'section', { id: 'other' });
  const other0 = await badgeOf(page, 'other');
  const menu0 = await H.text(page, '.mi[data-key="s:other"] .count');
  await page.evaluate(() => { window.__marker = 'same page'; });
  await H.resetAudio(page);
  await H.put(page, 'questions/live-1', newQ('live-1'));
  ok('new question shows in the list without a reload', await H.until(page, () => /A brand new question from Claude\?/.test(document.getElementById('qt-view').innerText), null, 5000));
  ok('(it is the same page: no reload happened)', (await page.evaluate(() => window.__marker)) === 'same page');
  ok(`tab title count rises to ${N0 + 1}`, await H.until(page, (n) => /^\((\d+)\)/.test(document.title) && Number(/^\((\d+)\)/.exec(document.title)[1]) === n, N0 + 1, 4000), await page.title());
  ok('badge count of the section rises by one', (await badgeOf(page, 'other')) === other0 + 1, `${other0} -> ${await badgeOf(page, 'other')}`);
  const menu1 = await H.text(page, '.mi[data-key="s:other"] .count');
  ok(`menu number for the section rises (${menu0} -> ${menu1})`, menu0 !== menu1 && Number(menu1) === Number(menu0) + 1);
  const newBadge = await page.evaluate(() => { const rows = [...document.querySelectorAll('#qt-view *')].filter((e) => /A brand new question from Claude\?/.test(e.textContent) && e.children.length < 8); const row = rows.length ? rows[rows.length - 1].closest('button, a, li, .item, .card, [role=button]') || rows[rows.length - 1] : null; return row ? !!row.querySelector('.badge-new, [class*=new]') || /\bNEW\b/.test(row.innerText) : false; });
  ok('NEW badge on the new question', newBadge);
  await H.settle(page, 400);
  ok('exactly ONE chime for it', (await H.chimes(page)) === 1, 'chimes: ' + (await H.chimes(page)));
  // a second unrelated change does not chime again
  await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'still here' });
  await H.settle(page, 400);
  ok('a heartbeat does not chime', (await H.chimes(page)) === 1, 'chimes: ' + (await H.chimes(page)));
  // a question for Miss Kathy does not raise the count and does not chime
  await H.put(page, 'questions/k99', Object.assign(newQ('k99'), { sectionId: 'kathy', kind: 'readonly', choices: [], who: 'kathy', title: 'Read-only newcomer?' }));
  await H.settle(page, 500);
  ok('a new question for Miss Kathy does not change the tab count', (await count(page)) === N0 + 1, await page.title());
  // opening it removes NEW
  await H.clickText(page, 'A brand new question from Claude?');
  await H.settle(page, 200);
  await H.go(page, 'section', { id: 'other' });
  const stillNew = await page.evaluate(() => { const rows = [...document.querySelectorAll('#qt-view *')].filter((e) => /A brand new question from Claude\?/.test(e.textContent) && e.children.length < 8); const row = rows.length ? rows[rows.length - 1].closest('button, a, li, .item, .card, [role=button]') || rows[rows.length - 1] : null; return row ? (!!row.querySelector('.badge-new') || /\bNEW\b/.test(row.innerText)) : null; });
  ok('NEW badge is gone after she opened it', stillNew === false, String(stillNew));
  // she answers it elsewhere: count goes down again
  await H.put(page, 'answers/live-1', { id: 'live-1', status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: 'Yes', answeredAt: new Date().toISOString(), round: 1 });
  ok(`tab title count falls back to ${N0} when answered`, await H.until(page, (n) => Number((/^\((\d+)\)/.exec(document.title) || [0, 0])[1]) === n, N0, 4000), await page.title());
  // Claude removes a question
  await H.del(page, 'questions/live-1');
  ok('a deleted question disappears from the list', await H.until(page, () => !/A brand new question from Claude\?/.test(document.getElementById('qt-view').innerText), null, 4000));
  // Claude edits a title
  await H.put(page, 'questions/c-short', Object.assign({}, DOCS['questions/c-short'], { title: 'Show the phone number EVERYWHERE?' }));
  ok('a changed title shows up', await H.until(page, () => /EVERYWHERE/.test(document.getElementById('qt-view').innerText), null, 4000));
  ok('no errors in the whole new-question run', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 3. the status chip walks through every state ---------- */
await H.block('3 the status chip walks through every', async () => {
  const DOCS = seed();
  DOCS['questions/live-2'] = newQ('live-2', { title: 'Chip walk question?' });
  const page = await H.open(h, { docs: DOCS, label: 'chip-walk: ' });
  await page.evaluate(() => window.QT.sound.set(true));
  await H.go(page, 'question', { id: 'live-2' });
  await H.resetAudio(page);
  const walk = async (name, want, rx, extra) => {
    ok(`chip [${name}]: state is ${want}`, await H.until(page, ([i, w]) => window.QT.status.state(i) === w, ['live-2', want], 4000), await state(page, 'live-2'));
    ok(`chip [${name}]: text matches ${rx}`, await H.until(page, (r) => { const e = document.querySelector('#qt-view .qbar'); return !!e && new RegExp(r, 'i').test(e.innerText); }, rx.source, 4000), (await H.text(page, '#qt-view .qbar')));
    if (extra) await extra();
  };
  await walk('no answer yet', 'waiting', /waiting for you/);
  const t0 = Date.now();
  await H.put(page, 'answers/live-2', { id: 'live-2', status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: 'Yes', answeredAt: new Date(t0).toISOString(), round: 1 });
  await walk('answered, Claude has not looked', 'answeredUnseen', /you answered.*waiting for claude/);
  await H.settle(page, 500);
  info('an answer arriving from outside (another window) chimes now: ' + (await H.chimes(page)) + ' (status module: "answered"); the chimes are counted again from here');
  await H.resetAudio(page);
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'seen', seenAt: new Date(t0 - 5 * MIN).toISOString(), note: '', doneNote: '', doneImages: [], followupId: null, at: new Date(t0 - 5 * MIN).toISOString() });
  await walk('seen BEFORE the answer', 'answeredUnseen', /you answered.*waiting for claude/);
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'seen', seenAt: new Date(t0 + 20000).toISOString(), note: '', doneNote: '', doneImages: [], followupId: null, at: new Date(t0 + 20000).toISOString() });
  await walk('seen after the answer', 'seen', /claude saw it/);
  await H.settle(page, 300);
  ok('no chime for "seen"', (await H.chimes(page)) === 0, 'chimes ' + (await H.chimes(page)));
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'working', seenAt: new Date(t0 + 20000).toISOString(), note: 'Making version B bigger', doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
  await walk('working', 'working', /working on it/, async () => {
    ok('chip [working]: the note line "Making version B bigger" is shown', await H.until(page, () => /Making version B bigger/.test(document.getElementById('qt-view').innerText), null, 3000), await H.text(page, '#qt-view .qbar'));
  });
  await H.settle(page, 300);
  ok('no chime for "working"', (await H.chimes(page)) === 0);
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'done', seenAt: new Date(t0 + 20000).toISOString(), note: '', doneNote: 'Version B is now bigger on the home page.', doneImages: [{ url: png(400, 200, '#99cc99', 'Result'), alt: 'The result', w: 400, h: 200 }], followupId: null, at: new Date().toISOString() });
  await walk('done', 'done', /done/, async () => {
    ok('chip [done]: the done note is shown', await H.until(page, () => /Version B is now bigger on the home page\./.test(document.getElementById('qt-view').innerText), null, 3000));
    ok('chip [done]: the result picture is shown ("See the result")', await H.until(page, () => !!document.querySelector('#qt-view .qv-done img, #qt-view .qtv-results img, #qt-view [aria-label*="result" i] img') || /see the result/i.test(document.getElementById('qt-view').innerText), null, 3000));
  });
  await H.settle(page, 500);
  ok('ONE chime when it becomes done', (await H.chimes(page)) === 1, 'chimes ' + (await H.chimes(page)));
  // writing the same done again does not chime again
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'done', seenAt: new Date(t0 + 20000).toISOString(), note: '', doneNote: 'Version B is now bigger on the home page.', doneImages: [], followupId: null, at: new Date().toISOString() });
  await H.settle(page, 400);
  ok('no second chime when "done" is written again', (await H.chimes(page)) === 1, 'chimes ' + (await H.chimes(page)));
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'followup', seenAt: new Date(t0 + 20000).toISOString(), note: '', doneNote: '', doneImages: [], followupId: IDS.followupChild, at: new Date().toISOString() });
  await walk('follow-up', 'followup', /follow-up/, async () => {
    const link = await page.evaluate(() => { const a = [...document.querySelectorAll('#qt-view a, #qt-view button')].find((e) => /follow-up|next question|see it|answer it|open/i.test(e.innerText)); return a ? a.innerText.trim() : null; });
    ok('chip [follow-up]: there is a link to the new question', !!link, String(link));
  });
  await H.put(page, 'status/live-2', { id: 'live-2', state: 'held', seenAt: new Date(t0 + 20000).toISOString(), note: '', doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
  await walk('held', 'held', /paused/);
  await H.shot(page, 'live-chip-held');
  // the question list shows the same chip
  await H.go(page, 'section', { id: 'other' });
  ok('the list shows the chip text too', /paused/i.test(await H.viewText(page)), (await H.viewText(page)).slice(0, 200));
  ok('no errors in the chip walk', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 4. the heartbeat ---------- */
await H.block('4 the heartbeat', async () => {
  const page = await H.open(h, { docs: seed(), label: 'heartbeat: ' });
  const hb = () => page.evaluate(() => ({ lab: window.QT.status.heartbeatLabel(), dom: (document.querySelector('.hb, [class*=heart]') || {}).innerText || '', stale: !!document.querySelector('.hb.stale, [class*=heart].stale') }));
  let x = await hb();
  ok(`heartbeat label at load: "${x.lab.text}" (2 min ago)`, /2 min/.test(x.lab.text) && !x.lab.stale, JSON.stringify(x));
  ok('top bar shows the label (Claude ... 2 min ago) and it is not amber', /Claude/i.test(x.dom) && /2 min/.test(x.dom) && !x.stale, JSON.stringify(x));
  ok('the full label says "Claude last checked for your answers 2 min ago"', /^Claude last checked for your answers 2 min ago$/.test(x.lab.text), x.lab.text);
  await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'just now' });
  ok('label updates when Claude looks again', await H.until(page, () => !/2 min/.test((document.querySelector('.hb, [class*=heart]') || {}).innerText || '') && /(just now|moment|0 min|1 min|few sec|seconds)/i.test((document.querySelector('.hb, [class*=heart]') || {}).innerText || ''), null, 4000), JSON.stringify(await hb()));
  await H.put(page, 'meta/heartbeat', { at: new Date(Date.now() - 45 * MIN).toISOString(), note: 'old' });
  ok('label goes stale: amber (class "stale") and the tooltip says "Claude may be busy" (at 700 px wide)', await H.until(page, () => { const e = document.querySelector('.hb, [class*=heart]'); return !!e && e.classList.contains('stale') && /may be busy/i.test(e.title || e.innerText); }, null, 4000), JSON.stringify(await hb()));
  const colors = await page.evaluate(() => { const e = document.querySelector('.hb'); return getComputedStyle(e).color; });
  await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'fresh' });
  await H.settle(page, 200);
  const fresh = await page.evaluate(() => getComputedStyle(document.querySelector('.hb')).color);
  ok(`stale label really has another (amber) colour than the fresh one (${fresh} -> ${colors})`, colors !== fresh);
  await H.put(page, 'meta/heartbeat', { at: new Date(Date.now() - 45 * MIN).toISOString(), note: 'old' });
  await H.settle(page, 200);
  const vis700 = await page.evaluate(() => document.querySelector('.hb').innerText);
  ok(`SPEC: the words "(Claude may be busy)" are READ on screen at 700 px wide (now: "${vis700}")`, /may be busy/i.test(vis700), 'the text is hidden under 780 px (layout: 10-layout.css  @media (max-width:779.98px){.hb .hb-extra{display:none}}); only colour + tooltip remain');
  await page.setViewportSize({ width: 1100, height: 800 }); await H.settle(page, 200);
  ok('the words "(Claude may be busy)" show on a wider window', /may be busy/i.test(await page.evaluate(() => document.querySelector('.hb').innerText)));
  await page.setViewportSize({ width: 700, height: 800 });
  await H.shot(page, 'live-heartbeat-stale');
  await H.del(page, 'meta/heartbeat');
  await H.settle(page, 300);
  const noHb = await hb();
  ok(`no heartbeat at all gives a calm label ("${noHb.lab.text}"), no errors`, typeof noHb.lab.text === 'string' && !/undefined|NaN|null/.test(noHb.lab.text + noHb.dom) && page.__errs.length === 0, JSON.stringify(noHb) + page.__errs.join('|'));
  await page.context().close();
  const p2 = await H.open(h, { docs: seed({ stale: true }), label: 'heartbeat-stale: ' });
  const s2 = await p2.evaluate(() => window.QT.status.heartbeatLabel());
  ok(`stale heartbeat at load: "${s2.text}"`, s2.stale === true && /45 min/.test(s2.text) && /may be busy/i.test(s2.text) && /Your answers are safe/i.test(s2.text), JSON.stringify(s2));
  await p2.context().close();
});

/* ---------- 5. a plan arrives ---------- */
await H.block('5 a plan arrives', async () => {
  const DOCS = seed();
  const plan = DOCS['plans/account-features'];
  delete DOCS['plans/account-features'];
  const page = await H.open(h, { docs: DOCS, label: 'plan: ' });
  await page.evaluate(() => window.QT.sound.set(true));
  await H.go(page, 'section', { id: IDS.sections.big });
  ok('no plan card before a plan exists', !/looks good/i.test(await H.viewText(page)));
  await H.resetAudio(page);
  await H.put(page, 'plans/account-features', plan);
  ok('plan card appears by itself', await H.until(page, () => /looks good/i.test(document.getElementById('qt-view').innerText), null, 5000), (await H.viewText(page)).slice(0, 300));
  const vt = await H.viewText(page);
  ok('the plan shows its steps in plain words', /Make a sign-up form/.test(vt) && /Test it on a phone/.test(vt) && /Change this/i.test(vt));
  await H.settle(page, 400);
  ok('ONE chime when the plan arrives', (await H.chimes(page)) === 1, 'chimes ' + (await H.chimes(page)));
  // a new version of the plan
  await H.put(page, 'plans/account-features', Object.assign({}, plan, { version: 2, steps: ['A new first step number two.'].concat(plan.steps) }));
  ok('a new plan version replaces the old steps', await H.until(page, () => /A new first step number two\./.test(document.getElementById('qt-view').innerText), null, 4000));
  await H.shot(page, 'live-plan');
  ok('no errors with the plan', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 6. the notebook is missing (db is null) ---------- */
await H.block('6 the notebook is missing db is null', async () => {
  const page = await H.open(h, { docs: seed(), mock: { db: null }, label: 'offline: ', wait: false });
  await H.settle(page, 600);
  ok('offline: QT.offline is true', await H.until(page, () => window.QT && window.QT.offline === true, null, 8000));
  await H.ready(page);
  const vis = await page.evaluate(() => { const b = document.getElementById('qt-offline'); return b ? { hidden: b.hidden || getComputedStyle(b).display === 'none', text: b.innerText.trim() } : null; });
  ok('offline: a friendly banner is visible', !!vis && !vis.hidden && vis.text.length > 10 && !/database|json|api|token/i.test(vis.text), JSON.stringify(vis));
  const mainTxt = await page.evaluate(() => (document.getElementById('qt-main') || {}).innerText || '');
  ok('offline: the page still draws, with the one plain banner "No connection. You can read, but answers will not save yet."', /No connection\. You can read, but answers will not save yet\./.test(mainTxt) && !/undefined|null|NaN|\[object/.test(mainTxt), mainTxt.slice(0, 200));
  ok('offline: the message is shown only once (no second copy in the home page)', (mainTxt.match(/answers will not save yet/gi) || []).length === 1, String((mainTxt.match(/answers will not save yet/gi) || []).length) + ' copies');
  const top = await H.text(page, 'header, .topbar');
  ok('offline: top bar says it is not live', /offline|not connected|can.?t reach|no connection/i.test(top || '') && !/\bLive\b/.test((top || '').replace(/offline/i, '')), top);
  for (const v of [['home', {}], ['done', {}], ['newsection', {}], ['section', { id: 'look' }]]) { await H.go(page, v[0], v[1]); }
  ok('offline: no errors while clicking around', page.__errs.length === 0, page.__errs.join(' | '));
  // an answer cannot be saved: she is told, nothing blows up
  await page.context().close();
  const p2 = await H.open(h, { docs: {}, mock: { db: null }, label: 'offline-nodocs: ' });
  ok('offline with nothing at all: draws and no errors', (await p2.evaluate(() => (document.getElementById('qt-main') || {}).innerText || '')).length > 10 && p2.__errs.length === 0, p2.__errs.join(' | '));
  await p2.context().close();
  // window.claude missing completely
  const p3 = await H.open(h, { docs: {}, initAfter: 'delete window.claude;', label: 'no-claude: ' });
  const t3 = await H.viewText(p3);
  ok('no window.claude at all: still draws, no errors', t3.length > 10 && p3.__errs.length === 0, t3.slice(0, 120) + ' ' + p3.__errs.join(' | '));
  await p3.context().close();
});

/* ---------- 7. a write fails -> she sees a toast ---------- */
await H.block('7 a write fails  she sees a toast', async () => {
  const page = await H.open(h, { docs: seed(), label: 'write-failure: ' });
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.evaluate(() => { window.__mock.failWrites = true; });
  await H.clearWrites(page);
  const clicked = await H.clickText(page, 'Under the main picture');
  ok('write failure: could click the answer', clicked);
  const toast = await H.until(page, () => { const t = [...document.querySelectorAll('.toast, .toasts [role=status], .toasts > *, .savestat.bad, [role=alert]')].find((e) => e.innerText && e.innerText.trim().length > 5); return t ? t.innerText.trim() : false; }, null, 5000);
  ok('write failure: a friendly message is shown', !!toast && !/error|exception|undefined|\bnull\b|json|database/i.test(String(toast)), String(toast));
  const vt = await H.viewText(page);
  ok('write failure: the page does NOT claim "Saved"', !/saved\s*✓/i.test(vt), vt.slice(0, 200));
  await H.shot(page, 'live-write-failure');
  await page.evaluate(() => { window.__mock.failWrites = false; });
  ok('write failure: no uncaught errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 8. the sound button ---------- */
await H.block('8 sound button', async () => {
  let page = await H.open(h, { docs: seed(), label: 'sound: ' });
  const st = () => page.evaluate(() => ({ on: window.QT.sound.enabled(), pressed: document.querySelector('.sound-btn').getAttribute('aria-pressed'), title: document.querySelector('.sound-btn').title, label: document.querySelector('.sound-btn').getAttribute('aria-label') }));
  let x = await st();
  ok('sound starts OFF', x.on === false && x.pressed === 'false', JSON.stringify(x));
  ok('sound button tooltip says "Play a happy sound when something new arrives. Click to turn it on."', /Play a happy sound when something new arrives\. Click to turn it on\./.test(x.title), x.title);
  ok('sound button has a spoken name', /sound/i.test(x.label || ''), x.label);
  await H.resetAudio(page);
  await page.click('.sound-btn');
  await H.settle(page, 300);
  x = await st();
  ok('one click turns the sound ON and says so (pressed, tooltip)', x.on === true && x.pressed === 'true' && /on/i.test(x.title), JSON.stringify(x));
  ok('the click plays ONE happy test chime (the browser needs a click first)', (await H.chimes(page)) === 1, 'chimes ' + (await H.chimes(page)));
  ok('the chime is 2 or 3 rising notes made with Web Audio', await page.evaluate(() => window.__audio.notes.length >= 2 && window.__audio.notes.length <= 4), await page.evaluate(() => window.__audio.notes.length + ' notes'));
  await page.reload({ waitUntil: 'load' }); await H.ready(page);
  x = await st();
  ok('the choice is remembered after a reload', x.on === true, JSON.stringify(x));
  await H.resetAudio(page);
  await page.click('.sound-btn');
  await H.settle(page, 300);
  x = await st();
  ok('a second click turns it OFF again, silently', x.on === false && (await H.chimes(page)) === 0, JSON.stringify(x) + ' chimes ' + (await H.chimes(page)));
  // with the sound OFF nothing chimes for new questions, done, or plans
  await H.put(page, 'questions/live-9', newQ('live-9'));
  await H.put(page, 'status/c-help', { id: 'c-help', state: 'done', seenAt: new Date().toISOString(), note: '', doneNote: 'x', doneImages: [], followupId: null, at: new Date().toISOString() });
  await H.settle(page, 500);
  ok('sound OFF: no chime for a new question or a done', (await H.chimes(page)) === 0, 'chimes ' + (await H.chimes(page)));
  ok('sound: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
  // storage blocked: the page still works
  const p2 = await H.open(h, { docs: seed(), label: 'sound-nostorage: ', init: "try { Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } }); } catch (e) {}" });
  ok('localStorage blocked: the page still draws and the sound button still toggles', (await H.viewText(p2)).length > 20 && (await p2.evaluate(() => { document.querySelector('.sound-btn').click(); return window.QT.sound.enabled(); })) === true, p2.__errs.join(' | '));
  ok('localStorage blocked: no page errors', p2.__errs.length === 0, p2.__errs.join(' | '));
  await p2.context().close();
});

/* ---------- 9. time passes, the notebook gets slow or goes away ---------- */
await H.block('9 time and trouble', async () => {
  // the heartbeat goes stale and the "min ago" numbers move on their own (no new data arrives)
  let page = await H.open(h, { docs: seed(), clock: true, label: 'clock: ' });
  const hbText = () => page.evaluate(() => (document.querySelector('.hb') || {}).innerText || '');
  ok('clock: label starts at 2 min', /2 min/.test(await hbText()), await hbText());
  await page.clock.fastForward(10 * MIN); await H.settle(page, 200);
  ok('clock: after 10 quiet minutes it says 12 min by itself, not amber yet', /12 min/.test(await hbText()) && !(await page.evaluate(() => document.querySelector('.hb').classList.contains('stale'))), await hbText());
  await page.clock.fastForward(10 * MIN); await H.settle(page, 200);
  ok('clock: after 22 minutes it turns amber by itself (no new data needed)', await H.until(page, () => document.querySelector('.hb').classList.contains('stale'), null, 3000) && /22 min/.test(await hbText()), await hbText());
  await H.put(page, 'meta/heartbeat', { at: await page.evaluate(() => new Date().toISOString()), note: 'back' });   // (the PAGE's clock is 20 minutes ahead of this program's)
  await H.settle(page, 200);
  ok('clock: a fresh heartbeat clears the amber', await H.until(page, () => !document.querySelector('.hb').classList.contains('stale'), null, 3000), await hbText());
  await page.context().close();

  // one collection never answers: the page must not hang on "loading"
  page = await H.open(h, { docs: seed(), mock: { silent: ['plans', 'planReplies', 'ideaStatus'] }, label: 'silent: ', wait: false });
  const t0 = Date.now();
  const drew = await H.ready(page, 20000);
  ok(`slow notebook: the page draws even if three collections never answer (took ${((Date.now() - t0) / 1000).toFixed(1)} s)`, drew && (Date.now() - t0) < 15000);
  ok('slow notebook: and it shows her questions', /waiting|question/i.test(await H.viewText(page)), (await H.viewText(page)).slice(0, 150));
  await page.evaluate(() => window.__mock.db.release('plans')); await page.evaluate(() => window.__mock.db.release('planReplies')); await page.evaluate(() => window.__mock.db.release('ideaStatus'));
  await H.settle(page, 300);
  ok('slow notebook: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();

  // a collection fails to open (first look refused): page still draws
  page = await H.open(h, { docs: seed(), label: 'failsub: ', init: '', initAfter: "window.__mock.db.failSubscribe('plans', 'permission_denied'); window.__mock.db.failSubscribe('ideaStatus', 'unavailable');", allowConsole: /./ });
  ok('one collection cannot be opened: the page still draws her questions', /waiting|question/i.test(await H.viewText(page)), (await H.viewText(page)).slice(0, 150));
  await page.context().close();

  // the notebook goes away while she is working
  page = await H.open(h, { docs: seed(), label: 'revoke: ', allowConsole: /./ });
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.evaluate(() => window.__mock.db.revoke());
  await H.settle(page, 800);
  ok('notebook revoked while open: the question is still on screen', /Book a visit/.test(await H.viewText(page)), (await H.viewText(page)).slice(0, 120));
  const rv = await page.evaluate(() => { const b = document.getElementById('qt-offline'); const btns = [...document.querySelectorAll('#qt-view button.qa-choice')]; return { banner: b && !b.hidden ? b.innerText.trim() : null, disabled: btns.length > 0 && btns.every((x) => x.disabled || x.getAttribute('aria-disabled') === 'true'), saved: /Saved ✓/.test(document.getElementById('qt-view').innerText) }; });
  if (!rv.disabled) { await page.click('#qt-view button.qa-choice[data-key="B"]').catch(() => {}); await H.settle(page, 600); }
  const vt = await H.viewText(page);
  const toasts = await page.evaluate(() => [...document.querySelectorAll('.toast, .toasts > *')].map((e) => e.innerText).join(' '));
  ok('notebook revoked: she is told plainly (banner "No connection. You can read, but answers will not save yet." and the answer buttons wait, or a "could not save" line) and nothing says "Saved"', !/Saved ✓/.test(vt) && (/No connection\. You can read, but answers will not save yet\./.test(rv.banner || '') || /could not save|cannot save|will not save|try again/i.test(vt + ' ' + toasts)), JSON.stringify(rv) + ' ' + vt.slice(0, 120));
  ok('notebook revoked: no uncaught exceptions', page.__errs.filter((e) => /pageerror/.test(e)).length === 0, page.__errs.join(' | '));
  await page.context().close();

  // the last place is remembered
  page = await H.open(h, { docs: seed(), label: 'remember: ' });
  await H.go(page, 'section', { id: 'later' });
  await page.reload({ waitUntil: 'load' }); await H.ready(page);
  ok('after a reload she is back in the section she was in (Ideas for later)', /Ideas for later/.test(await H.text(page, '#qt-view h1, #qt-view .sx-h1') || ''), await H.text(page, '#qt-view h1'));
  await H.go(page, 'question', { id: IDS.choiceNormal });
  await page.reload({ waitUntil: 'load' }); await H.ready(page);
  ok('after a reload she is back at the question she was reading', /Book a visit/.test(await H.text(page, '#qt-view .qbar-title') || ''), await H.viewText(page).then((t) => t.slice(0, 100)));
  // ... but not if that question has been taken away meanwhile
  await H.go(page, 'question', { id: 'live-gone' });
  ok('a question that does not exist shows a friendly message and a way back', /cannot find|not find|taken away|not here|moved/i.test(await H.viewText(page)) && (await H.clickText(page, 'Back to the start')), (await H.viewText(page)).slice(0, 120));
  ok('remember: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 10. a quiet page stays quiet (no redraw storms) ---------- */
await H.block('10 quiet page', async () => {
  const page = await H.open(h, { docs: seed(), label: 'quiet: ' });
  const watch = (sel) => page.evaluate((s) => { window.__mut = { n: 0, kinds: {} }; const el = document.querySelector(s); window.__mo && window.__mo.disconnect(); window.__mo = new MutationObserver((l) => { for (const m of l) { window.__mut.n++; window.__mut.kinds[m.type] = (window.__mut.kinds[m.type] || 0) + 1; } }); window.__mo.observe(el, { childList: true, subtree: true, characterData: true, attributes: false }); }, sel);
  const muts = () => page.evaluate(() => window.__mut);
  for (const [view, params, label] of [['home', {}, 'home'], ['section', { id: 'other' }, 'section'], ['question', { id: IDS.choiceNormal }, 'question'], ['question', { id: IDS.visual }, 'picture question'], ['section', { id: IDS.sections.big }, 'big section']]) {
    await H.go(page, view, params);
    await H.settle(page, label === 'picture question' ? 3500 : 300);   // (the broken picture needs a moment to be given up on)
    await watch('#qt-view');
    await sleep(2500);
    const m = await muts();
    ok(`quiet [${label}]: nothing is redrawn while nobody does anything (2.5 s)`, m.n === 0, JSON.stringify(m));
    await H.put(page, 'meta/heartbeat', { at: new Date().toISOString(), note: 'tick ' + Math.random() });
    await sleep(700);
    const m2 = await muts();
    ok(`quiet [${label}]: a heartbeat does not redraw the page body`, m2.n === 0, JSON.stringify(m2));
    await H.put(page, 'status/c-help', { id: 'c-help', state: 'working', seenAt: new Date().toISOString(), note: 'n' + Math.random(), doneNote: '', doneImages: [], followupId: null, at: new Date().toISOString() });
    await sleep(700);
    const m3 = await muts();
    info(`quiet [${label}]: after one unrelated status change the body changed ${m3.n} times`);
    ok(`quiet [${label}]: one unrelated status change causes only a handful of DOM changes (not a storm)`, m3.n <= 60, JSON.stringify(m3));
  }
  // timers: the page must not run busy loops
  const cpu = await page.evaluate(async () => { let ticks = 0; const t0 = performance.now(); const f = () => { ticks++; }; const id = setInterval(f, 10); await new Promise((r) => setTimeout(r, 1000)); clearInterval(id); return ticks; });
  ok(`quiet: the page is not busy (a 10 ms timer ticked ${cpu} times in 1 s)`, cpu >= 50, String(cpu));
  ok('quiet: no page errors', page.__errs.length === 0, page.__errs.join(' | '));
  await page.context().close();
});

/* ---------- 11. the top bar words at different widths ---------- */
await H.block('11 top bar labels', async () => {
  const want = [[1366, /^Check Claude hears me$/], [1200, /^Check Claude hears me$/], [1199, /^Check Claude$/], [900, /^Check Claude$/], [820, /^Check Claude$/], [819, /^$/], [700, /^$/], [640, /^$/], [400, /^$/]];   // the two switches (Sound, Voice) take room: the long words need 1200 px, the picture alone is enough under 820
  for (const [w, rx] of want) {
    const page = await H.open(h, { docs: seed(), w, h: 800, label: `topbar ${w}: ` });
    const r = await page.evaluate(() => { const b = document.querySelector('.test-btn'); const s = document.querySelector('.sound-btn'); const m = document.querySelector('.menu-btn'); const vis = (e) => e && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden'; const txt = (e) => [...e.querySelectorAll('*')].filter((n) => n.children.length === 0 && getComputedStyle(n).display !== 'none' && n.getClientRects().length).map((n) => n.textContent).join('').trim(); return { test: txt(b), testName: b.getAttribute('aria-label') || b.title || b.innerText, sound: txt(s), soundName: s.getAttribute('aria-label') || s.title, menu: vis(m) ? txt(m).replace(/\d+$/, '').trim() : null, menuName: vis(m) ? (m.getAttribute('aria-label') || m.innerText) : null, logo: (() => { const l = document.querySelector('.brand'); return l ? l.innerText.trim() : null; })(), docW: document.documentElement.scrollWidth }; });
    ok(`[${w}] test button words: "${r.test}" (wanted ${rx})`, rx.test(r.test), JSON.stringify(r));
    ok(`[${w}] the test button and the sound button always have a spoken name`, !!r.testName && r.testName.trim().length > 3 && !!r.soundName && r.soundName.trim().length > 3, JSON.stringify(r));
    ok(`[${w}] no sideways scroll in the top bar`, r.docW <= w + 1, JSON.stringify(r));
    if (w >= 640) ok(`[${w}] the sound button reads "Sound: on" or "Sound: off"`, /^Sound: (on|off)$/i.test(r.sound), JSON.stringify(r));
    await page.context().close();
  }
  // the top bar at many widths. Rules: the TIME ("... min ago") is always fully visible and inside the bar; the label shortens first; nothing sideways;
  //   logo icon hidden under 720 px; the word "Menu" hidden under 680 px; with a STALE heartbeat the title "Terminal" steps aside at 1000 px and below (the Sound and Voice switches take room), above it stays
  const timeCut = [];
  for (const stale of [false, true]) for (const w of [1366, 1100, 1000, 900, 840, 820, 800, 760, 730, 720, 710, 700, 690, 670, 640, 600, 500, 400]) {
    const page = await H.open(h, { docs: seed({ stale }), w, h: 800, label: `topbar ${stale ? 'stale ' : ''}${w}: ` });
    const r = await page.evaluate(() => {
      const g = (s) => document.querySelector(s); const shown = (e) => !!e && getComputedStyle(e).display !== 'none' && e.getClientRects().length > 0;
      const hb = g('.hb'); const m = g('.menu-btn'); const menuShown = shown(m);
      const bar = g('.topbar, header').getBoundingClientRect(), hr = hb.getBoundingClientRect();
      const leaf = [...hb.querySelectorAll('*')].find((n) => n.children.length === 0 && /(\d+\s*(min|h|hour|day)|just now)/i.test(n.textContent) && shown(n));
      const tr = leaf ? leaf.getBoundingClientRect() : null;
      return { icon: shown(g('.topbar .brand, header .brand')), title: shown(g('.brand-t')), menuBtn: menuShown, menuWord: menuShown ? [...m.querySelectorAll('*')].some((n) => n.children.length === 0 && n.getClientRects().length && /^Menu$/.test(n.textContent.trim())) : null,
        hb: hb.innerText, stale: hb.classList.contains('stale'), time: leaf ? leaf.textContent.trim() : null,
        timeInside: !!tr && tr.left >= bar.left - 1 && tr.right <= Math.min(bar.right, innerWidth) + 1 && tr.right <= hr.right + 1 && tr.bottom <= bar.bottom + 1 && tr.top >= bar.top - 1,
        timeClipped: !!leaf && (leaf.scrollWidth > leaf.clientWidth + 1 && getComputedStyle(leaf).display !== 'inline'),
        docW: document.documentElement.scrollWidth };
    });
    const tag = `[${w}] ${stale ? 'STALE' : 'fresh'} heartbeat`;
    if (!r.time || !r.timeInside || r.timeClipped) timeCut.push(`${stale ? 'stale' : 'fresh'} ${w}px: time=${JSON.stringify(r.time)} inside=${r.timeInside} clipped=${r.timeClipped} label="${r.hb}"`);
    ok(`${tag}: no sideways scroll, state ${stale ? 'amber' : 'calm'}`, r.docW <= w + 1 && r.stale === stale, JSON.stringify(r));
    const wantTitle = !(stale && w <= 1000);   // the two switches take room: with the long stale words the title steps aside up to 1000 px (the logo and the time stay)
    ok(`${tag}: the logo icon is ${w >= 720 ? 'shown' : 'hidden'} and the title "Terminal" is ${wantTitle ? 'shown' : 'hidden'}`, r.icon === (w >= 720) && (r.title === wantTitle || (!wantTitle && r.time)), JSON.stringify(r));
    if (r.menuBtn) ok(`${tag}: the word "Menu" is ${w >= 680 ? 'shown' : 'hidden'}`, r.menuWord === (w >= 680), JSON.stringify(r));
    await page.context().close();
  }
  ok('the time ("... min ago") is fully visible and inside the bar at every window width (the label shortens first, the number is never cut)', timeCut.length === 0, timeCut.slice(0, 5).join(' | '));
});

await H.stop(h);
