import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer, launch } from './lib.mjs';
import { injectMock } from './mockfix.mjs';
import { tasksDocs, byCollection } from './tasks.fixture.mjs';
const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.join(T, 'shots', 'tasks'); fs.mkdirSync(OUT, { recursive: true });
let site; for (let p = 9530; p < 9599 && !site; p++) { try { site = await startServer({ root: T, port: p }); } catch (e) { /* next */ } }
const browser = await launch();
async function open(w, h, o = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage(); page.errs = [];
  page.on('pageerror', (e) => page.errs.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') page.errs.push(m.text()); });
  await page.addInitScript((d) => { window.__TK = d; try { localStorage.setItem('qt.tasks.howto', 'closed'); } catch (e) {} }, byCollection(tasksDocs()));
  await injectMock(page, {}, {});
  await page.goto(site.url + 'dist-sections2/index.html' + (o.q || ''));
  await page.waitForSelector('.tk-tree', { timeout: 15000 });
  await page.waitForTimeout(400);
  return page;
}
const shot = (p, n, full) => p.screenshot({ path: path.join(OUT, n + '.png'), fullPage: !!full });
// narrow: closed intro, detail open
let p = await open(700, 800);
await shot(p, 'n1-700-closed-intro');
await p.locator('li[data-id="map"] > .tk-card').click(); await p.waitForTimeout(300);
await shot(p, 'n2-700-detail-map');
await p.getByRole('button', { name: 'Ask about this task' }).click(); await p.waitForTimeout(200);
await shot(p, 'n3-700-ask-form');
await p.context().close();
// wide
p = await open(1366, 768);
await p.locator('li[data-id="map"] > .tk-card').click(); await p.waitForTimeout(300);
await shot(p, 'w1-1366-detail-map');
await p.locator('li[data-id="map-words"] > .tk-card').click(); await p.waitForTimeout(300);
await shot(p, 'w2-1366-detail-waiting');
await p.getByRole('button', { name: '+ Add a task' }).click(); await p.waitForTimeout(300);
await shot(p, 'w3-1366-add-form');
await p.context().close();
p = await open(1920, 1080);
await p.locator('li[data-id="win-msg"] > .tk-card').click(); await p.waitForTimeout(300);
await shot(p, 'x1-1920-detail');
await p.context().close();
p = await open(700, 800, { scheme: 'dark' });
await shot(p, 'd1-700-dark');
await p.locator('li[data-id="map-words"] > .tk-card').click(); await p.waitForTimeout(300);
await shot(p, 'd2-700-dark-detail');
await p.context().close();
p = await open(1366, 768, { scheme: 'dark' });
await shot(p, 'd3-1366-dark');
console.log('errs', p.errs.join('|'));
await browser.close(); await site.close();
