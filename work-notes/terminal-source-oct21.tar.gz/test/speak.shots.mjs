/* speak.shots.mjs (owner: layout) - pictures of the "read it out loud" buttons: T/shots/voice/*.png
 *   QT_PAGE=dist-voice/index.html NODE_PATH=/opt/node22/lib/node_modules node test/speak.shots.mjs     (ports 9600-9615)
 * Question page, Workers part and Tasks part at 700x800, 1366x768, 1920x1080; with the buttons showing, one of them speaking. */
import fs from 'node:fs';
import path from 'node:path';
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
import { MOCK, VOICES } from './speak-mock.mjs';

const OUT = path.join(H.T, 'shots', 'voice');
fs.mkdirSync(OUT, { recursive: true });
const h = await H.start(9600);
const docs = seed({ parts: true, downloads: true, cathy: true });
const sizes = [[700, 800], [1366, 768], [1920, 1080]];
const only = process.env.SHOTS_ONLY ? new RegExp(process.env.SHOTS_ONLY) : null;

async function open(w, hh, scheme, mock) {
  const p = await H.open(h, { docs, w, h: hh, scheme, init: MOCK(mock || { auto: 0 }) });
  await H.settle(p, 700);
  return p;
}
const shot = async (p, name) => { await p.screenshot({ path: path.join(OUT, name + '.png') }); };
async function pageInfo(p) {
  return p.evaluate(() => ({ buttons: document.querySelectorAll('.qt-speak').length, docH: document.documentElement.scrollHeight, vh: innerHeight }));
}
for (const scheme of ['light', 'dark']) {
  for (const [w, hh] of sizes) {
    if (scheme === 'dark' && w === 1920) continue;
    const tag = `${w}x${hh}${scheme === 'dark' ? '-dark' : ''}`;
    const jobs = [
      ['question', async (p) => { await H.go(p, 'question', { id: 'c-normal' }); }, '.qa-choice .qt-speak'],
      ['visual', async (p) => { await H.go(p, 'question', { id: 'v-map-1' }); }, '.qbar-title'],
      ['workers', async (p) => { await H.go(p, 'workers', {}); }, '.wk-card'],
      ['tasks', async (p) => { await H.go(p, 'tasks', {}); await p.evaluate(() => localStorage.setItem('qt.tasks.howto', 'closed')); }, '.tk-card'],
    ];
    for (const [name, nav, wait] of jobs) {
      if (only && !only.test(name + '-' + tag)) continue;
      const p = await open(w, hh, scheme);
      await nav(p);
      await H.settle(p, 700);
      console.log(name, tag, JSON.stringify(await pageInfo(p)));
      await shot(p, `${name}-${tag}`);
      // start reading the first speaker in the main area (the mock never ends it on its own)
      const first = p.locator('#qt-view .qt-speak').first();
      if (await first.count()) {
        await first.scrollIntoViewIfNeeded().catch(() => {});
        await first.click().catch(() => {});
        await H.settle(p, 300);
        await shot(p, `${name}-${tag}-speaking`);
      }
      await p.context().close();
    }
  }
}
// no private voice on this computer (only cloud voices): no speakers, the Voice switch greyed out
{
  const p = await H.open(h, { docs, w: 700, h: 800, init: 'window.QT_SPEAK_GRACE=300;' + MOCK({ voices: VOICES.googleOnly, auto: 0 }) });
  await H.go(p, 'question', { id: 'c-normal' });
  await H.settle(p, 1200);
  console.log('novoice', JSON.stringify(await pageInfo(p)));
  await shot(p, 'novoice-700x800');
  await p.context().close();
}
console.log('errors', h.errs);
await H.stop(h);
