/* Shared glue for the whole-page tests (fit / live / flow / a11y).
 * Owner: tester.  Everything that depends on the mock's exact API lives HERE, so only this file changes if the mock changes.
 *
 *   const h = await H.start(9701);                       // { site, browser, base, errs }
 *   const page = await H.open(h, { docs: seed(), w: 700, h: 800, scheme: 'light' });
 *   await H.go(page, 'question', { id: 'c-normal' });
 *   await H.put(page, 'questions/new-1', {...});          // like Claude writing to the shared notebook
 *   const w = await H.writes(page);                       // what the PAGE wrote  [{op, path, data}]
 *   await H.stop(h);
 */
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { startServer, launch, ok, info, finish, ms, until, okSoon, axeSource } from './lib.mjs';

export const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const SHOTS = path.join(T, 'shots');
export { ok, info, ms, until, okSoon, axeSource };
export const sleep = (n) => new Promise((r) => setTimeout(r, n));

/** Build the page once (python3 T/build.py). Set QT_NOBUILD=1 to skip. */
export function build() {
  if (process.env.QT_NOBUILD) return true;
  try { execFileSync('python3', [path.join(T, 'build.py')], { cwd: T, stdio: 'pipe' }); return true; }
  catch (e) { console.log('FAIL build.py failed: ' + String(e.stderr || e.message).split('\n').slice(0, 4).join(' | ')); return false; }
}

/**
 * start(port, {src})  src:true (or QT_FROM_SRC=1) builds the page from T/src into its own snapshot (never touches T/dist);  QT_PAGE=<file> tests exactly that file
 * (for example QT_PAGE=dist-visual2/index.html). Without any of these: python3 T/build.py (-> T/dist/index.html) unless QT_NOBUILD, as before.
 */
export async function start(port, o = {}) {
  const fromSrc = !!(o.src || process.env.QT_FROM_SRC) && !process.env.QT_PAGE;
  const pageFile = process.env.QT_PAGE ? path.resolve(T, process.env.QT_PAGE) : null;
  if (!fromSrc && !pageFile) {
    if (!fs.existsSync(path.join(T, 'build.py')) || !build() || !fs.existsSync(path.join(T, 'dist', 'index.html'))) {
      ok('the page builds (T/build.py -> T/dist/index.html)', false, 'build.py or dist/index.html is missing (the other helpers have not delivered yet?)');
      await finish({});
      process.exit(1);
    }
  }
  // Other helpers rebuild T/dist all the time. Test ONE frozen copy so a run never mixes two versions of the page.
  const snapDir = path.join('dist-tester', String(process.pid));
  fs.mkdirSync(path.join(T, snapDir), { recursive: true });
  if (fromSrc) {
    try { execFileSync('python3', [path.join(T, 'build.py'), '--out', path.join(T, snapDir, 'index.html')], { cwd: T, stdio: 'pipe' }); }
    catch (e) { ok('the page builds from T/src (python3 build.py --out ...)', false, String(e.stderr || e.message).split('\n').slice(0, 5).join(' | ')); await finish({}); process.exit(1); }
  } else {
    fs.copyFileSync(pageFile || path.join(T, 'dist', 'index.html'), path.join(T, snapDir, 'index.html'));
  }
  let site = null, lastErr = null;
  for (let p = port; p < port + 15 && !site; p++) { try { site = await startServer({ root: T, port: p }); } catch (e) { lastErr = e; } }   // a busy port: try the next one of the range
  if (!site) throw lastErr;
  const browser = await launch();
  const h = { site, browser, base: site.url, errs: [], port: site.port, page: snapDir.split(path.sep).join('/') + '/index.html' };
  const stamp = fs.statSync(path.join(T, snapDir, 'index.html'));
  info(`testing ${fromSrc ? 'a fresh build of T/src' : pageFile ? path.relative(T, pageFile) : 'a copy of dist/index.html'} (${Math.round(stamp.size / 1024)} KB)`);
  return h;
}

export async function stop(h) {
  await finish({ browser: h.browser, site: h.site, errs: h.errs });
  try { fs.rmSync(path.join(T, 'dist-tester', String(process.pid)), { recursive: true, force: true }); } catch (e) { /* ignore */ }
}

const NOISE = /fonts\.g|net::ERR|Failed to load resource|favicon|broken\.invalid|ERR_NAME_NOT_RESOLVED/;

/** Script that runs in the page BEFORE anything else: stubs Web Audio so the tests can count chimes, records alert()/dialogs. */
const AUDIO_STUB = `(() => {
  const A = (window.__audio = { created: 0, notes: [], starts: 0 });
  function Ctx() {
    A.created++;
    this.currentTime = 0; this.state = 'running'; this.destination = {};
    this.resume = () => Promise.resolve(); this.close = () => Promise.resolve(); this.suspend = () => Promise.resolve();
  }
  const node = () => { const n = { connect(x) { return x || n; }, disconnect() {}, start() { A.starts++; A.notes.push(Date.now()); }, stop() {}, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {}, cancelScheduledValues() {}, setTargetAtTime() {}, addEventListener() {} };
    n.frequency = n.gain = n.detune = n.Q = n; n.type = ''; n.value = 0; return n; };
  Ctx.prototype.createOscillator = node; Ctx.prototype.createGain = node; Ctx.prototype.createBiquadFilter = node; Ctx.prototype.createBufferSource = node;
  Ctx.prototype.createDynamicsCompressor = node; Ctx.prototype.createStereoPanner = node;
  window.AudioContext = Ctx; window.webkitAudioContext = Ctx;
  window.__alerts = []; window.alert = (m) => window.__alerts.push(String(m)); window.confirm = () => true; window.prompt = () => null;
})();`;

/**
 * Opens a fresh page (own browser context).
 *   docs     seed documents { 'coll/id': doc }       (default: nothing)
 *   w,h      viewport                                  (default 700x800)
 *   scheme   'light' | 'dark'                          (OS colour scheme)
 *   reduced  true -> prefers-reduced-motion: reduce
 *   mock     options handed to the mock (e.g. { db: null, comments: 'unavailable' })
 *   keepStorage  do not clear localStorage
 *   init     extra script text to run before the page (and before the mock)
 *   clock    true -> the page clock can be moved: await page.clock.fastForward(ms)  (Playwright fake clock, runs on its own until moved)
 *   initAfter  extra script text that runs after the mock is in place, before the page
 *   url      page to load (default dist/index.html)
 *   wait     false -> do not wait for the first paint of the app
 */
export async function open(h, o = {}) {
  if (!h.browser.isConnected()) {   // the browser died (a crash, or the computer killed it): say so once, start a new one so the other checks still run
    h.crashes = (h.crashes || 0) + 1;
    ok(`the browser did not crash (crash number ${h.crashes}, noticed before: ${o.label || 'a new page'})`, false, 'Chromium exited while the test ran: a page crash or a computer short of memory');
    try { h.browser = await launch(); } catch (e) { throw new Error('could not start a new browser: ' + e.message); }
  }
  const ctx = await h.browser.newContext({
    viewport: { width: o.w || 700, height: o.h || 800 }, colorScheme: o.scheme || 'light', reducedMotion: o.reduced ? 'reduce' : 'no-preference',
    locale: 'en-US', timezoneId: 'America/New_York', deviceScaleFactor: o.dpr || 1,
  });
  const page = await ctx.newPage();
  if (o.clock) await page.clock.install({ time: new Date() });
  page.setDefaultTimeout(ms(15000));
  page.__errs = [];
  const label = o.label || '';
  page.on('pageerror', (e) => { const m = label + 'pageerror: ' + e.message; page.__errs.push(m); h.errs.push(m); });
  page.on('console', (m) => { if (m.type() === 'error' && !NOISE.test(m.text()) && !(o.allowConsole && o.allowConsole.test(m.text()))) { const t = label + 'console: ' + m.text(); page.__errs.push(t); h.errs.push(t); } });
  page.__dialogs = [];
  page.on('dialog', (d) => { page.__dialogs.push(d.message()); d.dismiss().catch(() => {}); });
  await page.addInitScript(AUDIO_STUB);
  if (o.init) await page.addInitScript(o.init);
  const { injectMock } = await import(pathToFileURL(path.join(T, 'test', 'mockfix.mjs')).href);
  await injectMock(page, o.docs || {}, o.mock || {});
  if (o.initAfter) await page.addInitScript(o.initAfter);   // runs after the mock is in place
  await page.goto(h.base + (o.url || h.page || 'dist/index.html'), { waitUntil: 'load', timeout: ms(30000) });
  if (o.wait !== false) await ready(page);
  return page;
}

/** Waits until the app is drawn (QT.ready resolved and the view element has content). */
export async function ready(page, limit = 15000) {
  const r = await until(page, async () => {
    if (!window.QT) return false;
    try { await window.QT.ready; } catch (e) { /* offline */ }
    const v = document.getElementById('qt-view');
    return !!v && v.children.length > 0;
  }, null, limit);
  await settle(page);
  return !!r;
}

/** A short pause that lets the page's own timers (render, debounce) run. */
export async function settle(page, n = 120) {
  try { await page.evaluate((t) => new Promise((r) => requestAnimationFrame(() => setTimeout(r, t))), n); } catch (e) { /* page gone */ }
}

export async function go(page, view, params = {}) {
  await page.evaluate(([v, p]) => window.QT.route.go(v, p), [view, params]);
  await settle(page, 150);
}

/* ---------------- mock access (the mock is test/mock-claude.js; adapt here if it changes) ---------------- */
/** Claude writes a document. path = 'coll/id'. */
export const put = (page, p, doc) => page.evaluate(([a, b]) => window.__mock.db.put(a, b), [p, doc]);
/** Claude deletes a document. */
export const del = (page, p) => page.evaluate((a) => window.__mock.db.remove(a), p);
/** What the PAGE wrote and the notebook accepted: [{op:'set'|'update'|'delete', path:'coll/id', data, at}] (oldest first). */
export const writes = (page) => page.evaluate(() => window.__mock.db.writes.slice());
export const attempts = (page) => page.evaluate(() => window.__mock.db.attempts.slice());
export const clearWrites = (page) => page.evaluate(() => window.__mock.db.clearWrites());
/** The document as the notebook holds it now (or undefined). */
export const get = (page, p) => page.evaluate((a) => window.__mock.db.get(a), p);
/** Paths where the page started a write while another write to the same document was still running (must be empty). */
export const overlaps = (page) => page.evaluate(() => window.__mock.db.overlaps.map((o) => o.path));
/** Everything the page sent with sendToClaude: [{anchor?, threadId?, text}] */
export const pings = (page) => page.evaluate(() => window.__mock.pings.map((p) => p.target));
/** Number of chimes since the last resetAudio (notes started within 80 ms of each other count as ONE chime). */
export const chimes = (page) => page.evaluate(() => { const n = (window.__audio && window.__audio.notes) || []; let c = 0, last = -1e9; for (const t of n) { if (t - last > 80) c++; last = t; } return c; });
export const resetAudio = (page) => page.evaluate(() => { window.__audio.notes.length = 0; window.__audio.starts = 0; });

/* ---------------- small page readers ---------------- */
export const text = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); return e ? e.textContent.trim().replace(/\s+/g, ' ') : null; }, sel);
export const viewText = (page) => page.evaluate(() => { const e = document.getElementById('qt-view'); return e ? e.innerText.replace(/\s+/g, ' ').trim() : ''; });
export const title = (page) => page.title();

/** Click a button (or link) inside the main view whose visible text matches (string = contains, case-insensitive; RegExp). */
export async function clickText(page, what, { within = '#qt-view', nth = 0, role = 'button, a, [role=button], [role=radio], [role=switch], label' } = {}) {
  const arg = [typeof what === 'string' ? { s: what } : { rx: what.source, flags: what.flags }, within, nth, role];
  for (let attempt = 0; attempt < 4; attempt++) {
    const handle = await page.evaluateHandle(([w, within, nth, role]) => {
      const rx = w.rx ? new RegExp(w.rx, w.flags) : null;
      const root = document.querySelector(within) || document;
      const list = [...root.querySelectorAll(role)].filter((e) => {
        const r = e.getBoundingClientRect(); if (!r.width || !r.height) return false;
        const t = (e.innerText || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
        return rx ? rx.test(t) : t.toLowerCase().includes(w.s.toLowerCase());
      });
      return list[nth] || null;
    }, arg);
    const el = handle.asElement();
    if (!el) return false;
    try { await el.scrollIntoViewIfNeeded(); await el.click(); return true; }
    catch (e) { if (!/not attached|detached|not stable/i.test(String(e.message)) || attempt === 3) throw e; await sleep(150); }   // the page drew the view again under our hand: look again
  }
  return false;
}

export async function shot(page, name, o = {}) {
  fs.mkdirSync(SHOTS, { recursive: true });
  try { await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: !!o.full }); } catch (e) { /* page closed */ }
}

/** Runs one block of a test; an exception (a click that cannot be done, a missing element) becomes ONE failed check, the run goes on. */
export async function block(name, fn) {
  if (process.env.QT_ONLY && !new RegExp(process.env.QT_ONLY, 'i').test(name)) return;   // QT_ONLY=fit runs just the blocks whose name matches
  try { await fn(); } catch (e) { ok(`${name}: the block ran to the end`, false, String((e && e.message) || e).split('\n').slice(0, 3).join(' / ').slice(0, 400)); }
}

/* ---------- measuring code that runs inside the page ---------- */
export function measure(opts) {
  const vw = window.innerWidth, vh = window.innerHeight;
  const de = document.documentElement;
  const isVisible = (e) => {
    if (!e.getClientRects().length) return false;
    const cs = getComputedStyle(e);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return false;
    if (e.closest('.sr, [hidden], [aria-hidden="true"][inert]')) return false;
    const r = e.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  };
  const sel = (e) => {
    let s = e.tagName.toLowerCase();
    if (e.id) s += '#' + e.id;
    if (e.className && typeof e.className === 'string') s += '.' + e.className.trim().split(/\s+/).slice(0, 3).join('.');
    return s;
  };
  const snip = (e) => (e.innerText || e.getAttribute('aria-label') || e.alt || '').replace(/\s+/g, ' ').trim().slice(0, 40);
  const clippedByAncestor = (e) => {
    for (let p = e.parentElement; p && p !== document.body && p !== de; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.position === 'fixed') return true;
      if (/(hidden|clip)/.test(cs.overflowX) && /ellipsis/.test(cs.textOverflow)) return true;   // text that is cut with "..." on purpose
      // a box that scrolls on purpose excuses what is inside it; a box that just cuts ("overflow:hidden") does NOT: cut-off content is a bug
      if (/(auto|scroll)/.test(cs.overflowX) && p.getBoundingClientRect().right <= vw + 1) return true;
    }
    return false;
  };
  const all = [...document.body.querySelectorAll('*')].filter((e) => !/^(SCRIPT|STYLE|LINK|META|TITLE|HEAD|NOSCRIPT|TEMPLATE|DEFS|PATH|G|CIRCLE|RECT|LINE|POLYGON|TSPAN)$/i.test(e.tagName));

  /* 1. sideways scroll, too-wide elements */
  const out = { vw, vh, docW: de.scrollWidth, docH: de.scrollHeight, bodyW: document.body.scrollWidth, scrollY: window.scrollY };
  out.wide = [];
  for (const e of all) {
    if (!isVisible(e)) continue;
    const r = e.getBoundingClientRect();
    if (getComputedStyle(e).position === 'fixed') continue;
    if (clippedByAncestor(e)) continue;
    if (r.width > vw + 1 || r.right > vw + 1) out.wide.push(`${sel(e)} "${snip(e)}" w=${Math.round(r.width)} right=${Math.round(r.right)}`);
  }

  /* 2. clipped text in buttons / chips */
  out.clipped = [];
  for (const e of document.body.querySelectorAll('button, .btn, .chip, a.btn, [role=button], .mi, .badge-new, .count, label.switch .lbl, select, input[type=text], input[type=button], summary')) {
    if (!isVisible(e)) continue;
    const cs = getComputedStyle(e);
    if (cs.display === 'inline') continue;
    if (e.matches('.ellipsis, .clamp2, [data-clip-ok]') || e.closest('.ellipsis, .clamp2, [data-clip-ok]')) continue;
    if (/ellipsis/.test(cs.textOverflow) || cs.webkitLineClamp !== 'none' && cs.webkitLineClamp) continue;
    if (e.tagName === 'INPUT' || e.tagName === 'SELECT') continue;
    // (Chromium reports scrollWidth/Height including the border for flex boxes: allow for the border widths)
    const bx = (parseFloat(cs.borderLeftWidth) || 0) + (parseFloat(cs.borderRightWidth) || 0), by = (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
    const dx = e.scrollWidth - e.clientWidth - bx, dy = e.scrollHeight - e.clientHeight - by;
    // text that spills a few pixels out of a box that does not cut it (overflow visible) is not clipped: 6 px of slack; a box that cuts gets 1 px
    const cuts = /(hidden|clip)/.test(cs.overflowX);
    if (dx > (cuts ? 1 : 6) || (dy > 1 && /(hidden|clip)/.test(cs.overflowY))) out.clipped.push(`${sel(e)} "${snip(e)}" scrollW=${e.scrollWidth}>${e.clientWidth} scrollH=${e.scrollHeight}>${e.clientHeight}`);
  }

  /* 2b. text cut off by any box that hides its overflow (cards, tiles, placeholders, rows) */
  out.cut = [];
  for (const e of all) {
    if (!isVisible(e)) continue;
    const cs = getComputedStyle(e);
    if (!/(hidden|clip)/.test(cs.overflowX + ' ' + cs.overflowY)) continue;
    if (e.matches('.ellipsis, .clamp2, [data-clip-ok], .sr, img, svg, canvas, picture') || e.closest('.ellipsis, .clamp2, [data-clip-ok]')) continue;
    if (/ellipsis/.test(cs.textOverflow) || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none')) continue;
    if (e.querySelector('.ellipsis, .clamp2, [data-clip-ok]') && !e.textContent.trim()) continue;
    if (e.clientWidth <= 2 && e.clientHeight <= 2) continue;   // a 1 px "read out loud only" box
    const dx = e.scrollWidth - e.clientWidth, dy = e.scrollHeight - e.clientHeight;
    if ((dx > 2 && /(hidden|clip)/.test(cs.overflowX)) || (dy > 2 && /(hidden|clip)/.test(cs.overflowY))) {
      // is there real text in the cut part? look at the text nodes' own boxes
      let cutText = '';
      const w2 = document.createTreeWalker(e, NodeFilter.SHOW_TEXT);
      const er = e.getBoundingClientRect();
      for (let n = w2.nextNode(); n; n = w2.nextNode()) {
        if (!n.nodeValue.trim()) continue;
        const pe = n.parentElement; if (!pe || !isVisible(pe)) continue;
        const range = document.createRange(); range.selectNodeContents(n);
        const rr = range.getBoundingClientRect();
        if (!rr.width) continue;
        if (rr.right > er.right + 1.5 || rr.bottom > er.bottom + 1.5 || rr.left < er.left - 1.5 || rr.top < er.top - 1.5) { cutText = n.nodeValue.trim().slice(0, 30); break; }
      }
      if (cutText) out.cut.push(`${sel(e)} cuts "${cutText}" (scroll ${e.scrollWidth}x${e.scrollHeight} > box ${e.clientWidth}x${e.clientHeight})`);
    }
  }

  /* 3. contrast */
  const cv = document.createElement('canvas'); cv.width = cv.height = 1;
  const cx = cv.getContext('2d', { willReadFrequently: true });
  const rgba = (c) => { cx.clearRect(0, 0, 1, 1); cx.fillStyle = '#000'; cx.fillStyle = c; cx.fillRect(0, 0, 1, 1); const d = cx.getImageData(0, 0, 1, 1).data; return [d[0], d[1], d[2], d[3] / 255]; };
  const over = (top, bot) => { const a = top[3] + bot[3] * (1 - top[3]); if (!a) return [0, 0, 0, 0]; return [0, 1, 2].map((i) => (top[i] * top[3] + bot[i] * bot[3] * (1 - top[3])) / a).concat([a]); };
  const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  const ratio = (a, b) => { const la = lum(a), lb = lum(b); return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05); };
  const bgOf = (e) => {
    let layers = [], unknown = false;
    for (let p = e; p; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.backgroundImage && cs.backgroundImage !== 'none') { unknown = true; break; }
      const c = rgba(cs.backgroundColor);
      if (c[3] > 0) { layers.push(c); if (c[3] >= 1) break; }
    }
    let base = [255, 255, 255, 1];
    for (let i = layers.length - 1; i >= 0; i--) base = over(layers[i], base);
    return { bg: base, unknown };
  };
  const opac = (e) => { let o = 1; for (let p = e; p; p = p.parentElement) o *= Number(getComputedStyle(p).opacity); return o; };
  out.contrast = []; let nText = 0, minRatio = 99;
  const seen = new Set();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    if (!n.nodeValue.trim()) continue;
    const e = n.parentElement;
    if (!e || seen.has(e) || /^(SCRIPT|STYLE|OPTION|TITLE)$/.test(e.tagName)) continue;
    seen.add(e);
    if (!isVisible(e)) continue;
    if (e.closest(':disabled, [aria-disabled="true"], [data-contrast-ok]')) continue;
    const cs = getComputedStyle(e);
    const { bg, unknown } = bgOf(e);
    if (unknown) continue;
    let fg = rgba(cs.color); fg = [fg[0], fg[1], fg[2], fg[3] * opac(e)];
    const eff = over(fg, bg);
    const r = ratio(eff, bg);
    const px = parseFloat(cs.fontSize), bold = Number(cs.fontWeight) >= 700;
    const need = (px >= 24 || (px >= 18.66 && bold)) ? 3 : 4.5;
    nText++; minRatio = Math.min(minRatio, r / need * 4.5);
    if (r < need - 0.01) out.contrast.push({ ratio: Math.round(r * 100) / 100, need, el: sel(e), text: n.nodeValue.trim().slice(0, 30), fg: cs.color, bg: `rgb(${bg.slice(0, 3).map(Math.round)})` });
  }
  out.nText = nText; out.contrast.sort((a, b) => a.ratio - b.ratio);

  /* 3b. things drawn on top of each other: any two blocks of text / buttons / pictures that are not inside one another must not intersect by more than 2 px in both directions */
  const flowing = (e) => { for (let p = e; p && p !== document.body; p = p.parentElement) { const pos = getComputedStyle(p).position; if (pos === 'fixed' || pos === 'sticky' || pos === 'absolute') return false; } return true; };
  const hasOwnText = (e) => { for (const n of e.childNodes) if (n.nodeType === 3 && n.nodeValue.trim()) return true; return false; };
  const root = document.getElementById('qt-view') || document.body;
  const cand = [];
  for (const e of root.querySelectorAll('*')) {
    if (/^(SCRIPT|STYLE|PATH|G|CIRCLE|RECT|LINE|POLYGON|TSPAN|OPTION|BR|SVG|USE)$/i.test(e.tagName)) continue;
    const cs0 = getComputedStyle(e);
    if (cs0.display === 'inline' || cs0.display === 'contents' || cs0.display === 'none') continue;
    if (!(hasOwnText(e) || /^(BUTTON|INPUT|TEXTAREA|SELECT|IMG)$/.test(e.tagName) || e.getAttribute('role') === 'progressbar')) continue;
    if (!isVisible(e) || !flowing(e) || e.closest('.sr, .toast, .toasts, [role=tooltip], .qtl, [data-overlap-ok]')) continue;
    { const d = e.closest('details:not([open])'); if (d && !(e.closest('summary') && e.closest('summary').parentElement === d)) continue; }   // folded away
    const r = e.getBoundingClientRect();
    if (r.width < 3 || r.height < 3) continue;
    cand.push({ e, r });
  }
  out.overlap = [];
  for (let i = 0; i < cand.length && out.overlap.length < 8; i++) for (let j = i + 1; j < cand.length; j++) {
    const a = cand[i], b = cand[j];
    if (a.e.contains(b.e) || b.e.contains(a.e)) continue;
    const w = Math.min(a.r.right, b.r.right) - Math.max(a.r.left, b.r.left), hh = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
    if (w > 2 && hh > 2) { out.overlap.push(`${sel(a.e)} "${snip(a.e)}" and ${sel(b.e)} "${snip(b.e)}" overlap by ${Math.round(w)}x${Math.round(hh)} px`); if (out.overlap.length >= 8) break; }
  }
  /* the story paragraphs of a question must be there, inside the window and not covered by something else */
  out.story = null;
  const st = root.querySelector('.qv-story');
  if (st) {
    const r = st.getBoundingClientRect();
    const first = st.querySelector('p') || st; const fr = first.getBoundingClientRect();
    const pts = [[fr.left + 8, fr.top + Math.min(8, fr.height / 2)], [fr.left + fr.width / 2, fr.top + Math.min(8, fr.height / 2)], [fr.right - 8, fr.top + Math.min(8, fr.height / 2)]];
    let covered = 0, tested = 0;
    for (const [x, y] of pts) { if (x < 0 || x > innerWidth || y < 0 || y > innerHeight) continue; tested++; const t = document.elementFromPoint(x, y); if (!(t && st.contains(t))) covered++; }
    out.story = { w: Math.round(r.width), h: Math.round(r.height), left: Math.round(r.left), right: Math.round(r.right), vw: innerWidth, covered, tested, shown: isVisible(st), text: st.innerText.trim().slice(0, 30) };
  }

  /* 4. the question bar and the key controls */
  const qb = document.querySelector('#qt-view .qbar');
  if (qb) { const r = qb.getBoundingClientRect(); out.qbar = { top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height), left: Math.round(r.left), right: Math.round(r.right), text: qb.innerText.replace(/\s+/g, ' ').slice(0, 160), hasChip: !!qb.querySelector('.chip, [class*=chip], [class*=status]') }; }
  const view = document.getElementById('qt-view') || document.body;
  const pos = (e) => { const r = e.getBoundingClientRect(); return { l: Math.round(r.left), t: Math.round(r.top + window.scrollY), r: Math.round(r.right), b: Math.round(r.bottom + window.scrollY), w: Math.round(r.width), h: Math.round(r.height) }; };
  const imgs = [...view.querySelectorAll('img')].filter(isVisible);
  out.imgs = imgs.map((e) => Object.assign(pos(e), { alt: (e.alt || '').slice(0, 20) }));
  const btns = [...view.querySelectorAll('button, a.btn, [role=button]')].filter((e) => isVisible(e) && !e.closest('.qbar'));
  out.btns = btns.map((e) => Object.assign(pos(e), { text: snip(e) }));
  out.tiles = view.querySelectorAll('.qtv-grid > *').length;
  out.ansBtns = [...view.querySelectorAll('.qa button, .qa-choice')].filter(isVisible).map((e) => Object.assign(pos(e), { text: snip(e) }));
  out.lastBottom = Math.max(0, ...out.btns.map((b) => b.b), ...out.imgs.map((i) => i.b));
  const lastEl = view.lastElementChild; out.viewBottom = Math.round(view.getBoundingClientRect().bottom + window.scrollY);
  return out;
}

/* scroll everything that can scroll to the very bottom; returns how far */
export function scrollAll() {
  const els = [document.scrollingElement, document.getElementById('qt-main')].filter(Boolean);
  let moved = 0;
  for (const e of els) { const before = e.scrollTop; e.scrollTop = e.scrollHeight; moved = Math.max(moved, e.scrollTop - before); }
  window.scrollTo(0, 1e7);
  return Math.max(moved, window.scrollY);
}
export function qbarState() {
  const qb = document.querySelector('#qt-view .qbar'); if (!qb) return null;
  const r = qb.getBoundingClientRect(); const cx = Math.round(r.left + Math.min(r.width / 2, 40)), cy = Math.round(r.top + r.height / 2);
  const top = document.elementFromPoint(cx, cy);
  const tb = document.querySelector('header, .topbar'); const tbr = tb ? tb.getBoundingClientRect() : { bottom: 0 };
  return { top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height), vh: innerHeight, visible: r.height > 0 && r.top >= -1 && r.bottom <= innerHeight + 1, covered: !(top && (qb.contains(top))), underTopbar: Math.round(tbr.bottom) };
}

