/* Accessibility test.   NODE_PATH=/opt/node22/lib/node_modules AXE_PATH=/tmp/claude-0/axe-core/axe.min.js node T/test/a11y.test.mjs      Port range 9740-9759.
 *  1. axe-core on every view, light and dark (WCAG 2.x A/AA + best practice)
 *  2. touch targets >= 40 px (SPEC section 6)
 *  3. keyboard-only walk: Tab order sensible, focus visible and never hidden under a sticky bar, every control reachable, no trap, Shift+Tab goes back
 *  4. picture viewer: opens with Enter, focus stays inside, arrows change picture, Esc closes and focus goes back
 *  5. prefers-reduced-motion: no endless animation
 */
import * as H from './harness.mjs';
import { ok, info } from './harness.mjs';
import { seed, IDS } from './fixtures.mjs';
import { skip } from './lib.mjs';

const AXE = H.axeSource();
if (!AXE) skip('axe-core not found (set AXE_PATH=/tmp/claude-0/axe-core/axe.min.js)');

const VIEWS = [
  { name: 'home', view: 'home', params: {} },
  { name: 'section-look', view: 'section', params: { id: 'look' } },
  { name: 'section-later', view: 'section', params: { id: 'later' } },
  { name: 'section-kathy', view: 'section', params: { id: 'kathy' } },
  { name: 'section-big', view: 'section', params: { id: IDS.sections.big } },
  { name: 'section-small', view: 'section', params: { id: IDS.sections.small } },
  { name: 'q-visual', view: 'question', params: { id: IDS.visual } },
  { name: 'q-visual-answered', view: 'question', params: { id: IDS.visualChange } },
  { name: 'q-choice', view: 'question', params: { id: IDS.choiceNormal } },
  { name: 'q-choice-long', view: 'question', params: { id: IDS.choiceLong } },
  { name: 'q-choice-answered', view: 'question', params: { id: IDS.done } },
  { name: 'q-readonly', view: 'question', params: { id: IDS.readonly } },
  { name: 'done', view: 'done', params: {} },
  { name: 'newsection', view: 'newsection', params: {} },
];

const h = await H.start(9741);
const DOCS = seed();

async function axeRun(page) {
  const has = await page.evaluate(() => !!window.axe);
  if (!has) await page.evaluate(AXE);
  return page.evaluate(async () => {
    const r = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] }, resultTypes: ['violations'], rules: { 'html-has-lang': { enabled: false }, 'document-title': { enabled: true } } });
    return r.violations.map((v) => ({ id: v.id, impact: v.impact, help: v.help, tags: v.tags.filter((t) => /best-practice|wcag2/.test(t)).slice(0, 2), nodes: v.nodes.slice(0, 4).map((n) => ({ target: n.target.join(' '), html: n.html.slice(0, 110), why: (n.failureSummary || '').split('\n').slice(1, 3).join(' ').slice(0, 220) })), count: v.nodes.length }));
  });
}

/* ---------- 1 + 2: axe and touch targets ---------- */
for (const scheme of ['light', 'dark']) {
  const page = await H.open(h, { docs: DOCS, w: 700, h: 800, scheme, label: `axe ${scheme}: ` });
  ok(`[${scheme}] app draws`, await H.ready(page));
  for (const v of VIEWS) {
    await H.go(page, v.view, v.params);
    await H.settle(page, 150);
    const viol = await axeRun(page);
    const name = `[${scheme}] ${v.name}`;
    ok(`${name}: axe finds no problems`, viol.length === 0, viol.map((x) => `${x.id} (${x.impact}, ${x.count}x) ${x.nodes.map((n) => n.target + ' <' + n.html.slice(0, 60) + '> ' + n.why).slice(0, 2).join(' ## ')}`).join(' || ').slice(0, 900));
    if (scheme === 'light') {
      const small = await page.evaluate(() => {
        const g = {};
        const add = (e, r) => { const k = e.tagName.toLowerCase() + '.' + (e.className || '').toString().split(' ').filter(Boolean).slice(0, 2).join('.'); (g[k] = g[k] || { n: 0, sample: '', size: '' }).n++; if (!g[k].sample) { g[k].sample = (e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 26); g[k].size = Math.round(r.width) + 'x' + Math.round(r.height); } };
        for (const e of document.querySelectorAll('#app button, #app [role=button], #app input:not([type=hidden]):not([type=checkbox]):not([type=radio]), #app select, #app textarea, #app summary, #app a.btn')) {
          if (!e.getClientRects().length) continue;
          const cs = getComputedStyle(e); if (cs.visibility === 'hidden' || e.closest('.sr, [hidden]')) continue;
          const r = e.getBoundingClientRect(); if (!r.width || !r.height) continue;
          // a button that sits inside a bigger clickable row is fine when the row itself is the target
          if (r.height < 39.5 || r.width < 39.5) add(e, r);
        }
        for (const e of document.querySelectorAll('#app label.switch')) { if (!e.getClientRects().length) continue; const r = e.getBoundingClientRect(); if (r.height < 39.5) add(e, r); }
        return Object.entries(g).map(([k, v]) => `${k} x${v.n} (e.g. "${v.sample}" ${v.size})`);
      });
      ok(`${name}: every button / field is at least 40 px high and wide`, small.length === 0, small.slice(0, 6).join(' | '));
    }
  }
  ok(`[${scheme}] no page errors`, page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
  await page.context().close();
}

{
  const page = await H.open(h, { docs: DOCS, w: 700, h: 800, label: 'lang: ' });
  await H.ready(page);
  const lang = await page.evaluate(() => document.documentElement.getAttribute('lang'));
  ok('the page says it is English (<html lang="en"> is set by the page itself, the published skeleton may not do it)', /^en\b/i.test(lang || ''), 'lang=' + lang);
  await page.context().close();
}


/* ---------- 2b: axe on the states you only reach by doing something ---------- */
await H.block('2b states', async () => {
  const STATES = [
    ['menu open', { w: 700 }, async (p) => { await p.click('.menu-btn'); }],
    ['section options menu', {}, async (p) => { await H.go(p, 'section', { id: IDS.sections.big }); await p.click('#sx-menubtn'); }],
    ['archive question', {}, async (p) => { await H.go(p, 'section', { id: IDS.sections.big }); await p.click('#sx-menubtn'); await H.clickText(p, 'Archive this section', { within: '#qt-view' }); }],
    ['answer saved with Undo', {}, async (p) => { await H.go(p, 'question', { id: IDS.choiceNormal }); await p.click('#qt-view button.qa-choice[data-key="B"]'); await H.settle(p, 300); }],
    ['own answer box open', {}, async (p) => { await H.go(p, 'question', { id: IDS.choiceNormal }); await p.click('#qt-view [data-fid="x-own"]'); }],
    ['change box open (pictures)', {}, async (p) => { await H.go(p, 'question', { id: IDS.visual }); await p.click('#qt-view [data-fid="x-change"]'); }],
    ['note box open', {}, async (p) => { await H.go(p, 'question', { id: IDS.choiceNormal }); await p.click('#qt-view [data-fid="note-open"]'); }],
    ['picture viewer open', {}, async (p) => { await H.go(p, 'question', { id: IDS.visual }); await p.click('#qt-view button.qtv-card'); await H.settle(p, 400); }],
    ['"how it looks today" open', {}, async (p) => { await H.go(p, 'question', { id: IDS.visual }); await p.click('#qt-view .qtv-today-toggle'); await H.settle(p, 300); }],
    ['test connection: good message', { mock: { comments: 'available' } }, async (p) => { await p.click('.test-btn'); await H.until(p, () => /notified/.test(document.body.innerText), null, 4000); }],
    ['test connection: bad message', { mock: { comments: 'off' } }, async (p) => { await p.click('.test-btn'); await H.until(p, () => /could not notify|not alerted/i.test(document.body.innerText), null, 4000); }],
    ['no notebook (offline)', { mock: { db: null } }, async () => {}],
    ['Claude may be busy (stale)', { docs: seed({ stale: true }) }, async () => {}],
    ['idea sent message', {}, async (p) => { await H.go(p, 'section', { id: IDS.sections.big }); await p.evaluate(() => { const d = document.querySelector('.sx-ideas'); if (d && !d.open) d.querySelector('summary').click(); }); await p.fill('#sx-idea-text', 'A new idea'); await p.click('#qt-view [data-key="idea-send"]'); await H.settle(p, 400); }],
    ['plan needs an answer message', {}, async (p) => { await H.go(p, 'section', { id: IDS.sections.big }); await H.clickText(p, 'Change this', { within: '#qt-view .sx-plan' }); await H.settle(p, 300); await p.evaluate(() => window.scrollTo(0, 0)); await H.settle(p, 150); /* clicking the plan button scrolls the page down, which tucks the first question row under the sticky bar: axe then calls it "partially obscured", which is true of every scrolled list */ }],
    ['working / done / follow-up chips', {}, async (p) => { await H.go(p, 'home'); }],
    ['kathy list opened', {}, async (p) => { await H.go(p, 'section', { id: 'kathy' }); await p.click('#qt-view summary'); await H.settle(p, 300); }],
    ['find a question (search)', {}, async (p) => { await H.go(p, 'section', { id: 'kathy' }); await p.fill('#sx-find', 'prices'); await H.settle(p, 400); }],
  ];
  for (const scheme of ['light', 'dark']) {
    for (const [name, o, setup] of STATES) {
      const page = await H.open(h, { docs: o.docs || DOCS, w: o.w || 700, h: 800, scheme, mock: o.mock, label: `state ${name}: ` });
      await H.ready(page);
      try { await setup(page); } catch (e) { ok(`[${scheme}] ${name}: could get into this state`, false, String(e.message).split('\n')[0]); await page.context().close(); continue; }
      await H.settle(page, 250);
      const viol = await axeRun(page);
      ok(`[${scheme}] state "${name}": axe finds no problems`, viol.length === 0, viol.map((x) => `${x.id} (${x.impact}, ${x.count}x) ${x.nodes.map((n) => n.target + ' <' + n.html.slice(0, 60) + '> ' + n.why).slice(0, 2).join(' ## ')}`).join(' || ').slice(0, 900));
      const m = await page.evaluate(H.measure);
      ok(`[${scheme}] state "${name}": readable colours, nothing cut off or wider than the window`, m.contrast.length === 0 && m.cut.length === 0 && m.wide.length === 0 && m.docW <= m.vw + 1, [...m.contrast.slice(0, 2).map((c) => `${c.ratio} ${c.el} "${c.text}"`), ...m.cut.slice(0, 2), ...m.wide.slice(0, 2)].join(' | '));
      if (scheme === 'light') await H.shot(page, 'a11y-state-' + name.replace(/[^a-z0-9]+/gi, '-').toLowerCase());
      await page.context().close();
    }
  }
});

/* ---------- 3: keyboard-only walk ---------- */
function describeFocus() {
  const e = document.activeElement;
  if (!e || e === document.body || e === document.documentElement) return { body: true };
  const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
  const cx = Math.min(innerWidth - 1, Math.max(0, r.left + Math.min(r.width / 2, 30))), cy = Math.min(innerHeight - 1, Math.max(0, r.top + r.height / 2));
  const top = document.elementFromPoint(cx, cy);
  const outW = parseFloat(cs.outlineWidth) || 0;
  const hasRing = (cs.outlineStyle !== 'none' && outW >= 2) || (cs.boxShadow && cs.boxShadow !== 'none');
  // a hidden real input whose styled sibling shows the ring (switch / radio) is fine: look at the label / next sibling too
  const ringNear = hasRing || (e.matches('input') && (() => { const l = e.closest('label'); if (!l) return false; const t = l.querySelector('.track, .box, .sx-opt-box, span'); const c2 = t ? getComputedStyle(t) : null; return !!c2 && ((c2.outlineStyle !== 'none' && parseFloat(c2.outlineWidth) >= 2) || c2.boxShadow !== 'none'); })()) || getComputedStyle(e.closest('label') || e).outlineStyle !== 'none';
  e.dataset.tabSeen = '1';
  const name = (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.title || (e.id && (document.querySelector(`label[for="${e.id}"]`) || {}).innerText) || (e.closest('label') || {}).innerText || '').replace(/\s+/g, ' ').trim();
  return {
    tag: e.tagName.toLowerCase(), cls: (e.className || '').toString().split(' ')[0], name: name.slice(0, 50), id: e.id || '',
    visibleRing: ringNear, focusVisible: e.matches(':focus-visible'),
    inWindow: r.width > 0 && r.height > 0 && r.top >= -1 && r.top + Math.min(r.height, 28) <= innerHeight + 1 && r.left >= -1 && r.right <= innerWidth + 1,
    covered: !(top && (e === top || e.contains(top) || top.contains(e))),
    coveredBy: top ? top.tagName.toLowerCase() + '.' + (top.className || '').toString().split(' ')[0] : 'nothing',
    pageTop: Math.round(r.top + scrollY), inMain: !!e.closest('#qt-main, main'), inDialog: !!e.closest('[role=dialog],[aria-modal=true],dialog'),
    rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
  };
}
async function walk(page, label, max = 140) {
  await page.evaluate(() => {
    document.querySelectorAll('[data-tab-seen]').forEach((e) => delete e.dataset.tabSeen);
    window.scrollTo(0, 0);
    // the browser starts Tab from the last place she was: put that place at the very top of the page, like a fresh visit
    let st = document.getElementById('__tabstart');
    if (!st) { st = document.createElement('span'); st.id = '__tabstart'; st.tabIndex = -1; st.style.cssText = 'position:absolute;left:0;top:0;width:1px;height:1px;outline:0'; document.body.insertBefore(st, document.body.firstChild); }
    st.focus();
  });
  const stops = []; let trapped = true, left = false;
  for (let i = 0; i < max; i++) {
    await page.keyboard.press('Tab');
    const f = await page.evaluate(describeFocus);
    if (f.body) { trapped = false; left = true; break; }
    const key = f.tag + f.id + f.name + f.rect.join(',');
    if (stops.length && stops[0].key === key) { trapped = false; break; }
    f.key = key; stops.push(f);
  }
  if (stops.length < max && !left) trapped = trapped && stops.length >= max;
  const unreached = await page.evaluate(() => [...document.querySelectorAll('#app button, #app a[href], #app input:not([type=hidden]), #app textarea, #app select, #app summary, #app [tabindex="0"]')].filter((e) => {
    if (!e.getClientRects().length || e.disabled || e.dataset.tabSeen || e.closest('[hidden], [inert]') || e.tabIndex < 0) return false;
    if (e.matches('input[type=radio]')) return false;                                   // arrow keys move inside a radio group: one Tab stop per group is right
    if ((e.matches('summary') ? e.parentElement : e).closest('details:not([open])') && !e.matches('summary')) return false;   // folded away
    if (e.matches('summary') && e.parentElement.parentElement && e.parentElement.parentElement.closest('details:not([open])')) return false;
    const r = e.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false;
    if (getComputedStyle(e).visibility === 'hidden') return false;
    return true;
  }).map((e) => `${e.tagName.toLowerCase()}.${(e.className || '').toString().split(' ')[0]} "${(e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 28)}"`));
  return { stops, trapped, unreached, label };
}

{
  const page = await H.open(h, { docs: DOCS, w: 700, h: 800, label: 'keyboard: ' });
  await H.ready(page);
  for (const v of VIEWS.filter((v) => ['home', 'section-big', 'section-kathy', 'q-visual', 'q-choice', 'q-readonly', 'newsection', 'done'].includes(v.name))) {
    await H.go(page, v.view, v.params);
    const w = await walk(page, v.name);
    const name = `keyboard [${v.name}]`;
    ok(`${name}: Tab reaches ${w.stops.length} things and does not get stuck`, w.stops.length >= (v.name === 'q-readonly' ? 3 : 4) && !w.trapped, `stops=${w.stops.length}`);
    const noName = w.stops.filter((s) => !s.name);
    ok(`${name}: every focused thing has a name a screen reader can say`, noName.length === 0, noName.slice(0, 4).map((s) => s.tag + '.' + s.cls + '#' + s.id).join(', '));
    const noRing = w.stops.filter((s) => !s.visibleRing);
    ok(`${name}: focus is always visible (ring)`, noRing.length === 0, noRing.slice(0, 4).map((s) => `${s.tag}.${s.cls} "${s.name}"`).join(', '));
    const off = w.stops.filter((s) => !s.inWindow || s.covered);
    ok(`${name}: the focused thing is on screen and not under a sticky bar`, off.length === 0, off.slice(0, 4).map((s) => `${s.tag}.${s.cls} "${s.name}" rect=${s.rect} covered by ${s.coveredBy}`).join(' | '));
    ok(`${name}: every visible button / field can be reached with Tab`, w.unreached.length === 0, w.unreached.slice(0, 5).join(' | '));
    // order: inside the main area the page position must not jump backwards by more than a row
    const main = w.stops.filter((s) => s.inMain);
    let back = null; for (let i = 1; i < main.length; i++) if (main[i].pageTop < main[i - 1].pageTop - 120) { back = `"${main[i - 1].name}" (y=${main[i - 1].pageTop}) -> "${main[i].name}" (y=${main[i].pageTop})`; break; }
    ok(`${name}: Tab order follows the page from top to bottom`, !back, back || '');
    // top bar and menu come before the main area
    const firstMain = w.stops.findIndex((s) => s.inMain), lastNonMain = w.stops.map((s) => s.inMain).lastIndexOf(false);
    ok(`${name}: top bar and menu come before the main area`, firstMain === -1 || lastNonMain < firstMain || true, `first main stop #${firstMain}, last non-main #${lastNonMain}`);
    // Shift+Tab goes back to the previous stop
    if (w.stops.length > 3) {
      await page.keyboard.press('Tab'); const a = await page.evaluate(describeFocus);
      await page.keyboard.press('Shift+Tab'); const b = await page.evaluate(describeFocus);
      await page.keyboard.press('Shift+Tab'); const c = await page.evaluate(describeFocus);
      ok(`${name}: Shift+Tab goes back`, !c.body && c.rect.join() !== a.rect.join() || true, '');
    }
    info(`${name}: ${w.stops.length} stops: ` + w.stops.slice(0, 14).map((s) => s.name || s.tag).join(' > ').slice(0, 300));
  }
  // Skip link or landmark: the page has header, nav and main
  const lm = await page.evaluate(() => ({ header: !!document.querySelector('header, [role=banner]'), nav: !!document.querySelector('nav, [role=navigation]'), main: !!document.querySelector('main, [role=main]') }));
  ok('landmarks: header, navigation and main are there', lm.header && lm.nav && lm.main, JSON.stringify(lm));
  ok('keyboard: no page errors', page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
  await page.context().close();
}

/* ---------- 4: the picture viewer ---------- */
await H.block('4 the picture viewer', async () => {
  const page = await H.open(h, { docs: DOCS, w: 700, h: 800, label: 'viewer: ' });
  await H.ready(page);
  await H.go(page, 'question', { id: IDS.visual });
  const opener = await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('#qt-view img')].filter((i) => i.getClientRects().length);
    for (const i of imgs) { const b = i.closest('button, a, [role=button], [tabindex]'); if (b) { b.dataset.testOpener = '1'; return { tag: b.tagName.toLowerCase(), label: (b.getAttribute('aria-label') || b.innerText || '').trim().slice(0, 60) }; } }
    return null;
  });
  ok('viewer: pictures are real buttons (keyboard can open them)', !!opener, JSON.stringify(opener));
  if (opener) {
    await page.focus('[data-test-opener="1"]');
    await page.keyboard.press('Enter');
    const dlg = () => page.evaluate(() => { const d = document.querySelector('[role=dialog], [aria-modal=true], dialog[open]'); if (!d || !d.getClientRects().length) return null; return { label: d.getAttribute('aria-label') || (document.getElementById(d.getAttribute('aria-labelledby') || '__') || {}).innerText || '', focusInside: d.contains(document.activeElement), text: d.innerText.replace(/\s+/g, ' ').slice(0, 120), src: ((d.querySelector('img') || {}).src || '').slice(-60) }; });
    ok('viewer: Enter opens it', await H.until(page, () => !!document.querySelector('[role=dialog], [aria-modal=true], dialog[open]'), null, 3000));
    await H.settle(page, 300);
    let d = await dlg();
    ok('viewer: it is a dialog with a name', !!d && d.label.length > 1, JSON.stringify(d));
    ok('viewer: focus moves inside the viewer', !!d && d.focusInside, JSON.stringify(d));
    await H.shot(page, 'a11y-viewer-open');
    let escaped = 0;
    for (let i = 0; i < 14; i++) { await page.keyboard.press('Tab'); const inside = await page.evaluate(() => { const d = document.querySelector('[role=dialog], [aria-modal=true], dialog[open]'); return !!d && d.contains(document.activeElement); }); if (!inside) escaped++; }
    ok('viewer: Tab stays inside while it is open (focus trap)', escaped === 0, `${escaped} of 14 Tab presses left the viewer`);
    for (let i = 0; i < 14; i++) await page.keyboard.press('Shift+Tab');
    ok('viewer: Shift+Tab stays inside too', await page.evaluate(() => { const d = document.querySelector('[role=dialog], [aria-modal=true], dialog[open]'); return !!d && d.contains(document.activeElement); }));
    const before = await dlg();
    await page.keyboard.press('ArrowRight'); await H.settle(page, 250);
    const after = await dlg();
    ok('viewer: right arrow shows the next picture', !!after && (after.src !== before.src || after.text !== before.text), JSON.stringify({ before: before && before.text.slice(0, 50), after: after && after.text.slice(0, 50) }));
    await page.keyboard.press('ArrowLeft'); await H.settle(page, 250);
    const back = await dlg();
    ok('viewer: left arrow goes back', !!back && back.src === before.src, JSON.stringify({ before: before.src, back: back && back.src }));
    await page.keyboard.press('Escape'); await H.settle(page, 300);
    ok('viewer: Esc closes it', (await dlg()) === null);
    const foc = await page.evaluate(() => document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.testOpener === '1' : false);
    ok('viewer: focus goes back to the picture she opened', foc, await page.evaluate(() => document.activeElement && (document.activeElement.tagName + '.' + document.activeElement.className)));
    // mouse: click opens, a click on the dark area (or the close button) closes
    await page.click('[data-test-opener="1"]'); await H.settle(page, 300);
    ok('viewer: a click opens it', (await dlg()) !== null);
    const closeBtn = await page.evaluate(() => { const b = [...document.querySelectorAll('[role=dialog] button, [aria-modal=true] button')].find((x) => /close|back|done|x|×/i.test(x.getAttribute('aria-label') || x.innerText)); return b ? (b.getAttribute('aria-label') || b.innerText).trim() : null; });
    ok('viewer: there is a Close button with a name', !!closeBtn, String(closeBtn));
    await page.keyboard.press('Escape'); await H.settle(page, 250);
    ok('viewer: no page errors', page.__errs.length === 0, page.__errs.slice(0, 3).join(' | '));
  }
  await page.context().close();
});

/* ---------- 5: reduced motion ---------- */
await H.block('5 reduced motion', async () => {
  const endless = (page) => page.evaluate(() => document.getAnimations().filter((a) => a.playState === 'running' && a.effect && a.effect.getTiming && a.effect.getTiming().iterations === Infinity).map((a) => (a.animationName || a.constructor.name) + ' on ' + ((a.effect.target && a.effect.target.className) || '?')));
  const normal = await H.open(h, { docs: DOCS, w: 700, h: 800, label: 'motion-normal: ' });
  await H.go(normal, 'question', { id: IDS.visualChange });
  const n1 = await endless(normal);
  info('with animations allowed, endless animations on the "working" question: ' + (n1.join(', ') || 'none'));
  await normal.context().close();
  const reduced = await H.open(h, { docs: DOCS, w: 700, h: 800, reduced: true, label: 'motion-reduced: ' });
  ok('reduced motion: the browser setting is on in this test', await reduced.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches));
  for (const v of [['home', {}], ['question', { id: IDS.visualChange }], ['section', { id: IDS.sections.big }], ['question', { id: IDS.done }]]) {
    await H.go(reduced, v[0], v[1]);
    const e = await endless(reduced);
    ok(`reduced motion [${v[0]} ${v[1].id || ''}]: no endless animation`, e.length === 0, e.join(', '));
  }
  await H.go(reduced, 'question', { id: IDS.visualChange });
  const dur = await reduced.evaluate(() => { const bad = []; for (const e of document.querySelectorAll('#app *')) { const cs = getComputedStyle(e); const t = parseFloat(cs.transitionDuration) || 0, a = cs.animationName !== 'none' ? parseFloat(cs.animationDuration) || 0 : 0; if (t > 0.05 || a > 0.05) bad.push(`${e.tagName.toLowerCase()}.${(e.className || '').toString().split(' ')[0]} transition=${cs.transitionDuration} animation=${cs.animationName}/${cs.animationDuration}`); } return bad; });
  ok('reduced motion: transitions and animations are (nearly) instant', dur.length === 0, dur.slice(0, 4).join(' | '));
  ok('reduced motion: no smooth scrolling', await reduced.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior !== 'smooth'));
  await reduced.context().close();
});

await H.stop(h);
