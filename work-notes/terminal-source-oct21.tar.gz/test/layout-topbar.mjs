/* Top bar at many widths on the real page: nothing overflows or is clipped, the bar is exactly 44px, labels shrink in the right order.  Port 9205. */
import * as H from './harness.mjs';
import { seed } from './fixtures.mjs';
const { ok, info } = H;
const h = await H.start(9205);
for (const stale of [false, true]) {
  const p = await H.open(h, { docs: seed({ stale }), w: 700, h: 800 });
  for (const w of [320, 360, 400, 440, 520, 560, 640, 700, 740, 760, 780, 800, 820, 900, 1000, 1100, 1200, 1366]) {
    await p.setViewportSize({ width: w, height: 800 }); await H.settle(p, 100);
    const r = await p.evaluate(() => {
      const bar = document.querySelector('.topbar'), out = { barH: bar.getBoundingClientRect().height, bad: [], hb: '', brand: '' };
      const W = document.documentElement.clientWidth;
      if (bar.scrollWidth > bar.clientWidth) out.bad.push('bar scrolls ' + bar.scrollWidth + '>' + bar.clientWidth);
      for (const e of bar.querySelectorAll('.btn, .brand, .live, .hb, .brand-t')) {
        const b = e.getBoundingClientRect(); if (!b.width) continue;
        if (b.right > W + 0.5 || b.left < -0.5) out.bad.push(e.className + ' outside window');
        if (e.classList.contains('btn') && e.scrollWidth > e.clientWidth + 1) out.bad.push(e.className + ' clipped ' + e.scrollWidth + '>' + e.clientWidth);
        if ((e.classList.contains('brand-t') || (e.classList.contains('live') && getComputedStyle(e.querySelector('.live-t')).display !== 'none')) && e.scrollWidth > e.clientWidth + 1) out.bad.push(e.className + ' text clipped');
      }
      const wh0 = bar.querySelector('.hb-when'), hb0 = bar.querySelector('.hb');
      if (wh0 && !hb0.hidden) { const a = wh0.getBoundingClientRect(), b = hb0.getBoundingClientRect(); if (!(a.width > 0 && a.right <= b.right + 1 && hb0.scrollWidth <= hb0.clientWidth + 1)) out.bad.push('the time ("' + wh0.textContent + '") is cut'); }
      const hb = bar.querySelector('.hb'); out.hbClipped = hb && !hb.hidden && hb.scrollWidth > hb.clientWidth + 1; out.hb = hb ? hb.innerText : '';
      out.test = [...bar.querySelectorAll('.test-btn')].map((b) => b.innerText.trim() + '|' + Math.round(b.getBoundingClientRect().width))[0];
      return out;
    });
    ok(`[${w}px${stale ? ' stale' : ''}] top bar 44px and nothing clipped`, r.barH === 44 && r.bad.length === 0, JSON.stringify(r.bad) + ' h=' + r.barH);
    info(`[${w}px${stale ? ' stale' : ''}] hb="${r.hb}" ${r.hbClipped ? '(ELLIPSIS)' : ''} test=${r.test}`);
  }
  await p.context().close();
}
await H.stop(h);
