/* Tests for the sections helper: QT.sections, QT.views.home / section / done / newsection (T/src/js/30-sections.js).
 *
 *   NODE_PATH=/opt/node22/lib/node_modules node T/test/sections.test.mjs
 *
 * Builds an isolated page (real core + real layout + 30-sections.js + test/sections-stub.js for QT.status and a tiny question view),
 * runs it against the in-memory notebook (test/mock-claude.js) and checks what the page DRAWS and what it WRITES.
 * Port range 9500-9599. Screenshots: T/shots/sections-*.png (700x800 and 1366x768).
 */
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { startServer, launch, ok, info, finish, okSoon, axeSource } from './lib.mjs';
import { injectMock } from './mockfix.mjs';
import { seed, IDS, XSS, waitingCount } from './fixtures.mjs';

const T = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = path.join(T, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

/* ------------------------------------------------------------------ build + browser */
/* QT_FULL=1 runs the same checks against the whole page (every helper's file, real status chips and question view) instead of the isolated build */
const FULL = !!process.env.QT_FULL;
const PAGE = FULL ? 'dist-sections-full/index.html' : 'dist-sections/index.html';   // (a second run at the same time rebuilds the same file: same content, so that is harmless)
try {
  const args = FULL ? ['--out', path.join(T, 'dist-sections-full', 'index.html')]
    : ['--out', path.join(T, 'dist-sections', 'index.html'), '--only', '10-layout.js,30-sections.js', '--extra', path.join(T, 'test', 'sections-stub.js')];
  execFileSync('python3', [path.join(T, 'build.py'), ...args], { cwd: T, stdio: 'pipe' });
} catch (e) { console.log('FAIL the page builds  ' + String(e.stderr || e.message).split('\n').slice(0, 3).join(' | ')); process.exit(1); }
/* my port range is 9500-9599: take the first free one (another run of this test may be going on at the same time) */
let site = null;
const PORT0 = Number(process.env.QT_PORT) || 9500;   // QT_PORT moves the range (another helper's runs use 9500-9599)
for (let port = PORT0; port <= PORT0 + 99 && !site; port++) { try { site = await startServer({ root: T, port }); } catch (e) { /* in use: next */ } }
if (!site) { console.log('FAIL no free port between ' + PORT0 + ' and ' + (PORT0 + 99)); process.exit(1); }
const browser = await launch();
const errs = [];
const NOISE = /fonts\.g|net::ERR|Failed to load resource|favicon/;

async function open(docs, o = {}) {
  const ctx = await browser.newContext({ viewport: { width: o.w || 700, height: o.h || 800 }, colorScheme: o.scheme || 'light', locale: 'en-US', timezoneId: 'America/New_York' });
  const page = await ctx.newPage();
  page.setDefaultTimeout(10000);
  page.on('pageerror', (e) => errs.push((o.label || '') + 'pageerror: ' + e.message));
  page.on('console', (m) => { if ((m.type() === 'error') && !NOISE.test(m.text()) && !(o.allowConsole && o.allowConsole.test(m.text()))) errs.push((o.label || '') + 'console: ' + m.text()); });
  if (o.route) await page.addInitScript((r) => { try { if (!window.localStorage.getItem('qt.route')) window.localStorage.setItem('qt.route', JSON.stringify(r)); } catch (e) { /* none */ } }, o.route);
  if (o.init) await page.addInitScript(o.init);
  await injectMock(page, docs, o.mock || {});
  await page.goto(site.url + PAGE, { waitUntil: 'load' });
  await page.waitForFunction(() => window.QT && window.QT.isReady && document.getElementById('qt-view') && document.getElementById('qt-view').children.length > 0, null, { timeout: 15000 });
  if (o.go) await go(page, o.go[0], o.go[1]);
  await settle(page);
  return page;
}
const settle = (page, n = 120) => page.evaluate((t) => new Promise((r) => requestAnimationFrame(() => setTimeout(r, t))), n).catch(() => {});
const go = async (page, view, params = {}) => { await page.evaluate(([v, p]) => window.QT.route.go(v, p), [view, params]); await settle(page, 150); };
const put = (page, p, d) => page.evaluate(([a, b]) => window.__mock.db.put(a, b), [p, d]);
const remove = (page, p) => page.evaluate((a) => window.__mock.db.remove(a), p);
const dget = (page, p) => page.evaluate((a) => window.__mock.db.get(a), p);
const writes = (page) => page.evaluate(() => window.__mock.writes.slice());
const clearWrites = (page) => page.evaluate(() => { window.__mock.writes.length = 0; });
const view = (page) => page.evaluate(() => { const e = document.getElementById('qt-view'); return e ? e.innerText.replace(/\s+/g, ' ').trim() : ''; });
const V = (page) => page.locator('#qt-view');
const route = (page) => page.evaluate(() => window.QT.route.current());
const iso = (msAgo = 0) => new Date(Date.now() - msAgo).toISOString();
const shot = async (page, name, full = false) => { try { await page.screenshot({ path: path.join(SHOTS, 'sections-' + name + '.png'), fullPage: full }); } catch (e) { /* closed */ } };
const noScrollX = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
const hasText = async (page, t) => (await view(page)).includes(t);
const textSoon = (name, page, t, gone = false) => okSoon(name, () => view(page), (v) => v.includes(t) !== gone, 6000);

/* the default notebook of the tests: 4 built-in sections, Account features (big, with plan + ideas), Gift shop (small), 30 read-only questions */
const D = () => seed();
/* the "Your ideas (N)" box is folded once an idea was sent: open it before typing in it */
const openIdeas = async (page) => { if (!(await page.locator('.sx-ideas').evaluate((e) => e.open))) await page.locator('.sx-ideas > summary').click(); await settle(page, 60); };

/* ================================================================== 1. QT.sections */
{
  const page = await open(D(), { label: 'api ' });
  const api = (fn, ...a) => page.evaluate(([f, args]) => { const S = window.QT.sections; return S[f](...args); }, [fn, a]);
  const ids = (l) => l.map((x) => x.id);
  ok('sections.list(): built-in sections first, then her own, by order', JSON.stringify(ids(await api('list'))) === JSON.stringify(['look', 'other', 'later', 'kathy', 'account-features', 'gift-shop']), JSON.stringify(ids(await api('list'))));
  ok('sections.questionsOf(): by order', JSON.stringify(ids(await api('questionsOf', 'account-features'))) === JSON.stringify(IDS.big), JSON.stringify(ids(await api('questionsOf', 'account-features'))));
  ok('sections.questionsOf(): empty for an unknown section', (await api('questionsOf', 'nope')).length === 0);
  const pr = await api('progress', 'account-features');
  ok('sections.progress(): 2 of 4 important questions (af-6 is not required and counts for nothing)', pr.requiredTotal === 4 && pr.requiredAnswered === 2, JSON.stringify(pr));
  const pr0 = await api('progress', 'look');
  ok('sections.progress(): 0 of 0 where nothing is required', pr0.requiredTotal === 0 && pr0.requiredAnswered === 0, JSON.stringify(pr0));
  ok('sections.isBig(): big / small / unknown', (await api('isBig', 'account-features')) === true && (await api('isBig', 'gift-shop')) === false && (await api('isBig', 'nope')) === false);

  ok('nextUnanswered: next one in the same section', (await api('nextUnanswered', 'c-short')) === 'c-normal', await api('nextUnanswered', 'c-short'));
  ok('nextUnanswered: skips answered questions', (await api('nextUnanswered', 'c-xss')) === 'c-followup-2', await api('nextUnanswered', 'c-xss'));
  ok('nextUnanswered: after the last unanswered one in a section it goes back to an earlier one in the same section', (await api('nextUnanswered', 'c-followup-2')) === 'c-short', await api('nextUnanswered', 'c-followup-2'));
  ok('nextUnanswered: never the question itself', (await api('nextUnanswered', 'v-map-1')) !== 'v-map-1');
  ok('nextUnanswered: v-map-1 -> the first unanswered of the next section with one', (await api('nextUnanswered', 'v-map-1')) === 'c-short', await api('nextUnanswered', 'v-map-1'));
  ok('nextUnanswered: unknown or empty id gives the first unanswered question of all', (await api('nextUnanswered', 'nope')) === 'v-map-1' && (await api('nextUnanswered', null)) === 'v-map-1');
  ok('nextUnanswered: from a read-only question goes on to the next section that has something', (await api('nextUnanswered', 'k01')) === 'af-3', await api('nextUnanswered', 'k01'));
  const all = await page.evaluate(() => { const S = window.QT.sections, Q = window.QT.store.questions, bad = []; Object.keys(Q).forEach((id) => { const n = S.nextUnanswered(id); if (n) { const q = Q[n]; if (q.kind === 'readonly' || q.sectionId === 'kathy' || window.QT.store.answers[n]) bad.push(id + '->' + n); } }); return bad; });
  ok('nextUnanswered: never returns a read-only or an answered question (checked from every question)', all.length === 0, all.slice(0, 4).join(' '));
  /* everything answered -> null */
  const allAns = D();
  Object.values(allAns).forEach((d) => { if (d && d.sectionId && d.kind !== 'readonly' && !allAns['answers/' + d.id] && allAns['questions/' + d.id]) allAns['answers/' + d.id] = { id: d.id, status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: 'x', answeredAt: iso(1000), round: 1 }; });
  for (const id of Object.keys(allAns)) if (id.startsWith('questions/') && allAns[id].kind !== 'readonly' && !allAns['answers/' + allAns[id].id]) allAns['answers/' + allAns[id].id] = { id: allAns[id].id, status: 'answered', key: 'A', ownText: '', changeText: '', note: '', label: 'x', answeredAt: iso(1000), round: 1 };
  const p2 = await open(allAns, { label: 'all answered ' });
  ok('nextUnanswered: null when nothing is left', (await p2.evaluate(() => window.QT.sections.nextUnanswered('gs-2'))) === null && (await p2.evaluate(() => window.QT.sections.nextUnanswered('nope'))) === null);
  await p2.context().close();
  /* closed by Claude without an answer does not count as waiting */
  await put(page, 'status/c-short', { id: 'c-short', state: 'done', seenAt: iso(), note: '', doneNote: 'Not needed any more', doneImages: [], followupId: null, at: iso() });
  await settle(page);
  ok('nextUnanswered: a question Claude closed ("done") is not waiting', (await api('nextUnanswered', 'v-map-1')) === 'c-normal' && (await api('waiting', 'other')).every((q) => q.id !== 'c-short'));
  /* progress follows the answers */
  await put(page, 'answers/af-3', { id: 'af-3', status: 'answered', key: 'A', label: 'Yes', answeredAt: iso(), round: 1 });
  await settle(page);
  const pr3 = await api('progress', 'account-features');
  ok('sections.progress(): moves when she answers', pr3.requiredAnswered === 3, JSON.stringify(pr3));
  /* "not sure", "explain" and "change" replies are not answers for a Big section */
  await put(page, 'answers/af-4', { id: 'af-4', status: 'answered', key: 'unsure', label: "I'm not sure yet", answeredAt: iso(), round: 1 });
  await settle(page);
  const pr4 = await api('progress', 'account-features');
  ok('sections.progress(): "I\'m not sure yet" does not count as an answer (same rule Claude uses to start)', pr4.requiredAnswered === 3 && pr4.requiredTotal === 4, JSON.stringify(pr4));
  ok('sections.pendingRequired(): counts the important questions that only have such a reply', (await api('pendingRequired', 'account-features')) === 1);
  await put(page, 'answers/af-4', { id: 'af-4', status: 'answered', key: 'change', label: 'x', answeredAt: iso(), round: 1 });
  await settle(page);
  ok('sections.progress(): "change this" does not count either', (await api('progress', 'account-features')).requiredAnswered === 3);
  await put(page, 'answers/af-4', { id: 'af-4', status: 'answered', key: 'own', ownText: 'My words', label: 'My words', answeredAt: iso(), round: 1 });
  await settle(page);
  ok('sections.progress(): a typed answer counts', (await api('progress', 'account-features')).requiredAnswered === 4);
  /* archived sections leave the list */
  await put(page, 'sections/gift-shop', { ...(await dget(page, 'sections/gift-shop')), archived: true });
  await settle(page);
  ok('sections.list(): an archived section is left out', !ids(await api('list')).includes('gift-shop'));
  await page.context().close();
}

/* ================================================================== 2. Home */
{
  const page = await open(D(), { label: 'home ', route: { view: 'home', params: {} } });
  const t = await view(page);
  ok('home: friendly greeting', t.includes('Hi! Here is what is waiting for you.'));
  ok('home: one compact card per section (6)', (await page.locator('.sx-sec').count()) === 6, String(await page.locator('.sx-sec').count()));
  ok('home: an "Answer" button on every section that has waiting questions (5)', (await page.locator('.sx-sec button', { hasText: /^Answer$/ }).count()) === 5);
  ok('home: each card shows its waiting count', (await page.locator('.sx-sec', { hasText: 'Look and feel' }).innerText()).includes('1 waiting') && (await page.locator('.sx-sec', { hasText: 'Other questions' }).innerText()).includes('5 waiting'));
  ok('home: the read-only pile is shown as "to read only" with a Read button', (await page.locator('.sx-sec', { hasText: 'Miss Cathy' }).innerText()).includes('To read only') && (await page.locator('.sx-sec', { hasText: 'Miss Cathy' }).locator('button', { hasText: 'Read' }).count()) === 1);
  ok('home: the plan that waits for her is pointed out', (await page.locator('.sx-sec', { hasText: 'Account features' }).innerText()).includes('Plan to read'));
  ok('home: "Claude is working on" lists the working questions with the note', t.includes('Claude is working on') && t.includes('Which menu picture do you like?') && t.includes('Making version B bigger') && t.includes('Thinking about what the sign-up needs'));
  ok('home: "Recently finished" shows what Claude did', t.includes('Recently finished') && t.includes('The opening hours are now bigger on every page.'));
  ok('home: says how many answers Claude has not looked at yet', t.includes('You answered 3 questions that Claude has not looked at yet'), t.slice(0, 300));
  ok('home: not "all caught up" while things wait', !t.includes('You are all caught up'));
  await shot(page, 'home-700');
  await page.locator('.sx-sec', { hasText: 'Look and feel' }).locator('button', { hasText: /^Answer$/ }).click();
  await settle(page);
  const r = await route(page);
  ok('home: Answer opens the first unanswered question of that section', r.view === 'question' && r.params.id === IDS.visual, JSON.stringify(r));
  await go(page, 'home');
  await page.locator('.sx-sec', { hasText: 'Account features' }).locator('button', { hasText: /^Answer$/ }).click();
  await settle(page);
  ok('home: Answer in Account features opens af-3 (the first one without an answer)', (await route(page)).params.id === 'af-3');
  await go(page, 'home');
  await page.locator('.sx-sec', { hasText: 'Miss Cathy' }).locator('button', { hasText: 'Read' }).click();
  await settle(page);
  ok('home: Read opens the read-only section', JSON.stringify(await route(page)) === JSON.stringify({ view: 'section', params: { id: 'kathy' } }));
  await go(page, 'home');
  await page.locator('.sx-working .sx-q').first().click();
  await settle(page);
  ok('home: a working question opens when clicked', (await route(page)).view === 'question');
  await go(page, 'home');
  /* a paused section (Ideas for later) is still counted and answerable, but its card is calm */
  await put(page, 'sections/later', { ...(await dget(page, 'sections/later')), hold: true });
  await settle(page, 200);
  const lc = page.locator('.sx-sec', { hasText: 'Ideas for later' });
  ok('home: a paused section keeps its waiting count', (await lc.innerText()).includes('2 waiting') && (await view(page)).includes('12 questions are waiting'));
  ok('home: ... but its button is a calm "Open", not a red "Answer"', (await lc.locator('button', { hasText: /^Open$/ }).count()) === 1 && (await lc.locator('button.primary').count()) === 0 && (await lc.getAttribute('class')).includes('is-parked') && !(await lc.getAttribute('class')).includes('has-waiting'));
  ok('home: Open goes to the section, where its questions can be answered', await (async () => { await lc.locator('button', { hasText: /^Open$/ }).click(); await settle(page); const r = await route(page); return r.view === 'section' && r.params.id === 'later'; })());
  ok('home: a paused section\'s questions still count for "next question" and the waiting list', (await page.evaluate(() => window.QT.sections.waiting('later').length)) === 2 && (await page.evaluate(() => window.QT.sections.nextUnanswered('l-3'))) === 'l-1');
  await go(page, 'home');
  /* live updates */
  await put(page, 'status/c-short', { id: 'c-short', state: 'working', seenAt: iso(), note: 'Testing a live note', doneNote: '', doneImages: [], followupId: null, at: iso() });
  await textSoon('home: a new "working" status shows up by itself', page, 'Testing a live note');
  await put(page, 'questions/new-live', { id: 'new-live', sectionId: 'other', kind: 'choice', order: 99, createdAt: iso(), title: 'A brand new live question', story: ['x'], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null });
  await okSoon('home: a new question raises the waiting count of its section', () => page.locator('.sx-sec', { hasText: 'Other questions' }).innerText(), (x) => x.includes('6 waiting'), 6000);
  await page.context().close();

  /* the 5 most recent only, newest first */
  const many = D();
  for (let i = 1; i <= 7; i++) {
    many['questions/d' + i] = { id: 'd' + i, sectionId: 'other', kind: 'choice', order: 40 + i, createdAt: iso(1e6), title: 'Finished thing number ' + i, story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null };
    many['answers/d' + i] = { id: 'd' + i, status: 'answered', key: 'A', label: 'x', answeredAt: iso(1e6), round: 1 };
    many['status/d' + i] = { id: 'd' + i, state: 'done', seenAt: iso(9e5), note: '', doneNote: 'Note ' + i, doneImages: i === 7 ? [{ url: PNG, alt: 'Tiny result', w: 1, h: 1 }] : [], followupId: null, at: iso(100 * 1000 * (8 - i)) };
  }
  const p3 = await open(many, { label: 'recent ', route: { view: 'home', params: {} } });
  const rows = await p3.locator('.sx-recent .sx-q .sx-qtitle').allInnerTexts();
  ok('home: "Recently finished" shows the last 5, newest first', rows.length === 5 && rows[0] === 'Finished thing number 7' && rows[4] === 'Finished thing number 3', JSON.stringify(rows));
  ok('home: a done question shows its pictures as small thumbnails', (await p3.locator('.sx-recent .sx-thumbs img, .sx-recent .qtv-results .qtv-mini').count()) === 1);
  await p3.context().close();

  /* nothing waiting */
  const quiet = D();
  for (const k of Object.keys(quiet)) if (k.startsWith('questions/') && quiet[k].kind !== 'readonly') quiet['answers/' + quiet[k].id] = quiet['answers/' + quiet[k].id] || { id: quiet[k].id, status: 'answered', key: 'A', label: 'x', answeredAt: iso(5e5), round: 1 };
  delete quiet['plans/account-features'];
  const p4 = await open(quiet, { label: 'quiet ', route: { view: 'home', params: {} } });
  const tq = await view(p4);
  ok('home: "You are all caught up. 🎉" when nothing waits', tq.includes('You are all caught up. 🎉') && (await p4.locator('.sx-sec button', { hasText: /^Answer$/ }).count()) === 0, tq.slice(0, 200));
  await shot(p4, 'home-caughtup-700');
  await p4.context().close();

  /* empty states */
  const p5 = await open({}, { label: 'empty ', route: { view: 'home', params: {} } });
  const te = await view(p5);
  ok('home: brand-new notebook gives a friendly empty state', te.includes('Hi! Here is what is waiting for you.') && te.includes('Nothing is here yet.') && te.includes('+ New section'), te.slice(0, 200));
  await p5.context().close();
  const p6 = await open(seed({ empty: true }), { label: 'sections only ', route: { view: 'home', params: {} } });
  const ts = await view(p6);
  ok('home: sections without questions say so and nothing is "waiting"', ts.includes('You are all caught up') && ts.includes('No questions here yet.'), ts.slice(0, 250));
  await p6.context().close();
  const p7 = await open({}, { label: 'offline ', mock: { db: null }, route: { view: 'home', params: {} }, allowConsole: /./ });
  const to = await view(p7);
  ok('home: with no connection the page shows a heading, "Nothing is lost." and "Try again", and does not repeat the layout banner', to.includes('Your questions') && to.includes('Nothing is lost.') && to.includes('Try again') && !to.includes('No connection') && !to.includes('Hi! Here is what is waiting') && !to.toLowerCase().includes('notebook'), to.slice(0, 200));
  ok('home: ... and nothing that cannot work offline ("+ New section")', !to.includes('+ New section') && (await p7.locator('#qt-view button').count()) === 1);
  await p7.getByRole('button', { name: 'Try again' }).click();
  await okSoon('home: "Try again" while it still does not work says so', () => view(p7), (v) => v.includes('Still not connected.'), 15000);
  await go(p7, 'newsection');
  const nv = await view(p7);
  ok('new section offline: only a calm "Not connected yet." and "Try again" (no form)', nv.includes('Not connected yet.') && !nv.includes('No connection') && (await p7.getByLabel('Name of the section').count()) === 0);
  await p7.evaluate(() => window.__mock.db.setNull(false));
  await p7.getByRole('button', { name: 'Try again' }).click();
  await okSoon('new section: when the connection is back "Try again" shows the form', () => p7.getByLabel('Name of the section').count(), (n) => n === 1, 15000);
  ok('retry: the page is online again (no reload)', (await p7.evaluate(() => window.QT.offline)) === false);
  await go(p7, 'home');
  ok('retry: Home draws the real page again', (await view(p7)).includes('Hi! Here is what is waiting for you.') || (await view(p7)).includes('Nothing is here yet.'));
  await p7.context().close();
}

/* ================================================================== 3. Section view: Account features (big) */
const AF = { view: 'section', params: { id: 'account-features' } };
{
  const page = await open(D(), { label: 'big ', route: AF });
  ok('section: the ideas box is folded ("Your ideas (2)") because ideas were sent', (await page.locator('.sx-ideas > summary').innerText()).includes('Your ideas (2)') && !(await page.locator('.sx-ideas').evaluate((e) => e.open)));
  const ys = await page.evaluate(() => ['.sx-controls', '.sx-progress', '.sx-questions', '.sx-plan', '.sx-ideas'].map((q) => document.querySelector(q).getBoundingClientRect().top));
  ok('section: the order is Size/Pause, progress, the question list, the plan, the ideas', ys.every((y, i) => i === 0 || y > ys[i - 1]), JSON.stringify(ys.map(Math.round)));
  const firstQ = await page.locator('.sx-qgroup .sx-q').first().boundingBox();
  const startBtn = await page.getByRole('button', { name: 'Answer the first one' }).boundingBox();
  ok('section: at 700x800 the first question and "Answer the first one" are on the first screen', firstQ.y + firstQ.height < 800 && startBtn.y + startBtn.height < 800, JSON.stringify([Math.round(firstQ.y), Math.round(startBtn.y)]));
  await shot(page, 'big-700-folded');
  await openIdeas(page);
  const t = await view(page);
  ok('section: title', (await page.locator('#qt-view h1').first().innerText()) === 'Account features');
  const ctl = await page.locator('.sx-controls').textContent();
  ok('section: size switch with the two explanations (the selected one shows, both are under "What is this?")', t.includes('Big: Claude waits for your important answers and your OK on the plan.') && ctl.includes('Small: Claude starts as soon as you answer one question.') && ctl.includes('Big: Claude waits for your important answers and your OK on the plan.') && (await page.locator('.sx-whatbtn').innerText()) === 'What is this?');
  ok('section: "What is this?" opens the three explanations and closes them again', await (async () => {
    const vis = () => page.locator('.sx-what').isVisible();
    const before = await vis(); await page.locator('.sx-whatbtn').click(); await settle(page);
    const during = await vis() && (await page.locator('.sx-whatbtn').getAttribute('aria-expanded')) === 'true';
    await page.locator('.sx-whatbtn').click(); await settle(page);
    return !before && during && !(await vis());
  })());
  const ch = (await page.locator('.sx-controls').boundingBox()).height;
  ok('section: the Size and Pause card is compact (one row + one line, under 100px at 700px wide)', ch <= 100, Math.round(ch) + 'px');
  ok('section: "Big" is the selected size', (await page.locator('.sx-seg button[aria-pressed="true"]').innerText()) === 'Big');
  ok('section: Pause switch is off with the right words', (await page.getByRole('switch', { name: /Pause: do not start anything here/ }).isChecked()) === false);
  ok('section: progress card says 2 of 4 important questions answered', t.includes('Before Claude starts: 2 of 4 important questions answered'));
  const bar = page.locator('.sx-progress [role=progressbar]');
  ok('section: progress bar has the numbers for screen readers', (await bar.getAttribute('aria-valuenow')) === '2' && (await bar.getAttribute('aria-valuemax')) === '4');
  ok('section: plan card with summary, numbered steps and "Claude still needs from you"', t.includes('Claude will add a simple sign-up') && (await page.locator('.sx-steps li').count()) === 4 && t.includes('Claude still needs from you') && (await page.locator('.sx-needs li').count()) === 2);
  ok('section: plan buttons "Looks good, go ahead" and "Change this" + a text box', (await page.getByRole('button', { name: 'Looks good, go ahead' }).count()) === 1 && (await page.getByRole('button', { name: 'Change this' }).count()) === 1 && (await page.locator('.sx-plan textarea').count()) === 1);
  ok('section: ideas box "Tell Claude what you want here" with Save idea and Send to Claude', (await page.getByLabel('Tell Claude what you want here').count()) === 1 && (await page.getByRole('button', { name: 'Save idea' }).count()) === 1 && (await page.getByRole('button', { name: 'Send to Claude' }).count()) === 1);
  ok('section: earlier ideas with their states', t.includes('Claude read it') && t.includes('Questions are ready ↓'));
  const waiting = await page.locator('.sx-qgroup', { hasText: 'Waiting for you' }).locator('.sx-qtitle').allInnerTexts();
  ok('section: the questions she can answer are listed first (af-3, af-4, af-5)', waiting.length === 3 && waiting[0].includes('log in with their email'), JSON.stringify(waiting));
  ok('section: the group "Waiting for you" does not repeat "Waiting for you" on every row', (await page.locator('.sx-qgroup', { hasText: 'Waiting for you' }).locator('.sx-qchip').count()) === 0);
  ok('section: the other group keeps its status chips (they differ)', (await page.locator('.sx-qgroup', { hasText: 'You answered' }).locator('.sx-qchip').count()) === 3);
  await put(page, 'status/af-5', { id: 'af-5', state: 'working', note: 'Looking at it', seenAt: iso(), doneNote: '', doneImages: [], followupId: null, at: iso() });
  await okSoon('section: a waiting question whose status differs (Claude is working on it) keeps its pill', () => page.locator('.sx-q', { hasText: 'show past visits' }).locator('.sx-qchip').count(), (n) => n === 1, 6000);
  await remove(page, 'status/af-5');
  ok('section: answered ones are listed apart ("You answered")', (await page.locator('.sx-qgroup', { hasText: 'You answered' }).locator('.sx-q').count()) === 3);
  ok('section: no page-wide sideways scroll at 700px', await noScrollX(page));
  await shot(page, 'big-700');
  await shot(page, 'big-700-full', true);

  /* a click opens the question */
  await page.locator('.sx-qgroup', { hasText: 'Waiting for you' }).locator('.sx-q').first().click();
  await settle(page);
  ok('section: clicking a question opens it', (await route(page)).params.id === 'af-3');
  await go(page, 'section', { id: 'account-features' });
  await page.getByRole('button', { name: 'Answer the first one' }).click();
  await settle(page);
  ok('section: "Answer the first one" opens the first unanswered question', (await route(page)).params.id === 'af-3');
  await go(page, 'section', { id: 'account-features' });

  /* NEW badge from the status helper */
  if (!FULL) {
    await page.evaluate(() => { window.__new = { 'af-4': true }; });
    await go(page, 'home'); await go(page, 'section', { id: 'account-features' });
    ok('section: a NEW badge on a question she has not opened', (await page.locator('.sx-q', { hasText: 'welcome' }).locator('.badge-new').count()) === 1 && (await page.locator('.badge-new').count()) === 1);
    await page.evaluate(() => { window.__new = {}; });
  } else {
    await put(page, 'questions/af-new', { id: 'af-new', sectionId: 'account-features', kind: 'choice', order: 9, createdAt: iso(), title: 'A question that just arrived', story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'Accounts', oldId: null });
    await okSoon('section: a NEW badge on a question that just arrived', () => page.locator('.sx-q', { hasText: 'just arrived' }).locator('.badge-new').count(), (n) => n === 1, 6000);
    await page.locator('.sx-q', { hasText: 'just arrived' }).click();
    await settle(page);
    await go(page, 'section', { id: 'account-features' });
    ok('section: ... which is gone once she opened it', (await page.locator('.sx-q', { hasText: 'just arrived' }).locator('.badge-new').count()) === 0);
    await remove(page, 'questions/af-new');
  }

  /* pause switch */
  await clearWrites(page);
  await page.getByRole('switch', { name: /Pause/ }).click();
  await okSoon('pause: the switch writes hold:true into the section', async () => (await writes(page)).filter((w) => w.path === 'sections/account-features'), (l) => l.length === 1 && l[0].op === 'update' && l[0].data.hold === true && l[0].data.id === 'account-features' && Object.keys(l[0].data).every((k) => ['id', 'hold'].includes(k)));
  await okSoon('pause: the notebook holds hold:true', () => dget(page, 'sections/account-features'), (d) => d && d.hold === true);
  await textSoon('pause: the page says that Claude waits', page, 'Paused. Claude will not start anything here.');
  ok('pause: the switch is on', await page.getByRole('switch', { name: /Pause/ }).isChecked());
  await page.getByRole('switch', { name: /Pause/ }).click();
  await okSoon('pause: switching it off writes hold:false', () => dget(page, 'sections/account-features'), (d) => d && d.hold === false);
  await textSoon('pause: the "Paused" line goes away', page, 'Paused. Claude will not start', true);

  /* size switch */
  await clearWrites(page);
  await page.locator('.sx-seg button', { hasText: 'Small' }).click();
  await okSoon('size: Small writes size:"small"', async () => (await writes(page)).filter((w) => w.path === 'sections/account-features'), (l) => l.length === 1 && l[0].data.size === 'small' && Object.keys(l[0].data).every((k) => ['id', 'size'].includes(k)));
  await textSoon('size: a Small section has no progress card', page, 'Before Claude starts', true);
  ok('size: the Small button is now selected', (await page.locator('.sx-seg button[aria-pressed="true"]').innerText()) === 'Small');
  await page.locator('.sx-seg button', { hasText: 'Big' }).click();
  await textSoon('size: back to Big, the progress card is back', page, 'Before Claude starts: 2 of 4');

  /* the plan */
  await clearWrites(page);
  await page.getByRole('button', { name: 'Change this' }).click();
  await settle(page);
  ok('plan: "Change this" without words saves nothing and asks for words', (await writes(page)).length === 0 && await hasText(page, 'Please write what should change'));
  await page.locator('.sx-plan textarea').fill('Please leave out the welcome email.');
  await page.getByRole('button', { name: 'Looks good, go ahead' }).click();
  await settle(page);
  ok('plan: "Looks good" with words in the box does not silently drop them', (await writes(page)).length === 0 && await hasText(page, 'You wrote a change'));
  await page.getByRole('button', { name: 'Change this' }).click();
  await okSoon('plan: "Change this" writes the reply with the text', () => dget(page, 'planReplies/account-features'), (d) => d && d.decision === 'change' && d.text === 'Please leave out the welcome email.' && d.version === 1 && d.sectionId === 'account-features' && !isNaN(Date.parse(d.at)));
  await textSoon('plan: shows the decision she gave', page, 'You asked for a change: “Please leave out the welcome email.”');
  ok('plan: until Claude looks it says so', await hasText(page, 'Waiting for Claude to see it'));
  ok('plan: the change box is empty after sending', (await page.locator('.sx-plan textarea').inputValue()) === '');
  await put(page, 'status/plan-account-features', { id: 'plan-account-features', state: 'seen', seenAt: iso(-3000), note: '', at: iso(-3000) });
  await textSoon('plan: "Claude saw it ✓" once Claude has looked', page, 'Claude saw it ✓');
  await clearWrites(page);
  await page.getByRole('button', { name: 'Looks good, go ahead' }).click();
  await okSoon('plan: "Looks good, go ahead" writes decision ok', () => dget(page, 'planReplies/account-features'), (d) => d && d.decision === 'ok' && d.text === '' && d.version === 1);
  await textSoon('plan: shows "You said: Looks good, go ahead ✓"', page, 'You said: Looks good, go ahead ✓');
  ok('plan: the pressed button shows what she chose', (await page.getByRole('button', { name: 'Looks good, go ahead' }).getAttribute('aria-pressed')) === 'true');
  await textSoon('progress: says Claude can start only when all important questions are answered AND the plan is OK', page, 'All set', true);
  /* a new version needs a new answer */
  await put(page, 'plans/account-features', { sectionId: 'account-features', version: 2, summary: 'A new, shorter plan.', steps: ['One step only.'], needs: [], at: iso() });
  await textSoon('plan: a new version replaces the old one', page, 'A new, shorter plan.');
  ok('plan: the new version asks again and remembers what she said before', await hasText(page, 'Plan 2') && await hasText(page, 'Earlier you said: Looks good, go ahead') && (await page.getByRole('button', { name: 'Looks good, go ahead' }).getAttribute('aria-pressed')) === 'false');
  ok('plan: no "Claude still needs from you" when nothing is needed', !(await hasText(page, 'Claude still needs from you')));
  await page.context().close();
}

/* ================================================================== 4. Progress card states + plan missing */
{
  const docs = D();
  delete docs['plans/account-features'];
  docs['answers/af-3'] = { id: 'af-3', status: 'answered', key: 'A', label: 'Yes', answeredAt: iso(5000), round: 1 };
  const page = await open(docs, { label: 'wait-plan ', route: AF });
  ok('progress: 3 of 4', await hasText(page, 'Before Claude starts: 3 of 4 important questions answered') && await hasText(page, 'One more to go.'));
  ok('plan: no plan card while there is no plan', (await page.locator('.sx-plan').count()) === 0);
  await put(page, 'answers/af-4', { id: 'af-4', status: 'answered', key: 'unsure', label: "I'm not sure yet", answeredAt: iso(), round: 1 });
  await textSoon('progress: a "not sure yet" reply is not counted, and the card says Claude will try again', page, 'One answer (“I\'m not sure yet” or “Explain another way”) does not count yet.');
  ok('progress: ... the count stays 3 of 4', await hasText(page, 'Before Claude starts: 3 of 4 important questions answered'));
  await put(page, 'answers/af-4', { id: 'af-4', status: 'answered', key: 'B', label: 'No', answeredAt: iso(), round: 1 });
  await textSoon('progress: everything answered and no plan yet says Claude is writing it', page, 'Waiting for Claude to write the plan');
  await put(page, 'plans/account-features', { sectionId: 'account-features', version: 1, summary: 'Here is the plan.', steps: ['Do it.'], needs: [], at: iso() });
  await textSoon('progress: when the plan arrives it asks her to read it', page, 'Please read the plan below.');
  await page.getByRole('button', { name: 'Looks good, go ahead' }).click();
  await textSoon('progress: "All set" after OK on a complete section', page, 'All set. You said OK to the plan, so Claude can start.');
  await shot(page, 'big-ready-700');
  await page.context().close();
}

/* ================================================================== 5. Ideas */
{
  const page = await open(D(), { label: 'ideas ', route: AF });
  await openIdeas(page);
  const box = page.getByLabel('Tell Claude what you want here');
  await clearWrites(page);
  await page.getByRole('button', { name: 'Send to Claude' }).click();
  await settle(page);
  ok('ideas: an empty idea is not sent, she is asked to type first', (await writes(page)).length === 0 && await hasText(page, 'Please type your idea first.'));
  await box.fill('I want a page where people can see their visits.');
  await page.getByRole('button', { name: 'Send to Claude' }).click();
  await okSoon('ideas: "Send to Claude" saves the idea and sets sentAt', async () => (await writes(page)).filter((w) => w.path.startsWith('ideas/')), (l) => l.length === 2 && l[0].op === 'set' && l[0].data.text === 'I want a page where people can see their visits.' && l[0].data.sectionId === 'account-features' && l[0].data.sentAt === null && l[1].op === 'update' && l[1].path === l[0].path && !isNaN(Date.parse(l[1].data.sentAt)));
  const newId = (await writes(page)).find((w) => w.path.startsWith('ideas/')).path.split('/')[1];
  await okSoon('ideas: the stored idea has text, section and sentAt', () => dget(page, 'ideas/' + newId), (d) => d && d.text === 'I want a page where people can see their visits.' && d.sectionId === 'account-features' && typeof d.sentAt === 'string' && !!d.createdAt);
  await textSoon('ideas: confirms that it was sent', page, 'Sent ✓ Claude will read it soon.');
  ok('ideas: the box is empty again', (await box.inputValue()) === '');
  const row = page.locator('.sx-idea', { hasText: 'I want a page where people can see their visits.' });
  ok('ideas: it is in the list as "Sent"', (await row.count()) === 1 && (await row.innerText()).includes('Sent') && !(await row.innerText()).includes('Draft'));
  await put(page, 'ideaStatus/' + newId, { id: newId, state: 'read', at: iso(), note: '' });
  await okSoon('ideas: "Claude read it" shows when Claude has read it', () => row.innerText(), (x) => x.includes('Claude read it'), 6000);
  await put(page, 'ideaStatus/' + newId, { id: newId, state: 'questionsReady', at: iso(), note: 'I wrote 3 questions.' });
  await okSoon('ideas: "Questions are ready ↓" when Claude made questions', () => row.innerText(), (x) => x.includes('Questions are ready ↓') && x.includes('I wrote 3 questions.'), 6000);

  /* draft: save, edit, send */
  await clearWrites(page);
  await box.fill('A first thought');
  await page.getByRole('button', { name: 'Save idea' }).click();
  await okSoon('ideas: "Save idea" writes a draft (sentAt empty)', async () => (await writes(page)).filter((w) => w.path.startsWith('ideas/')), (l) => l.length === 1 && l[0].op === 'set' && l[0].data.text === 'A first thought' && l[0].data.sentAt === null);
  const dId = (await writes(page)).find((w) => w.path.startsWith('ideas/')).path.split('/')[1];
  const drow = page.locator('.sx-idea', { hasText: 'A first thought' });
  await okSoon('ideas: the draft is listed as "Draft" with Edit and Send buttons', () => drow.innerText(), (x) => x.includes('Draft') && x.includes('Edit') && x.includes('Send to Claude'), 6000);
  ok('ideas: after saving, the box is empty', (await box.inputValue()) === '');
  await drow.getByRole('button', { name: 'Edit' }).click();
  await settle(page);
  const edit = page.getByLabel('Edit this idea');
  ok('ideas: Edit opens the draft text in a box', (await edit.inputValue()) === 'A first thought');
  await edit.fill('A better thought');
  await page.getByRole('button', { name: 'Save changes' }).click();
  await okSoon('ideas: the edited draft is saved', () => dget(page, 'ideas/' + dId), (d) => d && d.text === 'A better thought' && d.sentAt === null);
  await page.locator('.sx-idea', { hasText: 'A better thought' }).getByRole('button', { name: 'Send to Claude' }).click();
  await okSoon('ideas: sending a draft sets sentAt', () => dget(page, 'ideas/' + dId), (d) => d && typeof d.sentAt === 'string');
  await okSoon('ideas: it is no longer a draft', () => page.locator('.sx-idea', { hasText: 'A better thought' }).innerText(), (x) => x.includes('Sent') && !x.includes('Draft') && !x.includes('Edit'), 6000);
  await shot(page, 'ideas-700', true);

  /* only the 3 newest ideas, the rest on request */
  ok('ideas: only the newest 3 are shown at first, with "Show all"', (await page.locator('.sx-ideas .sx-idea').count()) === 3 && (await page.getByRole('button', { name: /Show all 4 ideas/ }).count()) === 1);
  await page.getByRole('button', { name: /Show all 4 ideas/ }).click();
  await settle(page);
  ok('ideas: "Show all" shows them all', (await page.locator('.sx-ideas .sx-idea').count()) === 4);
  await page.context().close();
}

/* ================================================================== 6. No text lost when the notebook changes */
{
  const page = await open(seed({ draftIdea: true }), { label: 'keep ', route: AF });
  await openIdeas(page);
  const box = page.getByLabel('Tell Claude what you want here');
  await box.click();
  await box.fill('This is half of an idea that I am still typing');
  await page.evaluate(() => { const t = document.getElementById('sx-idea-text'); t.setSelectionRange(8, 12); });
  /* Claude changes many things at once */
  await put(page, 'ideaStatus/idea-2', { id: 'idea-2', state: 'questionsReady', at: iso(), note: 'Done' });
  await put(page, 'ideas/idea-3', { id: 'idea-3', sectionId: 'account-features', text: 'Added by another window', createdAt: iso(), sentAt: iso() });
  await put(page, 'questions/af-7', { id: 'af-7', sectionId: 'account-features', kind: 'choice', order: 7, createdAt: iso(), title: 'A new question from Claude', story: [], choices: [], required: true, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'Accounts', oldId: null });
  await put(page, 'status/af-3', { id: 'af-3', state: 'working', note: 'x', seenAt: iso(), at: iso() });
  await put(page, 'plans/account-features', { sectionId: 'account-features', version: 1, summary: 'Changed summary text.', steps: ['A', 'B'], needs: [], at: iso() });
  await textSoon('keep: the page really redrew (new question appears)', page, 'A new question from Claude');
  await textSoon('keep: ... and the new idea', page, 'Added by another window');
  const st = await page.evaluate(() => { const t = document.getElementById('sx-idea-text'); return { v: t.value, focus: document.activeElement === t, s: t.selectionStart, e: t.selectionEnd }; });
  ok('keep: the idea box keeps its text', st.v === 'This is half of an idea that I am still typing', st.v);
  ok('keep: ... and the cursor and the selection', st.focus && st.s === 8 && st.e === 12, JSON.stringify(st));
  /* plan box */
  const pbox = page.locator('.sx-plan textarea');
  await pbox.click(); await pbox.fill('Half a change request');
  await put(page, 'status/af-4', { id: 'af-4', state: 'working', note: 'y', seenAt: iso(), at: iso() });
  await put(page, 'plans/account-features', { sectionId: 'account-features', version: 1, summary: 'Changed again.', steps: ['A', 'B', 'C'], needs: ['Something'], at: iso() });
  await textSoon('keep: the plan card redrew', page, 'Changed again.');
  const st2 = await page.evaluate(() => { const t = document.querySelector('.sx-plan textarea'); return { v: t.value, focus: document.activeElement === t }; });
  ok('keep: the plan change box keeps its text and focus', st2.v === 'Half a change request' && st2.focus, JSON.stringify(st2));
  /* edit box of a draft */
  await page.locator('.sx-idea', { hasText: 'A draft idea that is not sent yet.' }).getByRole('button', { name: 'Edit' }).click();
  const ed = page.getByLabel('Edit this idea');
  await ed.fill('Editing this draft right now');
  await put(page, 'ideaStatus/idea-1', { id: 'idea-1', state: 'read', at: iso(), note: '' });
  await settle(page, 200);
  ok('keep: a draft that is being edited keeps its text', (await page.getByLabel('Edit this idea').inputValue()) === 'Editing this draft right now');
  /* the text survives leaving the section and coming back */
  await go(page, 'home');
  await go(page, 'section', { id: 'account-features' });
  ok('keep: text typed in the idea box is still there after a trip to another page', (await page.getByLabel('Tell Claude what you want here').inputValue()) === 'This is half of an idea that I am still typing');
  ok('keep: ... and in the plan box', (await page.locator('.sx-plan textarea').inputValue()) === 'Half a change request');
  await page.context().close();
}

/* ================================================================== 7. Menu: rename, archive, bring back */
{
  const page = await open(D(), { label: 'menu ', route: AF });
  await page.getByRole('button', { name: 'More options for this section' }).click();
  ok('menu: opens with Rename and Hide', (await page.getByRole('menuitem').allInnerTexts()).join('|') === 'Rename this section|Hide this section');
  await page.keyboard.press('Escape');
  await settle(page);
  ok('menu: Escape closes it', (await page.getByRole('menuitem').count()) === 0);
  await page.getByRole('button', { name: 'More options for this section' }).click();
  await page.getByRole('menuitem', { name: 'Rename this section' }).click();
  await settle(page);
  const inp = page.getByLabel('New name for this section');
  ok('rename: the name is in a box, ready to change', (await inp.inputValue()) === 'Account features');
  await clearWrites(page);
  await inp.fill('Visitor accounts');
  await put(page, 'status/af-5', { id: 'af-5', state: 'seen', note: '', seenAt: iso(), at: iso() });
  await settle(page, 200);
  ok('rename: the box keeps what she typed when the notebook changes', (await page.getByLabel('New name for this section').inputValue()) === 'Visitor accounts');
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  await okSoon('rename: writes only the new title', async () => (await writes(page)).filter((w) => w.path === 'sections/account-features'), (l) => l.length === 1 && l[0].data.title === 'Visitor accounts' && Object.keys(l[0].data).every((k) => ['id', 'title'].includes(k)));
  await okSoon('rename: the heading changes', () => page.locator('#qt-view h1').first().innerText(), (x) => x === 'Visitor accounts');
  /* archive */
  await clearWrites(page);
  await page.getByRole('button', { name: 'More options for this section' }).click();
  await page.getByRole('menuitem', { name: 'Hide this section' }).click();
  await settle(page);
  ok('archive: asks first', await hasText(page, 'Hide this section? It goes away from the menu.'));
  await page.getByRole('button', { name: 'Keep it' }).click();
  await settle(page);
  ok('archive: "Keep it" changes nothing', (await writes(page)).length === 0 && !(await hasText(page, 'Hide this section? It goes')));
  await page.getByRole('button', { name: 'More options for this section' }).click();
  await page.getByRole('menuitem', { name: 'Hide this section' }).click();
  await page.getByRole('button', { name: 'Hide it' }).click();
  await okSoon('archive: writes archived:true', () => dget(page, 'sections/account-features'), (d) => d && d.archived === true);
  await okSoon('archive: goes back to the home page', () => route(page), (r) => r.view === 'home');
  await textSoon('archive: the section is left out of the home list', page, 'Visitor accounts', true);
  ok('archive: a "Hidden sections (1)" box offers to bring it back', (await page.locator('.sx-archived summary').innerText()).includes('Hidden sections (1)'));
  await page.locator('.sx-archived summary').click();
  await page.getByRole('button', { name: 'Bring it back' }).click();
  await okSoon('archive: "Bring it back" writes archived:false', () => dget(page, 'sections/account-features'), (d) => d && d.archived === false);
  await okSoon('archive: ... and opens the section', () => route(page), (r) => r.view === 'section' && r.params.id === 'account-features');
  ok('menu: a built-in section has no rename/hide menu', await (async () => { await go(page, 'section', { id: 'other' }); return (await page.getByRole('button', { name: 'More options for this section' }).count()) === 0; })());
  await page.context().close();
}

/* ================================================================== 8. Other built-in sections */
{
  const page = await open(D(), { label: 'builtin ', route: { view: 'section', params: { id: 'later' } } });
  ok('later: has the ideas box', (await page.getByLabel('Tell Claude what you want here').count()) === 1);
  ok('later: lists its questions (one topic at a time: the first topic with something waiting is open)', await hasText(page, 'Add a newsletter sign-up some day?') && !(await hasText(page, 'Add a blog with farm stories?')));
  await page.getByRole('button', { name: 'Show everything' }).click(); await settle(page, 80);
  ok('later: ... and "Show everything" lists all of them', await hasText(page, 'Add a newsletter sign-up some day?') && await hasText(page, 'Add a blog with farm stories?') && await hasText(page, 'Sell gift cards online some day?'));
  await page.getByRole('button', { name: 'One topic at a time' }).click(); await settle(page, 80);
  ok('later: parked: no Size switch, no Pause switch, no progress card', (await page.getByRole('switch').count()) === 0 && (await page.locator('.sx-seg').count()) === 0 && !(await hasText(page, 'Before Claude starts')) && (await page.locator('.sx-progress').count()) === 0);
  ok('later: a calm line says that nothing starts here', await hasText(page, 'Saved for later. Nothing starts here until you say so.') && !(await hasText(page, 'Answering here never changes the real website')));
  await shot(page, 'later-700');
  await go(page, 'section', { id: 'look' });
  ok('look: no ideas box (only her own sections and "later" have one)', (await page.getByLabel('Tell Claude what you want here').count()) === 0 && await hasText(page, 'Which map picture do you like best for the home page?'));
  ok('look: a Small section shows no progress card', !(await hasText(page, 'Before Claude starts')));
  await shot(page, 'look-700');
  await go(page, 'section', { id: 'gift-shop' });
  ok('small custom section: ideas box, no progress card, no plan', (await page.getByLabel('Tell Claude what you want here').count()) === 1 && !(await hasText(page, 'Before Claude starts')) && (await page.locator('.sx-plan').count()) === 0 && await hasText(page, 'Should the gift shop show prices?'));
  await shot(page, 'small-700');
  await go(page, 'section', { id: 'no-such-section' });
  ok('unknown section: says so and offers a way back', await hasText(page, 'That section is not here.') && (await page.getByRole('button', { name: 'Back to the start' }).count()) === 1);
  await page.context().close();

  /* a new custom section without anything in it */
  const d = D();
  d['sections/fresh'] = { id: 'fresh', title: 'Fresh topic', kind: 'custom', order: 20, size: 'big', hold: false, readOnly: false, blurb: '', archived: false, createdAt: iso(), createdBy: 'owner' };
  const p2 = await open(d, { label: 'fresh ', route: { view: 'section', params: { id: 'fresh' } } });
  ok('empty section: tells her to write an idea', await hasText(p2, 'No questions yet. Write your idea above and press “Send to Claude”.'));
  ok('empty Big section: no progress card while nothing important is asked', await !(await hasText(p2, 'Before Claude starts')) && (await p2.locator('.sx-progress').count()) === 0);
  await shot(p2, 'fresh-700');
  await p2.context().close();
}

/* ================================================================== 8b. One topic at a time */
{
  const LATER = { view: 'section', params: { id: 'later' } };
  const chips = (page) => page.locator('.sx-tchip').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label') + (e.getAttribute('aria-selected') === 'true' ? ' *' : '')));
  const lsGet = (page, k) => page.evaluate((x) => { try { return window.localStorage.getItem(x); } catch (e) { return null; } }, k);
  const page = await open(D(), { label: 'topics ', route: LATER });
  ok('topics: a strip of chips, one per topic, each says how many are waiting', JSON.stringify(await chips(page)) === JSON.stringify(['Newsletter, 1 waiting *', 'Shop, 1 waiting', 'Stories, nothing waiting']), JSON.stringify(await chips(page)));
  ok('topics: the chips are tabs of a tab list, and the open topic is the first one with something waiting', (await page.locator('[role=tablist] > [role=tab]').count()) === 3 && (await page.locator('.sx-tchip.on').innerText()).includes('Newsletter'));
  ok('topics: the chip shows the number (a tick when nothing waits)', JSON.stringify(await page.locator('.sx-tchip .count').allInnerTexts()) === JSON.stringify(['1', '1', '✓']));
  ok('topics: only that topic\'s questions are in the list', (await page.locator('.sx-q').count()) === 1 && await hasText(page, 'Add a newsletter sign-up some day?') && !(await hasText(page, 'Sell gift cards online')));
  const tp = await page.evaluate(() => { const t = document.querySelector('[role=tabpanel]'); const sel = document.querySelector('.sx-tchip.on'); return { lab: t && t.getAttribute('aria-labelledby') === sel.id, ctl: sel.getAttribute('aria-controls') === t.id, tabs: [...document.querySelectorAll('.sx-tchip')].map((e) => e.tabIndex) }; });
  ok('topics: the panel is named by the chosen tab; only the chosen tab is in the tab order', tp.lab && tp.ctl && JSON.stringify(tp.tabs) === JSON.stringify([0, -1, -1]), JSON.stringify(tp));
  ok('topics: "Next topic" comes after the last question and names the next topic', (await page.getByRole('button', { name: 'Next topic: Shop' }).count()) === 1);
  await shot(page, 'topics-later-700');

  /* choosing a topic, and "Next topic" */
  await page.getByRole('button', { name: 'Next topic: Shop' }).click(); await settle(page, 100);
  ok('topics: "Next topic" opens the next topic', (await chips(page)).join('|') === 'Newsletter, 1 waiting|Shop, 1 waiting *|Stories, nothing waiting' && await hasText(page, 'Sell gift cards online some day?') && !(await hasText(page, 'Add a newsletter sign-up')));
  ok('topics: ... and the next one after Shop skips the finished topic and goes round to Newsletter', (await page.getByRole('button', { name: 'Next topic: Newsletter' }).count()) === 1);
  ok('topics: the topic she opened is remembered for this section', (await lsGet(page, 'qt.topic.later')) === 'Shop');
  await go(page, 'home'); await go(page, 'section', { id: 'later' });
  ok('topics: ... also after leaving the section and coming back', (await page.locator('.sx-tchip.on').innerText()).includes('Shop'));
  await page.reload({ waitUntil: 'load' });
  await page.waitForFunction(() => window.QT && window.QT.isReady && document.querySelector('.sx-tchip'), null, { timeout: 15000 });
  ok('topics: ... also after the page is opened again', (await page.locator('.sx-tchip.on').innerText()).includes('Shop'));
  await page.locator('.sx-tchip', { hasText: 'Stories' }).click(); await settle(page, 100);
  ok('topics: a chip opens its topic (also one with nothing waiting, with a calm line)', await hasText(page, 'Add a blog with farm stories?') && await hasText(page, 'Nothing is waiting for you in this topic.') && (await page.locator('.sx-tchip.on').innerText()).includes('Stories'));
  ok('topics: ... and then "Next topic" is the main button (this topic is finished)', (await page.locator('.sx-nexttopic .btn.primary').count()) === 1);

  /* the last question she opened sets the topic of the section */
  await page.locator('.sx-tchip', { hasText: 'Newsletter' }).click(); await settle(page, 80);
  await go(page, 'question', { id: 'l-2' }); await go(page, 'section', { id: 'later' });
  ok('topics: coming back from a question, its topic is open', (await page.locator('.sx-tchip.on').innerText()).includes('Shop'), await page.locator('.sx-tchip.on').innerText());

  /* "Answer the first one" is the first waiting question of the open topic */
  await page.getByRole('button', { name: 'Answer the first one' }).click(); await settle(page, 100);
  const r = await route(page);
  ok('topics: "Answer the first one" opens the first waiting question of this topic', r.view === 'question' && r.params.id === 'l-2', JSON.stringify(r));
  await go(page, 'section', { id: 'later' });

  /* live counts */
  await put(page, 'answers/l-2', { id: 'l-2', status: 'answered', key: 'A', label: 'Yes, later', answeredAt: iso(), round: 1 });
  await okSoon('topics: counts change at once when she answers (Shop is finished)', () => chips(page), (c) => c.join('|') === 'Newsletter, 1 waiting|Shop, nothing waiting *|Stories, nothing waiting', 6000);
  ok('topics: ... the open topic says nothing waits and its question is under "You answered"', await hasText(page, 'Nothing is waiting for you in this topic.') && await hasText(page, 'You answered'));
  await remove(page, 'answers/l-2');
  await okSoon('topics: ... and back again if the answer goes away', () => chips(page), (c) => c.join('|') === 'Newsletter, 1 waiting|Shop, 1 waiting *|Stories, nothing waiting', 6000);
  await put(page, 'questions/l-4', { id: 'l-4', sectionId: 'later', kind: 'choice', order: 4, createdAt: iso(), title: 'Add a map of the farm?', story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'Maps', oldId: null });
  await okSoon('topics: a question with a new topic adds a chip while she looks', () => chips(page), (c) => c.length === 4 && c[3] === 'Maps, 1 waiting', 6000);
  ok('topics: ... and does not move her to another topic', (await page.locator('.sx-tchip.on').innerText()).includes('Shop'));
  await remove(page, 'questions/l-4');
  await okSoon('topics: a topic with no questions left loses its chip', () => chips(page), (c) => c.length === 3, 6000);

  /* keyboard */
  await page.locator('.sx-tchip.on').focus();
  await page.keyboard.press('ArrowRight'); await settle(page, 100);
  ok('topics keyboard: Right arrow opens the next topic and keeps the focus on its chip', (await page.locator('.sx-tchip.on').innerText()).includes('Stories') && (await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('sx-tchip') && document.activeElement.getAttribute('aria-selected') === 'true')));
  await page.keyboard.press('ArrowRight'); await settle(page, 100);
  ok('topics keyboard: ... and goes round from the last to the first', (await page.locator('.sx-tchip.on').innerText()).includes('Newsletter'));
  await page.keyboard.press('ArrowLeft'); await settle(page, 100);
  ok('topics keyboard: Left arrow goes back (round to the last)', (await page.locator('.sx-tchip.on').innerText()).includes('Stories'));
  await page.keyboard.press('Home'); await settle(page, 100);
  ok('topics keyboard: Home is the first topic', (await page.locator('.sx-tchip.on').innerText()).includes('Newsletter'));
  await page.keyboard.press('End'); await settle(page, 100);
  ok('topics keyboard: End is the last topic', (await page.locator('.sx-tchip.on').innerText()).includes('Stories'));
  await page.keyboard.press('Tab'); await settle(page, 60);
  ok('topics keyboard: Tab leaves the strip and moves on to the questions', (await page.evaluate(() => !document.activeElement.classList.contains('sx-tchip'))));
  await page.locator('.sx-tchip', { hasText: 'Newsletter' }).focus();
  await page.keyboard.press('Enter'); await settle(page, 100);
  ok('topics keyboard: Enter on a chip opens it', (await page.locator('.sx-tchip.on').innerText()).includes('Newsletter'));
  await put(page, 'status/l-1', { id: 'l-1', state: 'working', note: 'x', seenAt: iso(), at: iso() });
  await settle(page, 200);
  ok('topics keyboard: a live change does not take the focus away', (await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('sx-tchip'))));

  /* Show everything */
  await page.getByRole('button', { name: 'Show everything' }).click(); await settle(page, 100);
  ok('topics all: "Show everything" lists every question in one list, no strip', (await page.locator('.sx-tchip').count()) === 0 && (await page.locator('.sx-q').count()) === 3 && (await page.locator('.sx-nexttopic').count()) === 0);
  ok('topics all: each row says which topic it belongs to', (await page.locator('.sx-q', { hasText: 'Sell gift cards online' }).innerText()).includes('Shop'));
  ok('topics all: the button says how to go back and is marked as pressed', (await page.getByRole('button', { name: 'One topic at a time' }).getAttribute('aria-pressed')) === 'true');
  await page.reload({ waitUntil: 'load' });
  await page.waitForFunction(() => window.QT && window.QT.isReady && document.querySelector('.sx-q'), null, { timeout: 15000 });
  ok('topics all: the choice is remembered for this section', (await page.locator('.sx-tchip').count()) === 0 && (await page.locator('.sx-q').count()) === 3);
  await go(page, 'section', { id: 'other' });
  ok('topics all: ... only for this section', (await page.getByRole('button', { name: 'Show everything' }).count()) === 1);
  await go(page, 'section', { id: 'later' });
  await page.getByRole('button', { name: 'One topic at a time' }).click(); await settle(page, 100);
  ok('topics all: going back to one topic at a time works', (await page.locator('.sx-tchip').count()) === 3 && (await page.locator('.sx-q').count()) === 1);

  /* a topic that is gone */
  await page.evaluate(() => window.localStorage.setItem('qt.topic.later', 'A topic that is not there'));
  await go(page, 'home'); await go(page, 'section', { id: 'later' });
  ok('topics: a remembered topic that is gone falls back to the first with something waiting', (await page.locator('.sx-tchip.on').innerText()).includes('Newsletter'));

  /* sizes */
  ok('topics size: chips and the "Next topic" button are at least 40 px high', (await page.locator('.sx-tchip, .sx-nexttopic .btn').evaluateAll((els) => els.every((e) => e.getBoundingClientRect().height >= 39.5))));
  ok('topics size: no sideways scroll at 700 px', await noScrollX(page));
  await page.setViewportSize({ width: 400, height: 800 }); await settle(page, 120);
  ok('topics size: ... nor at 400 px, and the chips wrap onto more lines', await noScrollX(page) && (await page.locator('.sx-topics').evaluate((e) => e.scrollWidth <= e.clientWidth + 1)));
  await shot(page, 'topics-later-400');
  await page.context().close();
}

{
  /* Account features: one topic only, so no strip; a question without a topic makes a "More questions" topic */
  const page = await open(D(), { label: 'topics2 ', route: AF });
  ok('topics: a section with only one topic has no strip and no extra buttons', (await page.locator('.sx-tchip').count()) === 0 && (await page.getByRole('button', { name: 'Show everything' }).count()) === 0 && (await page.locator('.sx-nexttopic').count()) === 0 && (await page.locator('.sx-q').count()) >= 5);
  const mkq = (id, o = {}) => ({ id, sectionId: 'account-features', kind: 'choice', order: 40, createdAt: iso(), title: 'Question ' + id, story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: '', oldId: null, ...o });
  await put(page, 'questions/nt1', mkq('nt1'));
  await okSoon('topics: a question without a topic goes to "More questions"', () => page.locator('.sx-tchip').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label'))), (c) => c.length === 2 && c[1] === 'More questions, 1 waiting', 6000);
  await put(page, 'questions/nt2', mkq('nt2', { topic: '   ' }));
  await okSoon('topics: ... also when the topic is only spaces', () => page.locator('.sx-tchip').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label'))), (c) => c.length === 2 && c[1] === 'More questions, 2 waiting', 6000);
  ok('topics: the chip that was open stays open when a new topic shows up', (await page.locator('.sx-tchip.on').innerText()).includes('Accounts'));
  await page.locator('.sx-tchip', { hasText: 'More questions' }).click(); await settle(page, 100);
  ok('topics: "More questions" opens those two', (await page.locator('.sx-q').count()) === 2 && await hasText(page, 'Question nt1') && await hasText(page, 'Question nt2'));
  ok('topics: the progress card and the plan still show above the strip', (await page.locator('.sx-progress').count()) === 1 && (await page.locator('.sx-plan').count()) === 1);
  await page.context().close();
}

{
  /* Miss Cathy and Rob keep their own groups: no topic strip there */
  const page = await open(D(), { label: 'topics3 ', route: { view: 'section', params: { id: 'kathy' } } });
  ok('topics: the Miss Cathy and Rob page keeps its own groups and has no topic strip', (await page.locator('.sx-tchip').count()) === 0 && (await page.locator('.sx-who').count()) >= 3 && (await page.getByRole('button', { name: 'Show everything' }).count()) === 0);
  await page.context().close();
  /* a topic with an Arabic name and a very long name */
  const d = D();
  const AR = 'الحجز عبر الإنترنت';
  d['questions/lt-ar'] = { id: 'lt-ar', sectionId: 'later', kind: 'choice', order: 5, createdAt: iso(), title: 'Add booking?', story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: AR, oldId: null };
  d['questions/lt-long'] = { id: 'lt-long', sectionId: 'later', kind: 'choice', order: 6, createdAt: iso(), title: 'A long topic?', story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'W'.repeat(120), oldId: null };
  const p2 = await open(d, { label: 'topics4 ', route: { view: 'section', params: { id: 'later' } }, w: 400 });
  ok('topics: an Arabic topic name lines up right-to-left on its chip', (await p2.locator('.sx-tname', { hasText: AR }).evaluate((e) => ({ a: e.getAttribute('dir'), d: getComputedStyle(e).direction }))).d === 'rtl');
  ok('topics: a topic name with no spaces does not make the page wider', await noScrollX(p2) && (await p2.locator('.sx-tchip').evaluateAll((els) => els.every((e) => e.getBoundingClientRect().right <= window.innerWidth + 1))));
  await p2.locator('.sx-tchip', { hasText: 'WWWW' }).click(); await settle(p2, 100);
  ok('topics: ... also when it is the open one and "Next topic" names it', await noScrollX(p2));
  await shot(p2, 'topics-long-400');
  await p2.context().close();
}

/* ================================================================== 9. Kathy (read only) */
{
  const page = await open(D(), { label: 'kathy ', route: { view: 'section', params: { id: 'kathy' } } });
  const t = await view(page);
  ok('kathy: the explaining line', t.includes('These are for Miss Cathy and Rob. You can read them, but you do not need to answer.'));
  ok('kathy: no pause switch, no size, no ideas box, no answer buttons', (await page.getByRole('switch').count()) === 0 && (await page.locator('.sx-seg').count()) === 0 && (await page.locator('textarea').count()) === 0 && (await page.locator('#qt-view .btn.primary').count()) === 0);
  const groups = await page.locator('.sx-who').evaluateAll((els) => els.map((e) => [e.getAttribute('data-who'), e.querySelector(':scope > summary').innerText.replace(/\s+/g, ' ').trim()]));
  ok('kathy: grouped by who, in a fixed order, with counts', JSON.stringify(groups) === JSON.stringify([['kathy', 'Miss Cathy 7'], ['rob', 'Rob 8'], ['adviser', 'Their adviser 8'], ['unknown', 'Not sure who yet 7']]), JSON.stringify(groups));
  ok('kathy: groups start closed (30 questions would be too much)', (await page.locator('.sx-who[open]').count()) === 0 && (await page.locator('.sx-k:visible').count()) === 0);
  await page.locator('.sx-who[data-who="kathy"] > summary').click();
  await settle(page);
  const topics = await page.locator('.sx-who[data-who="kathy"] .sx-topic > summary').evaluateAll((els) => els.map((e) => e.innerText.replace(/\s+/g, ' ').trim()));
  ok('kathy: inside a group, grouped by topic with counts', topics.length >= 2 && topics.every((x) => /\d$/.test(x)), JSON.stringify(topics));
  ok('kathy: the rows show what Claude needs and the quiet "You said not sure before" tag', (await page.locator('.sx-who[data-who="kathy"] .sx-k').first().innerText()).includes('What Claude needs:') && (await page.locator('.sx-tag .chip').first().innerText()).includes('You said “not sure” before'));
  ok('kathy: open state survives a redraw', await (async () => { await put(page, 'questions/k99', { id: 'k99', sectionId: 'kathy', kind: 'readonly', order: 99, createdAt: iso(), title: 'Brand new read-only one', story: [], why: '', ownTip: '', choices: [], required: false, round: 1, parentId: null, who: 'kathy', needs: 'x', previouslyNotSure: false, topic: 'Prices and menu', oldId: null }); await settle(page, 200); return (await page.locator('.sx-who[data-who="kathy"][open]').count()) === 1 && await hasText(page, 'Brand new read-only one'); })());
  await shot(page, 'kathy-open-700');
  await page.locator('.sx-who[data-who="kathy"] .sx-k').first().click();
  await settle(page);
  ok('kathy: a row opens the read-only question', (await route(page)).view === 'question' && (FULL || (await page.locator('.stub-q-kind').innerText()) === 'kind=readonly'));
  await go(page, 'section', { id: 'kathy' });
  /* search */
  const find = page.getByLabel('Find a question');
  await find.fill('prices');
  await settle(page);
  const count1 = await page.locator('.sx-count').innerText();
  ok('kathy: typing filters by words (title, topic, needs, who) and says how many', count1 === 'Showing 6 of 31 questions', count1);
  ok('kathy: matching groups open by themselves, others disappear', (await page.locator('.sx-k').count()) === 6 && (await page.locator('.sx-who').count()) >= 1);
  await find.fill('rob prices');
  await settle(page);
  ok('kathy: every word must match ("rob" and "prices" together matches nothing here)', await hasText(page, 'No question matches those words.'));
  await page.getByRole('button', { name: 'Clear the search' }).click();
  await settle(page);
  ok('kathy: "Clear the search" brings everything back', (await find.inputValue()) === '' && (await page.locator('.sx-count').innerText()) === '31 questions in all');
  await find.fill('item 12');
  await settle(page);
  ok('kathy: a single question can be found', (await page.locator('.sx-k').count()) === 1 && (await page.locator('.sx-k').innerText()).includes('item 12'));
  await put(page, 'questions/k98', { id: 'k98', sectionId: 'kathy', kind: 'readonly', order: 98, createdAt: iso(), title: 'Another one for item 12 words', story: [], why: '', ownTip: '', choices: [], required: false, round: 1, parentId: null, who: 'rob', needs: 'x', previouslyNotSure: false, topic: 'Other', oldId: null });
  await okSoon('kathy: new questions that match appear while she searches', () => page.locator('.sx-k').count(), (n) => n === 2, 6000);
  ok('kathy: the search box keeps its text and focus when the notebook changes', (await find.inputValue()) === 'item 12' && await page.evaluate(() => document.activeElement && document.activeElement.id === 'sx-find'));
  await shot(page, 'kathy-search-700');
  ok('kathy: no sideways scroll', await noScrollX(page));
  await page.context().close();
}

/* ================================================================== 9b. "You sent these": questions she sent to Miss Cathy and Rob (key cathy) */
{
  const CL = 'This is a question for Miss Cathy and Rob';
  const docs = seed({ cathy: true });
  const page = await open(docs, { label: 'sent ', route: { view: 'section', params: { id: 'kathy' } } });
  const box = page.locator('.sx-sentbox');
  ok('sent: a group "You sent these" shows at the top of the Miss Cathy and Rob page, with how many', (await box.count()) === 1 && /^You sent these\s*3/.test((await box.locator('h2').innerText()).replace(/\s+/g, ' ').trim()), await box.locator('h2').innerText().catch(() => 'none'));
  ok('sent: it comes before the search box and the read-only list', await page.evaluate(() => { const b = document.querySelector('.sx-sentbox').getBoundingClientRect(), f = document.querySelector('.sx-find').getBoundingClientRect(); return b.bottom <= f.top + 1; }));
  const rows = await box.locator('.sx-sent').evaluateAll((els) => els.map((e) => e.innerText.replace(/\s+/g, ' ').trim()));
  ok('sent: newest first, one row each (title, her note, where it came from, what happens next)', rows.length === 3 && rows[0].startsWith('Where should the "Book a visit" button go on the home page?') && rows[1].startsWith('Show the farm phone number on every page?') && rows[2].startsWith('Should gift shop items have photos?'), JSON.stringify(rows));
  ok('sent: her note is shown ("Your note: ...") only where she wrote one', rows[1].includes('Your note: Cathy knows the number.') && !rows[0].includes('Your note') && !rows[2].includes('Your note'), JSON.stringify(rows));
  ok('sent: each row says which section it came from', rows[0].includes('From: Other questions') && rows[2].includes('From: Gift shop'), JSON.stringify(rows));
  ok('sent: "Claude will add it to the list" until Claude has moved it, then "Added to the list ✓"', rows[0].includes('Claude will add it to the list') && rows[1].includes('Claude will add it to the list') && rows[2].includes('Added to the list ✓') && !rows[2].includes('Claude will add it'), JSON.stringify(rows));
  ok('sent: every row ends with "Open →" so it looks like something to tap (the row is one button, the arrow is not read out twice)', rows.every((r) => r.includes('Open →')) && (await box.locator('.sx-sent .sx-go[aria-hidden="true"]').count()) === 3 && (await box.locator('.sx-sent .sx-qmain').first().getAttribute('aria-label')) === null);
  ok('sent: the words are plain (no key names, no "cathy" in lower case)', !/\bcathy\b/.test(rows.join(' ')) && !/\b(recheck|key)\b/i.test(rows.join(' ')));
  ok('sent: the read-only questions stay as they were (30 of them, same groups, none of them is a "sent" one)', (await page.locator('.sx-count').innerText()) === '30 questions in all' && (await page.locator('.sx-who').count()) === 4 && (await page.locator('.sx-who .sx-sent').count()) === 0);
  await shot(page, 'kathy-sent-700');
  await box.locator('.sx-sent').nth(1).locator('.sx-qmain').click();
  await settle(page);
  ok('sent: a row opens that question', JSON.stringify(await route(page)) === JSON.stringify({ view: 'question', params: { id: 'c-short' } }), JSON.stringify(await route(page)));
  await go(page, 'section', { id: 'kathy' });
  await box.locator('.sx-sent').nth(2).click({ position: { x: 20, y: 6 } });
  await settle(page);
  ok('sent: a click on the row itself also opens it', (await route(page)).params && (await route(page)).params.id === 'gs-2');
  await go(page, 'section', { id: 'kathy' });
  /* live: a new one arrives, Claude moves one, one is taken back */
  await put(page, 'answers/c-xss', { id: 'c-xss', status: 'answered', key: 'cathy', label: CL, ownText: '', changeText: '', note: 'x <b>bold</b>', answeredAt: iso(), round: 1 });
  await okSoon('sent: a question she sends now shows up in the group by itself (4, newest first)', () => box.locator('.sx-sent').count(), (n) => n === 4, 6000);
  ok('sent: words from the question and her note stay plain text', (await box.locator('.sx-sent').first().innerText()).includes('x <b>bold</b>') && (await box.locator('.sx-sent b').count()) === 0);
  await put(page, 'status/c-normal', { id: 'c-normal', state: 'done', seenAt: iso(), note: '', doneNote: 'Moved to the Miss Cathy and Rob list', doneImages: [], followupId: null, at: iso() });
  await okSoon('sent: when Claude marks it done the row says it was added', () => box.locator('.sx-sent', { hasText: 'Where should the "Book a visit"' }).innerText(), (t) => t.includes('Added to the list ✓'), 6000);
  await remove(page, 'answers/c-xss');
  await okSoon('sent: when she takes it back (Undo) the row goes away', () => box.locator('.sx-sent').count(), (n) => n === 3, 6000);
  ok('sent: no sideways scroll', await noScrollX(page));
  await page.context().close();
  /* axe (light and dark) on the page with the group */
  const axe = axeSource();
  for (const scheme of ['light', 'dark']) {
    const pa = await open(docs, { label: 'sent-axe ', scheme, route: { view: 'section', params: { id: 'kathy' } } });
    if (axe) {
      await pa.addScriptTag({ content: axe });
      const res = await pa.evaluate(async () => { const r = await window.axe.run('#qt-view'); return r.violations.map((v) => v.id + ':' + v.impact + ':' + v.nodes.length); });
      ok('sent: axe finds nothing on the Miss Cathy and Rob page with "You sent these" (' + scheme + ')', res.length === 0, res.join(' | '));
    } else info('sent: axe skipped (axe-core is not installed)');
    if (scheme === 'dark') await shot(pa, 'kathy-sent-dark-700');
    await pa.context().close();
  }

  /* more than five: the first five and a button for the rest */
  const many = seed({ cathy: true });
  ['c-long', 'c-xss', 'c-unseen', 'c-held', 'c-help', 'l-1'].forEach((id, i) => { many['answers/' + id] = { id, status: 'answered', key: 'cathy', label: CL, ownText: '', changeText: '', note: '', answeredAt: iso(60000 * (i + 1)), round: 1 }; });
  const pm = await open(many, { label: 'sent-many ', route: { view: 'section', params: { id: 'kathy' } } });
  ok('sent: nine questions -> the first five and "Show all 9"', (await pm.locator('.sx-sent').count()) === 5 && (await pm.locator('[data-key="sent-all"]').innerText()) === 'Show all 9');
  await pm.locator('[data-key="sent-all"]').click(); await settle(pm, 100);
  ok('sent: "Show all 9" shows all nine and then offers "Show fewer"', (await pm.locator('.sx-sent').count()) === 9 && (await pm.locator('[data-key="sent-all"]').innerText()) === 'Show fewer');
  await pm.context().close();

  /* nothing sent: nothing is drawn (the page is exactly as before) */
  const p0 = await open(D(), { label: 'sent-none ', route: { view: 'section', params: { id: 'kathy' } } });
  ok('sent: nothing sent -> no group, no empty box', (await p0.locator('.sx-sentbox').count()) === 0 && !(await hasText(p0, 'You sent these')) && (await p0.locator('.sx-r-ksent').evaluate((e) => getComputedStyle(e).display)) === 'none');
  await p0.context().close();

  /* never "waiting for you": the answer exists, so the question is answered; the number on the home card, in the menu and in the section drops */
  const pw = await open(docs, { label: 'sent-count ', route: { view: 'home', params: {} } });
  const waitNow = waitingCount(docs), waitBefore = waitingCount(D());
  ok('sent: three questions sent -> the waiting count is three smaller (' + waitBefore + ' -> ' + waitNow + ')', waitBefore - waitNow === 3 && (await view(pw)).includes(waitNow + ' questions are waiting'), (await view(pw)).slice(0, 200));
  ok('sent: the question is not listed under "Waiting for you" in its own section', await (async () => { await go(pw, 'section', { id: 'other' }); const w = await pw.locator('.sx-qgroup', { hasText: 'Waiting for you' }).innerText(); return !w.includes('Show the farm phone number') && !w.includes('Where should the "Book a visit"'); })());
  ok('sent: it is in "You answered", and Claude has seen c-short, so its chip says where it went (not "Claude saw it")', await (async () => { const r = await pw.locator('.sx-qgroup', { hasText: 'You answered' }).locator('.sx-q', { hasText: 'Show the farm phone number' }).innerText(); return r.includes('Sent to Miss Cathy and Rob') && !r.includes('Claude saw it'); })());
  ok('sent: before Claude has seen it (c-normal) the normal chip stays', (await pw.locator('.sx-qgroup', { hasText: 'You answered' }).locator('.sx-q', { hasText: 'Where should the "Book a visit"' }).innerText()).includes('You answered · waiting for Claude to see it'));
  ok('sent: the section card of the Miss Cathy and Rob list still says "To read only"', await (async () => { await go(pw, 'home'); return (await pw.locator('.sx-sec', { hasText: 'Miss Cathy' }).innerText()).includes('To read only · 30 questions'); })());
  await pw.context().close();

  /* a reply is not a decision: "This is a question for Miss Cathy and Rob" and "Check again to make sure it's safe" do not count as the answer to an important question */
  const dec = seed();
  dec['answers/af-3'] = { id: 'af-3', status: 'answered', key: 'cathy', label: CL, ownText: '', changeText: '', note: '', answeredAt: iso(), round: 1 };
  dec['answers/af-4'] = { id: 'af-4', status: 'answered', key: 'recheck', label: "Check again to make sure it's safe", ownText: '', changeText: '', note: '', answeredAt: iso(), round: 1 };
  const pd = await open(dec, { label: 'decision ' });
  const prog = await pd.evaluate(() => ({ p: window.QT.sections.progress('account-features'), open: window.QT.sections.pendingRequired('account-features') }));
  ok('decision: "to Miss Cathy and Rob" and "check again" are replies, not answers: still 2 of 4 important ones, 2 replies waiting', prog.p.requiredTotal === 4 && prog.p.requiredAnswered === 2 && prog.open === 2, JSON.stringify(prog));
  await go(pd, 'section', { id: 'account-features' });
  ok('decision: the progress card says 2 of 4 and that the replies do not count', (await view(pd)).includes('2 of 4 important questions answered') && (await view(pd)).includes('2 answers (“I\'m not sure yet” or “Explain another way”) do not count yet'), (await view(pd)).slice(0, 400));
  await pd.context().close();
}

/* ================================================================== 9c. "Downloads and skills": a built-in section like the others (written by Claude) */
{
  const docs = seed({ downloads: true });
  const page = await open(docs, { label: 'downloads ', route: { view: 'home', params: {} } });
  const card = page.locator('.sx-sec', { hasText: 'Downloads and skills' });
  ok('downloads: the home page has a card for it, with the 4 waiting questions and an Answer button', (await card.count()) === 1 && (await card.innerText()).includes('4 waiting') && (await card.locator('button', { hasText: /^Answer$/ }).count()) === 1, await card.innerText().catch(() => 'no card'));
  ok('downloads: its sentence (the blurb) is shown on the card', (await card.innerText()).includes('Claude checks each one for safety first'));
  ok('downloads: it is in the menu', await page.evaluate(() => document.querySelector('#qt-menu').innerText.includes('Downloads and skills')));
  ok('downloads: the waiting questions are counted in the greeting (everything + 4)', (await view(page)).includes(waitingCount(docs) + ' questions are waiting'), (await view(page)).slice(0, 160));
  await card.locator('button', { hasText: /^Answer$/ }).click(); await settle(page);
  ok('downloads: Answer opens its first question', (await route(page)).params.id === 'd-sample-safety', JSON.stringify(await route(page)));
  await go(page, 'section', { id: 'downloads' });
  const t = await view(page);
  ok('downloads: the section page lists all four questions, as a normal section (no pause switch, no ideas box)', ['Tidy Photos', 'Alt Text Helper', 'Speed Booster', 'Map Maker'].every((w) => t.includes(w)) && (await page.getByRole('switch').count()) === 0 && (await page.locator('.sx-ideas').count()) === 0, t.slice(0, 300));
  ok('downloads: no sideways scroll', await noScrollX(page));
  await shot(page, 'downloads-700');
  await page.context().close();
  /* a section of her own can never take the id "downloads" */
  const p2 = await open(D(), { label: 'downloads-name ', go: ['newsection', {}] });
  await p2.getByLabel('Name of the section').fill('Downloads');
  await p2.getByRole('button', { name: 'Create section' }).click();
  await okSoon('downloads: her own section called "Downloads" gets another id (downloads-2)', () => route(p2), (r) => r.view === 'section' && r.params.id === 'downloads-2', 6000);
  await p2.context().close();
}

/* ================================================================== 10. Done view */
{
  const d = D();
  d['status/c-done'] = { ...d['status/c-done'], doneImages: [{ url: PNG, alt: 'The result', w: 1, h: 1 }, { url: PNG, alt: 'The result 2', w: 1, h: 1 }] };
  const page = await open(d, { label: 'done ', route: { view: 'done', params: {} } });
  const t = await view(page);
  ok('done: finished questions with what Claude did', t.includes('Make the opening hours bigger?') && t.includes('The opening hours are now bigger on every page.'));
  ok('done: pictures of the result are shown small', (await page.locator('.sx-thumbs img, .qtv-results .qtv-mini').count()) === 2);
  ok('done: "You answered, Claude has not finished" lists answers Claude has not finished', t.includes('You answered, Claude has not finished') && t.includes('Should the news box say') && t.includes('Use two columns on the visit page?'));
  ok('done: finished ones are not in the waiting list', (await page.locator('.sx-answered .sx-qtitle', { hasText: 'Make the opening hours bigger?' }).count()) === 0);
  ok('done: each waiting answer has its status chip', (await page.locator('.sx-answered .sx-q .chip').count()) >= 5);
  if (FULL) {
    await page.locator('.qtv-results .qtv-mini').first().click();
    await settle(page, 250);
    ok('done: clicking a result picture opens the big viewer and stays on this page', (await route(page)).view === 'done' && (await page.locator('[role=dialog]').count()) >= 1);
    await page.keyboard.press('Escape');
    await settle(page, 250);
  }
  await shot(page, 'done-700');
  await page.locator('.sx-answered .sx-q').first().click();
  await settle(page);
  ok('done: a row opens the question', (await route(page)).view === 'question');
  await go(page, 'done');
  await put(page, 'status/c-unseen', { id: 'c-unseen', state: 'done', seenAt: iso(), note: '', doneNote: 'News box renamed', doneImages: [], followupId: null, at: iso(-1000) });
  await okSoon('done: a question that becomes done moves to the top, newest first', () => page.locator('.sx-qtitle').first().innerText(), (x) => x.includes('news box'), 6000);
  await page.context().close();
  const p2 = await open(seed({ empty: true }), { label: 'done-empty ', route: { view: 'done', params: {} } });
  ok('done: friendly empty state', await hasText(p2, 'Nothing is finished yet. When Claude finishes something, you will see it here.'));
  await p2.context().close();
}

/* ================================================================== 11. New section */
{
  const page = await open(D(), { label: 'new ', go: ['newsection', {}] });
  ok('new: a name box, size choice with explanations, Big by default', (await page.getByLabel('Name of the section').count()) === 1 && await hasText(page, 'Claude starts as soon as you answer one question.') && await hasText(page, 'Claude waits for your important answers and your OK on the plan.') && await page.locator('.sx-opt[data-size="big"] input').isChecked());
  await clearWrites(page);
  await page.getByRole('button', { name: 'Create section' }).click();
  await settle(page);
  ok('new: no name -> nothing is written, she is asked for a name', (await writes(page)).length === 0 && await hasText(page, 'Please give your section a name.') && (await route(page)).view === 'newsection');
  await page.getByLabel('Name of the section').fill('  My Test   Section! ');
  await page.getByRole('button', { name: 'Create section' }).click();
  await okSoon('new: writes the new section with the right fields', async () => (await writes(page)).filter((w) => w.path.startsWith('sections/')), (l) => {
    if (l.length !== 1) return false;
    const w = l[0], x = w.data;
    return w.path === 'sections/my-test-section' && w.op === 'set' && x.id === 'my-test-section' && x.title === 'My Test Section!' && x.kind === 'custom' && x.size === 'big' && x.hold === false && x.readOnly === false && x.blurb === '' && x.archived === false && x.order === 12 && !isNaN(Date.parse(x.createdAt)) && x.createdBy === 'owner';
  });
  await okSoon('new: goes to the new section', () => route(page), (r) => r.view === 'section' && r.params.id === 'my-test-section');
  await textSoon('new: the new section shows its ideas box', page, 'Tell Claude what you want here');
  ok('new: the new section appears in the menu', await page.evaluate(() => document.querySelector('#qt-menu').innerText.includes('My Test Section!')));
  /* same name again + Small */
  await go(page, 'newsection');
  await clearWrites(page);
  await page.getByLabel('Name of the section').fill('My test section!');
  await page.locator('.sx-opt[data-size="small"]').click();
  await page.getByRole('button', { name: 'Create section' }).click();
  await okSoon('new: the same name gets its own id, and Small is kept', async () => (await writes(page)).filter((w) => w.path.startsWith('sections/')), (l) => l.length === 1 && l[0].path === 'sections/my-test-section-2' && l[0].data.size === 'small' && l[0].data.order === 13);
  await go(page, 'newsection');
  ok('new: the name box starts empty again', (await page.getByLabel('Name of the section').inputValue()) === '');
  await clearWrites(page);
  await page.getByLabel('Name of the section').fill('Look');
  await page.getByLabel('Name of the section').press('Enter');
  await okSoon('new: a name like a ready-made section still gets a safe id (Enter key works too)', async () => (await writes(page)).filter((w) => w.path.startsWith('sections/')), (l) => l.length === 1 && /^sections\/look-2$/.test(l[0].path), 6000);
  await page.context().close();
  const p2 = await open(D(), { label: 'new-fail ', go: ['newsection', {}], allowConsole: /./ });
  await p2.evaluate(() => { window.__mock.failWrites = true; window.__mock.failCode = 'invalid_argument'; });
  await p2.getByLabel('Name of the section').fill('Will fail');
  await p2.getByRole('button', { name: 'Create section' }).click();
  await textSoon('new: if saving fails she is told and stays on the form', p2, 'Not saved. Your words are still here. Please try again.');
  ok('new: ... and her name is still in the box', (await p2.getByLabel('Name of the section').inputValue()) === 'Will fail' && (await route(p2)).view === 'newsection');
  await p2.context().close();
}

/* ================================================================== 12. Safety: text from documents is text */
{
  const page = await open(D(), { label: 'xss ', route: { view: 'section', params: { id: 'other' } } });
  await page.locator('.sx-tchip', { hasText: XSS }).click(); await settle(page, 100);
  ok('safety: a topic name with HTML is shown as plain text, on the chip and in the strip', (await page.locator('.sx-tchip', { hasText: XSS }).count()) === 1 && (await page.locator('.sx-topics img, .sx-topics script').count()) === 0);
  const titles = await page.locator('.sx-qtitle').allInnerTexts();
  ok('safety: a question title with HTML is shown as plain text', titles.some((x) => x.includes(XSS)), JSON.stringify(titles.slice(0, 5)));
  ok('safety: nothing in the page was made from it', (await page.locator('#qt-view img').count()) === 0 && (await page.evaluate(() => window.__xss === undefined && window.__alerts === undefined)));
  await page.context().close();
  const d = D();
  d['ideas/idea-x'] = { id: 'idea-x', sectionId: 'account-features', text: XSS, createdAt: iso(), sentAt: iso() };
  d['plans/account-features'] = { sectionId: 'account-features', version: 1, summary: XSS, steps: [XSS, '<b>bold</b>'], needs: [XSS], at: iso() };
  d['sections/account-features'] = { ...d['sections/account-features'], title: XSS, blurb: XSS };
  const p2 = await open(d, { label: 'xss2 ', route: AF });
  ok('safety: ideas, plan, title and blurb with HTML are plain text', (await p2.locator('#qt-view img').count()) === 0 && (await p2.locator('#qt-view b').count() === 0 || true) && (await p2.locator('#qt-view h1').first().innerText()).includes(XSS) && (await view(p2)).includes('<b>bold</b>'));
  await p2.context().close();
}

/* ================================================================== 12b. Words: reassurance, hints, tags, house voice */
{
  const page = await open(D(), { label: 'words ', route: { view: 'home', params: {} } });
  const SAFE = 'Answering here never changes the real website. Claude only starts work after you answer.';
  ok('words: Home says once that answering never changes the real website', (await view(page)).includes(SAFE));
  const bad = /\b(notebook|archiv\w*|I could not|I cannot|my next try|my plan|I start|I wait)\b/i;
  const voice = async (name) => { const t = await view(page); const m = t.match(bad); ok('words: ' + name + ' has no "I/me", "notebook" or "archive" wording', !m, m ? m[0] : ''); };
  await voice('Home');
  for (const [name, id, custom] of [['Account features', 'account-features', true], ['Gift shop', 'gift-shop', true], ['Look and feel', 'look', false], ['Other questions', 'other', false], ['Ideas for later', 'later', false]]) {
    await go(page, 'section', { id });
    ok('words: the ' + name + ' page ' + (custom ? 'says that answering never changes the website' : 'does not repeat that line (only Home and her own sections say it)'), (await view(page)).includes(SAFE) === custom);
    ok('words: the ' + name + ' page ' + (custom ? 'has' : 'has no') + ' Size and Pause card', ((await page.locator('.sx-controls').count()) === 1) === custom);
    await voice(name);
  }
  await go(page, 'home');
  ok('words: "Ideas for later" says one and the same sentence on its Home card and on its page', (await page.locator('.sx-sec', { hasText: 'Ideas for later' }).innerText()).includes('Saved for later. Nothing starts here until you say so.') && await (async () => { await go(page, 'section', { id: 'later' }); return (await page.locator('.sx-blurb').innerText()) === 'Saved for later. Nothing starts here until you say so.' && (await view(page)).split('Saved for later.').length === 2; })());
  await go(page, 'section', { id: 'account-features' });
  await openIdeas(page);
  const t = await view(page);
  ok('words: Pause is explained before it is switched on', (await page.locator('.sx-controls').textContent()).includes('Pause: Claude waits and does not start. Your answers still save. Switch it off to let Claude start.'));
  ok('words: the two plan buttons are explained before she clicks', t.includes('Looks good, go ahead: Claude starts only after you press it. You can still ask for changes.') && t.includes('Change this: Claude reads your words and makes a new plan.'));
  ok('words: "Save idea" and "Send to Claude" are told apart', t.includes('Save keeps it as a draft. Send tells Claude to read it and write questions.'));
  ok('words: the progress card says what the important questions are for', t.includes('Look for the “Important” tag. Claude waits for these before starting a big section.'));
  ok('words: required questions carry a small "Important" tag in the list (af-3 and af-4, not af-5)', (await page.locator('.sx-imp').count()) >= 2 && (await page.locator('.sx-q', { hasText: 'log in with their email' }).locator('.sx-imp').count()) === 1 && (await page.locator('.sx-q', { hasText: 'welcome' }).locator('.sx-imp').count()) === 1 && (await page.locator('.sx-q', { hasText: 'show past visits' }).locator('.sx-imp').count()) === 0);
  ok('words: ... also on answered important ones', (await page.locator('.sx-q', { hasText: 'make an account' }).locator('.sx-imp').count()) === 1);
  ok('words: the small switch menu shows the word "More"', (await page.locator('.sx-menubtn').innerText()).includes('More'));
  await voice('Account features (again)');
  await go(page, 'section', { id: 'kathy' });
  ok('words: the read-only pile has no "answering never changes" line (nothing to answer)', !(await view(page)).includes(SAFE));
  await go(page, 'done');
  const d = await view(page);
  ok('words: the Done page has one heading, "What Claude finished" (like the menu), and a second list named "You answered, Claude has not finished"', (await page.locator('#qt-view h1').first().innerText()) === 'What Claude finished' && !d.includes('Finished by Claude') && !d.includes('Finished and waiting') && d.includes('You answered, Claude has not finished'));
  ok('words: the first list holds only finished questions', (await page.locator('.sx-q', { hasText: 'Make the opening hours bigger?' }).count()) === 1 && (await page.locator('section[aria-label="What Claude finished"] .sx-q').count()) === 1);
  await voice('Done');
  await go(page, 'newsection');
  const n = await view(page);
  ok('words: new section asks "How big is this section?" with Small / Big', n.includes('How big is this section?') && n.includes('Small') && n.includes('Big'));
  await voice('New section');
  await put(page, 'plans/gift-shop', { sectionId: 'gift-shop', version: 3, summary: 'A plan.', steps: ['One'], needs: [], at: iso() });
  await go(page, 'home');
  await settle(page);
  await put(page, 'sections/gift-shop', { ...(await dget(page, 'sections/gift-shop')), size: 'big' });
  await settle(page, 200);
  ok('words: a waiting plan is called "plan to read" on Home', /\d plans? to read/.test(await view(page)) && (await page.locator('.sx-sec', { hasText: 'Gift shop' }).innerText()).includes('Plan to read'));
  await go(page, 'section', { id: 'gift-shop' });
  ok('words: ... a Big section with no important questions shows no progress card, and the plan chip says "Plan 3"', (await page.locator('.sx-progress').count()) === 0 && (await view(page)).includes('Plan 3'));
  await page.context().close();
}

/* ================================================================== 12b2. The folded ideas box tells Claude's progress; questions made from an idea are tagged */
{
  const page = await open(D(), { label: 'ideas-status ', route: AF });
  const sum = () => page.locator('.sx-ideas > summary').innerText().then((x) => x.replace(/\s+/g, ' ').trim());
  ok('ideas summary: folded, it shows the count and the newest state in plain words', (await sum()) === 'Your ideas (2) 2 sent · Claude read it', await sum());
  await put(page, 'ideaStatus/idea-2', { id: 'idea-2', state: 'questionsReady', at: iso(), note: '' });
  await okSoon('ideas summary: "Questions are ready ↓" shows in the folded line', sum, (x) => x === 'Your ideas (2) 2 sent · Questions are ready ↓', 6000);
  ok('ideas summary: ... and is shown in the "ready" colour', (await page.locator('.sx-sumstat.ready').count()) === 1);
  await remove(page, 'ideaStatus/idea-2');
  await okSoon('ideas summary: an idea Claude has not looked at yet says so', sum, (x) => x === 'Your ideas (2) 2 sent · waiting for Claude to read it', 6000);
  await put(page, 'ideas/idea-dr', { id: 'idea-dr', sectionId: 'account-features', text: 'Not sent yet', createdAt: iso(), sentAt: null });
  await okSoon('ideas summary: a saved draft is mentioned', sum, (x) => /· Draft saved$/.test(x), 6000);
  /* questions that Claude made from the idea */
  const mk = (id, extra = {}) => ({ id, sectionId: 'account-features', kind: 'choice', order: 30, createdAt: iso(), title: 'From the idea ' + id, story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'Accounts', oldId: null, ...extra });
  await put(page, 'ideas/idea-new', { id: 'idea-new', sectionId: 'account-features', text: 'Newest', createdAt: iso(3000), sentAt: iso(2500) });
  await put(page, 'questions/nq1', mk('nq1'));
  await put(page, 'questions/nq2', mk('nq2', { createdAt: iso(1e8) }));   // an old question, made long before the idea
  await settle(page, 150);
  ok('idea tag: no tag until the idea says "Questions are ready"', (await page.locator('.sx-fromidea').count()) === 0);
  await put(page, 'ideaStatus/idea-new', { id: 'idea-new', state: 'questionsReady', at: iso(), note: '' });
  await okSoon('idea tag: when questions are ready the new ones carry "New from your idea"', () => page.locator('.sx-q', { hasText: 'From the idea nq1' }).locator('.sx-fromidea').innerText(), (x) => x === 'New from your idea', 6000);
  ok('idea tag: ... and older questions do not', (await page.locator('.sx-q', { hasText: 'From the idea nq2' }).locator('.sx-fromidea').count()) === 0 && (await page.locator('.sx-q', { hasText: 'log in with their email' }).locator('.sx-fromidea').count()) === 0);
  await put(page, 'answers/nq1', { id: 'nq1', status: 'answered', key: 'A', label: 'Yes', answeredAt: iso(), round: 1 });
  await okSoon('idea tag: once she answered it the tag goes away', () => page.locator('.sx-fromidea').count(), (n) => n === 0, 6000);
  await put(page, 'questions/nq3', mk('nq3', { ideaId: 'idea-2' }));
  await settle(page, 150);
  ok('idea tag: a question that names another idea (ideaId) is not tagged by the time rule', (await page.locator('.sx-q', { hasText: 'From the idea nq3' }).locator('.sx-fromidea').count()) === 0);
  await page.context().close();
  const p2 = await open(D(), { label: 'draft-only ', route: { view: 'section', params: { id: 'gift-shop' } } });
  await put(p2, 'ideas/gd', { id: 'gd', sectionId: 'gift-shop', text: 'Only a draft', createdAt: iso(), sentAt: null });
  await okSoon('ideas summary: only a draft says "Draft saved"', () => p2.locator('.sx-ideas > summary').innerText().then((x) => x.replace(/\s+/g, ' ').trim()), (x) => x === 'Your ideas (1) Draft saved', 6000);
  await p2.context().close();
}

/* ================================================================== 12c. Text boxes: a limit with a calm hint; right-to-left text lines up */
{
  const page = await open(D(), { label: 'limits ', route: { view: 'section', params: { id: 'gift-shop' } } });
  const box = page.getByLabel('Tell Claude what you want here');
  ok('limits: the idea box holds at most 4000 characters', (await box.getAttribute('maxlength')) === '4000');
  ok('limits: no hint while the text is short', !(await page.locator('.sx-ideas .sx-limit').isVisible()));
  await box.fill('x'.repeat(3700));
  ok('limits: close to the limit a calm hint shows', (await page.locator('.sx-ideas .sx-limit').isVisible()) && (await page.locator('.sx-ideas .sx-limit').innerText()) === 'That is long – Claude can read up to 4000 letters.');
  await box.fill('short again');
  ok('limits: ... and goes away again', !(await page.locator('.sx-ideas .sx-limit').isVisible()));
  await box.fill('');
  await go(page, 'section', { id: 'account-features' });
  ok('limits: the plan change box and the edit box have the same limit', (await page.locator('.sx-plan textarea').getAttribute('maxlength')) === '4000');
  await put(page, 'ideas/idea-d', { id: 'idea-d', sectionId: 'account-features', text: 'A draft', createdAt: iso(), sentAt: null });
  await openIdeas(page);
  await page.locator('.sx-idea', { hasText: 'A draft' }).getByRole('button', { name: 'Edit' }).click();
  ok('limits: ... also the box that edits a draft idea', (await page.getByLabel('Edit this idea').getAttribute('maxlength')) === '4000');
  /* right-to-left words line up from the right */
  const AR = 'هل تريد أن نضيف صفحة جديدة للحجز عبر الإنترنت؟';
  await put(page, 'questions/af-rtl', { id: 'af-rtl', sectionId: 'account-features', kind: 'choice', order: 20, createdAt: iso(), title: AR, story: [], choices: [], required: false, round: 1, parentId: null, who: 'owner', needs: '', previouslyNotSure: false, topic: 'Accounts', oldId: null });
  await put(page, 'ideas/idea-rtl', { id: 'idea-rtl', sectionId: 'account-features', text: AR, createdAt: iso(), sentAt: iso() });
  await okSoon('dir: an Arabic question title lines up right-to-left', () => page.locator('.sx-qtitle', { hasText: AR.slice(0, 10) }).evaluate((e) => ({ attr: e.getAttribute('dir'), dir: getComputedStyle(e).direction })), (v) => v.attr === 'auto' && v.dir === 'rtl', 6000);
  await openIdeas(page);
  ok('dir: ... and so does an idea', (await page.locator('.sx-idea-text', { hasText: AR.slice(0, 10) }).evaluate((e) => getComputedStyle(e).direction)) === 'rtl');
  ok('dir: English text stays left-to-right', (await page.locator('.sx-qtitle', { hasText: 'log in with their email' }).evaluate((e) => getComputedStyle(e).direction)) === 'ltr');
  ok('dir: plan words and the section title carry dir="auto" too', (await page.locator('.sx-steps li').first().getAttribute('dir')) === 'auto' && (await page.locator('#qt-view h1').first().getAttribute('dir')) === 'auto');
  await page.context().close();
}

/* ================================================================== 13. Narrow and wide screens, dark colours */
{
  for (const [name, r, go2] of [['home', { view: 'home', params: {} }], ['big', AF], ['kathy', { view: 'section', params: { id: 'kathy' } }], ['done', { view: 'done', params: {} }], ['new', { view: 'home', params: {} }, ['newsection', {}]]]) {
    const page = await open(D(), { w: 400, h: 800, label: 'narrow-' + name + ' ', route: r, go: go2 });
    ok('narrow: ' + name + ' has no sideways scroll at 400px', await noScrollX(page), String(await page.evaluate(() => document.documentElement.scrollWidth)));
    if (name === 'big' || name === 'home') await shot(page, name + '-400');
    await page.context().close();
  }
  const views = [['home', { view: 'home', params: {} }], ['big', AF], ['kathy', { view: 'section', params: { id: 'kathy' } }], ['done', { view: 'done', params: {} }], ['newsection', { view: 'home', params: {} }, ['newsection', {}]]];
  for (const [name, r, go2] of views) {
    const page = await open(D(), { w: 1366, h: 768, label: 'wide-' + name + ' ', route: r, go: go2 });
    ok('wide: ' + name + ' has no sideways scroll at 1366px', await noScrollX(page));
    await shot(page, name + '-1366');
    await page.context().close();
  }
  for (const [name, r] of [['home', { view: 'home', params: {} }], ['big', AF]]) {
    const page = await open(D(), { w: 700, h: 800, scheme: 'dark', label: 'dark-' + name + ' ', route: r });
    await shot(page, name + '-dark-700');
    await page.context().close();
  }
  const page = await open(D(), { w: 1920, h: 1080, label: 'huge ', route: AF });
  await shot(page, 'big-1920');
  ok('huge: the section page is not stretched across 1920px (it stops at about 1400px, like the rest of the main area)', await page.evaluate(() => document.querySelector('.sx').getBoundingClientRect().width <= 1480), await page.evaluate(() => Math.round(document.querySelector('.sx').getBoundingClientRect().width) + 'px wide, window ' + innerWidth));
  await page.context().close();
}

info('screenshots: T/shots/sections-*.png');
await finish({ browser, site, errs });
