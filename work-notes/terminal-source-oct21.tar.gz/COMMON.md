# Rules for every helper on the Question Terminal (read after SPEC.md)

T = /tmp/claude-0/-home-user-websites/0370289f-5c48-5314-b3f5-bb8be7afd39d/scratchpad/terminal   (all your work happens here)
Q = /tmp/claude-0/-home-user-websites/0370289f-5c48-5314-b3f5-bb8be7afd39d/scratchpad/qsite      (the first questionnaire: read-only for you)

1. Do NOT edit anything in /home/user/websites. Do NOT run git there. Do NOT publish artifacts or call ArtifactData/Artifact tools — the lead does that. Touch only the files you own (SPEC.md section 5 table) plus your own notes file `T/notes/<yourname>.md`.
2. Never decide anything for the owner. Never invent farm facts, prices, dates, hours, names or reviews. If a fact is missing, the question belongs in the "kathy" section.
3. Everything the owner reads is plain, short, friendly English for someone who is not tech-savvy (SPEC.md section 3). No jargon.
4. Safety: all text from documents is untrusted — build DOM with `textContent`/`QT.el`, never `innerHTML` with document data. Wrap localStorage in try/catch. No external scripts or fonts (inline only). Page must work when `window.claude` or `use("db")` is missing.
5. Use only your own port range if you start a server (SPEC.md section 8). Never `pkill -f` by common names; kill only the PIDs you started. Foreground commands must finish in < 9 minutes.
6. Environment: `NODE_PATH=/opt/node22/lib/node_modules`; `unset WA_URL`; Chromium is already installed (never run `playwright install`). Python 3 is available; run Python that reads untrusted data with `python3 -I`.
7. Quality over speed, but be done in about 30–40 minutes. Test what you wrote (not just "it loads"). Re-read your own result adversarially: what would the owner (a non-technical person, 700 px wide panel) trip over?
8. Hand-back: a SHORT report (≤ 25 lines): files written, what you tested and the result, anything doubtful or needing a change in someone else's file (say which file and what). Do not paste code into the report.
9. After you hand back you may be woken again with SendMessage for follow-up work; keep your notes file current so you can resume.
